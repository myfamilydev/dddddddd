﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPortal.Helper
{
    public class KhmerDate
    {
        public DateTime Date { set; get; }

        private Dictionary<char, string> numberList = new Dictionary<char, string>(){
            {'0', "០"},
            {'1', "១"},
            {'2', "២"},
            {'3', "៣"},
            {'4', "៤"},
            {'5', "៥"},
            {'6', "៦"},
            {'7', "៧"},
            {'8', "៨"},
            {'9', "៩"}
        };
        public string toKhmerMonth()
        {
            var months = new Dictionary<string, string>(){
                {"01", "មករា"},
                {"02", "កុម្ភៈ"},
                {"03", "មីនា"},
                {"04", "មេសា"},
                {"05", "ឧសភា"},
                {"06", "មិថុនា"},
                {"07", "កក្កដា"},
                {"08", "សីហា"},
                {"09", "កញ្ញា"},
                {"10", "តុលា"},
                {"11", "វិច្ឆិកា"},
                {"12", "ធ្នូ"}
            };
            string keyMonth = Date.Month.ToString("00");
            if(!months.ContainsKey(keyMonth))
            {
                throw new Exception("Invalid date");
            }

            string month = months[keyMonth];

            return month;
        }

        public string toKhmerDay()
        {
            string days = Date.Day.ToString("00");
            return toKhmerNumber(days);
        }

        public string toKhmerYear()
        {
            string days = Date.Year.ToString();
            return toKhmerNumber(days);
        }


        private string toKhmerNumber(string number)
        {
            char[] numberArr = number.ToCharArray();
            string khmerNumber = "";

            foreach (var dayNumber in numberArr)
            {
                if (!numberList.ContainsKey(dayNumber))
                {
                    throw new Exception("Invalid date");
                }

                khmerNumber += numberList[dayNumber];
            }


            return khmerNumber;
        }
    }
}
