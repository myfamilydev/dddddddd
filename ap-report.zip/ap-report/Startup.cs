using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Session;
using System.Configuration;
using DataAccess.DBContexts;
using DocumentFormat.OpenXml.InkML;
using WebPortal.Controllers.Middleware;

namespace WebPortal
{
    public class Startup
    {
    
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;          
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
			//string cnn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
			//var constrings = ConfigurationManager.ConnectionStrings["conn"];

			var appDbConnection = Configuration.GetConnectionString("APConnection");
			services.AddCors();
            services.AddControllers();
            services.AddDbContext<ApDBContext>(
                option => option.UseSqlServer(appDbConnection)
            );
            //services.AddDbContext<ReportDBContext>(
            //    option => option.UseSqlServer(appDbConnection)
            //);
            //services.AddDbContext<ArDBContext>(
            //    option => option.UseSqlServer(appDbConnection)
            //);
            //services.AddDbContext<MayuraDBContext>(
            //    option => option.UseSqlServer(appDbConnection)
            //);
            services.AddControllersWithViews();
            services.AddDistributedMemoryCache();
            //services.AddSession();
            services.AddSession(options => { options.IdleTimeout = TimeSpan.FromMinutes(240); });
            services.AddMvc(options =>
            {
                options.RespectBrowserAcceptHeader = true; // false by default
            });
			services.AddHttpContextAccessor();
		}

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseCors(
                options => options.WithOrigins("*").AllowAnyMethod()
            );
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseSession();
            app.UseRouting();

            app.UseAuthorization();

            app.UseMiddleware<SsoMiddleware>();


			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllerRoute(
					name: "printing",
					pattern: "{controller=Printing}/{action=Index}/{id?}");
			});

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "oauth",
                    pattern: "{controller=Aauth}/{action=index}/{id?}");
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
