﻿using System;
using System.Net;

namespace LibraryAccess
{
    public static class StdLib
    {
        public static string AccountingNumberFormat(decimal value)
        {
            return  value.ToString("<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">#,##0.00</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">(#,##0.00)</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right;padding-right:20%\">-</div></div></div>");
        }

        public static string AccountingNumberFormat2(decimal value)
        {
            return value.ToString("<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">#,##0</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">(#,##0)</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right;padding-right:20%\">-</div></div></div>");
        }

    }
}
