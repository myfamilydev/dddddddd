﻿namespace WebPortal.Models
{
    public class Header
    {
        public string? Title { get; set; }
        public string? Project { get; set; }
    }
}
