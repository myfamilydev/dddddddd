﻿using DocumentFormat.OpenXml.Office2016.Drawing.Command;

namespace WebPortal.Models
{
    public class Footer
    {
        public string PreparedBy { get; set; }
        public string CheckedBy { get; set; }
        public string ApprovedBy { get; set; }
    }
}
