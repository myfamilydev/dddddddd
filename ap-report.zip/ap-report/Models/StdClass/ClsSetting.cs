﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace WebPortal.Models.StdClass
{
    public class ClsSetting
    {
        public string ColumnCaption { set; get; }
        public string ShowTotalColumns { set; get; }
        public string ColumnFormat { set; get; }
        public string ColumnHalignment { set; get; }
        public string ColumnValignmentAll { set; get; }
        public string lineBottom1 { set; get; }
        public string lineBottom2 { set; get; }
        public string ReportTitle { set; get; }
        public string ViewUrl { set; get; }
        public string SqlProcedure { set; get; }


        public Dictionary<string,string> ColumnDropDownLookup { set; get; }
        
    }
}
