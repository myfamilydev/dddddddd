﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebPortal.Models.StdClass
{
    public class ClsInitialize
    {
        public string visibleColumns { set; get; }
        public string sortColumns { set; get; }
    }
}
