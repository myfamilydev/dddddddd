﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class SuppliersContractsTerminatesInput : TableFilterReportInterace

    {
        [Display(Name = "Company")]
        public short? company_id { get; set; }

        [Display(Name = "Project")]
        public int? project_id { get; set; }

        [Display(Name = "Supplier Item")]             
        public int? supplier_item_id { get; set; }
        [Display(Name = "Contract PO")]        
        public string contract_po { get; set; }
        [Display(Name = "Cancel Date")]        
        public DateTime? cancel_date { get; set; }
  
        public ClsSetting setting()
        {
            var setting = new ClsSetting();
            setting.ReportTitle = "Suppliers Contracts Terminates Report";
            setting.SqlProcedure = "[report].[sp_suppliers_contracts_terminates]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "";
            setting.ShowTotalColumns = ""; //created_by
            //date, datetime, number, currency
            //dob:date,created_at:datetime,created_by:currency
            setting.ColumnFormat = "";
            //vendor_category:left,email:left
            setting.ColumnHalignment = "";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
            setting.lineBottom1 = "ត្រួតពិនិត្យដោយ,ត្រួតពិនិត្យដោយ";
            setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានទីផ្សារ,នាយករង នាយកដ្ឋានលក់";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["company_id"] = "SELECT id as [value], name_en as [text]  FROM dbo.v_dblhd_companies";
            setting.ColumnDropDownLookup["project_id"] = "select id as [value], project_short [text] from dbo.v_dblive_projects";
            setting.ColumnDropDownLookup["supplier_item_id"] = "select id as [value], item_code +' - '+ [name] collate SQL_Latin1_General_CP850_BIN as [text] from  dbo.suppliers_items";

            return setting;
        }

    }
}
