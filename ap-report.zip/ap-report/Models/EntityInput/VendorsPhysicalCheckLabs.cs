﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class VendorsPhysicalCheckLabsInput : TableFilterReportInterace

    {
        [Display(Name = "Company")]
        public short? company_id { get; set; }

        [Display(Name = "Payment Tracking Code")]
        public int? settlement_id { get; set; }
        [Display(Name = "Physical Check Labs Code")]
        public string code { get; set; }

        [Display(Name = "Check Date")]
       
        public DateTime? check_date { get; set; }
 
        public ClsSetting setting()
        {
            var setting = new ClsSetting();

            setting.ReportTitle = "Vendors Physical Check Labs Report";
            setting.SqlProcedure = "[report].[sp_vendors_physical_check_labs]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "";
            setting.ShowTotalColumns = ""; //created_by
            //date, datetime, number, currency
            //dob:date,created_at:datetime,created_by:currency
            setting.ColumnFormat = "";
            //vendor_category:left,email:left
            setting.ColumnHalignment = "";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
			setting.lineBottom1 = "អនុម័តដោយ,ត្រួតពិនិត្យដោយ";
			setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានហិរញ្ញវត្ថុ,នាយករង នាយកដ្ឋានហិរញ្ញវត្ថុ";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["company_id"] = "SELECT id as [value], name_en as [text]  FROM dbo.v_dblhd_companies";
            setting.ColumnDropDownLookup["settlement_id"] = "select id as [value], code as [text] from dbo.vendors_settlement_lab";


            return setting;
        }


    }
}
