﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class VendorsContractsInput : TableFilterReportInterace
    {
        [Display(Name = "Company")]
        public short? company_id { get; set; }

        [Display(Name = "Project")]
        public int? pro_id { get; set; }

        [Display(Name = "Vendors Category")]             
        public string vendor_category { get; set; }

        [Display(Name = "Vendors ID")]        
        public int? vendorId { get; set; }

        [Display(Name = "Contract PO ID")]
        public string contractPurchaseId { get; set; }

        [Display(Name = "Name En")]        
        public string name_en { get; set; }

        [Display(Name = " Name Kh")]
        public string name_kh { get; set; }

        [Display(Name = "National ID")]
        public string nid_no { get; set; }
  
        public ClsSetting setting()
        {
            var setting = new ClsSetting();

            setting.ReportTitle = "Vendors Contracts Report";
            setting.SqlProcedure = "[report].[sp_vendors_contracts]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "";
            setting.ShowTotalColumns = ""; //created_by
            //date, datetime, number, currency
            //dob:date,created_at:datetime,created_by:currency
            setting.ColumnFormat = "";
            //vendor_category:left,email:left
            setting.ColumnHalignment = "";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
			setting.lineBottom1 = "អនុម័តដោយ,ត្រួតពិនិត្យដោយ";
			setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានហិរញ្ញវត្ថុ,នាយករង នាយកដ្ឋានហិរញ្ញវត្ថុ";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["company_id"] = "SELECT id as [value], name_en as [text]  FROM dbo.v_dblhd_companies";
            setting.ColumnDropDownLookup["pro_id"] = "select id as [value], project_short [text] from dbo.v_dblive_projects";
            setting.ColumnDropDownLookup["vendorId"] = "select id as [value], vendor_code + ' - ' + name_kh collate SQL_Latin1_General_CP850_BIN  as  [text] from dbo.vendors";
            setting.ColumnDropDownLookup["vendor_category"] = "SELECT category_text as [value], category_text as [text]  FROM vendors_category WHERE status = 1";

            return setting;
        }

    }
}
