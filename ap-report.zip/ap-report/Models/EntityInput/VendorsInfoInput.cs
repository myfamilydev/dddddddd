﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class VendorsInfoInput: TableFilterReportInterace
    {

        [Display(Name = "Category")]
        public string vendor_category { get; set; }

        [Display(Name = "Name EN")]
        public string name_en { get; set; }

        [Display(Name = "Name KH")]
        public string name_kh { get; set; }

        [Display(Name = "National ID")]
        public string NID_no { get; set; }

        [Display(Name = "Phone Number Contract")]
        public string phone_contract { get; set; }

        [Display(Name = "Phone Number Update")]
        public string phone_number_update { get; set; }

        [Display(Name = "Settlement Method", GroupName = "Settlement Info 1")]
        public int? settlement_method_id_1 { get; set; }

        [Display(Name = "Cheque Name", GroupName = "Settlement Info 1")]
        public string cheque_name_1 { get; set; }

        [Display(Name = "Payment Collector", GroupName = "Settlement Info 1")]
        public string payment_collector_1 { get; set; }

        [Display(Name = "Phone Number Update", GroupName = "Settlement Info 1")]
        public string settlement_phone_1 { get; set; }
        public string settlement_method_id_1_load()
        {
            return "select id as [value], settlement_type [text] from dbo.vendors_settlement_methods";
        }
        public string vendor_category_load()
        {
            return "SELECT category_text as [value], category_text as [text]  FROM vendors_category WHERE status = 1";
        }

        public ClsSetting setting()
        {
            var setting = new ClsSetting();

            setting.ReportTitle = "Chart Of Account Report";
            setting.SqlProcedure = "[report].[sp_chart_account]";
            setting.ViewUrl = "Report/TableFilterReport";
            //Report title
            setting.ReportTitle = "Vendors Report";
            setting.SqlProcedure = "[report].[sp_vendors_info]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB,Phone_Contract:Phone Contract";
            setting.ShowTotalColumns = ""; //created_by
                                           //date, datetime, number, currency
            setting.ColumnFormat = "dob:date,created_at:datetime,created_by:currency";
            setting.ColumnHalignment = "vendor_category:left,email:left";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
			setting.lineBottom1 = "អនុម័តដោយ,ត្រួតពិនិត្យដោយ";
			setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានហិរញ្ញវត្ថុ,នាយករង នាយកដ្ឋានហិរញ្ញវត្ថុ";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["settlement_method_id_1"] = "select id as [value], settlement_type [text] from dbo.vendors_settlement_methods";
            setting.ColumnDropDownLookup["vendor_category"] = "SELECT category_text as [value], category_text as [text]  FROM vendors_category WHERE status = 1";

            return setting;
        }


    }
}
