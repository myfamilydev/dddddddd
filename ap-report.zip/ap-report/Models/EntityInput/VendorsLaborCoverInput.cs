﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class VendorsLaborCoverInput : TableFilterReportInterace

    {
        [Display(Name = "Company")]
        public short? company_id { get; set; }

        [Display(Name = "Project")]
        public int? pro_id { get; set; }

        [Display(Name = "Vendor Name EN")]        
        public int? vendor_id { get; set; }

        [Display(Name = "Contract Code")]
        public int? contract_id { get; set; }

        [Display(Name = "Item Name")]        
        public int? vendorItemId { get; set; }

        [Display(Name = "Cover Code")]
        public string cover_code { get; set; }

        public ClsSetting setting()
        {
            var setting = new ClsSetting();

            setting.ReportTitle = "Vendors Labor Cover Report";
            setting.SqlProcedure = "[report].[sp_vendors_labor_cover]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "";
            setting.ShowTotalColumns = ""; //created_by
            //date, datetime, number, currency
            //dob:date,created_at:datetime,created_by:currency
            setting.ColumnFormat = "";
            //vendor_category:left,email:left
            setting.ColumnHalignment = "";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
			setting.lineBottom1 = "អនុម័តដោយ,ត្រួតពិនិត្យដោយ";
			setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានហិរញ្ញវត្ថុ,នាយករង នាយកដ្ឋានហិរញ្ញវត្ថុ";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["company_id"] = "SELECT id as [value], name_en as [text]  FROM dbo.v_dblhd_companies";
            setting.ColumnDropDownLookup["pro_id"] = "select id as [value], project_short [text] from dbo.v_dblive_projects";
            setting.ColumnDropDownLookup["vendor_id"] = "select v.id as [value], v.vendor_code +'  '+ isnull(vc.name_en,'')  from  dbo.vendors v left join " +
                                                        "dbo.vendors_labor_covers lc  on lc.vendor_id = v.id left join " +
                                                        "dbo.vendors_contracts vc on lc.contract_id = vc.id";

            setting.ColumnDropDownLookup["contract_id"] = "select id as [value], contract_code as [text] from dbo.vendors_contracts";
            setting.ColumnDropDownLookup["vendorItemId"] = "select vt.id as [value],  isnull(vc.items,'') + isnull(vt.item_code,'') as [text] from dbo.vendors_items vt left join " +
                                                           "dbo.vendors_labor_covers lc on lc.vendorItemId = vt.id  left join " +
                                                           "dbo.vendors_contracts vc on lc.contract_id = vc.id";
            setting.ColumnDropDownLookup["cover_code"] = "select cover_code as [value], cover_code as [text] from dbo.vendors_labor_covers";
            return setting;
        }



    }
}
