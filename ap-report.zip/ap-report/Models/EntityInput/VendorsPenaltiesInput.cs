﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class VendorsPenaltiesInput : TableFilterReportInterace
    {

        [Display(Name = "Company")]
        public short? company_id { get; set; }

        [Display(Name = "Project")]
        public int? project_id { get; set; }

        [Display(Name = "Vendors Category")]             
        public string vendor_category { get; set; }

        [Display(Name = "Vendors Name")]       
        public string vendor_id { get; set; }

        [Display(Name = "Payment Tracking")]
        public short? payment_tracking_id { get; set; }

        //[Display(Name = "Account Code")]
        //public string account_code { get; set; }
         

        public ClsSetting setting()
        {
            var setting = new ClsSetting();

            setting.ReportTitle = "Vendors Penalties Report";
            setting.SqlProcedure = "[report].[sp_vendors_penalties]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "";
            setting.ShowTotalColumns = ""; //created_by
            //date, datetime, number, currency
            //dob:date,created_at:datetime,created_by:currency
            setting.ColumnFormat = "";
            //vendor_category:left,email:left
            setting.ColumnHalignment = "";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
			setting.lineBottom1 = "អនុម័តដោយ,ត្រួតពិនិត្យដោយ";
			setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានហិរញ្ញវត្ថុ,នាយករង នាយកដ្ឋានហិរញ្ញវត្ថុ";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["company_id"] = "SELECT id as [value], name_en as [text]  FROM dbo.v_dblhd_companies";
            setting.ColumnDropDownLookup["project_id"] = "select id ,[project_code] as [project_short] from v_dblive_projects";
            setting.ColumnDropDownLookup["vendor_category"] = "SELECT category_text as [value], category_text as [text]  FROM vendors_category WHERE status = 1";
            setting.ColumnDropDownLookup["vendor_id"] = "select id as [value], vendor_code + ' - ' + name_kh collate SQL_Latin1_General_CP850_BIN  as  [text] from dbo.vendors";
            setting.ColumnDropDownLookup["payment_tracking_id"] = "SELECT id as [value], settlement_code as [text]  FROM dbo.vendors_settlement_sub";
            setting.ColumnDropDownLookup["account_code"] = "select account_code as [value], account_code +' - '+vp.project_short collate SQL_Latin1_General_CP850_BIN [text] from dbo.chart_accounts ca inner join dbo.v_dblive_projects vp on ca.account_code=ca.account_code";

            return setting;
        }

    }
}
