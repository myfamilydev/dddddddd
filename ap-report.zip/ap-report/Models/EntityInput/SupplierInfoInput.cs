﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.EntityInput
{
    public class SupplierInfoInput : TableFilterReportInterace
    {
        [Display(Name = "Company")]
        public short? company_id { get; set; }

        [Display(Name = "Supplier Code")]
        public string supplier_code { get; set; }

        [Display(Name = "Supplier Location")]
        public string supplier_location { get; set; }

        [Display(Name = "Name KH")]        
        public string name_kh { get; set; }

        [Display(Name = "Name En")]             
        public string name_en { get; set; }

        [Display(Name = "NID")]               
        public string nid { get; set; }

        [Display(Name = "Contact Number")]       
        public string contact_number { get; set; }

        [Display(Name = "Contact Telegram")]       
        public string contact_telegram { get; set; }
  
        public ClsSetting setting()
        {
            var setting = new ClsSetting();

            setting.ReportTitle = "Supplier Report";
            setting.SqlProcedure = "[report].[sp_suppliers]";
            setting.ViewUrl = "Report/TableFilterReport";
            //vendor_category:Vendor Category,name_en:Name EN,name_kh:Name KH,NID_no:NID No,dob:DOB
            setting.ColumnCaption = "";
            setting.ShowTotalColumns = ""; //created_by
            //date, datetime, number, currency
            //dob:date,created_at:datetime,created_by:currency
            setting.ColumnFormat = "";
            //vendor_category:left,email:left
            setting.ColumnHalignment = "";
            setting.ColumnValignmentAll = "top"; //top, middle, bottom
			setting.lineBottom1 = "អនុម័តដោយ,ត្រួតពិនិត្យដោយ";
			setting.lineBottom2 = "អគ្គនាយិកា អគ្គនាយកដ្ឋានហិរញ្ញវត្ថុ,នាយករង នាយកដ្ឋានហិរញ្ញវត្ថុ";

			//loading lookup value
			setting.ColumnDropDownLookup = new Dictionary<string, string>();
            setting.ColumnDropDownLookup["company_id"] = "SELECT id as [value], name_en as [text]  FROM dbo.v_dblhd_companies";
            setting.ColumnDropDownLookup["supplier_location"] = "select [name] as [value],[name] as [text] from dbo.suppliers_locations";


            return setting;
        }


    }
}
