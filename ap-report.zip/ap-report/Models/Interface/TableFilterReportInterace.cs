﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.StdClass;

namespace WebPortal.Models.Interface
{
    interface TableFilterReportInterace
    {
        public ClsSetting setting();
    }
}
