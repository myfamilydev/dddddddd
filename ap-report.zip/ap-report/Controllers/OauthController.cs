﻿using BVMPP.ClientOauth.Models;
using BVMPP.ClientOauth;
using Microsoft.AspNetCore.Mvc;
using WebPortal.Controllers.Models;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using DocumentFormat.OpenXml.InkML;

namespace WebPortal.Controllers
{
    public class OauthController : Controller
    {

        private readonly IConfiguration _config;
		public OauthController(IConfiguration config)
        {
            _config = config;
        }
        public async Task<IActionResult> callback([FromQuery] Query query)
        {
			return View("asLogin");
		}
    }
}
