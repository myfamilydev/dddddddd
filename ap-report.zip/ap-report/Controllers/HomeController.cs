﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models;

namespace WebPortal.Controllers
{
    public class HomeController : BaseController
	{
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ISession _session;
        private readonly ILogger<HomeController> _logger;
		private readonly IConfiguration _config;
		public HomeController(ILogger<HomeController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;

            //var userId = httpContextAccessor.HttpContext.Session.GetString("userId");

            //if (userId == null || string.IsNullOrEmpty(userId))
            //{
            //    RedirectTo("http://localhost:3002/oauth/callback");
            //}

		}

		public async Task<IActionResult> index()
        {
            
            ViewBag.UserId = HttpContext.Session.GetString("userId");
            return View("Index");
        }
      
    }
}
