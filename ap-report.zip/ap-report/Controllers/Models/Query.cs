﻿namespace WebPortal.Controllers.Models
{
    public class Query
    {
        public string Code { get; set; }
    }
}