﻿
using BVMPP.ClientOauth;
using BVMPP.ClientOauth.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace WebPortal.Controllers.Middleware
{
	public class SsoMiddleware
	{
		private readonly RequestDelegate _next;

		private readonly IConfiguration _config;

		public SsoMiddleware(RequestDelegate next, IConfiguration config)
		{
			_next = next;
			_config = config;
		}

		public async Task InvokeAsync(HttpContext context)
		{
			var userId = context.Session.GetString("userId");
			var ClientId = _config["SSO:ClientId"];
			var RedirectUri = _config["SSO:RedirectUri"];
			var ProviderURL = _config["SSO:Url"];
			var ClientSecret = _config["SSO:ClientSecret"];
			var BasePath = _config["BasePath"];
			int lastSlash = BasePath.LastIndexOf('/');
			BasePath = (lastSlash > -1) ? BasePath.Substring(0, lastSlash) : BasePath;

			if (userId == null || string.IsNullOrEmpty(userId))
			{
				if (!(context.Request.Path.HasValue && context.Request.Path.Value.Contains("oauth/callback")))
				{
					if (userId == null || string.IsNullOrEmpty(userId))
					{
						context.Session.SetString("prevUrl", $"{BasePath}{context.Request.Path.Value}");
						context.Response.Redirect($"{ProviderURL}/oauth/authorize?client_id={ClientId}&redirect_uri={RedirectUri}&response_type=code&scope=");
					}

				}

				var code = context.Request.Query["Code"].ToString();

				if ((userId == null || string.IsNullOrEmpty(userId)) && !string.IsNullOrEmpty(code))
				{
					var _SDKConfiguration = new SDKConfiguration
					{
						ClienId = ClientId,
						ClientSecret = ClientSecret,
						RedirectUri = RedirectUri,
					};

					var _clientApi = new ClientApi(_SDKConfiguration);

					SSOAccessOwner oauthToken = await _clientApi.GetSSOAccessOwner(context.Request.Query["Code"]);
					if (string.IsNullOrEmpty(context.Session.GetString("userId")))
					{
						context.Session.SetString("userId", oauthToken.Id.ToString());
						context.Session.SetString("username", oauthToken.Username);
						context.Session.SetString("accessToken", oauthToken.AccessToken);
						context.Response.Redirect(context.Session.GetString("prevUrl"));
					}
				}
			}
			await _next(context);
		}
	}
}
