﻿using Microsoft.AspNetCore.Mvc;

namespace WebPortal.Controllers
{
    public class TemplateController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
