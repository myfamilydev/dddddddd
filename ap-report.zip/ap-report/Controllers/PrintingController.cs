﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using DataAccess.DBContexts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebPortal.Models;
using WebPortal.Models.EntityInput;
using WebPortal.Models.Interface;
using WebPortal.Models.StdClass;

namespace WebPortal.Controllers
{
    public class PrintingController : Controller
	{

        private readonly ILogger<HomeController> _logger;
        private readonly ApDBContext _ApDbContext;
		private readonly IConfiguration _config;
		public PrintingController(ILogger<HomeController> logger, ApDBContext ApDbContext, IConfiguration config)
        {
            _logger = logger;
            _ApDbContext = ApDbContext;
            _config= config;
            //ConfigurationManager.RefreshSection("configuration");
            //connectionString = ConfigurationManager.ConnectionStrings["connstr"]?.ConnectionString;
        }

        private DataTable loadLookupData(string sql)
        {
            DataTable ds = new DataTable();
            if (sql != "")
            {
                using (var cnn = new SqlConnection(_ApDbContext.Database.GetDbConnection().ConnectionString))
                {
                    var adapter = new SqlDataAdapter(sql, cnn);
                    adapter.Fill(ds);
                    return ds;
                }
            }
            return null;
        }
        private async Task<IActionResult> TableFilterReport(TableFilterReportInterace data, int action, ClsInitialize init)
        {
                
                ClsSetting setting = data.setting();

                string reportTitle = setting.ReportTitle;
                ViewData["ReportTitle"] = reportTitle;
                ViewBag.init = init;
                ViewBag.setting = setting;                    
                

                var com = new SqlCommand();
                var properties = data.GetType().GetProperties();
                string order_by = init.sortColumns ?? "".Trim();
                if (order_by != "")
                {
                    order_by = order_by.Substring(0, order_by.Length - 1);
                    order_by = order_by.Replace(';', ',');
                    order_by = order_by.Replace("|1", " asc");
                    order_by = order_by.Replace("|2", " desc");
                }
                com.Parameters.Add(new SqlParameter("order_by", order_by));

                foreach (var prop in properties)
                {
                    string prop_name = prop.Name;
                    var value = prop.GetValue(data, null);
                    Type type = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    string type_name = type.Name;

                if (type_name == "String")
                {
                    if (value == null) value = "";
                    //ViewData[prop_name] = loadLookupData(data, prop_name);

                }
                else if (type_name == "Byte" || type_name == "Int16" || type_name == "Int32" || type_name == "Int64")
                {
                    if (value == null) value = 0;
                    //ViewData[prop_name] = loadLookupData(data, prop_name);
                }
                else if (type_name == "Single" || type_name == "Decimal" ||
                      type_name == "Double" || type_name == "Guid" || type_name == "Boolean")
                {
                    if (value == null)  value = 0;
                }
                else if (type_name == "DateTime" || type_name == "DateTimeOffset" || type_name == "TimeSpan")
                {
                    if (value == null) value = DBNull.Value;
                }

                    if (action != 0) com.Parameters.Add(new SqlParameter($"@{prop_name}", value));

                    //load lookup data
                    if (setting.ColumnDropDownLookup.ContainsKey(prop_name))
                    {
                        string sql = setting.ColumnDropDownLookup[prop_name];
                        ViewData[prop_name] = loadLookupData(sql);
                    }

                }

                //com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                //com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                //com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));


                if (action != 0)
                {
                    com.Connection = (SqlConnection)_ApDbContext.Database.GetDbConnection();
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = setting.SqlProcedure; //exec [dbo].[sp_vendors_info] '','','','','','','','','',''                
                    var adapt = new SqlDataAdapter();
                    adapt.SelectCommand = com;
                    DataTable dataset = new DataTable();
                    adapt.Fill(dataset);
                    ViewBag.Detail = dataset;

                    if (action == 2)
                    {

                        var columnCaption = new Dictionary<string, string>();
                        var columnFormatList = new Dictionary<string, string>();
                        if (setting.ColumnCaption != "")
                        {
                            string[] arr = setting.ColumnCaption.Split(',');
                            foreach (string item in arr)
                            {
                                string[] arr_caption = item.Split(':');
                                columnCaption[arr_caption[0]] = arr_caption[1];
                            }
                        }
                        //defined column format
                        if (setting.ColumnFormat != "")
                        {
                            string[] arr = setting.ColumnFormat.Split(',');
                            foreach (string item in arr)
                            {
                                string[] arr_format = item.Split(':');
                                columnFormatList[arr_format[0]] = arr_format[1];
                            }
                        }
                        var stream = new MemoryStream();
                        using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                        {
                                var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                                var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                                csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                                csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                                csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                                csv.WriteField(reportTitle);
                                csv.NextRecord();
                                //header
                                for (int i = 0; i < dataset.Columns.Count; i++)
                                {
                                    string col_name = dataset.Columns[i].ColumnName;
                                    string col_caption = columnCaption.ContainsKey(col_name) ? columnCaption[col_name] : col_name;
                                    csv.WriteField(col_caption);
                                }
                                csv.NextRecord();
                                decimal dvalue;
                                DateTime dtvalue;

                                for (int i = 0; i < dataset.Rows.Count; i++)
                                {
                                    
                                    for (int j = 0; j < dataset.Columns.Count; j++)
                                    {
                                        string col_name = dataset.Columns[j].ColumnName;
                                        string column_format = columnFormatList.ContainsKey(col_name) ? columnFormatList[col_name] : "";
                                        string value = dataset.Rows[i][j].ToString();
                                        if (value != "")
                                        {
                                            if (column_format == "date") value = Convert.ToDateTime(value).ToString("MM/dd/yyyy");
                                            else if(column_format == "datetime") value = Convert.ToDateTime(value).ToString("MM/dd/yyyy HH:mm");
                                            else if(!(decimal.TryParse(value, out dvalue) || DateTime.TryParse(value, out dtvalue))) {
                                               if(value.Contains(",")) value = "\"" + value+"\"";
                                            }
                                        }  
                                        csv.WriteField(value);
                                    }
                                    csv.NextRecord();
                                }
                                //body                               
                        }
                        var a = stream.ToArray();
                        return File(stream.ToArray(), "text/csv", reportTitle.Replace(" ", "") + "_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                    }

                }

                com = null;
                //ViewBag.ModelData = data;
                return View(setting.ViewUrl, data);
        }

        public async Task<IActionResult> VendorsInfo(VendorsInfoInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }
        public async Task<IActionResult> ChartOfAccount(ChartOfAccountInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> SupplierInfo(SupplierInfoInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }
        public async Task<IActionResult> SupplierItem(SupplierItemInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }


        public async Task<IActionResult> VendorsContractsTerminations(VendorsContractsTerminationsInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> VendorsContracts(VendorsContractsInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> ReceivedDocumentCancel(ReceivedDocumentCancelInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> ReceivedDocument(ReceivedDocumentInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> VendorsPenalties(VendorsPenaltiesInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> DailyCleanerInfo(DailyCleanerInfoInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> VendorsSettlementLab(VendorsSettlementLabInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);

        }

        public async Task<IActionResult> vendorsPhysicalCheckSubs(VendorsPhysicalCheckSubsInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> DailyCleanerSettle(DailyCleanerSettleInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> VendorsLaborCover(VendorsLaborCoverInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> SuppliersContractsTerminates(SuppliersContractsTerminatesInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);

        }

        public async Task<IActionResult> VendorsItems(VendorsItemsInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }
        public async Task<IActionResult> VendorsPhysicalCheckLabs(VendorsPhysicalCheckLabsInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> VendorsSettlementSub(VendorsSettlementSubInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }
        public async Task<IActionResult> SettlePaymentMaterials(SettlePaymentMaterialsInput data, int action, ClsInitialize init)
        {
            return await TableFilterReport(data, action, init);
        }

        public async Task<IActionResult> SuppliersSchedulesPayments(SuppliersSchedulesPaymentsInput data, int action, ClsInitialize init)
        {

            //setting 
            string reportTitle = "Suppliers Schedules Payments Report";

            ClsSetting setting = data.setting();
            ViewBag.init = init;
            ViewBag.setting = setting;

            var com = new SqlCommand();
            var properties = data.GetType().GetProperties();
            string order_by = init.sortColumns ?? "".Trim();
            if (order_by != "")
            {
                order_by = order_by.Substring(0, order_by.Length - 1);
                order_by = order_by.Replace(';', ',');
                order_by = order_by.Replace("|1", " asc");
                order_by = order_by.Replace("|2", " desc");
            }
            com.Parameters.Add(new SqlParameter("order_by", order_by));

            foreach (var prop in properties)
            {
                string prop_name = prop.Name;
                var value = prop.GetValue(data, null);
                Type type = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                string type_name = type.Name;

                if (type_name == "String")
                {
                    if (value == null) value = "";
                    //ViewData[prop_name] = loadLookupData(data, prop_name);

                }
                else if (type_name == "Byte" || type_name == "Int16" || type_name == "Int32" || type_name == "Int64")
                {
                    if (value == null) value = 0;
                    //ViewData[prop_name] = loadLookupData(data, prop_name);
                }
                else if (type_name == "Single" || type_name == "Decimal" ||
                        type_name == "Double" || type_name == "Guid" || type_name == "Boolean" && value == null) value = 0;

                else if (type_name == "DateTime" || type_name == "DateTimeOffset" || type_name == "TimeSpan") value = DBNull.Value;

                if (action != 0) com.Parameters.Add(new SqlParameter($"@{prop_name}", value));

                //load lookup data
                if (setting.ColumnDropDownLookup.ContainsKey(prop_name))
                {
                    string sql = setting.ColumnDropDownLookup[prop_name];
                    ViewData[prop_name] = loadLookupData(sql);
                }

            }

            //com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
            //com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
            //com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));


            if (action != 0)
            {
                com.Connection = (SqlConnection)_ApDbContext.Database.GetDbConnection();
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "[report].[sp_suppliers_schedules_payments]"; //exec [dbo].[sp_vendors_info] '','','','','','','','','',''                
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                adapt.Fill(dataset);
                ViewBag.Detail = dataset;

                if (action == 2)
                {
                    var stream = new MemoryStream();
                    using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                    {
                        var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                        var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                        csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                        csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                        csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                        csv.WriteField(reportTitle);
                        csv.NextRecord();
                        //header
                        for (int i = 0; i < dataset.Columns.Count; i++)
                            csv.WriteField(dataset.Columns[i].ColumnName);

                        for (int i = 0; i < dataset.Rows.Count; i++)
                        {
                            csv.NextRecord();
                            for (int j = 0; j < dataset.Columns.Count; j++)
                            {
                                csv.WriteField(dataset.Rows[i][j].ToString());
                            }

                        }
                        //body

                        //csv.WriteRecords(list);
                    }
                    return File(stream.ToArray(), "text/csv", reportTitle.Replace(" ", "") + "_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                }

            }

            com = null;
            //ViewBag.ModelData = data;
            return View("Report/SuppliersSchedulesPayments", data);

        }


    }
}
