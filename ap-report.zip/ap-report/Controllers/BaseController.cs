﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;

namespace WebPortal.Controllers
{
    public class BaseController : Controller
    {
		private readonly IConfiguration _config;

		public IActionResult RedirectTo(string url)
		{
			return Redirect(url);
		}
	}
}
