﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.AP;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.DBContexts
{
    public partial class ApDBContext : DbContext
    {
        public ApDBContext()
        {
        }

        public ApDBContext(DbContextOptions<ApDBContext> options)
            : base(options)
        {
        }
        public virtual DbSet<VVendorSettlementSub> VVendorSettlementSubs { get; set; }
        public virtual DbSet<Attachments> Attachments { get; set; }
        public virtual DbSet<AuditLogs> AuditLogs { get; set; }
        public virtual DbSet<BankLists> BankLists { get; set; }
        public virtual DbSet<BankLocations> BankLocations { get; set; }
        public virtual DbSet<ChartAccounts> ChartAccounts { get; set; }
        public virtual DbSet<ChequeBook> ChequeBook { get; set; }
        public virtual DbSet<ChequeBookCancel> ChequeBookCancel { get; set; }
        public virtual DbSet<ChequeBookSubterms> ChequeBookSubterms { get; set; }
        public virtual DbSet<ChequeBookUsers> ChequeBookUsers { get; set; }
        public virtual DbSet<Companies> Companies { get; set; }
        public virtual DbSet<CompanyCostCenters> CompanyCostCenters { get; set; }
        public virtual DbSet<ContractArAdminFees> ContractArAdminFees { get; set; }
        public virtual DbSet<ContractArDisbursments> ContractArDisbursments { get; set; }
        public virtual DbSet<ContractArDisbursmentsCostCenters> ContractArDisbursmentsCostCenters { get; set; }
        public virtual DbSet<ContractArDisbursmentsHtds> ContractArDisbursmentsHtds { get; set; }
        public virtual DbSet<ContractArDisbursmentsUseFunds> ContractArDisbursmentsUseFunds { get; set; }
        public virtual DbSet<ContractArDocumentsRequirements> ContractArDocumentsRequirements { get; set; }
        public virtual DbSet<ContractArLimitPrincipals> ContractArLimitPrincipals { get; set; }
        public virtual DbSet<ContractArLoans> ContractArLoans { get; set; }
        public virtual DbSet<ContractArPaymentTerms> ContractArPaymentTerms { get; set; }
        public virtual DbSet<ContractArSettlements> ContractArSettlements { get; set; }
        public virtual DbSet<ContractIndividualCostCenters> ContractIndividualCostCenters { get; set; }
        public virtual DbSet<ContractIndividualHtdItems> ContractIndividualHtdItems { get; set; }
        public virtual DbSet<ContractIndividualLoans> ContractIndividualLoans { get; set; }
        public virtual DbSet<ContractIndividualScheduleDetails> ContractIndividualScheduleDetails { get; set; }
        public virtual DbSet<ContractIndividualSchedules> ContractIndividualSchedules { get; set; }
        public virtual DbSet<ContractIndividualSchedulesInfo> ContractIndividualSchedulesInfo { get; set; }
        public virtual DbSet<ContractIndividualSettlements> ContractIndividualSettlements { get; set; }
        public virtual DbSet<ContractIndividualUseFunds> ContractIndividualUseFunds { get; set; }
        public virtual DbSet<ContractStandardLoans> ContractStandardLoans { get; set; }
        public virtual DbSet<CostTypes> CostTypes { get; set; }
        public virtual DbSet<Currencies> Currencies { get; set; }
        public virtual DbSet<CustomerBehaviorTypes> CustomerBehaviorTypes { get; set; }
        public virtual DbSet<DailyCleanerInfo> DailyCleanerInfo { get; set; }
        public virtual DbSet<DailyCleanerSettle> DailyCleanerSettle { get; set; }
        public virtual DbSet<DailyCleanerSettleHouses> DailyCleanerSettleHouses { get; set; }
        public virtual DbSet<DailyCleanerSettleInfo> DailyCleanerSettleInfo { get; set; }
        public virtual DbSet<DailyCleanerWages> DailyCleanerWages { get; set; }
        public virtual DbSet<DimAccountThreatmentTypes> DimAccountThreatmentTypes { get; set; }
        public virtual DbSet<DimAccountTypes> DimAccountTypes { get; set; }
        public virtual DbSet<DimShareCostStandard> DimShareCostStandard { get; set; }
        public virtual DbSet<ErrorLogs> ErrorLogs { get; set; }
        public virtual DbSet<ExchangeRates> ExchangeRates { get; set; }
        public virtual DbSet<FileLinks> FileLinks { get; set; }
        public virtual DbSet<ItemName> ItemName { get; set; }
        public virtual DbSet<ItemType> ItemType { get; set; }
        public virtual DbSet<LoanBanks> LoanBanks { get; set; }
        public virtual DbSet<LoanBanksItems> LoanBanksItems { get; set; }
        public virtual DbSet<LoanCostCenters> LoanCostCenters { get; set; }
        public virtual DbSet<LoanDisburementItems> LoanDisburementItems { get; set; }
        public virtual DbSet<LoanDocumentsRequirement> LoanDocumentsRequirement { get; set; }
        public virtual DbSet<LoanHtdItems> LoanHtdItems { get; set; }
        public virtual DbSet<LoanReschedules> LoanReschedules { get; set; }
        public virtual DbSet<LoanSchedulesInfo> LoanSchedulesInfo { get; set; }
        public virtual DbSet<LoanStandardScheduleDetails> LoanStandardScheduleDetails { get; set; }
        public virtual DbSet<LoanStandardSchedules> LoanStandardSchedules { get; set; }
        public virtual DbSet<LoanTypes> LoanTypes { get; set; }
        public virtual DbSet<LoanUseFunds> LoanUseFunds { get; set; }
        public virtual DbSet<PayOffLoanRequests> PayOffLoanRequests { get; set; }
        public virtual DbSet<PettyCashSubterms> PettyCashSubterms { get; set; }
        public virtual DbSet<PettyCashes> PettyCashes { get; set; }
        public virtual DbSet<ReceivedDocuments> ReceivedDocuments { get; set; }
        public virtual DbSet<ReceivedDocumentsCancel> ReceivedDocumentsCancel { get; set; }
        public virtual DbSet<RedesignFees> RedesignFees { get; set; }
        public virtual DbSet<RedesignFloors> RedesignFloors { get; set; }
        public virtual DbSet<RedesignJobs> RedesignJobs { get; set; }
        public virtual DbSet<SettlePaymentInvoices> SettlePaymentInvoices { get; set; }
        public virtual DbSet<SettlePaymentInvoicesDetail> SettlePaymentInvoicesDetail { get; set; }
        public virtual DbSet<SettlePaymentInvoicesNonstocks> SettlePaymentInvoicesNonstocks { get; set; }
        public virtual DbSet<SettlePaymentInvoicesNonstocksDetail> SettlePaymentInvoicesNonstocksDetail { get; set; }
        public virtual DbSet<SettlePaymentInvoicesNonstocksDetailCosts> SettlePaymentInvoicesNonstocksDetailCosts { get; set; }
        public virtual DbSet<SettlePaymentMaterials> SettlePaymentMaterials { get; set; }
        public virtual DbSet<Suppliers> Suppliers { get; set; }
        public virtual DbSet<SuppliersContracts> SuppliersContracts { get; set; }
        public virtual DbSet<SuppliersContractsItems> SuppliersContractsItems { get; set; }
        public virtual DbSet<SuppliersContractsItemsSub> SuppliersContractsItemsSub { get; set; }
        public virtual DbSet<SuppliersContractsPaymentTerms> SuppliersContractsPaymentTerms { get; set; }
        public virtual DbSet<SuppliersContractsTerminates> SuppliersContractsTerminates { get; set; }
        public virtual DbSet<SuppliersItems> SuppliersItems { get; set; }
        public virtual DbSet<SuppliersItemsTypes> SuppliersItemsTypes { get; set; }
        public virtual DbSet<SuppliersLocations> SuppliersLocations { get; set; }
        public virtual DbSet<SuppliersSchedulesPaid> SuppliersSchedulesPaid { get; set; }
        public virtual DbSet<SuppliersSchedulesPaidCosts> SuppliersSchedulesPaidCosts { get; set; }
        public virtual DbSet<SuppliersSchedulesPayments> SuppliersSchedulesPayments { get; set; }
        public virtual DbSet<SuppliersSchedulesPaymentsDetails> SuppliersSchedulesPaymentsDetails { get; set; }
        public virtual DbSet<TelegramLog> TelegramLog { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<UsersCompanies> UsersCompanies { get; set; }
        public virtual DbSet<UsersDepartments> UsersDepartments { get; set; }
        public virtual DbSet<UsersGroups> UsersGroups { get; set; }
        public virtual DbSet<UsersGroupsPermissions> UsersGroupsPermissions { get; set; }
        public virtual DbSet<UsersNotifySessions> UsersNotifySessions { get; set; }
        public virtual DbSet<UsersPages> UsersPages { get; set; }
        public virtual DbSet<UsersPagesToRoles> UsersPagesToRoles { get; set; }
        public virtual DbSet<UsersPermissions> UsersPermissions { get; set; }
        public virtual DbSet<UsersPositions> UsersPositions { get; set; }
        public virtual DbSet<UsersRoles> UsersRoles { get; set; }
        public virtual DbSet<UsersToRoles> UsersToRoles { get; set; }
        public virtual DbSet<VAffectedRow> VAffectedRow { get; set; }
        public virtual DbSet<VArchRedesignHouses> VArchRedesignHouses { get; set; }
        public virtual DbSet<VAttachmentList> VAttachmentList { get; set; }
        public virtual DbSet<VBanks> VBanks { get; set; }
        public virtual DbSet<VChartAccounts> VChartAccounts { get; set; }
        public virtual DbSet<VChequeBook> VChequeBook { get; set; }
        public virtual DbSet<VChequeBookCancel> VChequeBookCancel { get; set; }
        public virtual DbSet<VChequeBookSubterms> VChequeBookSubterms { get; set; }
        public virtual DbSet<VChequeBookUsers> VChequeBookUsers { get; set; }
        public virtual DbSet<VCompanyCostCenter> VCompanyCostCenter { get; set; }
        public virtual DbSet<VContractAdminFees> VContractAdminFees { get; set; }
        public virtual DbSet<VContractArDisbursments> VContractArDisbursments { get; set; }
        public virtual DbSet<VContractArDisbursmentsCostCenters> VContractArDisbursmentsCostCenters { get; set; }
        public virtual DbSet<VContractArDisbursmentsHtds> VContractArDisbursmentsHtds { get; set; }
        public virtual DbSet<VContractArDisbursmentsUseFunds> VContractArDisbursmentsUseFunds { get; set; }
        public virtual DbSet<VContractArDocumentRequirements> VContractArDocumentRequirements { get; set; }
        public virtual DbSet<VContractArLoans> VContractArLoans { get; set; }
        public virtual DbSet<VContractArSettlements> VContractArSettlements { get; set; }
        public virtual DbSet<VContractIndividualCostCenters> VContractIndividualCostCenters { get; set; }
        public virtual DbSet<VContractIndividualHtdItems> VContractIndividualHtdItems { get; set; }
        public virtual DbSet<VContractIndividualLoans> VContractIndividualLoans { get; set; }
        public virtual DbSet<VContractIndividualScheduleDetails> VContractIndividualScheduleDetails { get; set; }
        public virtual DbSet<VContractIndividualSettlements> VContractIndividualSettlements { get; set; }
        public virtual DbSet<VContractIndividualUseFunds> VContractIndividualUseFunds { get; set; }
        public virtual DbSet<VContractLoanStandard> VContractLoanStandard { get; set; }
        public virtual DbSet<VCustomerRequestBasic> VCustomerRequestBasic { get; set; }
        public virtual DbSet<VCustomerRequestDetails> VCustomerRequestDetails { get; set; }
        public virtual DbSet<VDailyCleanerInfo> VDailyCleanerInfo { get; set; }
        public virtual DbSet<VDailyCleanerSettlementHouses> VDailyCleanerSettlementHouses { get; set; }
        public virtual DbSet<VDailyCleanerSettlementInfo> VDailyCleanerSettlementInfo { get; set; }
        public virtual DbSet<VDailyCleanerSettlements> VDailyCleanerSettlements { get; set; }
        public virtual DbSet<VDailyCleanerWages> VDailyCleanerWages { get; set; }
        public virtual DbSet<VDblhdCompanies> VDblhdCompanies { get; set; }
        public virtual DbSet<VDbliveContracts> VDbliveContracts { get; set; }
        public virtual DbSet<VDbliveCustomers> VDbliveCustomers { get; set; }
        public virtual DbSet<VDbliveHouseCategories> VDbliveHouseCategories { get; set; }
        public virtual DbSet<VDbliveHouseTypes> VDbliveHouseTypes { get; set; }
        public virtual DbSet<VDbliveHousesNotHandOver> VDbliveHousesNotHandOver { get; set; }
        public virtual DbSet<VDbliveProjects> VDbliveProjects { get; set; }
        public virtual DbSet<VDbliveStreets> VDbliveStreets { get; set; }
        public virtual DbSet<VGetUserRoles> VGetUserRoles { get; set; }
        public virtual DbSet<VGetWorkflow> VGetWorkflow { get; set; }
        public virtual DbSet<VHouseCategory> VHouseCategory { get; set; }
        public virtual DbSet<VHouses> VHouses { get; set; }
        public virtual DbSet<VHousesList> VHousesList { get; set; }
        public virtual DbSet<VHousesTypes> VHousesTypes { get; set; }
        public virtual DbSet<VJobPricing> VJobPricing { get; set; }
        public virtual DbSet<VLoanBanksItems> VLoanBanksItems { get; set; }
        public virtual DbSet<VLoanCostCenters> VLoanCostCenters { get; set; }
        public virtual DbSet<VLoanDisburementItems> VLoanDisburementItems { get; set; }
        public virtual DbSet<VLoanSchedulesInfo> VLoanSchedulesInfo { get; set; }
        public virtual DbSet<VLoanUseFunds> VLoanUseFunds { get; set; }
        public virtual DbSet<VPettyCashSubterms> VPettyCashSubterms { get; set; }
        public virtual DbSet<VPettyCashes> VPettyCashes { get; set; }
        public virtual DbSet<VProjectHouseCategories> VProjectHouseCategories { get; set; }
        public virtual DbSet<VProjects> VProjects { get; set; }
        public virtual DbSet<VReceivedDocuments> VReceivedDocuments { get; set; }
        public virtual DbSet<VReceivedDocumentsCancel> VReceivedDocumentsCancel { get; set; }
        public virtual DbSet<VRedesignFees> VRedesignFees { get; set; }
        public virtual DbSet<VRedesignFloors> VRedesignFloors { get; set; }
        public virtual DbSet<VRedesignedCalculationCancel> VRedesignedCalculationCancel { get; set; }
        public virtual DbSet<VRedesignedCalculationItems> VRedesignedCalculationItems { get; set; }
        public virtual DbSet<VSchedulesDetails> VSchedulesDetails { get; set; }
        public virtual DbSet<VSchedulesStandardLoans> VSchedulesStandardLoans { get; set; }
        public virtual DbSet<VSettlePaymentInvoicesNonstocksDetailCosts> VSettlePaymentInvoicesNonstocksDetailCosts { get; set; }
        public virtual DbSet<VSettlePaymentMaterials> VSettlePaymentMaterials { get; set; }
        public virtual DbSet<VShareCostStandard> VShareCostStandard { get; set; }
        public virtual DbSet<VSubJobUnlinks> VSubJobUnlinks { get; set; }
        public virtual DbSet<VSuppliersBasic> VSuppliersBasic { get; set; }
        public virtual DbSet<VSuppliersContracts> VSuppliersContracts { get; set; }
        public virtual DbSet<VSuppliersContractsBasic> VSuppliersContractsBasic { get; set; }
        public virtual DbSet<VSuppliersItems> VSuppliersItems { get; set; }
        public virtual DbSet<VSuppliersItemsBasic> VSuppliersItemsBasic { get; set; }
        public virtual DbSet<VSuppliersSchedulesPayments> VSuppliersSchedulesPayments { get; set; }
        public virtual DbSet<VSuppliersTerminates> VSuppliersTerminates { get; set; }
        public virtual DbSet<VTestUsers> VTestUsers { get; set; }
        public virtual DbSet<VUserLoggedIn> VUserLoggedIn { get; set; }
        public virtual DbSet<VUsers> VUsers { get; set; }
        public virtual DbSet<VUsersCompanies> VUsersCompanies { get; set; }
        public virtual DbSet<VUsersGroupsPermisssions> VUsersGroupsPermisssions { get; set; }
        public virtual DbSet<VUsersPages> VUsersPages { get; set; }
        public virtual DbSet<VUsersPermissions> VUsersPermissions { get; set; }
        public virtual DbSet<VVendorContractBasic> VVendorContractBasic { get; set; }
        public virtual DbSet<VVendorContracts> VVendorContracts { get; set; }
        public virtual DbSet<VVendorSettlementSubItems> VVendorSettlementSubItems { get; set; }
        public virtual DbSet<VVendors> VVendors { get; set; }
        public virtual DbSet<VVendorsContractItems> VVendorsContractItems { get; set; }
        public virtual DbSet<VVendorsContractsMaster> VVendorsContractsMaster { get; set; }
        public virtual DbSet<VVendorsContractsPaymentTerms> VVendorsContractsPaymentTerms { get; set; }
        public virtual DbSet<VVendorsContractsPriceItems> VVendorsContractsPriceItems { get; set; }
        public virtual DbSet<VVendorsContractsPricing> VVendorsContractsPricing { get; set; }
        public virtual DbSet<VVendorsContractsTerminations> VVendorsContractsTerminations { get; set; }
        public virtual DbSet<VVendorsContractsTerminationsHouses> VVendorsContractsTerminationsHouses { get; set; }
        public virtual DbSet<VVendorsLaborCovers> VVendorsLaborCovers { get; set; }
        public virtual DbSet<VVendorsLaborCoversBasic> VVendorsLaborCoversBasic { get; set; }
        public virtual DbSet<VVendorsLaborCoversBasicFinal> VVendorsLaborCoversBasicFinal { get; set; }
        public virtual DbSet<VVendorsLaborCoversHousesBasic> VVendorsLaborCoversHousesBasic { get; set; }
        public virtual DbSet<VVendorsPenalties> VVendorsPenalties { get; set; }
        public virtual DbSet<VVendorsPenaltiesCovers> VVendorsPenaltiesCovers { get; set; }
        public virtual DbSet<VVendorsPhysicalCheckSubsDetails> VVendorsPhysicalCheckSubsDetails { get; set; }
        public virtual DbSet<VVendorsSettlementLab> VVendorsSettlementLab { get; set; }
        public virtual DbSet<VVendorsSettlementSubBasic> VVendorsSettlementSubBasic { get; set; }
        public virtual DbSet<VVendorsSettlementsSub> VVendorsSettlementsSub { get; set; }
        public virtual DbSet<VWorkflowAction> VWorkflowAction { get; set; }
        public virtual DbSet<VWorkflowNotifications> VWorkflowNotifications { get; set; }
        public virtual DbSet<VWorkflowStatus> VWorkflowStatus { get; set; }
        public virtual DbSet<Vendors> Vendors { get; set; }
        public virtual DbSet<VendorsContracts> VendorsContracts { get; set; }
        public virtual DbSet<VendorsContractsItems> VendorsContractsItems { get; set; }
        public virtual DbSet<VendorsContractsMaster> VendorsContractsMaster { get; set; }
        public virtual DbSet<VendorsContractsPaymentTerms> VendorsContractsPaymentTerms { get; set; }
        public virtual DbSet<VendorsContractsPaymentTermsItems> VendorsContractsPaymentTermsItems { get; set; }
        public virtual DbSet<VendorsContractsPrice> VendorsContractsPrice { get; set; }
        public virtual DbSet<VendorsContractsPriceItems> VendorsContractsPriceItems { get; set; }
        public virtual DbSet<VendorsContractsSettlementInfos> VendorsContractsSettlementInfos { get; set; }
        public virtual DbSet<VendorsContractsTerminations> VendorsContractsTerminations { get; set; }
        public virtual DbSet<VendorsContractsTerminationsHouses> VendorsContractsTerminationsHouses { get; set; }
        public virtual DbSet<VendorsContractsTrackingCostNames> VendorsContractsTrackingCostNames { get; set; }
        public virtual DbSet<VendorsContractsTrackingHouses> VendorsContractsTrackingHouses { get; set; }
        public virtual DbSet<VendorsItems> VendorsItems { get; set; }
        public virtual DbSet<VendorsLaborCovers> VendorsLaborCovers { get; set; }
        public virtual DbSet<VendorsLaborCoversHouses> VendorsLaborCoversHouses { get; set; }
        public virtual DbSet<VendorsLaborCoversItems> VendorsLaborCoversItems { get; set; }
        public virtual DbSet<VendorsLaborCoversRedesignItems> VendorsLaborCoversRedesignItems { get; set; }
        public virtual DbSet<VendorsLaborCoversSchedules> VendorsLaborCoversSchedules { get; set; }
        public virtual DbSet<VendorsPenalties> VendorsPenalties { get; set; }
        public virtual DbSet<VendorsPenaltiesCovers> VendorsPenaltiesCovers { get; set; }
        public virtual DbSet<VendorsPhysicalCheckLabs> VendorsPhysicalCheckLabs { get; set; }
        public virtual DbSet<VendorsPhysicalCheckLabsCovers> VendorsPhysicalCheckLabsCovers { get; set; }
        public virtual DbSet<VendorsPhysicalCheckLabsRemarks> VendorsPhysicalCheckLabsRemarks { get; set; }
        public virtual DbSet<VendorsPhysicalCheckSubs> VendorsPhysicalCheckSubs { get; set; }
        public virtual DbSet<VendorsPhysicalCheckSubsDetails> VendorsPhysicalCheckSubsDetails { get; set; }
        public virtual DbSet<VendorsSettlementLab> VendorsSettlementLab { get; set; }
        public virtual DbSet<VendorsSettlementLabItems> VendorsSettlementLabItems { get; set; }
        public virtual DbSet<VendorsSettlementMethods> VendorsSettlementMethods { get; set; }
        public virtual DbSet<VendorsSettlementSub> VendorsSettlementSub { get; set; }
        public virtual DbSet<VendorsSettlementSubItems> VendorsSettlementSubItems { get; set; }
        public virtual DbSet<VendorsSettlementSubRedesigns> VendorsSettlementSubRedesigns { get; set; }
        public virtual DbSet<VendorsSettlementSubTracking> VendorsSettlementSubTracking { get; set; }
        public virtual DbSet<Workflow> Workflow { get; set; }
        public virtual DbSet<WorkflowApi> WorkflowApi { get; set; }
        public virtual DbSet<WorkflowDetail> WorkflowDetail { get; set; }
        public virtual DbSet<WorkflowHistory> WorkflowHistory { get; set; }
        public virtual DbSet<WorkflowNotifContent> WorkflowNotifContent { get; set; }
        public virtual DbSet<WorkflowNotifContentUrl> WorkflowNotifContentUrl { get; set; }
        public virtual DbSet<WorkflowNotifications> WorkflowNotifications { get; set; }
        public virtual DbSet<WorkflowPeople> WorkflowPeople { get; set; }
        public virtual DbSet<WorkflowRoleLabel> WorkflowRoleLabel { get; set; }
        public virtual DbSet<WorkflowStatus> WorkflowStatus { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("data source=192.168.1.88;initial catalog=ap_db_staging;user id=mayura;password=ARSystem@2021");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Attachments>(entity =>
            {
                entity.Property(e => e.FileExt).IsUnicode(false);

                entity.Property(e => e.FileName).IsUnicode(false);

                entity.Property(e => e.FileRef).IsUnicode(false);
            });

            modelBuilder.Entity<AuditLogs>(entity =>
            {
                entity.Property(e => e.Action).IsUnicode(false);

                entity.Property(e => e.Controller).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);
            });

            modelBuilder.Entity<BankLists>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.AccountName).IsUnicode(false);

                entity.Property(e => e.AccountNumber).IsUnicode(false);

                entity.Property(e => e.BankAccountNo).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.PcvNo).IsUnicode(false);

                entity.Property(e => e.PvRef).IsUnicode(false);
            });

            modelBuilder.Entity<ChartAccounts>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.AccountNameEn).IsUnicode(false);

                entity.Property(e => e.InsertType).IsUnicode(false);
            });

            modelBuilder.Entity<ChequeBookCancel>(entity =>
            {
                entity.Property(e => e.CancelNo).IsUnicode(false);
            });

            modelBuilder.Entity<ChequeBookUsers>(entity =>
            {
                entity.Property(e => e.UserId).IsFixedLength();
            });

            modelBuilder.Entity<Companies>(entity =>
            {
                entity.Property(e => e.AccountThreatmentType).IsUnicode(false);

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.CompanyName).IsUnicode(false);
            });

            modelBuilder.Entity<CompanyCostCenters>(entity =>
            {
                entity.Property(e => e.CostCenter).IsUnicode(false);

                entity.Property(e => e.ShareType).IsUnicode(false);
            });

            modelBuilder.Entity<ContractArAdminFees>(entity =>
            {
                entity.Property(e => e.MultipleWith).IsUnicode(false);
            });

            modelBuilder.Entity<ContractArDisbursments>(entity =>
            {
                entity.Property(e => e.CardNo).IsUnicode(false);

                entity.Property(e => e.LekPhorPor).IsUnicode(false);

                entity.Property(e => e.LoanNo).IsUnicode(false);
            });

            modelBuilder.Entity<ContractArLoans>(entity =>
            {
                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.LoanBankRef).IsUnicode(false);

                entity.Property(e => e.LoanPhaseNo).IsUnicode(false);
            });

            modelBuilder.Entity<ContractArSettlements>(entity =>
            {
                entity.Property(e => e.BankAccountNumber).IsUnicode(false);
            });

            modelBuilder.Entity<ContractIndividualHtdItems>(entity =>
            {
                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.TotalSize).IsUnicode(false);

                entity.Property(e => e.Type).IsFixedLength();
            });

            modelBuilder.Entity<ContractIndividualLoans>(entity =>
            {
                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.PhaseNo).IsUnicode(false);
            });

            modelBuilder.Entity<ContractIndividualSettlements>(entity =>
            {
                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.PayChequeTo).IsFixedLength();
            });

            modelBuilder.Entity<ContractStandardLoans>(entity =>
            {
                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.LoanBankRef).IsUnicode(false);
            });

            modelBuilder.Entity<CostTypes>(entity =>
            {
                entity.HasKey(e => new { e.Id, e.Type, e.Shortcut });

                entity.Property(e => e.Shortcut).IsUnicode(false);
            });

            modelBuilder.Entity<CustomerBehaviorTypes>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Ordering).HasDefaultValueSql("((0))");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<DailyCleanerInfo>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Contact).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.Nid).IsUnicode(false);
            });

            modelBuilder.Entity<DailyCleanerSettle>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);
            });

            modelBuilder.Entity<DailyCleanerWages>(entity =>
            {
                entity.Property(e => e.PaymentMethod).IsUnicode(false);

                entity.Property(e => e.PositionEn).IsUnicode(false);
            });

            modelBuilder.Entity<DimAccountThreatmentTypes>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccountThreatmentType).IsUnicode(false);
            });

            modelBuilder.Entity<DimAccountTypes>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccountType).IsUnicode(false);
            });

            modelBuilder.Entity<ErrorLogs>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.CreatedAt)
                    .IsRowVersion()
                    .IsConcurrencyToken();

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Ip).IsUnicode(false);

                entity.Property(e => e.LogType).IsUnicode(false);
            });

            modelBuilder.Entity<FileLinks>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Url).IsUnicode(false);
            });

            modelBuilder.Entity<ItemType>(entity =>
            {
                entity.Property(e => e.ItemTypeEn).IsUnicode(false);
            });

            modelBuilder.Entity<LoanBanks>(entity =>
            {
                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.BankShort).IsUnicode(false);
            });

            modelBuilder.Entity<LoanDisburementItems>(entity =>
            {
                entity.Property(e => e.LoanPhaseNo).IsUnicode(false);

                entity.Property(e => e.SettlementType).IsUnicode(false);
            });

            modelBuilder.Entity<LoanHtdItems>(entity =>
            {
                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.Ownership).IsUnicode(false);

                entity.Property(e => e.TotalSize).IsUnicode(false);
            });

            modelBuilder.Entity<LoanReschedules>(entity =>
            {
                entity.Property(e => e.LoanBankRef).IsUnicode(false);

                entity.Property(e => e.RescheduleCode).IsUnicode(false);
            });

            modelBuilder.Entity<LoanSchedulesInfo>(entity =>
            {
                entity.Property(e => e.LoanPhaseNo).IsUnicode(false);

                entity.Property(e => e.ScheduleNumber).IsUnicode(false);
            });

            modelBuilder.Entity<LoanTypes>(entity =>
            {
                entity.Property(e => e.LoanCode).IsUnicode(false);
            });

            modelBuilder.Entity<PayOffLoanRequests>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.FinalType).IsUnicode(false);
            });

            modelBuilder.Entity<PettyCashSubterms>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);
            });

            modelBuilder.Entity<PettyCashes>(entity =>
            {
                entity.Property(e => e.PvRef).IsUnicode(false);
            });

            modelBuilder.Entity<ReceivedDocuments>(entity =>
            {
                entity.Property(e => e.DocumentCode).IsUnicode(false);

                entity.Property(e => e.DocumentType).IsUnicode(false);

                entity.Property(e => e.InvoiceNo).IsUnicode(false);
            });

            modelBuilder.Entity<ReceivedDocumentsCancel>(entity =>
            {
                entity.Property(e => e.DocumentCode).IsUnicode(false);
            });

            modelBuilder.Entity<RedesignFloors>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Status).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<RedesignJobs>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Status).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<SettlePaymentInvoices>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.InvoiceNo).IsUnicode(false);

                entity.Property(e => e.PoNo).IsUnicode(false);
            });

            modelBuilder.Entity<SettlePaymentInvoicesDetail>(entity =>
            {
                entity.Property(e => e.Uom).IsUnicode(false);
            });

            modelBuilder.Entity<SettlePaymentInvoicesNonstocks>(entity =>
            {
                entity.Property(e => e.ContractNo).IsUnicode(false);

                entity.Property(e => e.InvoiceNo).IsUnicode(false);
            });

            modelBuilder.Entity<SettlePaymentInvoicesNonstocksDetail>(entity =>
            {
                entity.Property(e => e.ShareCostType).IsUnicode(false);

                entity.Property(e => e.Uom).IsUnicode(false);
            });

            modelBuilder.Entity<SettlePaymentMaterials>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.SettleMonths).IsUnicode(false);

                entity.Property(e => e.SettlePaymentCode).IsUnicode(false);
            });

            modelBuilder.Entity<Suppliers>(entity =>
            {
                entity.HasIndex(e => e.SupplierCode)
                    .HasName("IX_suppliers");

                entity.Property(e => e.CollectorNumber).IsUnicode(false);

                entity.Property(e => e.CollectorTelegram).IsUnicode(false);

                entity.Property(e => e.ContactNumber).IsUnicode(false);

                entity.Property(e => e.ContactTelegram).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NameOnCheque).IsUnicode(false);

                entity.Property(e => e.Nid).IsUnicode(false);

                entity.Property(e => e.Normal).IsUnicode(false);

                entity.Property(e => e.PaymentCollector).IsUnicode(false);

                entity.Property(e => e.Remark).IsUnicode(false);

                entity.Property(e => e.SupplierCode).IsUnicode(false);

                entity.Property(e => e.SupplierLocation).IsUnicode(false);

                entity.Property(e => e.SupplierType).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersContracts>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPo).IsUnicode(false);

                entity.Property(e => e.PaymentMethod).IsUnicode(false);

                entity.Property(e => e.SupplierName).IsUnicode(false);

                entity.Property(e => e.TermPay).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersContractsItemsSub>(entity =>
            {
                entity.Property(e => e.Uom).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersContractsTerminates>(entity =>
            {
                entity.Property(e => e.ContractPo).IsUnicode(false);

                entity.Property(e => e.TerminateCode).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersItems>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ItemCode).IsUnicode(false);

                entity.Property(e => e.UomEn).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersItemsTypes>(entity =>
            {
                entity.Property(e => e.ItemDesc).IsUnicode(false);

                entity.Property(e => e.ItemType).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersSchedulesPaid>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.SupplierNameEn).IsUnicode(false);

                entity.Property(e => e.TermPay).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersSchedulesPaidCosts>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Status).IsFixedLength();
            });

            modelBuilder.Entity<SuppliersSchedulesPayments>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.SchedulePaymentCode).IsUnicode(false);

                entity.Property(e => e.ShareCostType).IsUnicode(false);

                entity.Property(e => e.TermPay).IsUnicode(false);
            });

            modelBuilder.Entity<SuppliersSchedulesPaymentsDetails>(entity =>
            {
                entity.Property(e => e.PvRef).IsUnicode(false);

                entity.Property(e => e.Type).IsUnicode(false);
            });

            modelBuilder.Entity<TelegramLog>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.ActionLabel).IsUnicode(false);

                entity.Property(e => e.Comment).IsUnicode(false);

                entity.Property(e => e.Content1).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseType).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Project).IsUnicode(false);

                entity.Property(e => e.TelegramContent).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);

                entity.Property(e => e.UserName).IsUnicode(false);

                entity.Property(e => e.WorkflowName).IsUnicode(false);
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.Property(e => e.Designation).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.EmpId).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.Password).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<UsersCompanies>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.CompanyId, e.Status });

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UsersDepartments>(entity =>
            {
                entity.Property(e => e.CostCenter).IsUnicode(false);

                entity.Property(e => e.Department).IsUnicode(false);
            });

            modelBuilder.Entity<UsersGroupsPermissions>(entity =>
            {
                entity.HasKey(e => new { e.UserGroupId, e.UserPermissionId });

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<UsersNotifySessions>(entity =>
            {
                entity.Property(e => e.SignalRSession).IsUnicode(false);
            });

            modelBuilder.Entity<UsersPages>(entity =>
            {
                entity.Property(e => e.IconName).IsUnicode(false);

                entity.Property(e => e.PageName).IsUnicode(false);

                entity.Property(e => e.PageTitle).IsUnicode(false);

                entity.Property(e => e.PageType).IsUnicode(false);

                entity.Property(e => e.PageUrl).IsUnicode(false);
            });

            modelBuilder.Entity<UsersPermissions>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Main).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Sub).IsUnicode(false);
            });

            modelBuilder.Entity<UsersPositions>(entity =>
            {
                entity.Property(e => e.Position).IsUnicode(false);
            });

            modelBuilder.Entity<UsersRoles>(entity =>
            {
                entity.Property(e => e.Auth).IsUnicode(false);

                entity.Property(e => e.IsDynamic).HasDefaultValueSql("((0))");

                entity.Property(e => e.RoleDescription).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);
            });

            modelBuilder.Entity<VAffectedRow>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_affected_row");
            });

            modelBuilder.Entity<VArchRedesignHouses>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_arch_redesign_houses");

                entity.Property(e => e.RedesignType).IsUnicode(false);

                entity.Property(e => e.RedesignedCode).IsUnicode(false);

                entity.Property(e => e.SubJobCode).IsUnicode(false);
            });

            modelBuilder.Entity<VAttachmentList>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_attachment_list");

                entity.Property(e => e.FileExt).IsUnicode(false);

                entity.Property(e => e.FileName).IsUnicode(false);

                entity.Property(e => e.FileRef).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);
            });

            modelBuilder.Entity<VBanks>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_banks");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.BankShort).IsUnicode(false);
            });

            modelBuilder.Entity<VChartAccounts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_chart_accounts");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.AccountNameEn).IsUnicode(false);

                entity.Property(e => e.AccountType).IsUnicode(false);

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.CreatedByName).IsUnicode(false);

                entity.Property(e => e.InsertType).IsUnicode(false);

                entity.Property(e => e.StatusName).IsUnicode(false);

                entity.Property(e => e.SubAccountOf).IsUnicode(false);

                entity.Property(e => e.UpdatedByName).IsUnicode(false);
            });

            modelBuilder.Entity<VChequeBook>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_cheque_book");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.BankShort).IsUnicode(false);
            });

            modelBuilder.Entity<VChequeBookCancel>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_cheque_book_cancel");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.BankShort).IsUnicode(false);

                entity.Property(e => e.CancelNo).IsUnicode(false);
            });

            modelBuilder.Entity<VChequeBookSubterms>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_cheque_book_subterms");

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VChequeBookUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_cheque_book_users");

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.UserId).IsFixedLength();

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VCompanyCostCenter>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_company_cost_center");

                entity.Property(e => e.AccountThreatmentType).IsUnicode(false);

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.CompanyName).IsUnicode(false);

                entity.Property(e => e.CostCenter).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);
            });

            modelBuilder.Entity<VContractAdminFees>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_admin_fees");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.MultipleWith).IsUnicode(false);
            });

            modelBuilder.Entity<VContractArDisbursments>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_disbursments");

                entity.Property(e => e.CardNo).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LekPhorPor).IsUnicode(false);

                entity.Property(e => e.LoanNo).IsUnicode(false);
            });

            modelBuilder.Entity<VContractArDisbursmentsCostCenters>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_disbursments_cost_centers");
            });

            modelBuilder.Entity<VContractArDisbursmentsHtds>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_disbursments_htds");
            });

            modelBuilder.Entity<VContractArDisbursmentsUseFunds>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_disbursments_use_funds");
            });

            modelBuilder.Entity<VContractArDocumentRequirements>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_document_requirements");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VContractArLoans>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_loans");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.BankShort).IsUnicode(false);

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.LoanBankRef).IsUnicode(false);

                entity.Property(e => e.LoanPhaseNo).IsUnicode(false);
            });

            modelBuilder.Entity<VContractArSettlements>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_ar_settlements");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VContractIndividualCostCenters>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_individual_cost_centers");
            });

            modelBuilder.Entity<VContractIndividualHtdItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_individual_htd_items");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.TotalSize).IsUnicode(false);

                entity.Property(e => e.Type).IsFixedLength();
            });

            modelBuilder.Entity<VContractIndividualLoans>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_individual_loans");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.PhaseNo).IsUnicode(false);
            });

            modelBuilder.Entity<VContractIndividualScheduleDetails>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_individual_schedule_details");
            });

            modelBuilder.Entity<VContractIndividualSettlements>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_individual_settlements");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.PayChequeTo).IsFixedLength();
            });

            modelBuilder.Entity<VContractIndividualUseFunds>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_individual_use_funds");
            });

            modelBuilder.Entity<VContractLoanStandard>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_loan_standard");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.LoanBankRef).IsUnicode(false);
            });

            modelBuilder.Entity<VCustomerRequestBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_customer_request_basic");

                entity.Property(e => e.NationalId1).IsUnicode(false);

                entity.Property(e => e.NationalId2).IsUnicode(false);

                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.Phone1).IsUnicode(false);

                entity.Property(e => e.Phone2).IsUnicode(false);

                entity.Property(e => e.RequestCode).IsUnicode(false);
            });

            modelBuilder.Entity<VCustomerRequestDetails>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_customer_request_details");

                entity.Property(e => e.Type).IsUnicode(false);
            });

            modelBuilder.Entity<VDailyCleanerInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_daily_cleaner_info");

                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Contact).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.Nid).IsUnicode(false);

                entity.Property(e => e.PositionEn).IsUnicode(false);
            });

            modelBuilder.Entity<VDailyCleanerSettlementHouses>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_daily_cleaner_settlement_houses");

                entity.Property(e => e.Number).IsUnicode(false);
            });

            modelBuilder.Entity<VDailyCleanerSettlementInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_daily_cleaner_settlement_info");

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.PositionEn).IsUnicode(false);
            });

            modelBuilder.Entity<VDailyCleanerSettlements>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_daily_cleaner_settlements");

                entity.Property(e => e.Code).IsUnicode(false);
            });

            modelBuilder.Entity<VDailyCleanerWages>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_daily_cleaner_wages");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.PaymentMethod).IsUnicode(false);

                entity.Property(e => e.PositionEn).IsUnicode(false);
            });

            modelBuilder.Entity<VDblhdCompanies>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblhd_companies");

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.ContractNo).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.RegisterNo).IsUnicode(false);

                entity.Property(e => e.VatNo).IsUnicode(false);
            });

            modelBuilder.Entity<VDbliveContracts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_contracts");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.MergedHouses).IsUnicode(false);
            });

            modelBuilder.Entity<VDbliveCustomers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_customers");

                entity.Property(e => e.ContactType).IsUnicode(false);

                entity.Property(e => e.CustomerType).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.Gender).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.IdType).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.Other).IsUnicode(false);

                entity.Property(e => e.PhoneCall).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);

                entity.Property(e => e.TelegramNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VDbliveHouseCategories>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_house_categories");

                entity.Property(e => e.Desc).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VDbliveHouseTypes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_house_types");

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);

                entity.Property(e => e.LandLength).IsUnicode(false);

                entity.Property(e => e.LandWidth).IsUnicode(false);
            });

            modelBuilder.Entity<VDbliveHousesNotHandOver>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_houses_not_hand_over");

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VDbliveProjects>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_projects");
            });

            modelBuilder.Entity<VDbliveStreets>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_dblive_streets");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VGetUserRoles>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_get_user_roles");

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.Position).IsUnicode(false);

                entity.Property(e => e.RoleCreatedAt).IsUnicode(false);

                entity.Property(e => e.RoleCreatedBy).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VGetWorkflow>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_getWorkflow");

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);
            });

            modelBuilder.Entity<VHouseCategory>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_house_category");

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VHouses>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_houses");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);
            });

            modelBuilder.Entity<VHousesList>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_houses_list");

                entity.Property(e => e.Billercode).IsUnicode(false);

                entity.Property(e => e.Block).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LandLength).IsUnicode(false);

                entity.Property(e => e.LandWidth).IsUnicode(false);

                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.Payproaccid).IsUnicode(false);

                entity.Property(e => e.Payproref).IsUnicode(false);

                entity.Property(e => e.Phase).IsUnicode(false);

                entity.Property(e => e.RoadType).IsUnicode(false);
            });

            modelBuilder.Entity<VHousesTypes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_houses_types");

                entity.Property(e => e.Number).IsUnicode(false);
            });

            modelBuilder.Entity<VJobPricing>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_job_pricing");

                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.JopPricingCode).IsUnicode(false);

                entity.Property(e => e.StatusName).IsUnicode(false);
            });

            modelBuilder.Entity<VLoanBanksItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_loan_banks_items");

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankNameEn).IsUnicode(false);

                entity.Property(e => e.BankShort).IsUnicode(false);
            });

            modelBuilder.Entity<VLoanCostCenters>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_loan_cost_centers");
            });

            modelBuilder.Entity<VLoanDisburementItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_loan_disburement_items");

                entity.Property(e => e.BankShort).IsUnicode(false);

                entity.Property(e => e.LoanPhaseNo).IsUnicode(false);

                entity.Property(e => e.SettlementType).IsUnicode(false);
            });

            modelBuilder.Entity<VLoanSchedulesInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_loan_schedules_info");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LoanPhaseNo).IsUnicode(false);

                entity.Property(e => e.ScheduleNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VLoanUseFunds>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_loan_use_funds");
            });

            modelBuilder.Entity<VPettyCashSubterms>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_petty_cash_subterms");

                entity.Property(e => e.AccountCode).IsUnicode(false);
            });

            modelBuilder.Entity<VPettyCashes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_petty_cashes");

                entity.Property(e => e.BankShort).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.PvRef).IsUnicode(false);

                entity.Property(e => e.SettlementCode).IsUnicode(false);
            });

            modelBuilder.Entity<VProjectHouseCategories>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_project_house_categories");
            });

            modelBuilder.Entity<VProjects>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_projects");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VReceivedDocuments>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_received_documents");

                entity.Property(e => e.DocumentCode).IsUnicode(false);

                entity.Property(e => e.DocumentType).IsUnicode(false);

                entity.Property(e => e.InvoiceNo).IsUnicode(false);

                entity.Property(e => e.VendorCode).IsUnicode(false);

                entity.Property(e => e.VendorName).IsUnicode(false);
            });

            modelBuilder.Entity<VReceivedDocumentsCancel>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_received_documents_cancel");

                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.DocumentCode).IsUnicode(false);

                entity.Property(e => e.DocumentType).IsUnicode(false);

                entity.Property(e => e.InvoiceNo).IsUnicode(false);

                entity.Property(e => e.VendorCode).IsUnicode(false);

                entity.Property(e => e.VendorName).IsUnicode(false);
            });

            modelBuilder.Entity<VRedesignFees>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_redesign_fees");
            });

            modelBuilder.Entity<VRedesignFloors>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_redesign_floors");
            });

            modelBuilder.Entity<VRedesignedCalculationCancel>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_redesigned_calculation_cancel");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.Project).IsUnicode(false);

                entity.Property(e => e.RedesignedCancelCode).IsUnicode(false);

                entity.Property(e => e.RedesingedType).IsUnicode(false);

                entity.Property(e => e.Tel1).IsUnicode(false);

                entity.Property(e => e.Tel2).IsUnicode(false);
            });

            modelBuilder.Entity<VRedesignedCalculationItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_redesigned_calculation_items");

                entity.Property(e => e.JobCode).IsUnicode(false);

                entity.Property(e => e.RedesingedFloor).IsUnicode(false);

                entity.Property(e => e.SubJobCode).IsUnicode(false);
            });

            modelBuilder.Entity<VSchedulesDetails>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_schedules_details");
            });

            modelBuilder.Entity<VSchedulesStandardLoans>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_schedules_standard_loans");

                entity.Property(e => e.BankShort).IsUnicode(false);
            });

            modelBuilder.Entity<VSettlePaymentInvoicesNonstocksDetailCosts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_settle_payment_invoices_nonstocks_detail_costs");
            });

            modelBuilder.Entity<VSettlePaymentMaterials>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_settle_payment_materials");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ItemType).IsUnicode(false);

                entity.Property(e => e.SettleMonths).IsUnicode(false);

                entity.Property(e => e.SettlePaymentCode).IsUnicode(false);

                entity.Property(e => e.SupplierNameEn).IsUnicode(false);
            });

            modelBuilder.Entity<VShareCostStandard>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_share_cost_standard");
            });

            modelBuilder.Entity<VSubJobUnlinks>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_sub_job_unlinks");

                entity.Property(e => e.JobCode).IsUnicode(false);

                entity.Property(e => e.SubJobCode).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.SupplierCode).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersContracts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_contracts");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPo).IsUnicode(false);

                entity.Property(e => e.ItemType).IsUnicode(false);

                entity.Property(e => e.PaymentMethod).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.SupplierName).IsUnicode(false);

                entity.Property(e => e.SupplierNameEn).IsUnicode(false);

                entity.Property(e => e.SupplierNid).IsUnicode(false);

                entity.Property(e => e.TermPay).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersContractsBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_contracts_basic");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPo).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.SupplierName).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_items");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ItemCode).IsUnicode(false);

                entity.Property(e => e.ItemType).IsUnicode(false);

                entity.Property(e => e.UomEn).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersItemsBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_items_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.ItemCode).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersSchedulesPayments>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_schedules_payments");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ItemType).IsUnicode(false);

                entity.Property(e => e.SchedulePaymentCode).IsUnicode(false);

                entity.Property(e => e.ShareCostType).IsUnicode(false);

                entity.Property(e => e.SupplierNameEn).IsUnicode(false);

                entity.Property(e => e.TermPay).IsUnicode(false);
            });

            modelBuilder.Entity<VSuppliersTerminates>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_suppliers_terminates");

                entity.Property(e => e.ContactNumber).IsUnicode(false);

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPo).IsUnicode(false);

                entity.Property(e => e.Nid).IsUnicode(false);

                entity.Property(e => e.SupplierEn).IsUnicode(false);

                entity.Property(e => e.TermPay).IsUnicode(false);

                entity.Property(e => e.TerminateCode).IsUnicode(false);
            });

            modelBuilder.Entity<VTestUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_test_users");

                entity.Property(e => e.Address).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.TestName).IsUnicode(false);
            });

            modelBuilder.Entity<VUserLoggedIn>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_user_logged_in");

                entity.Property(e => e.Auth).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.UserRole).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_users");

                entity.Property(e => e.Designation).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VUsersCompanies>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_users_companies");

                entity.Property(e => e.Company).IsUnicode(false);
            });

            modelBuilder.Entity<VUsersGroupsPermisssions>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_users_groups_permisssions");

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<VUsersPages>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_users_pages");

                entity.Property(e => e.Icon).IsUnicode(false);

                entity.Property(e => e.PageName).IsUnicode(false);

                entity.Property(e => e.Title).IsUnicode(false);

                entity.Property(e => e.Type).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);
            });

            modelBuilder.Entity<VUsersPermissions>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_users_permissions");

                entity.Property(e => e.Company).IsUnicode(false);

                entity.Property(e => e.MainModule).IsUnicode(false);

                entity.Property(e => e.Permission).IsUnicode(false);

                entity.Property(e => e.SubModule).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorContractBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendor_contract_basic");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPurchaseId).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.TermPayment).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorContracts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendor_contracts");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPurchaseId).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NidNo).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.Shortcut).IsUnicode(false);

                entity.Property(e => e.StatusName).IsUnicode(false);

                entity.Property(e => e.TermPayment).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorSettlementSubItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendor_settlement_sub_items");

                entity.Property(e => e.ClaimId).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VVendors>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors");

                entity.Property(e => e.AccountNameEn2).IsUnicode(false);

                entity.Property(e => e.AccountNumber2).IsUnicode(false);

                entity.Property(e => e.CardNo2).IsUnicode(false);

                entity.Property(e => e.Currency2).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NidNo).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);

                entity.Property(e => e.PhoneNumberUpdate).IsUnicode(false);

                entity.Property(e => e.SettlementPhone1).IsUnicode(false);

                entity.Property(e => e.SettlementPhone2).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);

                entity.Property(e => e.VendorCode).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsContractItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contract_items");
            });

            modelBuilder.Entity<VVendorsContractsMaster>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contracts_master");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseRedo).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsContractsPaymentTerms>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contracts_payment_terms");
            });

            modelBuilder.Entity<VVendorsContractsPriceItems>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contracts_price_items");
            });

            modelBuilder.Entity<VVendorsContractsPricing>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contracts_pricing");
            });

            modelBuilder.Entity<VVendorsContractsTerminations>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contracts_terminations");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractTerminateCode).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NidNo).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsContractsTerminationsHouses>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_contracts_terminations_houses");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PaidStatus).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsLaborCovers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_labor_covers");

                entity.Property(e => e.ClaimHouses).IsUnicode(false);

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.SiteAreaEngineer).IsUnicode(false);

                entity.Property(e => e.SiteEngineer).IsUnicode(false);

                entity.Property(e => e.VendorName).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsLaborCoversBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_labor_covers_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VVendorsLaborCoversBasicFinal>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_labor_covers_basic_final");

                entity.Property(e => e.CoverCode).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsLaborCoversHousesBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_labor_covers_houses_basic");

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.CoverCode).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsPenalties>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_penalties");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.PaymentMethod).IsUnicode(false);

                entity.Property(e => e.PenaltyCode).IsUnicode(false);

                entity.Property(e => e.SettlementCode).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsPenaltiesCovers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_penalties_covers");
            });

            modelBuilder.Entity<VVendorsPhysicalCheckSubsDetails>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_physical_check_subs_details");

                entity.Property(e => e.ClaimTime).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsSettlementLab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_settlement_lab");
            });

            modelBuilder.Entity<VVendorsSettlementSubBasic>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_settlement_sub_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.SettlementCode).IsUnicode(false);
            });

            modelBuilder.Entity<VVendorsSettlementsSub>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_vendors_settlements_sub");

                entity.Property(e => e.ContractPurchaseId).IsUnicode(false);

                entity.Property(e => e.SettlementCode).IsUnicode(false);

                entity.Property(e => e.VendorNameEn).IsUnicode(false);
            });

            modelBuilder.Entity<VWorkflowAction>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_workflow_action");

                entity.Property(e => e.BtnAction).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);

                entity.Property(e => e.WorkflowName).IsUnicode(false);
            });

            modelBuilder.Entity<VWorkflowNotifications>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_workflow_notifications");

                entity.Property(e => e.NotifTitle).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);
            });

            modelBuilder.Entity<VWorkflowStatus>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_workflow_status");

                entity.Property(e => e.StatusName).IsUnicode(false);
            });

            modelBuilder.Entity<Vendors>(entity =>
            {
                entity.Property(e => e.AccountNameEn2).IsUnicode(false);

                entity.Property(e => e.AccountNumber2).IsUnicode(false);

                entity.Property(e => e.CardNo2).IsUnicode(false);

                entity.Property(e => e.Currency2).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.IsEditable).HasDefaultValueSql("((1))");

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NidNo).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);

                entity.Property(e => e.PhoneNumberUpdate).IsUnicode(false);

                entity.Property(e => e.SettlementPhone1).IsUnicode(false);

                entity.Property(e => e.SettlementPhone2).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);

                entity.Property(e => e.VendorCode).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsContracts>(entity =>
            {
                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.ContractPurchaseId).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NidNo).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.TermPayment).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsContractsSettlementInfos>(entity =>
            {
                entity.Property(e => e.AttachmentRef).IsUnicode(false);

                entity.Property(e => e.BankAccountNameEn).IsUnicode(false);

                entity.Property(e => e.BankAccountNumber).IsUnicode(false);

                entity.Property(e => e.BankName).IsUnicode(false);

                entity.Property(e => e.CardNo).IsUnicode(false);

                entity.Property(e => e.Currency).IsUnicode(false);

                entity.Property(e => e.PaymentCollector).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.SettlementMethod).IsUnicode(false);

                entity.Property(e => e.SettlementOption).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsContractsTerminations>(entity =>
            {
                entity.Property(e => e.ContractTerminateCode).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsContractsTerminationsHouses>(entity =>
            {
                entity.Property(e => e.PaidStatus).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsContractsTrackingCostNames>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.VendorId, e.MasterId, e.ItemId, e.Status })
                    .HasName("PK_vendors_contracts_tracking_cost_names_1");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VendorsContractsTrackingHouses>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.VendorId, e.MasterId, e.HouseId, e.ItemId, e.Status });

                entity.Property(e => e.ClaimTime).HasDefaultValueSql("((0))");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.TotalClaimPerc).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<VendorsItems>(entity =>
            {
                entity.Property(e => e.CogsAccount).IsUnicode(false);

                entity.Property(e => e.ItemCode).IsUnicode(false);

                entity.Property(e => e.JobCode).IsUnicode(false);

                entity.Property(e => e.VendorCategory).IsUnicode(false);

                entity.Property(e => e.VendorShort).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsLaborCovers>(entity =>
            {
                entity.Property(e => e.ClaimHouses).IsUnicode(false);

                entity.Property(e => e.SiteAreaEngineer).IsUnicode(false);

                entity.Property(e => e.SiteEngineer).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsLaborCoversHouses>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.ContractCode).IsUnicode(false);

                entity.Property(e => e.CoverCode).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VendorsLaborCoversRedesignItems>(entity =>
            {
                entity.Property(e => e.RedesignedCode).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsLaborCoversSchedules>(entity =>
            {
                entity.Property(e => e.ClaimLink).IsUnicode(false);

                entity.Property(e => e.PaymentVoucherId).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsPenalties>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.PaymentMethod).IsUnicode(false);

                entity.Property(e => e.PenaltyCode).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsPhysicalCheckLabs>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsPhysicalCheckLabsRemarks>(entity =>
            {
                entity.Property(e => e.RemarkShort).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsPhysicalCheckSubsDetails>(entity =>
            {
                entity.Property(e => e.ClaimTime).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsSettlementSub>(entity =>
            {
                entity.Property(e => e.ClaimTime).HasDefaultValueSql("((1))");

                entity.Property(e => e.ContractPurchaseId).IsUnicode(false);

                entity.Property(e => e.SettlementCode).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsSettlementSubItems>(entity =>
            {
                entity.Property(e => e.ClaimId).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsSettlementSubRedesigns>(entity =>
            {
                entity.Property(e => e.RedesignedCode).IsUnicode(false);
            });

            modelBuilder.Entity<VendorsSettlementSubTracking>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<Workflow>(entity =>
            {
                entity.HasIndex(e => e.Id)
                    .HasName("IX_workflow")
                    .IsUnique();

                entity.Property(e => e.FormUrl)
                    .IsUnicode(false)
                    .HasComment("front-end link URI");

                entity.Property(e => e.Indexing)
                    .HasDefaultValueSql("((0))")
                    .HasComment("related the same table have different threshold");

                entity.Property(e => e.WorkflowName).IsUnicode(false);

                entity.Property(e => e.WorkflowTitle).IsUnicode(false);

                entity.Property(e => e.WorkflowUuid).HasDefaultValueSql("(newid())");
            });

            modelBuilder.Entity<WorkflowApi>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ApiName).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);
            });

            modelBuilder.Entity<WorkflowDetail>(entity =>
            {
                entity.HasIndex(e => e.WfDetailUuid)
                    .HasName("IX_workflow_detail")
                    .IsUnique();

                entity.Property(e => e.ActionLabel).IsUnicode(false);

                entity.Property(e => e.BtnAction).IsUnicode(false);

                entity.Property(e => e.CurLabel).IsUnicode(false);

                entity.Property(e => e.ExecuteSp).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);

                entity.Property(e => e.WfDetailUuid).HasDefaultValueSql("(newid())");

                entity.Property(e => e.WorkflowLabel).IsUnicode(false);

                entity.Property(e => e.WorkflowName).IsUnicode(false);
            });

            modelBuilder.Entity<WorkflowHistory>(entity =>
            {
                entity.HasIndex(e => new { e.WorkflowId, e.RefId })
                    .HasName("IX_workflow_history");

                entity.Property(e => e.Comment).IsUnicode(false);
            });

            modelBuilder.Entity<WorkflowNotifContent>(entity =>
            {
                entity.Property(e => e.EmailContent).IsUnicode(false);

                entity.Property(e => e.NotifCc).IsUnicode(false);

                entity.Property(e => e.NotifFunction).IsUnicode(false);

                entity.Property(e => e.NotifSubject).IsUnicode(false);

                entity.Property(e => e.NotifTo).IsUnicode(false);

                entity.Property(e => e.NotifType).IsUnicode(false);

                entity.Property(e => e.ParamJson).IsUnicode(false);
            });

            modelBuilder.Entity<WorkflowNotifContentUrl>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.BaseUrl).IsUnicode(false);
            });

            modelBuilder.Entity<WorkflowNotifications>(entity =>
            {
                entity.Property(e => e.NotifTitle).IsUnicode(false);

                entity.Property(e => e.NotifType).HasComment("1=To do, 2=Inform");
            });

            modelBuilder.Entity<WorkflowPeople>(entity =>
            {
                entity.HasIndex(e => new { e.WorkflowId, e.RefId })
                    .HasName("IX_workflow_people");
            });

            modelBuilder.Entity<WorkflowRoleLabel>(entity =>
            {
                entity.Property(e => e.RoleName).IsUnicode(false);
            });

            modelBuilder.Entity<WorkflowStatus>(entity =>
            {
                entity.Property(e => e.StatusName).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
