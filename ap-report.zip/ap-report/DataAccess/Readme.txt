﻿



Scaffold-DbContext "data source=192.168.1.88;initial catalog=ap_db_staging;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities\AP -Schemas dbo  -contextdir DBContexts -Context ApDBContext -DataAnnotations -Force