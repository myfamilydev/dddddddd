﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("daily_cleaner_wages")]
    public partial class DailyCleanerWages
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("position_en")]
        [StringLength(100)]
        public string PositionEn { get; set; }
        [Column("position_kh")]
        [StringLength(100)]
        public string PositionKh { get; set; }
        [Column("daily_wage_fee", TypeName = "decimal(15, 2)")]
        public decimal? DailyWageFee { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("payment_method")]
        [StringLength(50)]
        public string PaymentMethod { get; set; }
        [Column("source")]
        [StringLength(100)]
        public string Source { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
