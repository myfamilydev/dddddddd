﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VBanks
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("bank_short")]
        [StringLength(50)]
        public string BankShort { get; set; }
        [Column("bank_name_kh")]
        [StringLength(200)]
        public string BankNameKh { get; set; }
        [Column("bank_name_en")]
        [StringLength(200)]
        public string BankNameEn { get; set; }
        [Column("bank_location_id")]
        public int? BankLocationId { get; set; }
        [Column("bank_account_name")]
        [StringLength(200)]
        public string BankAccountName { get; set; }
        [Column("bank_account_number")]
        [StringLength(100)]
        public string BankAccountNumber { get; set; }
        [Column("location")]
        [StringLength(100)]
        public string Location { get; set; }
        [Column("description")]
        [StringLength(100)]
        public string Description { get; set; }
    }
}
