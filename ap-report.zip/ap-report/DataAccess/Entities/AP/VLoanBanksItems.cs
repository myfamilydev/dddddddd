﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VLoanBanksItems
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("currency_id")]
        public int? CurrencyId { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("effective_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? EffectiveInterestRate { get; set; }
        [Column("interest_nature", TypeName = "decimal(15, 2)")]
        public decimal? InterestNature { get; set; }
        [Column("change_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? ChangeInterestRate { get; set; }
        [Column("bank_short")]
        [StringLength(50)]
        public string BankShort { get; set; }
        [Column("bank_name_kh")]
        [StringLength(200)]
        public string BankNameKh { get; set; }
        [Column("bank_name_en")]
        [StringLength(200)]
        public string BankNameEn { get; set; }
        [Column("bank_location_id")]
        public int? BankLocationId { get; set; }
        [Column("bank_account_name")]
        [StringLength(200)]
        public string BankAccountName { get; set; }
        [Column("bank_account_number")]
        [StringLength(100)]
        public string BankAccountNumber { get; set; }
        [Column("currency")]
        [StringLength(50)]
        public string Currency { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("location")]
        [StringLength(100)]
        public string Location { get; set; }
    }
}
