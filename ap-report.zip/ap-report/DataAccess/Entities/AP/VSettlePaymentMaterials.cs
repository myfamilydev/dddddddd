﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSettlePaymentMaterials
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("settle_payment_code")]
        [StringLength(50)]
        public string SettlePaymentCode { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("term_pay")]
        public int? TermPay { get; set; }
        [Column("item_stock_id")]
        public int? ItemStockId { get; set; }
        [Column("account_code")]
        [StringLength(100)]
        public string AccountCode { get; set; }
        [Column("settle_months")]
        [StringLength(100)]
        public string SettleMonths { get; set; }
        [Column("total", TypeName = "decimal(18, 0)")]
        public decimal? Total { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("supplier_name_en")]
        [StringLength(100)]
        public string SupplierNameEn { get; set; }
        [Column("supplier_name_kh")]
        [StringLength(100)]
        public string SupplierNameKh { get; set; }
        [Column("item_type")]
        [StringLength(50)]
        public string ItemType { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("item_name")]
        [StringLength(50)]
        public string ItemName { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
