﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VRedesignedCalculationItems
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("redesinged_floor")]
        [StringLength(10)]
        public string RedesingedFloor { get; set; }
        [Column("sub_job_name")]
        [StringLength(250)]
        public string SubJobName { get; set; }
        [Column("sub_job_code")]
        [StringLength(50)]
        public string SubJobCode { get; set; }
        [Column("sub_job_id")]
        public int? SubJobId { get; set; }
        [Column("job_code")]
        [StringLength(50)]
        public string JobCode { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }
        [Column("unit_id")]
        public int? UnitId { get; set; }
        [Column("qty")]
        public int? Qty { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("redesigned_calculation_id")]
        public int? RedesignedCalculationId { get; set; }
    }
}
