﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VUsersPermissions
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("main_module")]
        [StringLength(50)]
        public string MainModule { get; set; }
        [Column("sub_module")]
        [StringLength(50)]
        public string SubModule { get; set; }
        [Column("permission")]
        [StringLength(100)]
        public string Permission { get; set; }
        [Column("company")]
        [StringLength(50)]
        public string Company { get; set; }
        [Column("ordering")]
        public int Ordering { get; set; }
    }
}
