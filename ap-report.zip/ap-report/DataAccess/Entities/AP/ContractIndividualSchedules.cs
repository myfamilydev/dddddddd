﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("contract_individual_schedules")]
    public partial class ContractIndividualSchedules
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_individual_schedule_info_id")]
        public int? ContractIndividualScheduleInfoId { get; set; }
        [Column("repay_date", TypeName = "date")]
        public DateTime? RepayDate { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("from_date", TypeName = "date")]
        public DateTime? FromDate { get; set; }
        [Column("days")]
        public int? Days { get; set; }
        [Column("rate", TypeName = "decimal(15, 2)")]
        public decimal? Rate { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
