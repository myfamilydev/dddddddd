﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VDailyCleanerInfo
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("code")]
        [StringLength(30)]
        public string Code { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        public string NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string NameKh { get; set; }
        [Column("nid")]
        [StringLength(50)]
        public string Nid { get; set; }
        [Column("address")]
        [StringLength(1000)]
        public string Address { get; set; }
        [Column("contact")]
        [StringLength(50)]
        public string Contact { get; set; }
        [Column("position_id")]
        public int? PositionId { get; set; }
        [Column("position_en")]
        [StringLength(100)]
        public string PositionEn { get; set; }
        [Column("position_kh")]
        [StringLength(100)]
        public string PositionKh { get; set; }
        [Column("daily_wage_fee", TypeName = "decimal(15, 2)")]
        public decimal? DailyWageFee { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
