﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("workflow_history")]
    public partial class WorkflowHistory
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("workflow_id")]
        public byte WorkflowId { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("post_status")]
        public byte? PostStatus { get; set; }
        [Column("comment")]
        [StringLength(1000)]
        public string Comment { get; set; }
        [Column("position_id")]
        public int? PositionId { get; set; }
        [Column("is_done")]
        public byte? IsDone { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
