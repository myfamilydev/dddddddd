﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("settle_payment_invoices_nonstocks")]
    public partial class SettlePaymentInvoicesNonstocks
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("supplier_settle_payment_id")]
        public int? SupplierSettlePaymentId { get; set; }
        [Column("invoice_date", TypeName = "datetime")]
        public DateTime? InvoiceDate { get; set; }
        [Column("invoice_no")]
        [StringLength(50)]
        public string InvoiceNo { get; set; }
        [Column("contract_no")]
        [StringLength(50)]
        public string ContractNo { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
