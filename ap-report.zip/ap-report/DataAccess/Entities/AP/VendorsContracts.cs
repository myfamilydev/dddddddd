﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_contracts")]
    public partial class VendorsContracts
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("cost_type_id")]
        public int? CostTypeId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("contractPurchaseId")]
        [StringLength(50)]
        public string ContractPurchaseId { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        public string ContractCode { get; set; }
        [Column("vendorId")]
        public int? VendorId { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        public string VendorCategory { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        public string NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(300)]
        public string NameKh { get; set; }
        [Column("nid_no")]
        [StringLength(50)]
        public string NidNo { get; set; }
        [Column("dob", TypeName = "date")]
        public DateTime? Dob { get; set; }
        [Column("address")]
        [StringLength(2000)]
        public string Address { get; set; }
        [Column("phone_number")]
        [StringLength(100)]
        public string PhoneNumber { get; set; }
        [Column("item_name")]
        [StringLength(200)]
        public string ItemName { get; set; }
        [Column("term_payment")]
        [StringLength(200)]
        public string TermPayment { get; set; }
        [Column("job_duration_start", TypeName = "date")]
        public DateTime? JobDurationStart { get; set; }
        [Column("job_duration_end", TypeName = "date")]
        public DateTime? JobDurationEnd { get; set; }
        [Column("items")]
        [StringLength(100)]
        public string Items { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("is_final")]
        public bool? IsFinal { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("is_not_match")]
        public bool? IsNotMatch { get; set; }
        [Column("claim_perc", TypeName = "decimal(15, 2)")]
        public decimal? ClaimPerc { get; set; }
    }
}
