﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("settle_payment_invoices")]
    public partial class SettlePaymentInvoices
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("account_code")]
        [StringLength(50)]
        public string AccountCode { get; set; }
        [Column("supplier_settle_payment_id")]
        public int? SupplierSettlePaymentId { get; set; }
        [Column("invoice_date", TypeName = "datetime")]
        public DateTime? InvoiceDate { get; set; }
        [Column("invoice_no")]
        [StringLength(50)]
        public string InvoiceNo { get; set; }
        [Column("PO_no")]
        [StringLength(50)]
        public string PoNo { get; set; }
        [Column("total", TypeName = "decimal(18, 0)")]
        public decimal? Total { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
