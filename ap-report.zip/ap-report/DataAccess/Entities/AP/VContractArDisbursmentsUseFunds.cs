﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VContractArDisbursmentsUseFunds
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("other")]
        [StringLength(50)]
        public string Other { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("contract_ar_disbursment_id")]
        public int? ContractArDisbursmentId { get; set; }
    }
}
