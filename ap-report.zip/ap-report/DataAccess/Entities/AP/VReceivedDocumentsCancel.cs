﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VReceivedDocumentsCancel
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("received_document_id")]
        public int? ReceivedDocumentId { get; set; }
        [Column("code")]
        [StringLength(30)]
        public string Code { get; set; }
        [Column("cancel_reason")]
        [StringLength(2000)]
        public string CancelReason { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("received_date", TypeName = "date")]
        public DateTime? ReceivedDate { get; set; }
        [Column("document_type")]
        [StringLength(20)]
        public string DocumentType { get; set; }
        [Column("invoice_no")]
        [StringLength(30)]
        public string InvoiceNo { get; set; }
        [Column("invoice_amount", TypeName = "decimal(18, 2)")]
        public decimal? InvoiceAmount { get; set; }
        [Column("remark")]
        [StringLength(2000)]
        public string Remark { get; set; }
        [Column("vendor_name")]
        [StringLength(200)]
        public string VendorName { get; set; }
        [Column("vendor_code")]
        [StringLength(20)]
        public string VendorCode { get; set; }
        [Column("project_code")]
        [StringLength(100)]
        public string ProjectCode { get; set; }
        [Column("document_code")]
        [StringLength(30)]
        public string DocumentCode { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
