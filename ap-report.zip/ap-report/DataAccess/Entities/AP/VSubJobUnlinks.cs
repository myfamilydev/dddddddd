﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSubJobUnlinks
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("job_code")]
        [StringLength(50)]
        public string JobCode { get; set; }
        [Column("sub_job_code")]
        [StringLength(50)]
        public string SubJobCode { get; set; }
        [Column("sub_job_name")]
        [StringLength(250)]
        public string SubJobName { get; set; }
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }
        [Column("customer_cost", TypeName = "decimal(15, 2)")]
        public decimal? CustomerCost { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
