﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("suppliers_items_types")]
    public partial class SuppliersItemsTypes
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("item_type")]
        [StringLength(50)]
        public string ItemType { get; set; }
        [Column("item_desc")]
        [StringLength(500)]
        public string ItemDesc { get; set; }
        [Column("is_stock")]
        public bool? IsStock { get; set; }
        [Column("is_active")]
        public bool? IsActive { get; set; }
    }
}
