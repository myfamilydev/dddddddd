﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_contracts_settlement_infos")]
    public partial class VendorsContractsSettlementInfos
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("settlement_option")]
        [StringLength(50)]
        public string SettlementOption { get; set; }
        [Column("settlement_method")]
        [StringLength(50)]
        public string SettlementMethod { get; set; }
        [Column("cheque_name")]
        [StringLength(300)]
        public string ChequeName { get; set; }
        [Column("payment_collector")]
        [StringLength(100)]
        public string PaymentCollector { get; set; }
        [Column("phone_number")]
        [StringLength(100)]
        public string PhoneNumber { get; set; }
        [Column("bank_name")]
        [StringLength(50)]
        public string BankName { get; set; }
        [Column("bank_account_name_en")]
        [StringLength(200)]
        public string BankAccountNameEn { get; set; }
        [Column("bank_account_name_kh")]
        [StringLength(300)]
        public string BankAccountNameKh { get; set; }
        [Column("bank_account_number")]
        [StringLength(50)]
        public string BankAccountNumber { get; set; }
        [Column("card_no")]
        [StringLength(50)]
        public string CardNo { get; set; }
        [Column("currency")]
        [StringLength(50)]
        public string Currency { get; set; }
        [Column("attachment_ref")]
        [StringLength(30)]
        public string AttachmentRef { get; set; }
        [Column("remarks")]
        [StringLength(2000)]
        public string Remarks { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
