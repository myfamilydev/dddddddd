﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("dim_account_threatment_types")]
    public partial class DimAccountThreatmentTypes
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("account_threatment_type")]
        [StringLength(100)]
        public string AccountThreatmentType { get; set; }
    }
}
