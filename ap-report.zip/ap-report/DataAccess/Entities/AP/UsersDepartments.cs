﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("users_departments")]
    public partial class UsersDepartments
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("department")]
        [StringLength(100)]
        public string Department { get; set; }
        [Column("cost_center")]
        [StringLength(5)]
        public string CostCenter { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
    }
}
