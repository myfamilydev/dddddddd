﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VDblhdCompanies
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("business_type")]
        [StringLength(50)]
        public string BusinessType { get; set; }
        [Column("name_kh")]
        [StringLength(50)]
        public string NameKh { get; set; }
        [Column("name_en")]
        [StringLength(50)]
        public string NameEn { get; set; }
        [Column("address")]
        public string Address { get; set; }
        [Column("contract_no")]
        [StringLength(20)]
        public string ContractNo { get; set; }
        [Column("vat_no")]
        [StringLength(20)]
        public string VatNo { get; set; }
        [Column("register_no")]
        [StringLength(20)]
        public string RegisterNo { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
