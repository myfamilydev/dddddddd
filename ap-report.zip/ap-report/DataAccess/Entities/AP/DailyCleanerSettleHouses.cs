﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("daily_cleaner_settle_houses")]
    public partial class DailyCleanerSettleHouses
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("cleaner_settle_id")]
        public int? CleanerSettleId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("comment")]
        [StringLength(1000)]
        public string Comment { get; set; }
    }
}
