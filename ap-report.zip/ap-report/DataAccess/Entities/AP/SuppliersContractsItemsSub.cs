﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("suppliers_contracts_items_sub")]
    public partial class SuppliersContractsItemsSub
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_item_id")]
        public int? ContractItemId { get; set; }
        [Column("item_description")]
        [StringLength(1000)]
        public string ItemDescription { get; set; }
        [Column("uom")]
        [StringLength(50)]
        public string Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("remarks")]
        [StringLength(1000)]
        public string Remarks { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
