﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("telegram_log")]
    public partial class TelegramLog
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("workflow_id")]
        public int? WorkflowId { get; set; }
        [Column("telegram_content")]
        [StringLength(3000)]
        public string TelegramContent { get; set; }
        [Column("telegram_group_id")]
        public int? TelegramGroupId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("comment")]
        [StringLength(300)]
        public string Comment { get; set; }
        [Column("user_name")]
        [StringLength(50)]
        public string UserName { get; set; }
        [Column("action_label")]
        [StringLength(50)]
        public string ActionLabel { get; set; }
        [Column("workflow_name")]
        [StringLength(50)]
        public string WorkflowName { get; set; }
        [Column("house_type")]
        [StringLength(80)]
        public string HouseType { get; set; }
        [Column("house_no")]
        [StringLength(10)]
        public string HouseNo { get; set; }
        [Column("project")]
        [StringLength(50)]
        public string Project { get; set; }
        [Column("content1")]
        [StringLength(100)]
        public string Content1 { get; set; }
        [Column("url")]
        [StringLength(200)]
        public string Url { get; set; }
    }
}
