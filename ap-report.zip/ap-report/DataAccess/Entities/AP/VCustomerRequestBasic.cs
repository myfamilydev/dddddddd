﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VCustomerRequestBasic
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("request_code")]
        [StringLength(50)]
        public string RequestCode { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("number")]
        [StringLength(10)]
        public string Number { get; set; }
        [Column("customer1")]
        [StringLength(100)]
        public string Customer1 { get; set; }
        [Column("customer2")]
        [StringLength(100)]
        public string Customer2 { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("customer_id_1")]
        public int? CustomerId1 { get; set; }
        [Column("customer_id_2")]
        public int? CustomerId2 { get; set; }
        [Column("nationalId1")]
        [StringLength(100)]
        public string NationalId1 { get; set; }
        [Column("nationalId2")]
        [StringLength(100)]
        public string NationalId2 { get; set; }
        [Column("phone1")]
        [StringLength(100)]
        public string Phone1 { get; set; }
        [Column("phone2")]
        [StringLength(100)]
        public string Phone2 { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
