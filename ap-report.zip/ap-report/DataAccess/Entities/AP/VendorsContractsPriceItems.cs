﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_contracts_price_items")]
    public partial class VendorsContractsPriceItems
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("contract_price_id")]
        public int? ContractPriceId { get; set; }
        [Column("sub_item_name")]
        [StringLength(100)]
        public string SubItemName { get; set; }
        [Column("unit")]
        [StringLength(50)]
        public string Unit { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("remarks")]
        [StringLength(1000)]
        public string Remarks { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
