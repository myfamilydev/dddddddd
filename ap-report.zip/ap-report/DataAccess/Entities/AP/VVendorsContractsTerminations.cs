﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsContractsTerminations
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("contract_terminate_code")]
        [StringLength(20)]
        public string ContractTerminateCode { get; set; }
        [Column("cancellation_date", TypeName = "date")]
        public DateTime? CancellationDate { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("terminate_reason")]
        [StringLength(1000)]
        public string TerminateReason { get; set; }
        [Column("received_document_date", TypeName = "date")]
        public DateTime? ReceivedDocumentDate { get; set; }
        [Column("signed_new_contract_date", TypeName = "date")]
        public DateTime? SignedNewContractDate { get; set; }
        [Column("remarks")]
        [StringLength(2000)]
        public string Remarks { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        public string ContractCode { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        public string VendorCategory { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        public string NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(300)]
        public string NameKh { get; set; }
        [Column("nid_no")]
        [StringLength(50)]
        public string NidNo { get; set; }
        [Column("phone_number")]
        [StringLength(100)]
        public string PhoneNumber { get; set; }
        [Column("item_name")]
        [StringLength(100)]
        public string ItemName { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
