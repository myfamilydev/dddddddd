﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("suppliers")]
    public partial class Suppliers
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("supplier_location")]
        [StringLength(20)]
        public string SupplierLocation { get; set; }
        [Column("supplier_code")]
        [StringLength(20)]
        public string SupplierCode { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        public string NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string NameKh { get; set; }
        [Column("nid")]
        [StringLength(20)]
        public string Nid { get; set; }
        [Column("address")]
        public string Address { get; set; }
        [Column("contact_number")]
        [StringLength(50)]
        public string ContactNumber { get; set; }
        [Column("contact_telegram")]
        [StringLength(20)]
        public string ContactTelegram { get; set; }
        [Column("email")]
        [StringLength(100)]
        public string Email { get; set; }
        [Column("payment_collector")]
        [StringLength(1000)]
        public string PaymentCollector { get; set; }
        [Column("collector_number")]
        [StringLength(50)]
        public string CollectorNumber { get; set; }
        [Column("collector_telegram")]
        [StringLength(50)]
        public string CollectorTelegram { get; set; }
        [Column("name_on_cheque")]
        [StringLength(100)]
        public string NameOnCheque { get; set; }
        [Column("behavior")]
        [StringLength(50)]
        public string Behavior { get; set; }
        [Column("behavior_description")]
        [StringLength(100)]
        public string BehaviorDescription { get; set; }
        [Column("supplier_type")]
        [StringLength(50)]
        public string SupplierType { get; set; }
        [Column("normal")]
        [StringLength(50)]
        public string Normal { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        public string Remark { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
