﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VLoanSchedulesInfo
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("schedule_number")]
        [StringLength(50)]
        public string ScheduleNumber { get; set; }
        [Column("loan_phase_no")]
        [StringLength(50)]
        public string LoanPhaseNo { get; set; }
        [Column("loan_disbursment_id")]
        public int? LoanDisbursmentId { get; set; }
        [Column("add_principle", TypeName = "decimal(15, 2)")]
        public decimal? AddPrinciple { get; set; }
        [Column("reschedule_at", TypeName = "datetime")]
        public DateTime? RescheduleAt { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("final_at", TypeName = "datetime")]
        public DateTime? FinalAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
