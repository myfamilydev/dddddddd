﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsLaborCovers
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("vendorItemId")]
        public int? VendorItemId { get; set; }
        [Column("vendor_name")]
        [StringLength(200)]
        public string VendorName { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("cover_code")]
        [StringLength(50)]
        public string CoverCode { get; set; }
        [Column("site_area_engineer")]
        [StringLength(30)]
        public string SiteAreaEngineer { get; set; }
        [Column("site_engineer")]
        [StringLength(30)]
        public string SiteEngineer { get; set; }
        [Column("is_claim_same_contract")]
        public bool? IsClaimSameContract { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("payment_term_perc", TypeName = "decimal(15, 2)")]
        public decimal? PaymentTermPerc { get; set; }
        [Column("claim_houses")]
        [StringLength(200)]
        public string ClaimHouses { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        public string ContractCode { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
