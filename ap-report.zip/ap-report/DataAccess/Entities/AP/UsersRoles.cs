﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("users_roles")]
    public partial class UsersRoles
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        public string RoleName { get; set; }
        [Column("role_description")]
        [StringLength(1000)]
        public string RoleDescription { get; set; }
        [Column("auth")]
        [StringLength(50)]
        public string Auth { get; set; }
        [Column("is_dynamic")]
        public bool? IsDynamic { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
