﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("loan_types")]
    public partial class LoanTypes
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("category")]
        [StringLength(100)]
        public string Category { get; set; }
        [Column("type")]
        [StringLength(100)]
        public string Type { get; set; }
        [Column("loan_description")]
        [StringLength(100)]
        public string LoanDescription { get; set; }
        [Column("loan_code")]
        [StringLength(50)]
        public string LoanCode { get; set; }
        [Column("htd_remark")]
        public string HtdRemark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
    }
}
