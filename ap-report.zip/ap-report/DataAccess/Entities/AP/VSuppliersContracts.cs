﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSuppliersContracts
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        public string ContractCode { get; set; }
        [Column("contract_po")]
        [StringLength(20)]
        public string ContractPo { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("account_code")]
        [StringLength(50)]
        public string AccountCode { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("supplier_name")]
        [StringLength(100)]
        public string SupplierName { get; set; }
        [Column("term_pay")]
        [StringLength(100)]
        public string TermPay { get; set; }
        [Column("payment_method")]
        [StringLength(50)]
        public string PaymentMethod { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("item_type")]
        [StringLength(50)]
        public string ItemType { get; set; }
        [Column("item_name")]
        [StringLength(50)]
        public string ItemName { get; set; }
        [Column("supplier_name_en")]
        [StringLength(100)]
        public string SupplierNameEn { get; set; }
        [Column("supplier_name_kh")]
        [StringLength(100)]
        public string SupplierNameKh { get; set; }
        [Column("supplier_nid")]
        [StringLength(20)]
        public string SupplierNid { get; set; }
        [Column("phone_number")]
        [StringLength(50)]
        public string PhoneNumber { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
