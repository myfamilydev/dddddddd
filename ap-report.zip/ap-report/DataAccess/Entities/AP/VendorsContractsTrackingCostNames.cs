﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_contracts_tracking_cost_names")]
    public partial class VendorsContractsTrackingCostNames
    {
        [Column("id")]
        public long Id { get; set; }
        [Key]
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Key]
        [Column("vendor_id")]
        public int VendorId { get; set; }
        [Key]
        [Column("master_id")]
        public int MasterId { get; set; }
        [Required]
        [Column("cost_name")]
        public string CostName { get; set; }
        [Key]
        [Column("item_id")]
        public int ItemId { get; set; }
        [Key]
        [Column("status")]
        public bool Status { get; set; }
    }
}
