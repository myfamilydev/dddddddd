﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities.AP
{
    public class VVendorSettlementSub
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public int ProId { get; set; }
        public int VendorId { get; set; }
        public int VendorItem { get; set; }
        public DateTime settlement_date { get; set; }
        public string SettlementCode { get; set; }
    }
}
