﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("users")]
    public partial class Users
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("uuid")]
        public Guid? Uuid { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("password")]
        [StringLength(150)]
        public string Password { get; set; }
        [Column("password_change_at", TypeName = "datetime")]
        public DateTime? PasswordChangeAt { get; set; }
        [Column("email")]
        [StringLength(100)]
        public string Email { get; set; }
        [Column("designation")]
        [StringLength(200)]
        public string Designation { get; set; }
        [Column("department_id")]
        public short? DepartmentId { get; set; }
        [Column("phone_number")]
        [StringLength(50)]
        public string PhoneNumber { get; set; }
        [Column("telegram_id")]
        public int? TelegramId { get; set; }
        [Column("is_hod")]
        public bool? IsHod { get; set; }
        [Column("is_line_manager")]
        public bool? IsLineManager { get; set; }
        [Column("emp_id")]
        [StringLength(50)]
        public string EmpId { get; set; }
        [Column("company_session_id")]
        public int? CompanySessionId { get; set; }
        [Column("user_group_id")]
        public int? UserGroupId { get; set; }
        [Column("pos_id")]
        public int? PosId { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("line_manager_id")]
        public int? LineManagerId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
