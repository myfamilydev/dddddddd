﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VDbliveProjects
    {
        [Column("id")]
        public short? Id { get; set; }
        [Column("company_id")]
        public short? CompanyId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("project_code")]
        [StringLength(103)]
        public string ProjectCode { get; set; }
        [Column("project_name")]
        [StringLength(150)]
        public string ProjectName { get; set; }
    }
}
