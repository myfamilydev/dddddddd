﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorSettlementSubItems
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("settlement_sub_id")]
        public int? SettlementSubId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("price_item_id")]
        public long? PriceItemId { get; set; }
        [Column("quantity", TypeName = "decimal(18, 2)")]
        public decimal? Quantity { get; set; }
        [Column("uom")]
        [StringLength(200)]
        public string Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("total_price", TypeName = "decimal(18, 2)")]
        public decimal? TotalPrice { get; set; }
        [Column("claim_id")]
        [StringLength(50)]
        public string ClaimId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("sub_item_name")]
        [StringLength(100)]
        public string SubItemName { get; set; }
    }
}
