﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VCompanyCostCenter
    {
        [Column("company_id")]
        public short CompanyId { get; set; }
        [Column("company_uuid")]
        public Guid? CompanyUuid { get; set; }
        [Column("company_name")]
        [StringLength(200)]
        public string CompanyName { get; set; }
        [Column("business_type")]
        [StringLength(200)]
        public string BusinessType { get; set; }
        [Column("account_threatment_type")]
        [StringLength(200)]
        public string AccountThreatmentType { get; set; }
        [Column("cost_center_id")]
        public short? CostCenterId { get; set; }
        [Column("cost_center")]
        [StringLength(10)]
        public string CostCenter { get; set; }
        [Column("share_type")]
        public int? ShareType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("cost_center_status")]
        public byte? CostCenterStatus { get; set; }
    }
}
