﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("chart_accounts")]
    public partial class ChartAccounts
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public short? CompanyId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("account_code")]
        [StringLength(20)]
        public string AccountCode { get; set; }
        [Column("account_type_id")]
        public short? AccountTypeId { get; set; }
        [Column("account_name_kh")]
        [StringLength(400)]
        public string AccountNameKh { get; set; }
        [Column("account_name_en")]
        [StringLength(200)]
        public string AccountNameEn { get; set; }
        [Column("is_sub_account")]
        public bool? IsSubAccount { get; set; }
        [Column("sub_account_of_id")]
        public int? SubAccountOfId { get; set; }
        [Column("description")]
        [StringLength(1000)]
        public string Description { get; set; }
        [Column("note")]
        [StringLength(1000)]
        public string Note { get; set; }
        [Column("inactivate")]
        public bool? Inactivate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("insert_type")]
        [StringLength(10)]
        public string InsertType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
