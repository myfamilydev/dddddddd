﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSuppliersContractsBasic
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("supplier_name")]
        [StringLength(100)]
        public string SupplierName { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        public string ContractCode { get; set; }
        [Column("contract_po")]
        [StringLength(20)]
        public string ContractPo { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
