﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_settlement_lab")]
    public partial class VendorsSettlementLab
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("code")]
        [StringLength(50)]
        public string Code { get; set; }
        [Column("settlement_date", TypeName = "date")]
        public DateTime? SettlementDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
