﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsContractsPricing
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_item_id")]
        public int? ContractItemId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("item_name")]
        [StringLength(500)]
        public string ItemName { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("valid_date_until", TypeName = "date")]
        public DateTime? ValidDateUntil { get; set; }
        [Column("remarks")]
        [StringLength(2000)]
        public string Remarks { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
    }
}
