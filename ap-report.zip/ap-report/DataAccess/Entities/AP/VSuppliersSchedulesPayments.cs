﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSuppliersSchedulesPayments
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("schedule_payment_code")]
        [StringLength(50)]
        public string SchedulePaymentCode { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("term_pay")]
        [StringLength(50)]
        public string TermPay { get; set; }
        [Column("share_cost_type")]
        [StringLength(50)]
        public string ShareCostType { get; set; }
        [Column("description")]
        [StringLength(300)]
        public string Description { get; set; }
        [Column("account_code")]
        [StringLength(50)]
        public string AccountCode { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("supplier_name_en")]
        [StringLength(100)]
        public string SupplierNameEn { get; set; }
        [Column("supplier_name_kh")]
        [StringLength(100)]
        public string SupplierNameKh { get; set; }
        [Column("item_type")]
        [StringLength(50)]
        public string ItemType { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
