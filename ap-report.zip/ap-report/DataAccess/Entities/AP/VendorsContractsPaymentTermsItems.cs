﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_contracts_payment_terms_items")]
    public partial class VendorsContractsPaymentTermsItems
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_payment_term_id")]
        public int? ContractPaymentTermId { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
        [Column("phase")]
        [StringLength(100)]
        public string Phase { get; set; }
        [Column("percentage", TypeName = "decimal(5, 2)")]
        public decimal? Percentage { get; set; }
        [Column("condition")]
        [StringLength(2000)]
        public string Condition { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
