﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsContractsMaster
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_redesign_id")]
        public int? HouseRedesignId { get; set; }
        [Column("house_redo")]
        [StringLength(10)]
        public string HouseRedo { get; set; }
        [Column("require_reason")]
        public bool RequireReason { get; set; }
        [Column("cost_name")]
        [StringLength(50)]
        public string CostName { get; set; }
    }
}
