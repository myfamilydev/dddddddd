﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorContractBasic
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        public string ContractCode { get; set; }
        [Column("vendorId")]
        public int? VendorId { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        public string VendorCategory { get; set; }
        [Column("term_payment")]
        [StringLength(200)]
        public string TermPayment { get; set; }
        [Column("contractPurchaseId")]
        [StringLength(50)]
        public string ContractPurchaseId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
