﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VProjects
    {
        [Column("id")]
        public short Id { get; set; }
        [Column("company_id")]
        public int CompanyId { get; set; }
        [Column("project_code")]
        [StringLength(100)]
        public string ProjectCode { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("share_type")]
        public int? ShareType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("project_abbr")]
        [StringLength(100)]
        public string ProjectAbbr { get; set; }
    }
}
