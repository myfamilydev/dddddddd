﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("customer_behavior_types")]
    public partial class CustomerBehaviorTypes
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("type")]
        [StringLength(50)]
        public string Type { get; set; }
        [Column("status")]
        public byte Status { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
    }
}
