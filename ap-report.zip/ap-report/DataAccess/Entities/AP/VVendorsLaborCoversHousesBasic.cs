﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsLaborCoversHousesBasic
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("cover_code")]
        [StringLength(100)]
        public string CoverCode { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("claim_houses")]
        public string ClaimHouses { get; set; }
        [Column("item_name")]
        public string ItemName { get; set; }
        [Column("total_amount", TypeName = "decimal(18, 2)")]
        public decimal? TotalAmount { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("contract_code")]
        [StringLength(100)]
        public string ContractCode { get; set; }
        [Column("vendor_name")]
        [StringLength(300)]
        public string VendorName { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
