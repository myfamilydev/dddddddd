﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("suppliers_contracts_items")]
    public partial class SuppliersContractsItems
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("valid_date", TypeName = "date")]
        public DateTime? ValidDate { get; set; }
        [Column("remark")]
        [StringLength(2000)]
        public string Remark { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
