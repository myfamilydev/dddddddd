﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsSettlementsSub
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("settlement_code")]
        [StringLength(30)]
        public string SettlementCode { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("vendor_item")]
        public int? VendorItem { get; set; }
        [Column("item_name")]
        [StringLength(500)]
        public string ItemName { get; set; }
        [Column("payment_term_perc", TypeName = "decimal(15, 2)")]
        public decimal? PaymentTermPerc { get; set; }
        [Column("is_no_contract")]
        public bool? IsNoContract { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("is_match_payment_term")]
        public bool? IsMatchPaymentTerm { get; set; }
        [Column("document_id")]
        public int? DocumentId { get; set; }
        [Column("total", TypeName = "decimal(38, 2)")]
        public decimal Total { get; set; }
        [Column("deadline", TypeName = "date")]
        public DateTime? Deadline { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("vendor_name_en")]
        [StringLength(200)]
        public string VendorNameEn { get; set; }
        [Column("contract_purchase_id")]
        [StringLength(50)]
        public string ContractPurchaseId { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("rec_status")]
        public short RecStatus { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("settlement_date", TypeName = "datetime")]
        public DateTime? SettlementDate { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("cost_type")]
        [StringLength(50)]
        public string CostType { get; set; }
    }
}
