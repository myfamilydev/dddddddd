﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSuppliersItems
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("item_code")]
        [StringLength(20)]
        public string ItemCode { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }
        [Column("description")]
        [StringLength(1000)]
        public string Description { get; set; }
        [Column("uom_en")]
        [StringLength(20)]
        public string UomEn { get; set; }
        [Column("uom_kh")]
        [StringLength(100)]
        public string UomKh { get; set; }
        [Column("qb_item_code")]
        [StringLength(500)]
        public string QbItemCode { get; set; }
        [Column("account_code")]
        [StringLength(50)]
        public string AccountCode { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("item_type")]
        [StringLength(50)]
        public string ItemType { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
