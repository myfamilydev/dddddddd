﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VContractArDisbursments
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("disbursment_date", TypeName = "date")]
        public DateTime? DisbursmentDate { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("duration")]
        public int? Duration { get; set; }
        [Column("maturity_date", TypeName = "date")]
        public DateTime? MaturityDate { get; set; }
        [Column("loan_amount_khr", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmountKhr { get; set; }
        [Column("loan_amount_usd", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmountUsd { get; set; }
        [Column("exchange_rate", TypeName = "decimal(15, 2)")]
        public decimal? ExchangeRate { get; set; }
        [Column("loan_no")]
        [StringLength(50)]
        public string LoanNo { get; set; }
        [Column("card_no")]
        [StringLength(50)]
        public string CardNo { get; set; }
        [Column("lek_phor_por")]
        [StringLength(50)]
        public string LekPhorPor { get; set; }
        [Column("remark")]
        [StringLength(100)]
        public string Remark { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
