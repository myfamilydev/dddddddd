﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VRedesignedCalculationCancel
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("redesigned_cancel_code")]
        [StringLength(50)]
        public string RedesignedCancelCode { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project")]
        [StringLength(10)]
        public string Project { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("date", TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [Column("customer_id_1")]
        public int? CustomerId1 { get; set; }
        [Column("customer_id_2")]
        public int? CustomerId2 { get; set; }
        [Column("customer_1")]
        [StringLength(100)]
        public string Customer1 { get; set; }
        [Column("customer_2")]
        [StringLength(100)]
        public string Customer2 { get; set; }
        [Column("nid_1")]
        [StringLength(50)]
        public string Nid1 { get; set; }
        [Column("nid_2")]
        [StringLength(50)]
        public string Nid2 { get; set; }
        [Column("tel_1")]
        [StringLength(50)]
        public string Tel1 { get; set; }
        [Column("tel_2")]
        [StringLength(50)]
        public string Tel2 { get; set; }
        [Column("redesigned_type_id")]
        public int? RedesignedTypeId { get; set; }
        [Column("redesinged_type")]
        [StringLength(250)]
        public string RedesingedType { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("reasons")]
        public string Reasons { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
    }
}
