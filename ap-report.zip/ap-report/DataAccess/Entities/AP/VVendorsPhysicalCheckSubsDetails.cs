﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VVendorsPhysicalCheckSubsDetails
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("vendor_physical_check_sub_id")]
        public int? VendorPhysicalCheckSubId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("claim_time")]
        [StringLength(50)]
        public string ClaimTime { get; set; }
        [Column("claim_percentage", TypeName = "decimal(15, 2)")]
        public decimal? ClaimPercentage { get; set; }
        [Column("claim_amount", TypeName = "decimal(15, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("is_done")]
        public bool? IsDone { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
