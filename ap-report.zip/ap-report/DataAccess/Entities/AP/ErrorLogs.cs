﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("error_logs")]
    public partial class ErrorLogs
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("log_type")]
        [StringLength(50)]
        public string LogType { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("ip")]
        [StringLength(50)]
        public string Ip { get; set; }
        [Column("created_by")]
        [StringLength(50)]
        public string CreatedBy { get; set; }
        [Column("created_at")]
        public byte[] CreatedAt { get; set; }
    }
}
