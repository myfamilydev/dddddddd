﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSchedulesStandardLoans
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("repay_date", TypeName = "date")]
        public DateTime? RepayDate { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("from_date", TypeName = "date")]
        public DateTime? FromDate { get; set; }
        [Column("days")]
        public int? Days { get; set; }
        [Column("rate", TypeName = "decimal(15, 2)")]
        public decimal? Rate { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("bank_short")]
        [StringLength(50)]
        public string BankShort { get; set; }
        [Column("loan_schedule_info_id")]
        public int? LoanScheduleInfoId { get; set; }
    }
}
