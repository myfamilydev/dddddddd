﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_labor_covers_schedules")]
    public partial class VendorsLaborCoversSchedules
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("cover_item_id")]
        public long? CoverItemId { get; set; }
        [Column("claim_date", TypeName = "date")]
        public DateTime? ClaimDate { get; set; }
        [Column("claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("accumulated_claim", TypeName = "decimal(18, 2)")]
        public decimal? AccumulatedClaim { get; set; }
        [Column("remaining_claim", TypeName = "decimal(18, 2)")]
        public decimal? RemainingClaim { get; set; }
        [Column("claim_link")]
        [StringLength(200)]
        public string ClaimLink { get; set; }
        [Column("payment_voucher_id")]
        [StringLength(50)]
        public string PaymentVoucherId { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
