﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_items")]
    public partial class VendorsItems
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        public string VendorCategory { get; set; }
        [Column("vendor_short")]
        [StringLength(10)]
        public string VendorShort { get; set; }
        [Column("item_code")]
        [StringLength(20)]
        public string ItemCode { get; set; }
        [Column("item_name")]
        [StringLength(500)]
        public string ItemName { get; set; }
        [Column("item_description")]
        [StringLength(1000)]
        public string ItemDescription { get; set; }
        [Column("cogs_account")]
        [StringLength(100)]
        public string CogsAccount { get; set; }
        [Column("job_code")]
        [StringLength(50)]
        public string JobCode { get; set; }
        [Column("is_active")]
        public bool? IsActive { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
