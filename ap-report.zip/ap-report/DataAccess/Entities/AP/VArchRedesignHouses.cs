﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VArchRedesignHouses
    {
        [Column("redesigned_code")]
        [StringLength(50)]
        public string RedesignedCode { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("sub_job_code")]
        [StringLength(50)]
        public string SubJobCode { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("discount", TypeName = "decimal(15, 2)")]
        public decimal? Discount { get; set; }
        [Column("cancel_date", TypeName = "datetime")]
        public DateTime? CancelDate { get; set; }
        [Column("redesign_type")]
        [StringLength(250)]
        public string RedesignType { get; set; }
        [Column("sub_job_name")]
        [StringLength(250)]
        public string SubJobName { get; set; }
    }
}
