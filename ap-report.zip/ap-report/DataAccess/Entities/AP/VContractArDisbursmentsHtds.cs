﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VContractArDisbursmentsHtds
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("htd_project_id")]
        public int? HtdProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_ar_disbursment_id")]
        public int? ContractArDisbursmentId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("sreet_id")]
        public int? SreetId { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("ownership_name")]
        [StringLength(100)]
        public string OwnershipName { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
