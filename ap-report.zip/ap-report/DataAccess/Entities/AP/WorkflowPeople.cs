﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("workflow_people")]
    public partial class WorkflowPeople
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("workflow_id")]
        public byte? WorkflowId { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("wf_role_label_id")]
        public short? WfRoleLabelId { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("is_parallel")]
        public bool? IsParallel { get; set; }
        [Column("is_done")]
        public bool? IsDone { get; set; }
        [Column("is_invited")]
        public bool? IsInvited { get; set; }
        [Column("is_current")]
        public bool? IsCurrent { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
