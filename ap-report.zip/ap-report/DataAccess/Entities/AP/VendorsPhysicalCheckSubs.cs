﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_physical_check_subs")]
    public partial class VendorsPhysicalCheckSubs
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("settlement_id")]
        public int? SettlementId { get; set; }
        [Column("physical_code")]
        [StringLength(50)]
        public string PhysicalCode { get; set; }
        [Column("check_date", TypeName = "date")]
        public DateTime? CheckDate { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
