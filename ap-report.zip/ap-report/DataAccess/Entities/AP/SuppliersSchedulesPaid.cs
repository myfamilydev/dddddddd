﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("suppliers_schedules_paid")]
    public partial class SuppliersSchedulesPaid
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("supplier_name_en")]
        [StringLength(50)]
        public string SupplierNameEn { get; set; }
        [Column("supplier_name_kh")]
        [StringLength(50)]
        public string SupplierNameKh { get; set; }
        [Column("term_pay")]
        [StringLength(50)]
        public string TermPay { get; set; }
        [Column("paid_amount_kh", TypeName = "decimal(18, 2)")]
        public decimal? PaidAmountKh { get; set; }
        [Column("exchange_rate", TypeName = "decimal(18, 2)")]
        public decimal? ExchangeRate { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
