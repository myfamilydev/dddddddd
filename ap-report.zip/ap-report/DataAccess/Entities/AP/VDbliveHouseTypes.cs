﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VDbliveHouseTypes
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Required]
        [Column("name")]
        [StringLength(100)]
        public string Name { get; set; }
        [Column("land_width")]
        [StringLength(10)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        public string LandLength { get; set; }
        [Column("house_width")]
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [Column("house_length")]
        [StringLength(10)]
        public string HouseLength { get; set; }
        [Column("floor")]
        public byte? Floor { get; set; }
        [Column("bedroom")]
        public byte? Bedroom { get; set; }
        [Column("bathroom")]
        public byte? Bathroom { get; set; }
        [Column("remarks")]
        [StringLength(200)]
        public string Remarks { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("category_name")]
        [StringLength(250)]
        public string CategoryName { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
    }
}
