﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("vendors_labor_covers_redesign_items")]
    public partial class VendorsLaborCoversRedesignItems
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("labor_cover_id")]
        public int? LaborCoverId { get; set; }
        [Column("labor_cover_item_id")]
        public int? LaborCoverItemId { get; set; }
        [Column("adj_amount", TypeName = "decimal(15, 2)")]
        public decimal? AdjAmount { get; set; }
        [Column("redesign_amount", TypeName = "decimal(15, 2)")]
        public decimal? RedesignAmount { get; set; }
        [Column("redesigned_code")]
        [StringLength(100)]
        public string RedesignedCode { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
