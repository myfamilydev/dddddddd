﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    [Table("pay_off_loan_requests")]
    public partial class PayOffLoanRequests
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_type_id")]
        public int? LoanTypeId { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("loan_phase_id")]
        public int? LoanPhaseId { get; set; }
        [Column("project_htd_id")]
        public int? ProjectHtdId { get; set; }
        [Column("final_type")]
        [StringLength(50)]
        public string FinalType { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
