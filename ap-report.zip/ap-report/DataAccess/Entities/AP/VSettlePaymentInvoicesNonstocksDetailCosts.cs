﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VSettlePaymentInvoicesNonstocksDetailCosts
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("settle_payment_id")]
        public int? SettlePaymentId { get; set; }
        [Column("invoice_id")]
        public int? InvoiceId { get; set; }
        [Column("non_stock_detail_id")]
        public int? NonStockDetailId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("amount", TypeName = "decimal(18, 0)")]
        public decimal? Amount { get; set; }
        [Column("percentage", TypeName = "decimal(18, 0)")]
        public decimal? Percentage { get; set; }
        [Column("account_code")]
        public int? AccountCode { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
