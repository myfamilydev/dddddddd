﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AP
{
    public partial class VGetWorkflow
    {
        [Column("role_name")]
        [StringLength(100)]
        public string RoleName { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("is_done")]
        public byte? IsDone { get; set; }
        [Column("action_at", TypeName = "datetime")]
        public DateTime ActionAt { get; set; }
    }
}
