﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary
{
    public class ClsDistribute 
    {        
            public static void SaveSessionLog(HttpContext http,string token, int user_id)
            {

                try
                {

                        using(var _context = new MayuraContext())
                        {
                                string remote_ip = http.Connection.RemoteIpAddress?.ToString();
                                DateTime dt = DateTime.Today;

                                var sessionlog = _context.SessionsLog.FirstOrDefault(x => x.RemoteIp == remote_ip && x.CreatedBy == user_id);
                                if (sessionlog == null) //sessionlog == null
                                {
                                    var slog = new SessionsLog();
                                    var claim = token;
                                    slog.RemoteIp = remote_ip;
                                    slog.CreatedAt = DateTime.Now;
                                    slog.CreatedBy = user_id;
                                    slog.status = 1;
                                    slog.token = claim?.ToString();

                                    _context.SessionsLog.Add(slog);
                                    _context.SaveChanges();
                                }
                                else
                                {
                                    sessionlog.CreatedAt = DateTime.Now;
                                    sessionlog.token = token;
                                    sessionlog.status = 1;
                                    _context.SaveChanges();
                                }
                        }

                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

            }
    }
}
