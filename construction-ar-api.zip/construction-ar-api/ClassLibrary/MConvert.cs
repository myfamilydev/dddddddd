﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary
{
    public static class MConvert
    {
        public static string CurrencyToKhmer(double money)
        {
                string result = "";
                bool isdecimalpoint = true;
                string str_moeny = "" + (int)money;
                tt:
                int str_length = str_moeny.Length;
                int n = (int)Math.Ceiling((float)str_length / 3);
                int nchar = 0;
                int pos = 0;
                while (n > 0)
                {
                    if (pos == 0) nchar = str_length - (n - 1) * 3;
                    else nchar = 3;

                    string temp_moeny = str_moeny.Substring(pos, nchar);
                    int length = temp_moeny.Length;
                    for (int index = length; index > 0; index--)
                    {
                        string digit = temp_moeny.Substring(length - index, 1);
                        if (index == 2)
                        {
                            switch (digit)
                            {
                                case "1": result += "ដប់"; break;
                                case "2": result += "ម្ភៃ"; break;
                                case "3": result += "សាមសិប"; break;
                                case "4": result += "សែសិប"; break;
                                case "5": result += "ហាសិប"; break;
                                case "6": result += "ហុកសិប"; break;
                                case "7": result += "ចិតសិប"; break;
                                case "8": result += "ប៉ែតសិប"; break;
                                case "9": result += "កៅសិប"; break;
                            }

                        }
                        else
                        {
                            switch (digit)
                            {
                                case "1": result += "មួយ"; break;
                                case "2": result += "ពីរ"; break;
                                case "3": result += "បី"; break;
                                case "4": result += "បួន"; break;
                                case "5": result += "ប្រាំ"; break;
                                case "6": result += "ប្រាំមួយ"; break;
                                case "7": result += "ប្រាំពីរ"; break;
                                case "8": result += "ប្រាំបី"; break;
                                case "9": result += "ប្រាំបួន"; break;
                            }
                            if (index == 3) result += "រយ";
                        }

                    }

                    if ((n - 1) * 3 == 6) result += "លាន";
                    if ((n - 1) * 3 == 3) result += "ពាន់";
                    pos += nchar;
                    --n;

                }
                //do convert decimal point
                if (isdecimalpoint)
                {
                    result += "ដុល្លា";
                    str_moeny = money.ToString("#.00");
                    int charindex = str_moeny.LastIndexOf('.');
                    str_moeny = str_moeny.Substring(charindex + 1, str_moeny.Length - charindex - 1);
                    if (Int32.Parse(str_moeny) > 0)
                    {
                        isdecimalpoint = false;
                        result += " និង";
                        goto tt;
                    }
                }
                else result += "សេន";
                result += "គត់";
                return result;
        }

    }
}
