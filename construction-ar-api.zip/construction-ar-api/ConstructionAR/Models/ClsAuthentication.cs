﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Models
{
    public class ClsLogin
    {
        public string Username { set; get; }
        public string Password { set; get; }
        public string Email { set; get; }

        public string Token { set; get; }
    }

    public class UserChangePassword
    {
        public Guid Uuid { set; get; }
        public string OldPassword { set; get; }
        public string NewPassword { set; get; }
    }

    public class VeriedCode
    {
        public string Code { get; set; }

        //public string? RedirectUri { get; set; }
    }
}
