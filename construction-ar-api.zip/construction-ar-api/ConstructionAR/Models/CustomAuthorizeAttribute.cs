﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Models
{
    [AttributeUsage(AttributeTargets.Class)]
    public class CustomAuthorizeAttribute: Attribute, IAuthorizationFilter
    {
        
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
                    try
                    {
               
                        var request = filterContext.HttpContext.Request;
                        var url = $"{request.Scheme}://{request.Host}{request.Path}{Uri.UnescapeDataString(request.QueryString.ToString())}";
                        var controller_name = filterContext.ActionDescriptor.RouteValues["controller"].ToString();
                        var action = filterContext.ActionDescriptor.RouteValues["action"].ToString();

                        using (var _context = new MayuraContext())
                        {
                            var claimsIdentity = (ClaimsIdentity)filterContext.HttpContext.User.Identity;
                            var claims_obj = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
                            var apilog = new ApiLog();
                            apilog.Controller = controller_name;
                            apilog.Action = action;
                            apilog.Url = url;
                            apilog.CreatedAt = DateTime.Now;
                            apilog.CreatedBy = claims_obj != null ? int.Parse(claims_obj.Value) : 0;
                            _context.ApiLog.Add(apilog);
                            _context.SaveChanges();
                            apilog = null;
                            _context.Dispose();
                        }

                    }
                    catch(Exception ex)
                    {
                       // throw;
                    }
            


        }
        
    }
}
