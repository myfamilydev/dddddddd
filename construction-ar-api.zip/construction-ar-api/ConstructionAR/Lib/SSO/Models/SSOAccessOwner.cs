﻿

namespace BVMPP.ClientOauth.Models
{
    public class SSOAccessOwner
    {
        public long Id { get; set; }
        public string AccessToken { get; set; }
        public int ExpiresIn { get; set; }

        public string TokenType { get; set; }

        public string Username { get; set; }

        public string Email { get; set; }
    }
}
