﻿
namespace BVMPP.ClientOauth.Models
{
    public class SignupRes
    {
        public string messages { get; set; }
        public bool is_exist { get; set; }
        public object data { get; set; }
    }
}
