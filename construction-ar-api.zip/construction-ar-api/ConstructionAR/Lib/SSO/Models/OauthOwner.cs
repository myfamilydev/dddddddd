﻿

namespace BVMPP.ClientOauth.Models
{
    public class OauthOwner
    {
        public int id { get; set; }
        public string username { get; set; }

        public string email { get; set; }
    }
}
