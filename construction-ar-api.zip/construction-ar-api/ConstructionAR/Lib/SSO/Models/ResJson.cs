﻿
namespace BVMPP.ClientOauth.Models
{
    public class ResJson
    {
        public string messages { get; set; }
        public bool is_exist { get; set; }
        public OauthOwner data { get; set; }
    }

	public class ResJsonValid
	{
		public string messages { get; set; }
		public bool Valid { get; set; }
	}
}
