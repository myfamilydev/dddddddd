﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Parameters
{    
    public class PenaltyGenerateInput
    {
        public int HouseId { set; get; }
        public DateTime PaidDate { set; get; }
    }
    public class FinalPaymentInput
    {
        public int HouseId { set; get; }
        public DateTime finalPaymentDate { set; get; }
    }
    public class ClsScheduleToDisable
    {
        public int DisableScheduleRequestId { set; get; }
        public int HouseId { set; get; }
        public int PaymentScheduleInfoId { set; get; }
        public string Reason { set; get; }
        public int NewDuration { set; get; }

    }
    public class ClsPaidModel
    {
        public int RegularCollectionId { get; set; }
        public short? ProjectId { get; set; }
        public int HouseId { get; set; }
        public string CollectionClass { get; set; }
        public int? PayeeId { get; set; }
        public decimal? TotalAmount { get; set; }
        public int? Method1Id { get; set; }
        public decimal? Method1Amount { get; set; }
        public int? Method2Id { get; set; }
        public decimal? Method2Amount { get; set; }
        public int? Method3Id { get; set; }
        public decimal? Method3Amount { get; set; }
        public string Remark { get; set; }
        public DateTime PaidDate { get; set; }
        public decimal HousePaid { set; get; }
        public decimal PublicServicePaid { set; get; }
        public decimal PublicServiceDiscountPaid { set; get; }
        public decimal PenaltyPaid { set; get; }
        public decimal FirstExtraPrinciplePaid { set; get; }
        public decimal ExtraPrinciplePaid { set; get; }
        public decimal InterestPaid { set; get; }
        public decimal FinalPaymentPaid { set; get; }    
        public string ScheduleIdList { set; get; }
        public string HousePaidList { set; get; }
        public string PrePrintedNumber { set; get; }
        public string RefNo1 { get; set; }
        public string RefNo2 { get; set; }
        public string RefNo3 { get; set; }
        public DateTime? RefDate1 { get; set; }
        public DateTime? RefDate2 { get; set; }
        public DateTime? RefDate3 { get; set; }
        public string AccountNumber1 { get; set; }        
        public string AccountNumber2 { get; set; }       
        public string AccountNumber3 { get; set; }
        public decimal OverFinalPayment { set; get; }
        public short MovePrepaidOver { set; get; }

    }
    public class ClsPublicServiceMoreSchedule
    {
        public int HouseId { set; get; }
    }

}
