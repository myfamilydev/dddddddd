﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
namespace Web.Controllers
{
    [Route("api/v1/history")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class HistoryController : Controller
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public HistoryController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
           
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

       /*HttpGet("booking/house/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHistoryBookingByHouseId(int house_id)
        {
            var result = _context.HistoryBooking.FromSqlRaw("exec dbo.sp_booking_history_by_houseid {0}", house_id).AsEnumerable().ToList();
            if (result == null) return BadRequest("No Booking History for this house!");
            return Ok(result);

            //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
        } */

        [HttpGet("house/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHouseHistoryByHouseId(int house_id)
        {
            var result = _context.HouseHistory.FromSqlRaw("exec dbo.get_house_history {0}", house_id).AsEnumerable().ToList();
            if (result == null) return BadRequest("No Booking History for this house!");
            return Ok(result);

            //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
        }


        /* [HttpGet("booking/{booking_id}")]
         public async Task<ActionResult<IEnumerable<object>>> GetHistoryBookingByBookingId(int booking_id)
         {
             var result = _context.HistoryBooking.FromSqlRaw("exec dbo.sp_booking_history_by_bookingid {0}", booking_id).AsEnumerable().ToList();
             if (result == null) return BadRequest("No Contract History for this house!");
             return Ok(result);

             //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
         }
         [HttpGet("contract/house/{house_id}")]
         public async Task<ActionResult<IEnumerable<object>>> GetHistoryContractByHouseId(int house_id)
         {
             var result = _context.HistoryContract.FromSqlRaw("exec dbo.sp_contract_history_by_houseid {0}", house_id).AsEnumerable().ToList();
             if (result == null) return BadRequest("No Booking History for this contract!");
             return Ok(result);

             //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
         } 

        [HttpGet("contract/{contract_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHistoryContractByContractId(int contract_id)
        {
            var result = _context.HistoryContract.FromSqlRaw("exec dbo.sp_contract_history_by_contractid {0}", contract_id).AsEnumerable().ToList();
            if (result == null) return BadRequest("No Contract History for this contract!");
            return Ok(result);

            //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
        }*/

    }
}
