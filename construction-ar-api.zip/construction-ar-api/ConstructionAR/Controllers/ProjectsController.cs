﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/projects")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class ProjectsController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public ProjectsController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            //if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Projects>>> GetProjects()
        {
            return await _context.Projects.Where(x=>x.Status==1 && x.Id!=-14 && x.Id!=-15).ToListAsync();
        }

        [HttpGet("basicInfo")]
        public async Task<ActionResult<IEnumerable<object>>> GetProjectsBasic()
        {
            var data = (from t1 in _context.Projects
                        join t2 in _context.UsersToProjects.Where(t2 => t2.UserId == _userIdentity.Id) on t1.Id equals t2.ProjectId
                        select new { t1.Id, t1.ProjectAbbr, t1.ProjectCode, name = t1.ProjectShort }).ToList();

            return data;
        }      

        [HttpGet("{id}")]
        public async Task<ActionResult<Projects>> GetProjects(short id)
        {
            var data = await _context.Projects.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Projects>> AddProject(Projects data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            _context.Projects.Add(data);
                            await _context.SaveChangesAsync();

                            var usertoproject = new UsersToProjects
                            {
                                UserId = _userIdentity.Id,
                                ProjectId = data.Id,
                                CreatedAt = DateTime.Now,
                                CreatedBy = _userIdentity.Id
                            };
                            _context.UsersToProjects.Add(usertoproject);
                            await _context.SaveChangesAsync();
                            
                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[projects_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log project can not saved!");
                            dbContextTransaction.Commit();

                             return data;
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
                        
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateProject(Projects data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var user_exists = await _context.Projects.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (user_exists == null)
                            {
                                return BadRequest("Uuid not found");
                            }

                            data.Status = 1;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[projects_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log project can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
                    
        }

        //Street
        [HttpGet("streets")]
        public async Task<ActionResult<IEnumerable<VStreets>>> GetStreet([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VStreets
                    .Where(x => (!filter.ProId.HasValue || x.ProjectId == filter.ProId))
                    .ToListAsync();

            return data;
        }

        [HttpGet("streets/{id}")]
        public async Task<ActionResult<Streets>> GetStreets(int id)
        {
            var data = await _context.Streets.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("streets/add")]
        public async Task<ActionResult<Streets>> AddStreets(Streets data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var valid = _context.Projects.Where(x => x.Id == data.ProjectId && x.Status == 1).Any();
                            if (valid == false)
                            {
                                return BadRequest("Project is not exists");
                            }

                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            _context.Streets.Add(data);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[street_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log street can not saved!");
                            dbContextTransaction.Commit();
                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("streets/update")]
        public async Task<IActionResult> UpdateStreets(Streets data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {

                                var data_exists = await _context.Streets.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                                if (data_exists == null)
                                {
                                    return BadRequest("Street is not exists");
                                }

                                var valid = _context.Projects.Where(x => x.Id == data.ProjectId).Any();

                                if (valid == false)
                                {
                                    return BadRequest("Project is not exists");
                                }
                                data.Status = 1;
                                data.UpdatedAt = DateTime.Now;
                                data.UpdatedBy = _userIdentity.Id;

                                _context.Entry(data).State = EntityState.Modified;
                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[street_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log street can not updated!");
                                dbContextTransaction.Commit();

                                return Ok();
                        }
                        catch (Exception ex)
                        {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                        }
            }
        }

        [HttpPost("streets/delete")]
        public async Task<IActionResult> DeleteStreetss(Streets data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {
                        var data_delete = await _context.Streets.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                        if (data_delete == null) return BadRequest("Invalid street id");

                        data_delete.Status = 0;
                        await _context.SaveChangesAsync();

                        //save to audit log
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[street_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log street can not deleted!");
                        dbContextTransaction.Commit();
                        return Ok();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
            
        }

        // Bank settlement
        //Street
        [HttpGet("banks")]
        public async Task<ActionResult<IEnumerable<VBankSettlement>>> GetBanks([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VBankSettlement
                    .Where(x => (!filter.ProId.HasValue || x.ProjectId == filter.ProId))
                    .ToListAsync();

            return data;
        }

        [HttpGet("banks/{id}")]
        public async Task<ActionResult<BankSettlement>> GetBanks(int id)
        {
            var data = await _context.BankSettlement.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("banks/add")]
        public async Task<ActionResult<BankSettlement>> AddBanks(BankSettlement data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {

                        var valid = _context.Projects.Where(x => x.Id == data.ProjectId && x.Status == 1).Any();
                        if (valid == false)
                        {
                            return BadRequest("Project is not exists");
                        }
                        if (data.LyhourCard == null) data.LyhourCard = 0;

                        data.Status = 1;
                        data.CreatedAt = DateTime.Now;
                        data.CreatedBy = _userIdentity.Id;

                        _context.BankSettlement.Add(data);
                        await _context.SaveChangesAsync();

                        //save to audit log
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[settlement_bank_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log settlement bank can not saved!");
                        dbContextTransaction.Commit();
                        return data;

                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
            
        }

        [HttpPost("banks/update")]
        public async Task<IActionResult> UpdateBanks(BankSettlement data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                                var data_exists = await _context.BankSettlement.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                                if (data_exists == null)
                                {
                                    return BadRequest("Street is not exists");
                                }

                                var valid = _context.Projects.Where(x => x.Id == data.ProjectId && x.Status == 1).Any();

                                if (valid == false)
                                {
                                    return BadRequest("Project is not exists");
                                }

                                if (data.LyhourCard == null) data.LyhourCard = 0;

                                data.Status = 1;
                                data.UpdatedAt = DateTime.Now;
                                data.UpdatedBy = _userIdentity.Id;

                                _context.Entry(data).State = EntityState.Modified;
                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[settlement_bank_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log settlement bank can not updated!");
                                dbContextTransaction.Commit();
                                return Ok();
                        }
                        catch (Exception ex)
                        {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                        }
                }
                    
        }

        [HttpPost("banks/delete")]
        public async Task<IActionResult> DeleteBanks(BankSettlement data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                    try
                    {
                        var data_delete = await _context.BankSettlement.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                        if (data_delete == null) return BadRequest("Invalid bankSettlement ID");
                        //_context.BankSettlement.Remove(data_delete);
                        data_delete.Status = 0;
                        await _context.SaveChangesAsync();

                        //save to audit log
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[settlement_bank_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log settlement bank can not deleted!");
                        dbContextTransaction.Commit();
                        return Ok();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
            //return NoContent();
        }

        [HttpGet("daily-memo")]
        public async Task<ActionResult<IEnumerable<object>>> GetDailyMemo([FromQuery] PaginationFilter filter)
        {
            //return await _context.DailyMemo.ToListAsync();

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = @"select t1.*
                            from dbo.v_daily_memo t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}";

            var pagedData = _context.VDailyMemo
                               .FromSqlRaw(sql, _userIdentity.Id)
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Memo == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VDailyMemo.FromSqlRaw(sql, _userIdentity.Id)
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Memo == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("daily-memo/{id}")]
        public async Task<ActionResult<DailyMemo>> GetDailyMemoById(short id)
        {
            var data = await _context.DailyMemo.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);

            if (data == null)
            {
                return BadRequest("Memo Id is not available!");
            }
            return data;

        }
        [HttpPost("daily-memo/add")]
        public async Task<ActionResult<DailyMemo>> DailyMemoAdd(DailyMemo data)
        {

            data.Status = 1;
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _userIdentity.Id;

            try
            {
                _context.DailyMemo.Add(data);
                await _context.SaveChangesAsync();

                return data;

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("daily-memo/update")]
        public async Task<IActionResult> DailyMemoUpdate(DailyMemo data)
        {

            try
            {
                var user_exists = await _context.DailyMemo.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                if (user_exists == null)
                {
                    return BadRequest("Daily memo id is not available!");
                }

                data.Status = 1;
                data.UpdatedAt = DateTime.Now;
                data.UpdatedBy = _userIdentity.Id;

                _context.Entry(data).State = EntityState.Modified;
                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

                await _context.SaveChangesAsync();

                return Ok("Successfully updated!");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("daily-memo/delete")]
        public async Task<IActionResult> DailyMemoDelete(DailyMemo data)
        {

            try
            {
                var dailymemo = await _context.DailyMemo.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                if (dailymemo == null) return BadRequest("Daily memo id is not available!");
                dailymemo.Status = 0;
                await _context.SaveChangesAsync();

                return Ok("Successfully delete!");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("transaction/category")]
        public async Task<IEnumerable<object>> GetTransactionCategory()
        {
            return await _context.TransactionCategory.AsNoTracking().Where(x=>x.Status==1).ToListAsync();
        }

        [HttpGet("transaction/category/{id}")]
        public async Task<ActionResult<object>> GetTransactionCategoryById(int id)
        {
            var data = await _context.TransactionCategory.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return BadRequest("Invalid Transaction category Id");
            }
            return Ok(data);
        }

        [HttpPost("transaction/category/add")]
        public async Task<ActionResult<TransactionCategory>> TransactionCategoryAdd(TransactionCategory data)
        {
            try
            {

                data.CreatedAt = DateTime.Now;
                data.CreatedBy = _userIdentity.Id;
                data.Status = 1;
                _context.TransactionCategory.Add(data);
                await _context.SaveChangesAsync();
                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("transaction/category/update")]
        public async Task<IActionResult> TransactionCategoryUpdate(TransactionCategory data)
        {
            try
            {

                var category =await _context.TransactionCategory.SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1);
                if (category == null) return BadRequest("Invalid Transaction Category Id");

                category.CategoryName = data.CategoryName;
                category.Remark = data.Remark;
                category.UpdatedAt = DateTime.Now;
                category.UpdatedBy = _userIdentity.Id;
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("transaction/category/delete")]
        public async Task<IActionResult> TransactionCategoryDelete(TransactionCategory data)
        {
            try
            {

                var category = await _context.TransactionCategory.SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1);
                if (category == null) return BadRequest("Invalid Transaction Category Id");
                category.Status = 0;
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("transaction/type")]
        public async Task<ActionResult<object>> GetTransactionType([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = _context.VTransactionTypes
                                .Where(x => (
                                                    String.IsNullOrEmpty(filter.Search) ||
                                                    x.TransactionName.ToLower().Contains(validFilter.Search.ToLower()) ||
                                                    x.CategoryName.ToLower().Contains(validFilter.Search.ToLower()) ||
                                                    x.Remark.ToLower().Contains(validFilter.Search.ToLower())
                                            )
                                      )
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .OrderByDescending(x => x.Id)
                                .ToList();

            validFilter.TotalRecords =
                await _context.VTransactionTypes.CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }
        [HttpGet("transaction/type/{id}")]
        public async Task<ActionResult<object>> GetTransactionTypeById(byte id)
        {
            var data = await _context.TransactionTypes.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status!=0);
            if (data == null)
            {
                return BadRequest("Invalid Transaction type Id");
            }
            return Ok(data);
        }

        [HttpPost("transaction/type/add")]
        public async Task<ActionResult<TransactionTypes>> TransactionTypeAdd(TransactionTypes data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            data.Status = 10;
                            data.Ordering = 0;
                            _context.TransactionTypes.Add(data);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[transaction_types_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log transaction type can not saved!");
                            dbContextTransaction.Commit();
                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

        }

        [HttpPost("transaction/type/update")]
        public async Task<IActionResult> TransactionTypeUpdate(TransactionTypes data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var ttype = await _context.TransactionTypes.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status != 0);
                            if (ttype == null) return BadRequest("Invalid Transaction Type Id");

                            ttype.TransactionName = data.TransactionName;
                            ttype.Remark = data.Remark;
                            ttype.Ordering = 0;
                            ttype.UpdatedAt = DateTime.Now;
                            ttype.UpdatedBy = _userIdentity.Id;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[transaction_types_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log transaction type can not updated!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("transaction/type/delete")]
        public async Task<IActionResult> TransactionTypeDelete(TransactionTypes data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var ttype = await _context.TransactionTypes.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status != 0);
                            if (ttype == null) return BadRequest("Invalid Transaction Type Id");
                            ttype.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[transaction_types_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log transaction type can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            return BadRequest(ex.Message);
                        }
                }

        }

        [HttpGet("transaction/type/category/{id}")]
        public async Task<ActionResult<IEnumerable<object>>> TransactionTypeByCategoryId(int id)
        {
            try
            {
                return Ok(await _context.TransactionTypes.Where(x => x.TransactionCategoryId == id && x.Status == 10).ToListAsync());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("api-log")]
        public async Task<ActionResult<object>> GetApiLog([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = _context.ApiLog
                                .Where(x => (String.IsNullOrEmpty(filter.Search) || x.CreatedBy ==Convert.ToInt32(validFilter.Search)))
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .OrderByDescending(x => x.Id)
                                .ToList();

            validFilter.TotalRecords =
                await _context.ApiLog.CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("disable/paid-off-discount/{project_id}")]
        public async Task<ActionResult<object>> DisableProjectPaidOffDiscount(int project_id)
        {
            try
            {
                return Ok(await _context.DisableProjectPaidOffDiscount.Where(x => x.ProjectId == project_id && x.Status == 1).CountAsync());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}
