﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;


namespace Web.Controllers
{
    [Route("api/v1/dashboard")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class DashboardController : Controller
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public DashboardController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
           
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            //if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);


        }
        [HttpGet("smslog")]
        public async Task<ActionResult<IEnumerable<VTelegramLog>>> GetSMSLog()
        {

            var result = _context.TelegramLogMessage.FromSqlRaw("exec dbo.sp_get_telegram_log {0}", _userIdentity.Id).AsEnumerable().ToList();
            if (result == null) return BadRequest("There is no message alert!");
            return Ok(result);
            
        }
        [HttpGet("summary")]
        public async Task<ActionResult<IEnumerable<object>>> SummaryReport()
        {

            var result = _context.DashboardSummary.FromSqlRaw("exec sp_dashboard").AsEnumerable().FirstOrDefault();
            if (result == null) return BadRequest("There is no message alert!");
            return Ok(result);

        }
        [HttpGet("summaryallproject")]
        public async Task<ActionResult<IEnumerable<object>>> SummaryReportAllProject()
        {

            var result = _context.DashboardSummaryByProject.FromSqlRaw("exec sp_dashboard_all_project").AsEnumerable().ToList();
            if (result == null) return BadRequest("There is no message alert!");
            return Ok(result);

        }

        [HttpPost("smslog-visited/{id}")]
        public async Task<ActionResult> SMSLogVisited(long id)
        {

                var telegram_log = await _context.TelegramLog.FindAsync(id);
                if (telegram_log != null)
                {
                        _context.TelegramLogVisited.Add(new TelegramLogVisited()
                        {
                            TelegramLogId = telegram_log.Id,
                            VisitedAt = DateTime.Now,                           
                            UserId = _userIdentity.Id
                        });
                        await _context.SaveChangesAsync();
                        return Ok("success");
                }
                else
                {
                        return BadRequest("fail"); 
                }
        }


    }
}
