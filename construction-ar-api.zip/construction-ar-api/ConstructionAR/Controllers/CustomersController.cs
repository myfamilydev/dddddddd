﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/customers")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class CustomersController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public CustomersController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetCustomers([FromQuery] PaginationFilter filter)            
        {
            //var id = _userIdentity.Id;
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.Customers.AsEnumerable()
                                .Where(s => ((String.IsNullOrEmpty(filter.Search) ||
                                    (s.NameEn.ToLower().Contains(validFilter.Search.ToLower()) ||
                                    s.NameKh.Contains(validFilter.Search) ||
                                    (s.IdNo != null && s.IdNo.Contains(validFilter.Search))  ||
                                    (s.PhoneContract != null && s.PhoneContract.Contains(validFilter.Search)) ||
                                    (s.PhoneCall!=null && s.PhoneCall.Contains(validFilter.Search))
                                  ))))
                                .OrderByDescending(x=>x.CreatedAt)
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .Select(x => new
                                {
                                    x.Id,
                                    x.NameKh,
                                    x.NameEn,
                                    x.Dob,
                                    x.Gender,
                                    x.Nationality,
                                    x.IdNo,
                                    x.PhoneContract,
                                    x.PhoneCall,                                    
                                    x.CreatedAt,
                                    x.CreatedBy,
                                    x.TelegramNumber,
                                    x.Other
                                })
                                .ToList();

            validFilter.TotalRecords =
                 _context.Customers.AsEnumerable()
                    .Where(s => (String.IsNullOrEmpty(filter.Search) ||
                        (s.NameEn.ToLower().Contains(validFilter.Search.ToLower()) ||
                            s.NameKh.Contains(validFilter.Search) ||
                            (s.IdNo != null && s.IdNo.Contains(validFilter.Search)) ||
                            (s.PhoneContract != null && s.PhoneContract.Contains(validFilter.Search)) ||
                            (s.PhoneCall != null && s.PhoneCall.Contains(validFilter.Search))
                        )))
                    .Count();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetCustomersBasic()
        {
            var pagedData = await _context.Customers
                                    .Select(x => new
                                    {
                                        x.Id,
                                        NameKh = x.NameKh.ToString() + " | " + x.IdNo.ToString(),
                                        x.IdNo
                                    })
                                    .ToListAsync();

            return Ok(pagedData);

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetCustomers(int id)
        {
            var data = await _context.VCustomers.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Customers>> AddCustomers(Customers data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {
                            //-------------------------------------------------------  
                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;

                            _context.Customers.Add(data);
                            await _context.SaveChangesAsync();

                            var customer_history = new CustomersHistory();
                            customer_history.CustomerId = data.Id;
                            customer_history.Vdate = DateTime.Now;
                            customer_history.NameEn = data.NameEn;
                            customer_history.NameKh = data.NameKh;
                            customer_history.Gender = data.Gender;
                            customer_history.Dob = data.Dob;
                            customer_history.Nationality = data.Nationality;
                            customer_history.Occupation = data.Occupation;
                            customer_history.Email = data.Email;
                            customer_history.HouseNo = data.HouseNo;
                            customer_history.Street = data.Street;
                            customer_history.Village = data.Village;
                            customer_history.Commune = data.Commune;
                            customer_history.District = data.District;
                            customer_history.Province = data.Province;
                            customer_history.CustomerType = data.CustomerType;
                            customer_history.ContactType = data.ContactType;
                            customer_history.PhoneContract = data.PhoneContract;
                            customer_history.PhoneCall = data.PhoneCall;
                            customer_history.Facebook = data.Facebook;
                            customer_history.IdType = data.IdType;
                            customer_history.IdNo = data.IdNo;
                            customer_history.IdExpiryDate = data.IdExpiryDate;
                            customer_history.TelegramNumber = data.TelegramNumber;
                            customer_history.Other = data.Other;
                            customer_history.CreatedAt = DateTime.Now;
                            customer_history.CreatedBy = _userIdentity.Id;
                            customer_history.Status = 1;

                            _context.CustomersHistory.Add(customer_history);
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customers_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log customer can not saved!");
                            dbContextTransaction.Commit();

                           return data;
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
            }
            
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateCustomers(Customers data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var user_exists = _context.Customers.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                            if (user_exists == null)
                            {
                                return BadRequest("Customer not found");
                            }

                            var customer_history = new CustomersHistory();
                            customer_history.CustomerId = data.Id;
                            customer_history.Vdate = DateTime.Now;
                            customer_history.NameEn = data.NameEn;
                            customer_history.NameKh = data.NameKh;
                            customer_history.Gender = data.Gender;
                            customer_history.Dob = data.Dob;
                            customer_history.Nationality = data.Nationality;
                            customer_history.Occupation = data.Occupation;
                            customer_history.Email = data.Email;
                            customer_history.HouseNo = data.HouseNo;
                            customer_history.Street = data.Street;
                            customer_history.Village = data.Village;
                            customer_history.Commune = data.Commune;
                            customer_history.District = data.District;
                            customer_history.Province = data.Province;
                            customer_history.CustomerType = data.CustomerType;
                            customer_history.ContactType = data.ContactType;
                            customer_history.PhoneContract = data.PhoneContract;
                            customer_history.PhoneCall = data.PhoneCall;
                            customer_history.Facebook = data.Facebook;
                            customer_history.IdType = data.IdType;
                            customer_history.IdNo = data.IdNo;
                            customer_history.IdExpiryDate = data.IdExpiryDate;
                            customer_history.TelegramNumber = data.TelegramNumber;
                            customer_history.Other = data.Other;
                            customer_history.CreatedAt = DateTime.Now;
                            customer_history.CreatedBy = _userIdentity.Id;
                            customer_history.Status = 1;

                            _context.CustomersHistory.Add(customer_history);


                            data.Status = 1;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customers_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log customer can not update!");
                            dbContextTransaction.Commit();

                            return Ok();    

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
                   

        }

        [HttpPost("update-last")]
        public async Task<IActionResult> UpdateLastCustomers(Customers data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var user_exists = _context.Customers.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                    if (user_exists == null)
                    {
                        return BadRequest("Customer not found");
                    }

                    var customer_history = _context.CustomersHistory.Where(x => x.CustomerId == data.Id)
                                                                    .OrderByDescending(x=>x.CreatedAt)
                                                                    .FirstOrDefault();

                    if (customer_history != null)
                    {
                            //customer_history.CustomerId = data.Id;
                            customer_history.Vdate = DateTime.Now;
                            customer_history.NameEn = data.NameEn;
                            customer_history.NameKh = data.NameKh;
                            customer_history.Gender = data.Gender;
                            customer_history.Dob = data.Dob;
                            customer_history.Nationality = data.Nationality;
                            customer_history.Occupation = data.Occupation;
                            customer_history.Email = data.Email;
                            customer_history.HouseNo = data.HouseNo;
                            customer_history.Street = data.Street;
                            customer_history.Village = data.Village;
                            customer_history.Commune = data.Commune;
                            customer_history.District = data.District;
                            customer_history.Province = data.Province;
                            customer_history.CustomerType = data.CustomerType;
                            customer_history.ContactType = data.ContactType;
                            customer_history.PhoneContract = data.PhoneContract;
                            customer_history.PhoneCall = data.PhoneCall;
                            customer_history.Facebook = data.Facebook;
                            customer_history.IdType = data.IdType;
                            customer_history.IdNo = data.IdNo;
                            customer_history.IdExpiryDate = data.IdExpiryDate;
                            customer_history.TelegramNumber = data.TelegramNumber;
                            customer_history.Other = data.Other;
                            customer_history.CreatedAt = DateTime.Now;
                            customer_history.CreatedBy = _userIdentity.Id;
                            customer_history.Status = 1;
                    }
                    
                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customers_log] {0},{1},{2}", data.Id, "Update Last", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log last customer can not update!");
                    dbContextTransaction.Commit();

                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }


        }

        [HttpGet("complaint")]
        public async Task<ActionResult<object>> GetComplaint([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<CustomerComplaint>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("complaint/{id}")]
        public async Task<ActionResult<object>> GetComplaint(int id)
        {

            var data = await _context.CustomerComplaint.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("complaint/add")]
        public async Task<ActionResult<CustomerComplaint>> AddComplaint(CustomerComplaint data)
        {
            try
            {
                data.Status = 1;
                CrudLib<CustomerComplaint> crud = new CrudLib<CustomerComplaint>(_context, _userIdentity.Id);
                data = (CustomerComplaint)await crud.Add(data);

                return data;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("complaint/update")]
        public async Task<IActionResult> UpdateComplaint(CustomerComplaint data)
        {
            try
            {
                data.Status = 1;
                CrudLib<CustomerComplaint> crud = new CrudLib<CustomerComplaint>(_context, _userIdentity.Id);
                await crud.Update(data);

                return Ok();
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("complaint/delete")]
        public async Task<IActionResult> CustomerComplaintDelete(DeleteModel data)
        {
            try
            {
                var data_delete = await _context.CustomerComplaint.SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1);
                if (data_delete == null)
                {
                    return BadRequest();
                }

                data_delete.Status = 0;            
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("phonetracking")]
        public async Task<ActionResult<object>> GetPhoneTracking([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<PhoneTracking>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("phonetracking/{id}")]
        public async Task<ActionResult<object>> GetPhoneTracking(int id)
        {
            var data = await _context.PhoneTracking.SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("phonetracking/add")]
        public async Task<ActionResult<PhoneTracking>> AddPhoneTracking(PhoneTracking data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var contract = await _context.Contracts.FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                            if (contract != null)
                            {
                                data.BookingId = contract.BookingId;
                                data.ContractId = contract.Id;
                            }
                            data.Status = 1;
                            CrudLib<PhoneTracking> crud = new CrudLib<PhoneTracking>(_context, _userIdentity.Id);
                            data = (PhoneTracking)await crud.Add(data);

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[call_tracking_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log call tracking can not saved!");
                            dbContextTransaction.Commit();

                            return data;
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("phonetracking/update")]
        public async Task<IActionResult> UpdatePhoneTracking(PhoneTracking data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var phoneTracking = await _context.PhoneTracking.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id);
                            if (phoneTracking == null)
                            {
                                return BadRequest("There no phone tracking exist!, try again");
                            }

                            data.BookingId = phoneTracking.BookingId;
                            data.ContractId = phoneTracking.ContractId;
                            data.Status = 1;
                            CrudLib<PhoneTracking> crud = new CrudLib<PhoneTracking>(_context, _userIdentity.Id);
                            await crud.Update(data);

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[call_tracking_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log call tracking can not updated!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch(Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("phonetracking/delete")]
        public async Task<IActionResult> DeletePhoneTracking(DeleteModel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                                var data_delete = await _context.PhoneTracking.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                                if (data_delete == null)
                                {
                                    return BadRequest("Invalid phone tracking id");
                                }

                                data_delete.Status = 0;
                                await _context.SaveChangesAsync();

                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[call_tracking_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log call tracking can not deleted!");
                                dbContextTransaction.Commit();
                                return Ok();
                        }
                        catch (Exception ex)
                        {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                        }
                }
        }

        [HttpGet("currentstaying")]
        public async Task<ActionResult<object>> GetCurrentStaying([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VCurrentStaying>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("currentstaying/{id}")]
        public async Task<ActionResult<object>> GetCurrentStayingByid(int id)
        {
            var data = await _context.CurrentStaying.SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("currentstaying/add")]
        public async Task<ActionResult<CurrentStaying>> AddCurrentStaying(CurrentStaying data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            //check  house if exist 
                            var contract = await _context.Contracts.FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                            if (contract != null)
                            {
                                data.BookingId = contract.BookingId;
                                data.ContractId = contract.Id;
                            }

                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            _context.CurrentStaying.Add(data);
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[current_staying_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log current staying can not saved!");
                            dbContextTransaction.Commit();

                            return data;
                        }
                        catch(Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("currentstaying/update")]
        public async Task<IActionResult> UpdateCurrentStaying(CurrentStaying data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {

                            var currentStaying = await _context.CurrentStaying.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (currentStaying == null)
                            {
                                return BadRequest("There is no current stay exist!, try again");
                            }

                            currentStaying.OwnerName = data.OwnerName;
                            currentStaying.ContactNumber = data.ContactNumber;
                            currentStaying.Behavior = data.Behavior;
                            currentStaying.Remark = data.Remark;

                            currentStaying.UpdatedAt = DateTime.Now;
                            currentStaying.UpdatedBy = _userIdentity.Id;
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[current_staying_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log current staying can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
        }

        [HttpPost("currentstaying/delete")]
        public async Task<IActionResult> DeleteCurrentStaying(CurrentStaying data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var data_delete = await _context.CurrentStaying.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (data_delete == null)
                            {
                                return BadRequest("Invalid Current Staying id");
                            }

                            data_delete.Status = 0;
                            data_delete.UpdatedAt = DateTime.Now;
                            data_delete.UpdatedBy = _userIdentity.Id;
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[current_staying_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log current staying can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }


        [HttpGet("adjustment")]
        public async Task<ActionResult<object>> GetCustomerAdjustment([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_customer_adjustment_filter {0},{1},{2}";

            var data = _context.VCustomerAdjustmentFilter
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("adjustment/customers/{house_id}")]
        public async Task<ActionResult<object>> GetCustomerByHouse(int house_id)
        {
            string sql = $"exec dbo.get_customer_adjustment_by_house {house_id}";
            return _context.Customers.FromSqlRaw(sql).AsEnumerable().ToList();
        }

        [HttpGet("adjustment/customers/initial/{customer_adjustment_id}")]
        public async Task<ActionResult<object>> GetCustomerByCustomerAdjustmentId(int customer_adjustment_id)
        {
            string sql = $"exec dbo.get_customer_adjustment_by_adjustment_id {customer_adjustment_id}";
            return _context.Customers.FromSqlRaw(sql).AsEnumerable().ToList();
        }

        [HttpGet("adjustment/houses/{project_id}")]
        public async Task<IEnumerable<VCustomerAdjustmentHouse>> GetCustomerAdjustmentHousebyProject(int project_id)
        {
            string sql = $"exec dbo.get_customer_adjustment_house {project_id}";
            return _context.VCustomerAdjustmentHouse.FromSqlRaw(sql).AsEnumerable().ToList();
        }

        [HttpGet("adjustment/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetCustomerAdjustmentById(int id)
        {

            var data = await _context.CustomersAdjustment.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid customer adjustment");

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.customers_adjustment", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
            //return data;
        }

        [HttpPost("adjustment/approved/{id}")]
        public async Task<ActionResult> CustomerAdjustmentApprove(int id)
        {
            var public_service = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_customer_adjustment_approve {0},{1}", id, _userIdentity.Id);
            if (public_service == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpPost("adjustment/add")]
        public async Task<ActionResult<CustomersAdjustment>> AddCustomerAdjustment(CustomersAdjustment data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {

                    var customerInfo = await _context.Customers.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.SelectedCustomerId && x.Status == 1);
                    if (customerInfo == null) return BadRequest("There is no customer to update!");

                    //save to audit log
                    data.NameEn = customerInfo.NameEn;
                    data.NameKh = customerInfo.NameKh;
                    data.Gender = customerInfo.Gender;
                    data.Dob = customerInfo.Dob;
                    data.Nationality = customerInfo.Nationality;
                    data.Occupation = customerInfo.Occupation;
                    data.HouseNo = customerInfo.HouseNo;
                    data.Street = customerInfo.Street;
                    data.Village = customerInfo.Village;
                    data.Commune = customerInfo.Commune;
                    data.District = customerInfo.District;
                    data.Province = customerInfo.Province;
                    data.PhoneContract = customerInfo.PhoneContract;
                    data.IdType = customerInfo.IdType;
                    data.IdNo = customerInfo.IdNo;
                    data.IdExpiryDate = customerInfo.IdExpiryDate;

                    var contract = await _context.Contracts.SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                    if (contract != null)
                    {
                        data.ProjectId = contract.ProjectId;
                        data.HouseId = contract.HouseId;
                        data.BookingId = contract.BookingId;
                        data.ContractId = contract.Id;
                    }
                    else
                    {

                        var booking = await _context.Bookings.SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                        if (booking != null)
                        {
                            data.ProjectId = booking.ProjectId;
                            data.HouseId = booking.HouseId;
                            data.BookingId = booking.Id;
                            data.ContractId = null;
                        }
                    }

                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.RecStatus = 0;
                    data.Status = 1;

                    _context.Add(data);
                    await _context.SaveChangesAsync();

                    //Add Workflow History draft
                    WorkflowDetailModel wf = new WorkflowDetailModel();
                    var workflowhistory = wf.WorkflowHistoryDraft("dbo.customers_adjustment", data.Id, _userIdentity.Id);
                    _context.WorkflowHistory.Add(workflowhistory);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customers_adjustment_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log customer adjustment can not saved!");

                    dbContextTransaction.Commit();
                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("adjustment/update")]
        public async Task<ActionResult> UpdateCustomerAdjustment(CustomersAdjustment data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    //save to audit log
                    var customerAdjustment = await _context.CustomersAdjustment.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                    if (customerAdjustment == null)
                    {
                        return BadRequest("Invalid customer adjustment!");
                    }

                    var customerInfo = await _context.Customers.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.SelectedCustomerId && x.Status == 1);
                    if (customerInfo == null) return BadRequest("There is no customer to update!");

                    var contract = await _context.Contracts.SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                    if (contract != null)
                    {
                        customerAdjustment.ProjectId = contract.ProjectId;
                        customerAdjustment.HouseId = contract.HouseId;
                        customerAdjustment.BookingId = contract.BookingId;
                        customerAdjustment.ContractId = contract.Id;
                    }
                    else
                    {

                        var booking = await _context.Bookings.SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                        if (booking != null)
                        {
                            customerAdjustment.ProjectId = booking.ProjectId;
                            customerAdjustment.HouseId = booking.HouseId;
                            customerAdjustment.BookingId = booking.Id;
                            customerAdjustment.ContractId = null;
                        }
                    }

                    customerAdjustment.CurrentCustomer1Id = data.CurrentCustomer1Id;
                    customerAdjustment.CurrentCustomer2Id = data.CurrentCustomer2Id;
                    customerAdjustment.SelectedCustomerId = data.SelectedCustomerId;
                    //process update

                    customerAdjustment.NameEn = customerInfo.NameEn;
                    customerAdjustment.NameKh = customerInfo.NameKh;
                    customerAdjustment.Gender = customerInfo.Gender;
                    customerAdjustment.Dob = customerInfo.Dob;
                    customerAdjustment.Nationality = customerInfo.Nationality;
                    customerAdjustment.Occupation = customerInfo.Occupation;
                    customerAdjustment.HouseNo = customerInfo.HouseNo;
                    customerAdjustment.Street = customerInfo.Street;
                    customerAdjustment.Village = customerInfo.Village;
                    customerAdjustment.Commune = customerInfo.Commune;
                    customerAdjustment.District = customerInfo.District;
                    customerAdjustment.Province = customerInfo.Province;
                    customerAdjustment.PhoneContract = customerInfo.PhoneContract;
                    customerAdjustment.IdType = customerInfo.IdType;
                    customerAdjustment.IdNo = customerInfo.IdNo;
                    customerAdjustment.IdExpiryDate = customerInfo.IdExpiryDate;

                    customerAdjustment.NewNameEn = data.NewNameEn;
                    customerAdjustment.NewNameKh = data.NewNameKh;
                    customerAdjustment.NewGender = data.NewGender;
                    customerAdjustment.NewDob = data.NewDob;
                    customerAdjustment.NewNationality = data.NewNationality;
                    customerAdjustment.NewOccupation = data.NewOccupation;
                    customerAdjustment.NewHouseNo = data.NewHouseNo;
                    customerAdjustment.NewStreet = data.NewStreet;
                    customerAdjustment.NewVillage = data.NewVillage;
                    customerAdjustment.NewCommune = data.NewCommune;
                    customerAdjustment.NewDistrict = data.NewDistrict;
                    customerAdjustment.NewProvince = data.NewProvince;
                    customerAdjustment.NewPhoneContract = data.NewPhoneContract;
                    customerAdjustment.NewIdNo = data.NewIdNo;
                    customerAdjustment.NewIdExpiryDate = data.NewIdExpiryDate;

                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customers_adjustment_log] {0},{1},{2}", data.Id, "update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log customer adjustment can not saved!");

                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("adjustment/delete")]
        public async Task<ActionResult> DeleteScheduleToDisable(CustomersAdjustment data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {

                    //save to audit log
                    var customerAdjustment = await _context.CustomersAdjustment.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                    if (customerAdjustment == null)
                    {
                        return BadRequest("Invalid customer adjustment to delete!");
                    }

                    customerAdjustment.Status = 0;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customers_adjustment_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log customer adjustment can not saved!");

                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }




    }
}
