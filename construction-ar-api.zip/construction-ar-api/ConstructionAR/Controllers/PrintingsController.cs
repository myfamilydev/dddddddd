﻿using Microsoft.AspNetCore.Mvc;

namespace Web.Controllers
{
    [Route("api/v1/printings")]
    [ApiController]
    public class PrintingsController : Controller
    {
        [HttpGet("index")]
        public IActionResult Index()
        {
            return View("Views/Printings/Booking.cshtml");
        }
    }
}
