﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Entities.Customize;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/schedule")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class ScheduleController : Controller
    {
        private readonly ARContext _arcontext;
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public ScheduleController(ARContext arcontext,MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {            
            _httpContextAccessor = httpContextAccessor;
            _arcontext = arcontext;
            _context = context;
            _config = config;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet("noneinterest/{house_id}")]
        public async Task<IActionResult> NoneInterestSchedule(int house_id)
        {

                    object info;
                    object step_info = null;

                    var contract = await _context.Contracts.OrderByDescending(x => x.ContractDate).FirstOrDefaultAsync(x => x.HouseId == house_id && x.Status == 1);
                    if (contract == null) BadRequest("Invalid house id");
                    int contract_id = contract.Id;

                    var house_info = await _arcontext.VprintSchedule.FirstOrDefaultAsync(x => x.ContractId == contract_id);

                    
                    //info = await _arcontext.VPaymentSchedulesInfo.Where(x => x.ContractId == contract_id && x.InterestPercentMonth == 0 && (x.step == null || x.step == 1))
                    //.OrderByDescending(x => x.RescheduleNo).ThenBy(x => x.step)              //.ThenBy(x => x.InterestPercentMonth)
                    //.ToListAsync();

                    //step_info = await _arcontext.VPaymentSchedulesInfo.Where(x => x.ContractId == contract_id && x.InterestPercentMonth == 0)
                    //.Select(x => new { RescheduleNo = x.RescheduleNo, Step = x.step, Amount = x.OutstandingPrinciple, Month = x.NMonth })
                    //.OrderBy(x => x.RescheduleNo).ThenBy(x => x.Step)              //.ThenBy(x => x.InterestPercentMonth)
                    //.ToListAsync();

                    var list_info = await _arcontext.VPaymentSchedulesInfo.FromSqlRaw("exec sp_get_payment_schedules_info {0}", contract_id).ToListAsync();


                    info = list_info.Where(x => x.InterestPercentMonth == 0 && (x.step == null || x.step == 1))
                    .OrderByDescending(x => x.RescheduleNo).ThenBy(x => x.step)              //.ThenBy(x => x.InterestPercentMonth)
                    .ToList();

                    step_info = list_info.Where(x => x.InterestPercentMonth == 0)
                    .Select(x => new { RescheduleNo = x.RescheduleNo, Step = x.step, Amount = x.OutstandingPrinciple, Month = x.NMonth })
                    .OrderBy(x => x.RescheduleNo).ThenBy(x => x.Step)              //.ThenBy(x => x.InterestPercentMonth)
                    .ToList();
                    


                    if (info != null)
                    {
                        var booking_info= _arcontext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment {0}", house_id).AsEnumerable().ToList();
                        var bankSettle = await _context.BankSettlement.Where(x => x.ProjectId == contract.ProjectId && x.Status == 1).ToListAsync();
                        var detail = _arcontext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail_by_option {0},0", house_id).AsNoTracking().ToList();
                        return Ok(new { HouseInfo = house_info, Info = info, StepInfo = step_info, BookingInfo = booking_info, BankSettle = bankSettle, Detail = detail });
                    }
                    else
                    {
                        return BadRequest("No Schedule for this contract");
                    }

        }

        [HttpGet("interest/{house_id}")]
        public async Task<IActionResult> InterestSchedule(int house_id)
        {

            var contract = await _context.Contracts.OrderByDescending(x => x.ContractDate).FirstOrDefaultAsync(x => x.HouseId == house_id && x.Status == 1);
            if (contract == null) BadRequest("Invalid house id");
            int contract_id = contract.Id;
            //return BadRequest("No Schedule for this contract");
            var house_info = await _arcontext.VprintSchedule.FirstOrDefaultAsync(x => x.ContractId == contract_id);
            var booking_info= _arcontext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment {0}", house_id).AsEnumerable().ToList();

            //var info = await _arcontext.VPaymentSchedulesInfo.Where(x => x.ContractId == contract_id && x.InterestPercentMonth > 0)
            //    .OrderByDescending(x => x.CreatedAt)             //.ThenBy(x => x.InterestPercentMonth)
            //    .ToListAsync();

            var list_info = await _arcontext.VPaymentSchedulesInfo.FromSqlRaw("exec sp_get_payment_schedules_info {0}", contract_id).ToListAsync();

            var info = list_info.Where(x => x.InterestPercentMonth > 0)
                .OrderByDescending(x => x.CreatedAt)             //.ThenBy(x => x.InterestPercentMonth)
                .ToList();

            if (info != null)
            {
                var bankSettle = await _context.BankSettlement.Where(x => x.ProjectId == contract.ProjectId && x.Status == 1).ToListAsync();
                var detail = _arcontext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail_by_option {0},1", house_id).AsNoTracking().ToList();
                return Ok(new { HouseInfo = house_info, Info = info, BankSettle = bankSettle, BookingInfo= booking_info, Detail = detail });
            }
            else
            {
                return BadRequest("No Schedule for this contract");
            }
        }

        [HttpGet("noneinterest-termination/{contract_id}")]
        public async Task<IActionResult> NoneInterestScheduleTermination(int contract_id)
        {

            object info;
            object step_info = null;

            var contract = await _context.Contracts.SingleOrDefaultAsync(x => x.Id == contract_id && x.RecStatus == 18 && x.Status == 2);
            if (contract == null) return BadRequest("No Schedule for this contract!");

            var house_info = _arcontext.VprintSchedule.FromSqlRaw("exec dbo.sp_get_customer_detail_info_1 {0}", contract_id).AsEnumerable().FirstOrDefault();
            var list_info = await _arcontext.VPaymentSchedulesInfo.FromSqlRaw("exec dbo.sp_get_payment_schedules_info {0}", contract_id).ToListAsync();


            info = list_info.Where(x => x.InterestPercentMonth == 0 && (x.step == null || x.step == 1))
            .OrderByDescending(x => x.RescheduleNo).ThenBy(x => x.step)              //.ThenBy(x => x.InterestPercentMonth)
            .ToList();

            step_info = list_info.Where(x => x.InterestPercentMonth == 0)
            .Select(x => new { RescheduleNo = x.RescheduleNo, Step = x.step, Amount = x.OutstandingPrinciple, Month = x.NMonth })
            .OrderBy(x => x.RescheduleNo).ThenBy(x => x.Step)              //.ThenBy(x => x.InterestPercentMonth)
            .ToList();

            if (info != null)
            {
                var booking_info = _arcontext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment_1 {0}", contract_id).AsEnumerable().ToList();
                var bankSettle = await _context.BankSettlement.Where(x => x.ProjectId == house_info.ProjectId && x.Status == 1).ToListAsync();
                var detail = _arcontext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail_by_option_1 {0},0", contract_id).AsNoTracking().ToList();
                return Ok(new { HouseInfo = house_info, Info = info, StepInfo = step_info, BookingInfo = booking_info, BankSettle = bankSettle, Detail = detail });
            }
            else
            {
                return BadRequest("No Schedule for this contract!");
            }

        }

        [HttpGet("interest-termination/{contract_id}")]
        public async Task<IActionResult> InterestScheduleTermination(int contract_id)
        {

            //return BadRequest("No Schedule for this contract");
            var contract = await _context.Contracts.SingleOrDefaultAsync(x => x.Id == contract_id && x.RecStatus == 18 && x.Status == 2);
            if (contract == null) return BadRequest("No Schedule for this contract!");

            var house_info = _arcontext.VprintSchedule.FromSqlRaw("exec dbo.sp_get_customer_detail_info_1 {0}", contract_id).AsEnumerable().FirstOrDefault();
            var booking_info = _arcontext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment_1 {0}", contract_id).AsEnumerable().ToList();

            var list_info = await _arcontext.VPaymentSchedulesInfo.FromSqlRaw("exec sp_get_payment_schedules_info {0}", contract_id).ToListAsync();

            var info = list_info.Where(x => x.InterestPercentMonth > 0)
                .OrderByDescending(x => x.CreatedAt)             //.ThenBy(x => x.InterestPercentMonth)
                .ToList();

            if (info != null)
            {
                var bankSettle = await _context.BankSettlement.Where(x => x.ProjectId == house_info.ProjectId && x.Status == 1).ToListAsync();
                var detail = _arcontext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail_by_option_1 {0},1", contract_id).AsNoTracking().ToList();
                return Ok(new { HouseInfo = house_info, Info = info, BankSettle = bankSettle, BookingInfo = booking_info, Detail = detail });
            }
            else
            {
                return BadRequest("No Schedule for this contract");
            }
        }



        [HttpPost("instant/generate")]
        public async Task<IActionResult> ScheduleInstantGenerate(PaymentSchedulesInstantMain schedule)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    schedule.CreatedAt = DateTime.Now;
                    schedule.CreatedBy = _userIdentity.Id;
                    _context.PaymentSchedulesInstantMain.Add(schedule);
                    await _context.SaveChangesAsync();

                    await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_schedule_instant_generate {0},{1}", schedule.Id, _userIdentity.Id);
                    dbContextTransaction.Commit();
                    var ScheduleInfo = await _context.PaymentSchedulesInstantInfo.Where(x => x.InstantMainId == schedule.Id).ToListAsync();
                    var ScheduleDetail = await _context.PaymentSchedulesInstant.FromSqlRaw("exec dbo.sp_get_payment_schedules_instant {0}", schedule.Id).ToListAsync();
                    return Ok(new { info = ScheduleInfo, detail = ScheduleDetail });

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest("Transaction flooding, save not success, pls try again.");
                }

            }

        }

        [HttpPost("instant-reschedule/generate")]
        public async Task<IActionResult> InstantRescheduleGenerate(ReSchedulesInstantMain schedule)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    schedule.CreatedAt = DateTime.Now;
                    schedule.CreatedBy = _userIdentity.Id;
                    _context.ReSchedulesInstantMain.Add(schedule);
                    await _context.SaveChangesAsync();

                    await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_re_schedule_instant_generate {0},{1}", schedule.Id, _userIdentity.Id);
                    dbContextTransaction.Commit();
                    var ScheduleInfo = await _context.ReSchedulesInstantMain.Where(x => x.Id == schedule.Id).ToListAsync();
                    var ScheduleDetail = await _context.ReSchedulesInstant.Where(x => x.ReScheduleInstantMainId == schedule.Id).ToListAsync();
                    return Ok(new { info = ScheduleInfo, detail = ScheduleDetail });

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest("Transaction flooding, save not success, pls try again.");
                }

            }

            /* if (result == -1) return Ok("success");
             else return BadRequest("operation fail"); */

        }

        [HttpPost("fix/generate")]
        public async Task<IActionResult> ScheduleFixGenerate(ClsFixSchedule fix)
        {
            try
            {

                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_house_payment_schedule_recalculation {0},{1},0", fix.house_id, fix.error_date);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("fix/adjustment")]
        public async Task<IActionResult> ScheduleFixAdjustment(ClsFixAdjustment fix)
        {
            try
            {

                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.adjustment_schedule {0},{1},{2}", fix.house_id, fix.payment_date,fix.amount);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }




    }
}
