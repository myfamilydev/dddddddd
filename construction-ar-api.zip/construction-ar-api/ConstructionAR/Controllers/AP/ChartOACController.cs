﻿using DataAccess.DBcontexts;
using DataAccess.Entities.AP;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers.AP
{
    [Route("api/v1/ap/[controller]")]
    [ApiController]
    public class ChartOACController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
       
        private readonly IAuthenticationService _authService;
        private readonly AP_SystemContext _context;
        private userIdentity _userIdentity;
        public ChartOACController(IConfiguration config, IHttpContextAccessor httpContextAccessor,
                                IAuthenticationService authService, AP_SystemContext context)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _config = config;
            _authService = authService;
            _context = context;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }


        [HttpGet("all")]
        public async Task<ActionResult<IEnumerable<VChartAccounts>>> GetChartOAC([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VChartAccounts
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.BusinessType == validFilter.Search))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VChartAccounts
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.BusinessType == validFilter.Search)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ChartAccounts>> GetChartOAC(int id)
        {
            var data = await _context.ChartAccounts.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<ChartAccounts>> AddChartOAC(ChartAccounts data)
        {
            var exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == data.CompanyId && x.AccountCode == data.AccountCode);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Account Code is already exists!", "400"));
            }

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _userIdentity.Id;
            data.InsertType = "Form";
            data.RecStatus = 0;

            _context.ChartAccounts.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateChartOAC(ChartAccounts data)
        {
            var valid = _context.ChartAccounts.AsNoTracking().FirstOrDefault(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "ID is not found!", "400"));
            }

            // Prevent duplicate account code
            var exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == data.CompanyId
                            && x.AccountCode == data.AccountCode
                            && x.Id != data.Id);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Account Code is already exists!", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;
            _context.Entry(data).Property(x => x.InsertType).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _userIdentity.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("import")]
        public async Task<ActionResult<object>> ImportChartOAC(IFormFile file)
        {

            int total_records = 0;
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    reader.Read(); //ignore first row

                    var company = await _context.Companies.AsNoTracking().ToListAsync();
                    var accType = await _context.AccountTypes.AsNoTracking().ToListAsync();

                    while (reader.Read()) //Each ROW
                    {
                        // Get company Id by Business Type
                        var com = company.FirstOrDefault(x => x.BusinessType.ToLower() == reader.GetValue(0).ToString().ToLower());
                        if (com == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Company is not found!", "400"));
                        }

                        // Prevent duplicate account code
                        var exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == com.Id
                            && x.AccountCode == reader.GetValue(1).ToString());

                        if (exists != null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Account Code is already exists!", "400"));
                        }

                        // Get Account Type Id
                        var account_type = accType.FirstOrDefault(x => x.AccountType.ToLower() == reader.GetValue(2).ToString().ToLower());
                        if (account_type == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Account Type is not found!", "400"));
                        }

                        int? sub_acc_id = null;

                        // Check if Sub Account Of
                        if (reader.GetValue(5) != null)
                        {
                            // Get Account Type Id
                            var sub_acc = _context.ChartAccounts.AsNoTracking()
                                        .FirstOrDefault(x => x.CompanyId == com.Id
                                        && x.AccountCode == reader.GetValue(5).ToString());

                            if (sub_acc == null)
                            {
                                return BadRequest(new ApiResponse("failed", "Row # " + (total_records + 2).ToString() + " Sub Account is not found!", "400"));
                            }
                            sub_acc_id = sub_acc.Id;
                        }

                        ChartAccounts acc = new ChartAccounts();
                        acc.CompanyId = com.Id;
                        acc.AccountCode = reader.GetValue(1).ToString();
                        acc.AccountTypeId = account_type.Id;
                        acc.AccountNameEn = reader.GetValue(3).ToString();
                        acc.AccountNameKh = reader.GetValue(4).ToString();
                        acc.SubAccountOfId = sub_acc_id;
                        acc.Description = reader.GetValue(6).ToString();
                        acc.Note = reader.GetValue(7).ToString();
                        acc.RecStatus = 3; //Approved
                        acc.InsertType = "Import";
                        acc.CreatedAt = created_at;
                        acc.CreatedBy = _userIdentity.Id;
                        
                        _context.ChartAccounts.Add(acc);
                        await _context.SaveChangesAsync();
                        total_records++;

                    }
                }
            }

            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!"};
        }

    }
}
