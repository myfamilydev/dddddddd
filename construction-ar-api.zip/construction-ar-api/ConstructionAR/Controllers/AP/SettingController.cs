﻿using DataAccess.DBcontexts;
using DataAccess.Entities.AP;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers.AP
{
    [Route("api/v1/ap/[controller]")]
    [ApiController]
    public class SettingController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
    
        private readonly AP_SystemContext _context;
        private userIdentity _userIdentity;
        public SettingController(IHttpContextAccessor httpContextAccessor, AP_SystemContext context)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;

            //  if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet("company/all")]
        public async Task<ActionResult<IEnumerable<Companies>>> GetCompany()
        {
            return await _context.Companies.OrderBy(x => x.CompanyName).ToListAsync();
        }

        [HttpGet("company/{id}")]
        public async Task<ActionResult<Companies>> GetCompany(short id)
        {
            var data = await _context.Companies.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("company/add")]
        public async Task<ActionResult<Companies>> AddCompany(Companies data)
        {
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _userIdentity.Id;
            data.Uuid = Guid.NewGuid();
            data.Status = 1;

            _context.Companies.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPost("company/update")]
        public async Task<IActionResult> UpdateCompany(Companies data)
        {
            var valid = _context.Companies.AsNoTracking().SingleOrDefault(x => x.Uuid == data.Uuid);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.Uuid).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _userIdentity.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("company/changeStatus")]
        public async Task<IActionResult> InactiveCompany(Companies data)
        {
            var valid = _context.Companies.SingleOrDefault(x => x.Uuid == data.Uuid);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;
            valid.Status = data.Status;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _userIdentity.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        //cost center
        [HttpGet("company/cost-center/all")]
        public async Task<ActionResult<IEnumerable<VCompanyCostCenter>>> CostCenterGetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VCompanyCostCenter
                           .Where(s => (String.IsNullOrEmpty(filter.Search) || s.CompanyId == Convert.ToInt16(filter.Search)))
                           .OrderBy(x => x.CompanyName)
                           .ToListAsync();
            return Ok(data);
        }

        [HttpGet("company/cost-center/{id}")]
        public async Task<ActionResult<CompanyCostCenters>> GetCostCenter(short id)
        {
            var data = await _context.CompanyCostCenters.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("company/cost-center/add")]
        public async Task<ActionResult<CompanyCostCenters>> AddCostCenter(CompanyCostCenters data)
        {
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _userIdentity.Id;
            data.Status = 1;

            _context.CompanyCostCenters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPost("company/cost-center/update")]
        public async Task<IActionResult> UpdateCostCenter(CompanyCostCenters data)
        {
            var valid = _context.CompanyCostCenters.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _userIdentity.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("company/cost-center/changeStatus")]
        public async Task<IActionResult> InactiveCostCenter(CompanyCostCenters data)
        {
            var valid = _context.CompanyCostCenters.SingleOrDefault(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _userIdentity.Id;
            valid.Status = data.Status;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
