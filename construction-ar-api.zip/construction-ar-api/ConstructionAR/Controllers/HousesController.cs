﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/houses")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class HousesController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public HousesController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            //if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet("price")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousePrice([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = _context.VHousePrices
                                .Where(x => (String.IsNullOrEmpty(filter.Search) || x.HouseNumber == validFilter.Search) &&
                                            (!filter.ProId.HasValue || x.ProjectId == filter.ProId)
                                 )                                
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .OrderByDescending(x=>x.Id)
                                .ToList();

            validFilter.TotalRecords =
                await _context.HousePrices
                    .Where(s => (String.IsNullOrEmpty(filter.Search) ||
                        (s.HouseNumber.Contains(validFilter.Search))))
                    .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("price/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetHousePriceById(int id)
        {

            var data = await _context.HousePrices.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)  return BadRequest("Invalid house price id");            

            int index = 0;
            if (data.PreUpdatedBy != null) index = 1;
            
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.house_prices", data.Id, _userIdentity.Id,index);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("price/add")]
        public async Task<ActionResult<HousePrices>> AddHousePrice(HousePrices data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var houses = _context.Houses.SingleOrDefault(x => x.Id == data.HouseId && x.Status == 1 && x.RecStatus < 8);
                            if (houses == null) return BadRequest("House not available");

                            var houseprice = _context.HousePrices.SingleOrDefault(x => x.HouseId == data.HouseId && x.Status == 1);
                            if (houseprice != null) return BadRequest("House already added");

                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            data.RecStatus = WorkflowStatusModel.DRAFT;
                            _context.HousePrices.Add(data);
                            await _context.SaveChangesAsync();

                            WorkflowDetailModel wdm = new WorkflowDetailModel();
                            var workflowhistory = wdm.WorkflowHistoryDraft("dbo.house_prices", data.Id, _userIdentity.Id);
                            _context.WorkflowHistory.Add(workflowhistory);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_price_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house update price can not saved!");
                            dbContextTransaction.Commit();

                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("price/approved/{refId}")]
        public async Task<ActionResult> ApprovedHousePrice(int refId)
        { 

                try
                {
                        var data_exists = _context.HousePrices.SingleOrDefault(x => x.Id == refId && x.RecStatus == WorkflowStatusModel.APPROVED);
                        if (data_exists == null) return BadRequest("House Price is not available");

                        var data = _context.Houses.SingleOrDefault(x => x.Id == data_exists.HouseId && x.RecStatus < 8);
                        if (data == null) return BadRequest("House not available");

                        byte? old_status = data_exists.RecStatus;

                        data.Price = data_exists.Price;
                        data.UpdatedAt = DateTime.Now;
                        data.UpdatedBy = _userIdentity.Id;

                        if (data_exists.PreUpdatedBy != null)
                        {

                            var price_history = new HousePricesHistory
                            {
                                ProjectId = data_exists.ProjectId,
                                HouseId = data_exists.HouseId,
                                Price = data_exists.Price,
                                EffectiveDate = data_exists.EffectiveDate,
                                Remarks = data_exists.Remarks,
                                CreatedAt = data_exists.CreatedAt,
                                CreatedBy = data_exists.CreatedBy,
                                RecStatus = data_exists.RecStatus,
                                UpdatedAt = data_exists.UpdatedAt,
                                UpdatedBy = data_exists.UpdatedBy,
                                PrePrice = data_exists.PrePrice,
                                PreUpdateAt = data_exists.PreUpdatedAt,
                                PreUpdatedBy = data_exists.PreUpdatedBy,
                                Status = 1
                            };
                            await _context.HousePricesHistory.AddAsync(price_history);
                        }

                        WorkflowHistory wf = new WorkflowHistory()
                        {
                            WorkflowId = 3,
                            RefId = refId,
                            RecStatus = old_status,
                            PostStatus = WorkflowStatusModel.APPROVED,
                            Comment = "Approve House Price",
                            IsDone = 1,
                            CreatedAt = DateTime.Now,
                            CreatedBy = _userIdentity.Id
                        };

                        _context.WorkflowHistory.Add(wf);
                        await _context.SaveChangesAsync();

                        var result = await _context.Database.ExecuteSqlRawAsync("exec [dbo].[sp_house_prices_update]");
                        if (result == -1) return Ok("success");
                        else return BadRequest("operation fail");

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }

        [HttpPost("price/update")]
        public async Task<IActionResult> UpdateHousePrice(HousePrices data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var houses = await _context.Houses.FirstOrDefaultAsync(x => x.Id == data.HouseId && x.Status == 1 && x.RecStatus < 8);
                            if (houses == null) return BadRequest("House not available");

                            var houseprice = await _context.HousePrices.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1);
                            if (houseprice == null) return BadRequest("House is not exist");

                            data.Status = 1;
                            if (houseprice.RecStatus == WorkflowStatusModel.DRAFT)
                            {

                                data.UpdatedAt = DateTime.Now;
                                data.UpdatedBy = _userIdentity.Id;
                                data.RecStatus = 0;
                                _context.Entry(data).State = EntityState.Modified;
                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                _context.Entry(data).Property(x => x.PrePrice).IsModified = false;
                                _context.Entry(data).Property(x => x.PreUpdatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.PreUpdatedBy).IsModified = false;
                                await _context.SaveChangesAsync();

                            }
                            else if (houseprice.RecStatus < 8 || houseprice.RecStatus == WorkflowStatusModel.PRICEUPDATED)
                            {

                                houses.Price = 0;
                                data.PrePrice = houseprice.Price;
                                data.PreUpdatedAt = houseprice.UpdatedAt == null ? houseprice.CreatedAt : houseprice.UpdatedAt;
                                data.PreUpdatedBy = houseprice.UpdatedBy == null ? houseprice.CreatedBy : houseprice.UpdatedBy;


                                data.UpdatedAt = DateTime.Now;
                                data.UpdatedBy = _userIdentity.Id;
                                data.RecStatus = 0;

                                _context.Entry(data).State = EntityState.Modified;
                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

                                //  await _context.SaveChangesAsync();
                                WorkflowDetailModel wdm = new WorkflowDetailModel();
                                var workflowhistory = wdm.WorkflowHistoryDraft("dbo.house_prices", data.Id, _userIdentity.Id, 1);
                                _context.WorkflowHistory.Add(workflowhistory);
                                 await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_price_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log house update price can not updated!");
                                dbContextTransaction.Commit();

                            }
                            return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }       
    
         }

        [HttpPost("price/delete")]
        public async Task<IActionResult> DeleteHousePrice(HousePrices data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var data_delete = await _context.HousePrices.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (data_delete == null)
                            {
                                return BadRequest("No, house price can not be deleted!");
                            }
                            data_delete.Status = 0;
                            //_context.HousePrices.Remove(data_delete);            
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_price_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house update price can not deleted!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                             dbContextTransaction.Rollback();
                             return BadRequest(ex.Message);
                        }
                }
            
        }
        [HttpGet("price/history/{id}")]        
        public async Task<ActionResult<IEnumerable<object>>> GetHousePriceHistory(int id)
        {
            return await _context.VHousePricesHistory.Where(x=>x.HouseId==id)
                                                     .Select(x=>new { DateChange=x.UpdatedAt,UpdatedBy=x.UpdatedBy,NewPrice=x.Price,OldPrice=x.PrePrice })
                                                     .ToListAsync();
        }

        [HttpGet("categories")]
        public async Task<ActionResult<IEnumerable<VHouseCategories>>> GetHouseCategories([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VHouseCategories
                    .Where(x => (!filter.ProId.HasValue || x.ProjectId == filter.ProId))
                    .OrderByDescending(x=>x.Id)
                    .ToListAsync();

            return data;
        }

        [HttpGet("categories/{id}")]
        public async Task<ActionResult<HouseCategories>> GetProjects(int id)
        {

            var data = await _context.HouseCategories.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }
            return data;
        }

        [HttpPost("categories/add")]
        public async Task<ActionResult<HouseCategories>> AddHouseCategories(HouseCategories data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;

                            _context.HouseCategories.Add(data);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_category_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house category can not saved!");
                            dbContextTransaction.Commit();

                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

        }

        [HttpPost("categories/update")]
        public async Task<IActionResult> UpdateHouseCategories(HouseCategories data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            var user_exists = _context.HouseCategories.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);

                            if (user_exists == null)
                            {
                                return BadRequest("Category not found");
                            }
                            data.Status = 1;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_category_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house category can not updated!");
                            dbContextTransaction.Commit();

                             return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
               
        }


        [HttpPost("categories/delete")]
        public async Task<IActionResult> DeleteCategories(HouseCategories data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            var data_delete = await _context.HouseCategories.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (data_delete == null)
                            {
                                return BadRequest("No, house category can not be deleted!");
                            }

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_category_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house category can not deleted!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

            //return NoContent();
        }


        [HttpGet("rec-status/list")]
        public async Task<ActionResult<IEnumerable<HouseRecStatus>>> GetHouseTypes()
        {
            return await _context.HouseRecStatus.OrderBy(x => x.Ordering).ToListAsync();
        }

        // House Type
        [HttpGet("types")]
        public async Task<ActionResult<IEnumerable<VHouseTypes>>> GetHouseTypes([FromQuery] PaginationFilter filter)
        {
            return await _context.VHouseTypes
                            .Where(x => (!filter.ProId.HasValue || x.ProjectId == filter.ProId))
                            .OrderByDescending(x=>x.Id)
                            .ToListAsync();
        }

        [HttpGet("types/category/{cateId}")]
        public async Task<ActionResult<IEnumerable<VHouseTypes>>> GetHouseTypesByCategory(int cateId)
        {
            return await _context.VHouseTypes
                            .Where(x => x.HouseCategoryId == cateId)
                            .ToListAsync();
        }

        [HttpGet("types/{id}")]
        public async Task<ActionResult<HouseTypes>> GetHouseTypes(int id)
        {

            var data = await _context.HouseTypes.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("types/add")]
        public async Task<ActionResult<HouseTypes>> AddHouseTypes(HouseTypes data)
        {

                    using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                    {

                                try
                                {

                                    var valid = _context.Projects.Where(x => x.Id == data.ProjectId && x.Status == 1).Any();
                                    if (valid == false)
                                    {
                                        return BadRequest("Project is not exists");
                                    }
                                    data.Status = 1;
                                    data.CreatedAt = DateTime.Now;
                                    data.CreatedBy = _userIdentity.Id;

                                    _context.HouseTypes.Add(data);
                                    await _context.SaveChangesAsync();

                                    //save to audit log
                                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_types_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                    if (result != -1) throw new Exception("Log house type can not saved!");
                                    dbContextTransaction.Commit();

                                    return data;

                                }
                                catch (Exception ex)
                                {
                                    dbContextTransaction.Rollback();
                                    return BadRequest(ex.Message);
                                }
                    }

                    //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("types/update")]
        public async Task<IActionResult> UpdateHouseTypes(HouseTypes data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var user_exists = _context.HouseTypes.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);

                            if (user_exists == null)
                            {
                                return BadRequest("Invalid housetype id");
                            }

                            var valid = _context.Projects.Where(x => x.Id == data.ProjectId && x.Status == 1).Any();

                            if (valid == false)
                            {
                                return BadRequest("Project is not exists");
                            }

                            data.Status = 1;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_types_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house type can not update!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
            
        }


        [HttpPost("types/delete")]
        public async Task<IActionResult> DeleteHouseTypes(DeleteModel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var data_delete = await _context.HouseTypes.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (data_delete == null)
                            {
                                return BadRequest("No, house type can not be deleted!");
                            }

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_types_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house type can not deleted!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }   
           
        }

        //Houses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetHouses([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_house_filter {0},{1},{2},{3}";
            var data = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, filter.option ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.ProjectId,
                                   x.ProjectShort,
                                   x.CategoryName,
                                   x.HouseType,
                                   x.LandSize,
                                   x.RoadType,
                                   x.HouseNumber,
                                   x.HousePrice,
                                   x.StNo,
                                   x.HouseStatus,
                                   x.Payproaccid,
                                   x.RecStatus
                               })
                               .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

            /*var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = @"select t1.*
                           from dbo.v_houses_full_join t1 
                           where t1.project_id in (select distinct project_id from  dbo.users_to_projects where user_id={0})";

            var pagedData = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id)
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || (s.HouseNumber == validFilter.Search
                                     || s.CategoryName.Contains(validFilter.Search)
                                     || s.HouseType.Contains(validFilter.Search)
                                     || s.LandSize.Contains(validFilter.Search)
                                     || s.RoadType.Contains(validFilter.Search)
                                     || s.HouseStatus.Contains(validFilter.Search)))) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .OrderByDescending(x=>x.HouseId)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.ProjectId,
                                   x.ProjectShort,
                                   x.CategoryName,
                                   x.HouseType,
                                   x.LandSize,
                                   x.RoadType,
                                   x.HouseNumber,
                                   x.HousePrice,
                                   x.StNo,
                                   x.HouseStatus,
                                   x.Payproaccid
                               })
                               .ToList();

            validFilter.TotalRecords =
                await _context.VHousesFullJoin.FromSqlRaw(sql, _userIdentity.Id)
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter)); */

        }

        [HttpGet("booked/project/{proId}/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesBookedByProject(int proId,int house_id)
        {

            var booking = await _context.VBookingHouses.
                Where(x=>(x.ContractHouseId==house_id) &&
                         (x.ProjectId == proId && (x.RecStatus == 3 || x.RecStatus==17))
                     ).ToListAsync();
            if (booking != null) return Ok(booking);
            else return BadRequest("Invalid project id");
        }

        [HttpGet("booked-collection/project/{proId}/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesBookedCollectionByProject(int proId, int house_id)
        {

            var booking = await _context.VBookingHousesCollection.
                Where(x => (x.ContractHouseId == house_id) &&
                         (x.ProjectId == proId && (x.RecStatus == 3 || x.RecStatus == 17))
                     ).ToListAsync();
            if (booking != null) return Ok(booking);
            else return BadRequest("Invalid project id");
        }       

        [HttpGet("booked-contract/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesBookedContractProject(int proId)
        {

            var booked_contract = await _context.VBookedContract.
                Where(x => (x.ProjectId == proId)).ToListAsync();
            if (booked_contract != null) return Ok(booked_contract);
            else return BadRequest("Invalid project id");
        }

        [HttpGet("booked-approve/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesBookedApproveByProject(int proId)
        {

            var booking = await _context.VBookingHouses.
                Where(x => x.ProjectId == proId).ToListAsync();
            if (booking != null) return Ok(booking);
            else return BadRequest("Invalid project id");
        }

        [HttpGet("booked-and-expired/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesBookedAndExpiredByProject(int proId)
        {
            var booking = await _context.VBookingHousesExpired.
                Where(x => (x.ProjectId == proId && x.RecStatus == 3)
                     ).ToListAsync();
            if (booking != null) return Ok(booking);
            else return BadRequest("Invalid project id");
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetHouses(int id)
        {

            var data = await _context.Houses.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.houses", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;

            
        }
        [HttpGet("info/{id}")]

        public async Task<IEnumerable<object>> GetHousesInfoById(int id)
        {
            return await _context.VHousesHouseTypes.Where(x=>x.HouseId==id).ToListAsync();            
        }

        [HttpGet("project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesByProject(int proId)
        {
            string sql = @"select t1.*
                            from dbo.v_houses_full_join t1
                            where t1.rec_status=7 and t1.house_price>0
                            and t1.project_id in 
                            (select project_id from dbo.users_to_projects where user_id={0} and project_id={1})";

            var pagedData = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id, proId)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.HouseType,
                                   x.HouseNumber
                               })
                               .ToList();

            return Ok(pagedData);

        }

        [HttpGet("available-orbook/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesBookingByProject(int proId)
        {
            string sql = @"select t1.*
                            from dbo.v_houses_full_join t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}
                                    and t1.project_id = {1} where (t1.rec_status=7 or t1.rec_status=8) and t1.house_price>0 
                                    and t1.house_id not in(select house_id from payment_terms where house_id is not null and rec_status=3 and status=1)
                            ";

            var pagedData = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id, proId)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.HouseType,
                                   x.HouseNumber
                               })
                               .ToList();

            return Ok(pagedData);

        }

        [HttpGet("all/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesAllByProject(int proId)
        {
            string sql = @"select t1.*
                            from dbo.v_houses_full_join t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}
                                    and t1.project_id = {1}";

            var pagedData = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id, proId)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.HouseType,
                                   x.HouseNumber
                               })
                               .ToList();

            return Ok(pagedData);

        }
        [HttpGet("available/project/{proId}/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesAvailableByProject(int proId, int house_id = 0)
        {
            string sql = @"select t1.*
                            from dbo.v_houses_full_join t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}
                                and t1.project_id = {1} where (t1.rec_status=7 and t1.house_price>0)
                            " + (house_id==0?"": " or (t1.house_id="+house_id+ " and t1.project_id="+proId+")");  //or t1.rec_status=8

            var pagedData = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id, proId)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.HouseType,
                                   x.HouseNumber
                               })
                               .ToList();

            return Ok(pagedData);

        }

        [HttpGet("price/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousesPriceByProject(int proId)
        {
            string sql = @"select t1.*
                            from dbo.v_houses_full_join t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}
                                    and t1.project_id = {1} where t1.rec_status=7 or t1.rec_status=3
";

            var pagedData = _context.VHousesFullJoin
                               .FromSqlRaw(sql, _userIdentity.Id, proId)
                               .Select(x => new
                               {
                                   x.HouseId,
                                   x.HouseType,
                                   x.HouseNumber
                               })
                               .ToList();

            return Ok(pagedData);

        }
        [HttpPost("approved/{refId}")]
        public async Task<ActionResult> ApprovedHouse(int refId)
        {
            try
            {
                var house = await _context.Houses.FindAsync(refId);
                if (house == null) return BadRequest("House Id not available");
                _context.HousePrices.Add(new HousePrices{
                                                            ProjectId = house.ProjectId,
                                                            HouseId = house.Id,
                                                            HouseNumber = house.Number,
                                                            Price=house.Price??0,                                                        
                                                            Remarks="",
                                                            CreatedAt=DateTime.Now,
                                                            CreatedBy= _userIdentity.Id,
                                                            RecStatus=3,
                                                            Status=1
                                                        });

                await _context.SaveChangesAsync();
                return Ok("success");

            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            

        }

        [HttpPost("add")]
        public async Task<ActionResult<Houses>> AddHouses(Houses data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        var houses = await _context.Houses.AsNoTracking().SingleOrDefaultAsync(x => x.Number == data.Number && x.Status == 1 && x.ProjectId == data.ProjectId && x.RecStatus == 3); //correct
                        if (houses != null)
                        {
                            return BadRequest("House already exists");
                        }

                        data.Status = 1;
                        data.CreatedAt = DateTime.Now;
                        data.CreatedBy = _userIdentity.Id;
                        data.RecStatus = 0;
                        try
                        {
                            _context.Houses.Add(data);
                            await _context.SaveChangesAsync();
                            using (var _manual = new ManualDbContext())
                            {

                                string payproAcc = _manual.CustomObject.FromSqlRaw("select dbo.f_payproacc(" + data.Id + ") as object1").First().object1;
                                data.Payproaccid = payproAcc;
                            }

                            _context.Entry(data).State = EntityState.Modified;

                            WorkflowDetailModel wdm = new WorkflowDetailModel();
                            var workflowhistory = wdm.WorkflowHistoryDraft("dbo.houses", data.Id, _userIdentity.Id);
                            _context.WorkflowHistory.Add(workflowhistory);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[houses_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log house can not saved!");
                            dbContextTransaction.Commit();

                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }   
            //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateHouses(Houses data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {

                                var user_exists = _context.Houses.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);
                                if (user_exists == null)
                                {
                                    return BadRequest("House not found");
                                }

                                data.UpdatedAt = DateTime.Now;
                                data.Status = 1;
                                data.RecStatus = 0;

                                using (var _manual = new ManualDbContext())
                                {
                                    string payproAcc = _manual.CustomObject.FromSqlRaw("select dbo.f_payproacc(" + data.Id + ") as object1").First().object1;

                                    data.Payproaccid = payproAcc;

                                }

                                _context.Entry(data).State = EntityState.Modified;
                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[houses_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log house can not updated!");
                                dbContextTransaction.Commit();

                                return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
            }
            
        }

        [HttpPost("delete")]
        public async Task<IActionResult> DeleteHouses(Houses data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                    try
                    {

                        var data_delete = await _context.Houses.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                        if (data_delete == null)
                        {
                            return BadRequest("No, house can not be deleted!");
                        }

                        data_delete.Status = 0;
                        await _context.SaveChangesAsync();

                        //save to audit log
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[houses_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log house can not delete!");
                        dbContextTransaction.Commit();

                        return Ok();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
            
        }


        [HttpPost("import")]
        public async Task<ActionResult<object>> ImportHouses(IFormFile file)
        {

                    using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                    {
                            try
                            {
                                int total_records = 0;
                                string batch_code = Guid.NewGuid().ToString();
                                DateTime created_at = DateTime.Now;

                                System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                                using (var stream = file.OpenReadStream())
                                {
                                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                                    {

                                        reader.Read(); //ignore first row

                                        while (reader.Read()) //Each ROW
                                        {

                                            HouseImportTemplate tem = new HouseImportTemplate();
                                            tem.ProjectId = Convert.ToInt16(reader.GetValue(0));
                                            tem.HouseCategoryName = reader.GetValue(1).ToString();
                                            tem.HouseTypeName = reader.GetValue(2).ToString();
                                            tem.Block = reader.GetValue(3).ToString();
                                            tem.RoadType = reader.GetValue(4).ToString();
                                            tem.Number = reader.GetValue(5).ToString();
                                            tem.StreetNumber = reader.GetValue(6).ToString();
                                            // tem
                                            tem.LandWidth = reader.GetValue(7).ToString();
                                            tem.LandLength = reader.GetValue(8).ToString();
                                            tem.Phase = reader.GetValue(9).ToString();
                                            tem.Remarks = reader.GetValue(10) == null ? "" : reader.GetValue(10).ToString();
                                            /*
                                            tem.Payproref = reader.GetValue(9).ToString();
                                            tem.Billercode = reader.GetValue(10).ToString();
                                            */
                                            tem.CreatedAt = created_at;
                                            tem.CreatedBy = _userIdentity.Id;
                                            tem.BatchCode = batch_code;

                                            _context.HouseImportTemplate.Add(tem);
                                            await _context.SaveChangesAsync();
                                            total_records++;

                                        }
                                    }
                                }

                                string sql = "exec dbo.sp_house_import @batch_code = '" + batch_code + "'";
                                List<HouseImportResult> result;

                                using (var _manual = new ManualDbContext())
                                {
                                    result = _manual.HouseImportResult.FromSqlRaw(sql).ToList();

                                    if (result.Count() == 0)
                                    {
                                        return NoContent();
                                    }
                                }
                                dbContextTransaction.Commit();
                                return new { TotalUploadRecords = total_records, TotalInsertRecords = (int)result.First().insert_affected_row, TotalUpdateRecords = (int)result.First().update_affected_row };

                            }catch(Exception ex)
                            {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                            }
                    }
        }

        [HttpPost("prices/import")]
        [Obsolete]
        public async Task<ActionResult<UploadResult>> PriceImportHouses(IFormFile file)
        {

            int total_records = 0;
            int affective_row = 0;
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row

                    while (reader.Read()) //Each ROW
                    {
                        int houseid = Convert.ToInt32(reader.GetValue(1).ToString());
                        decimal price = decimal.Parse(reader.GetValue(3).ToString());
                        DateTime effectiveDate = DateTime.Parse(reader.GetValue(4).ToString());
                        string remarks = reader.GetValue(5) != null ? reader.GetValue(5).ToString() : "";

                        var houseprice = _context.HousePrices.SingleOrDefault(x => x.HouseId == houseid && (x.RecStatus < 8 || x.RecStatus == WorkflowStatusModel.PRICEUPDATED));
                        if (houseprice != null)
                        {
                            houseprice.Price = price;
                            houseprice.EffectiveDate = effectiveDate;
                            houseprice.RecStatus = WorkflowStatusModel.APPROVED; //if (effectiveDate > DateTime.Today)
                            houseprice.Remarks = remarks;
                            ++affective_row;
                        }
                        ++total_records;

                    }

                    reader.Close();
                    await _context.SaveChangesAsync();
                }
            }

            var result = await _context.Database.ExecuteSqlRawAsync("exec [dbo].[sp_house_prices_update]");

            return new UploadResult { TotalUploadRecords = total_records, TotalInsertRecords = affective_row };

            /* int total_records = 0;            
             DateTime created_at = DateTime.Now;

             System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
             using (var stream = file.OpenReadStream())
             {
                 using (var reader = ExcelReaderFactory.CreateReader(stream))
                 {
                     reader.Read(); //ignore first row

                     while (reader.Read()) //Each ROW
                     {
                         HousePrices tem = new HousePrices();

                         tem.ProjectId = Convert.ToInt16(reader.GetValue(0).ToString());
                         tem.HouseId = Convert.ToInt32(reader.GetValue(1).ToString());
                         tem.HouseNumber = reader.GetValue(2).ToString();
                         tem.Price = float.Parse(reader.GetValue(3).ToString());
                         tem.EffectiveDate = DateTime.Parse(reader.GetValue(4).ToString());
                         tem.Remarks = reader.GetValue(5) != null ? reader.GetValue(5).ToString() : "";
                         tem.RecStatus = 3; // Approved
                         tem.CreatedAt = created_at;
                         tem.CreatedBy = _userIdentity.Id;

                         _context.HousePrices.Add(tem);
                         await _context.SaveChangesAsync();

                         ++total_records;
                     }
                 }
             }

             var result = await _context.Database.ExecuteSqlRawAsync("exec [dbo].[sp_house_prices_update]");            

             return new UploadResult { TotalUploadRecords = total_records, TotalInsertRecords = total_records }; */

        }


        [HttpPost("prices/update/import")]
        [Obsolete]
        public async Task<ActionResult<object>> PriceUpdateImportHouses(IFormFile file)
        {

            int total_records = 0;
            int affective_row = 0;
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row

                    while (reader.Read()) //Each ROW
                    {
                        int houseid = Convert.ToInt32(reader.GetValue(1).ToString());
                        decimal price = decimal.Parse(reader.GetValue(3).ToString());
                        DateTime effectiveDate = DateTime.Parse(reader.GetValue(4).ToString());                        
                        string remarks = reader.GetValue(5) != null ? reader.GetValue(5).ToString() : "";

                        var houseprice = _context.HousePrices.SingleOrDefault(x=>x.HouseId==houseid && (x.RecStatus<8 || x.RecStatus==WorkflowStatusModel.PRICEUPDATED));
                        if (houseprice != null)
                        {
                            houseprice.Price = price;
                            houseprice.EffectiveDate = effectiveDate;
                            houseprice.RecStatus = WorkflowStatusModel.APPROVED; //if (effectiveDate > DateTime.Today)
                            houseprice.Remarks = remarks;                            
                            ++affective_row;
                        }
                        ++total_records;

                    }

                    reader.Close();
                    await _context.SaveChangesAsync();
                }
            }

            var result = await _context.Database.ExecuteSqlRawAsync("exec [dbo].[sp_house_prices_update]");

            return new { TotalUploadRecords = total_records, TotalUpdatedRecords = affective_row };
        }


        //Hard Title
        [HttpGet("hard-title")]
        public async Task<ActionResult<IEnumerable<VHouseHardTitles>>> GetHardTitle([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = await _context.VHouseHardTitles
                               .Where(s => (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .OrderByDescending(x => x.Id)
                               .ToListAsync();

            validFilter.TotalRecords =
                await _context.VHouseHardTitles
                            .Where(s => ((String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)))
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("hard-title/{id}")]
        public async Task<ActionResult<HouseHardTitles>> GetHardTitleById(int id)
        {

            var data = await _context.HouseHardTitles.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null)
            {
                return NoContent();
            }
            return data;
        }

        [HttpPost("hard-title/add")]
        public async Task<ActionResult<HouseHardTitles>> AddHardTitle(HouseHardTitles data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var contracts = await _context.Contracts.SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                    if (contracts == null)
                    {
                        return BadRequest("There is no contract for this house!");
                    }

                    data.BookingId = contracts.BookingId;
                    data.ContractId = contracts.Id;
                    data.Status = 1;
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;

                    _context.HouseHardTitles.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_hard_title_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log house hard title can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("hard-title/update")]
        public async Task<IActionResult> UpdateHardTitle(HouseHardTitles data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var data_exists = _context.HouseHardTitles.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);

                    if (data_exists == null)
                    {
                        return BadRequest("House Hard Titles is not exists");
                    }

                    data.BookingId = data_exists.BookingId;
                    data.ContractId = data_exists.ContractId;
                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_hard_title_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log house hard title can not updated!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("hard-title/delete")]
        public async Task<IActionResult> DeleteHardTitle(HouseHardTitles data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    var data_delete = await _context.HouseHardTitles.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                    if (data_delete == null)
                    {
                        return BadRequest("No, house hard title can not be deleted!");
                    }
                    data_delete.Status = 0;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_hard_title_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log house hard title can not deleted!");
                    dbContextTransaction.Commit();

                    return Ok();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

            //return NoContent();
        }

        [HttpGet("handover")]
        public async Task<ActionResult<object>> GetHouseHandovers([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VHouseHandovers>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("handover/{id}")]
        public async Task<ActionResult<object>> GetHouseHandovers(int id)
        {

            var data = await _context.VHouseHandovers.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("handover/add")]
        public async Task<ActionResult<HouseHandovers>> AddHouseHandovers(HouseHandovers data)
        {
            try
            {

                var contract = await _context.Contracts.AsNoTracking().Where(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1)
                .OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                if (contract == null)
                {
                    return BadRequest("There is no contract for this house!");
                }

                var handover = await _context.HouseHandovers.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status==1);
                if(handover!=null)
                {
                    return BadRequest("House handover is already exist!");               
                }

                var customer_history1 =  await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == contract.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                var customer_history2 =  await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == contract.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                data.CustomerId = customer_history1?.Id;
                data.CustomerId2 = customer_history2?.Id;
                data.Status = 1;
                data.ContractId = contract.Id;
                data.CustomerRelationship = contract.OwnerCustomerRelationship;
                CrudLib<HouseHandovers> crud = new CrudLib<HouseHandovers>(_context, _userIdentity.Id);
                data = (HouseHandovers)await crud.Add(data);

                return data;
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("handover/update")]
        public async Task<IActionResult> UpdateComplaint(HouseHandovers data)
        {

            try
            {

                var handover = await _context.HouseHandovers.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                if (handover == null)
                {
                    return BadRequest("Invalid house handover id");
                }

                //var customer_history1 = data.CustomerId == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.CustomerId).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                data.Status = 1;
                data.ContractId = handover.ContractId;

                CrudLib<HouseHandovers> crud = new CrudLib<HouseHandovers>(_context, _userIdentity.Id);

                await crud.Update(data);

                return Ok();
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("handover/delete")]
        public async Task<IActionResult> CustomerComplaintDelete(DeleteModel data)
        {
            try
            {

                var data_delete = await _context.HouseHandovers.FindAsync(data.Id);
                if (data_delete == null)
                {
                    return BadRequest("No, house handover can not be deleted!");
                }

                data_delete.Status = 0;
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("handover/export")]
        public async Task<IEnumerable<object>> HouseHandOverExport()
        {
            return await _context.VHousesHandoverExport.
                Select(x => new { x.ProjectShort, x.HouseId, HouseNumber=x.Number, x.HandOverDate, x.WarrentyEndDate, 
                    x.ScheduleDate,x.PersonHandle,x.Water,x.Electricity,x.Remark })
                .ToListAsync();
        }

        [HttpPost("handover/import")]
        public async Task<ActionResult<UploadResult>> ImportHouseHandOver(IFormFile file)
        {

            int total_records = 0;
            Guid batch_code = Guid.NewGuid();
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    reader.Read(); //ignore first row

                    while (reader.Read()) //Each ROW
                    {
                        HouseHandoversBatch tem = new HouseHandoversBatch();
                        tem.ProjectShort = reader.GetValue(0).ToString();
                        tem.HouseId = Convert.ToInt16(reader.GetValue(1).ToString());
                        tem.HouseNo = reader.GetValue(2).ToString();
                        tem.HandOverDate = Convert.ToDateTime(reader.GetValue(3).ToString());
                        tem.WarrentyEndDate = Convert.ToDateTime(reader.GetValue(4).ToString());
                        tem.ScheduleDate = Convert.ToDateTime(reader.GetValue(5).ToString());
                        tem.PersonHandle = reader.GetValue(6).ToString();
                        tem.Water = reader.GetValue(7).ToString();
                        tem.Electricity = reader.GetValue(8).ToString();
                        tem.Remark = reader.GetValue(9).ToString();
                        tem.CreatedAt = created_at;
                        tem.CreatedBy = _userIdentity.Id;
                        tem.BatchCode = batch_code;

                        _context.HouseHandoversBatch.Add(tem);
                        await _context.SaveChangesAsync();

                        total_records++;
                    }
                }
            }

            string sql = "exec dbo.sp_house_hand_over_batch @batch_code,@user_id,@result out";
            SqlParameter[] param ={
                                    new SqlParameter("@batch_code",SqlDbType.UniqueIdentifier) { Value =batch_code},
                                    new SqlParameter("@user_id", SqlDbType.Int) { Value= _userIdentity.Id},
                                    new SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output }
                                   };

            await _context.Database.ExecuteSqlRawAsync(sql, param);
            int TotalInsertRecords = (int)param[2].Value;

            //string sql = "exec dbo.sp_house_import @batch_code = '" + batch_code + "'";
            return new UploadResult { TotalUploadRecords = total_records, TotalInsertRecords = TotalInsertRecords };

        }


        [HttpGet("price-detail/{house_id}")]
        public async Task<ActionResult<IEnumerable<VHousePriceDetails>>> PriceDetailById(int house_id)
        {
            return Ok(await _context.VHousePriceDetails.FirstOrDefaultAsync(x=>x.Id==house_id));
        }

        [HttpGet("public-service-price/{house_id}")]
        public async Task<ActionResult<object>> GetPublicServicePriceByHouseId(int house_id)
        {

            var price = await _context.VCategoryPrice.SingleOrDefaultAsync(x => x.HouseId == house_id);
            if (price != null) return Ok(price);
            else return BadRequest("Invalid house id");
        }


    }

}
