﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Web.Parameters;

namespace Web.Controllers
{
    [Route("api/v1/ar_request")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class ArRequestController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public ArRequestController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }
        //Contract
        [HttpGet("schedule-to-disable")]
        public async Task<ActionResult<object>> GetScheduleToDisable([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_schedule_to_disable_filter {0},{1},{2}";

            var data = _context.VScheduleToDisable
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.OrderByDescending(x => x.CreatedAt)
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("schedule-to-disable/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetScheduleToDisableById(int id)
        {

            var data = await _context.DisableScheduleRequest.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid schedule request");

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.disable_schedule_request", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
            //return data;
        }

        [HttpGet("schedule-to-disable/detail/{disableScheduleRequestId}")]
        public async Task<ActionResult<IEnumerable<DisableScheduleRequestDetail>>> GetScheduleToDisableDetailById(int disableScheduleRequestId)
        {
            var data = await _context.DisableScheduleRequestDetail.AsNoTracking().Where(x => x.DisableScheduleRequestId == disableScheduleRequestId && x.Status == 1).ToListAsync();
            if (data == null) return BadRequest("Invalid schedule request");
            return data;
        }

        [HttpPost("schedule-to-disable/approved/{id}")]
        public async Task<ActionResult> ScheduleToDisableApprove(int id)
        {
            var public_service = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_schedule_to_disable_approve {0},{1}", id, _userIdentity.Id);
            if (public_service == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpGet("schedule-to-disable/available/{house_id}")]
        public async Task<ActionResult<IEnumerable<VAvailableScheduleToDisable>>> GetAvailableScheduleToDisableById(int house_id)
        {

            string sql = $"exec dbo.get_available_schedule_to_disable {house_id}";
            var data = _context.VAvailableScheduleToDisable.FromSqlRaw(sql).AsEnumerable().ToList();
            return data;
        }

        [HttpPost("schedule-to-disable/add")]
        public async Task<ActionResult<DisableScheduleRequest>> AddScheduleToDisable(ClsScheduleToDisable data)
        {

            try
            {
                //save to audit log
                string sql = string.Format("exec [dbo].[add_schedule_to_disable] {0},{1},N'{2}',{3},{4}", data.HouseId, data.PaymentScheduleInfoId, data.Reason, _userIdentity.Id, data.NewDuration);
                var result = _context.DisableScheduleRequest
                .FromSqlRaw(sql).AsEnumerable().FirstOrDefault();

                //Add Workflow History draft
                WorkflowDetailModel wf = new WorkflowDetailModel();
                var workflowhistory = wf.WorkflowHistoryDraft("dbo.disable_schedule_request", result.Id, _userIdentity.Id);
                _context.WorkflowHistory.Add(workflowhistory);
                await _context.SaveChangesAsync();

                return result;

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("schedule-to-disable/update")]
        public async Task<ActionResult> UpdateScheduleToDisable(ClsScheduleToDisable data)
        {

            try
            {
                //save to audit log
                ApiResponse res = new ApiResponse();
                string sql = string.Format("exec [dbo].[update_schedule_to_disable] {0},{1},N'{2}',{3},{4}", data.DisableScheduleRequestId, data.PaymentScheduleInfoId, data.Reason, _userIdentity.Id, data.NewDuration);
                var result = await _context.Database.ExecuteSqlRawAsync(sql);
                if (result == -1)
                {
                    res.status = "Success";
                    res.message = "Success";
                    return Ok(res);
                }
                else
                {
                    res.status = "failed";
                    res.message = "fail to update,please try again!";
                    return BadRequest(res);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("schedule-to-disable/delete")]
        public async Task<ActionResult> DeleteScheduleToDisable(ClsScheduleToDisable data)
        {

            try
            {

                //save to audit log
                ApiResponse res = new ApiResponse();
                string sql = string.Format("exec [dbo].[delete_schedule_to_disable] {0},{1}", data.DisableScheduleRequestId, _userIdentity.Id);
                var result = await _context.Database.ExecuteSqlRawAsync(sql);
                if (result == -1)
                {
                    res.status = "Success";
                    res.message = "Success";
                    return Ok(res);
                    //return Ok("Success");
                }
                else
                {
                    res.status = "failed";
                    res.message = "fail to delete,please try again!";
                    return BadRequest(res);
                }

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
