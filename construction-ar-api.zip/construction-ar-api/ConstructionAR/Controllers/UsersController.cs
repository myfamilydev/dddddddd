﻿using aspnetcore.ldap.Services;
using BVMPP.ClientOauth.Models;
using BVMPP.ClientOauth;
using ClassLibrary;
using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot.Types;
using Web.Models;
using System.Net.Http;

namespace ConstructionAR.Controllers
{
    /*
    return Ok(); // Http status code 200
    return Created(); // Http status code 201
    return NoContent(); // Http status code 204
    return BadRequest(); // Http status code 400
    return Unauthorized(); // Http status code 401
    return Forbid(); // Http status code 403
    return NotFound(); // Http status code 404
    */

    [Route("api/v1/users")]
    [ApiController]
    [Authorize]
    //[Web.Models.CustomAuthorize()]
    public class UsersController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;        
        private readonly IAuthenticationService _authService;
        private userIdentity _userIdentity;
        private readonly HttpClient client = new HttpClient();

        private ClientApi _clientApi;
        private SDKConfiguration _SDKConfiguration;
        public UsersController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor, 
                                IAuthenticationService authService)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;
            _authService = authService;

                if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true) {
                    _userIdentity = new userIdentity();
                    _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);

                }

            _config = config;

            var clientId = _config.GetSection("SSO:ClientId").Value;
            var clientSecret = _config.GetSection("SSO:ClientSecret").Value;
            var redirectUri = _config.GetSection("SSO:RedirectUri").Value;
            _SDKConfiguration = new SDKConfiguration
            {
                ClienId = clientId,
                ClientSecret = clientSecret,
                RedirectUri = redirectUri,
                ProvideURL = _config.GetSection("SSO:Url").Value
            };

            _clientApi = new ClientApi(_SDKConfiguration);

        }

        // GET: api/Users


        [Authorize]
        [HttpGet("me")]
        public async Task<IActionResult> getMe()
        {
            try
            {
                var user = _context.Users.Find(_userIdentity.Id);
                user.Password = "";

                return Ok(user);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Users>>> Getusers()
        {
            return await _context.Users.ToListAsync();
        }

        // GET: api/Users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Users>> GetUser(int id)
        {
            var user = await _context.Users.FindAsync(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        [HttpGet("basicinfo")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<object>>> GetusersBasicInfo()
        {
                return await _context.Users.AsNoTracking().Where(x=>x.Status==1)
                .Select(x => new
                {
                    Id = x.Id,
                    FullName = x.FullName,
                    Designation = x.Designation
                }).ToListAsync();
        }

        [HttpGet("department/{department_id}")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<object>>> GetUsersByRoleID(int department_id)
        {
            return await _context.VUserToRole.AsNoTracking().Where(x => x.Department==department_id)
            .Select(x => new
            {
                Id = x.UserId,
                FullName = x.FullName,
                UserName = x.Username
            }).ToListAsync();
        }


        // POST: api/Users
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost("add")]
        public async Task<ActionResult<Users>> AddUser(Users user)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                                var user_exists = _context.Users.Where(x => x.Username == user.Username && x.Email == user.Email && x.Status == 1).Any();
                                if (user_exists == true)
                                {
                                    return BadRequest("User name is already exists.");
                                }
                                Encryption enc = new Encryption();
                                user.Status = 1;
                                user.Uuid = Guid.NewGuid();
                                user.Password = enc.ComputeSha512Hash(user.Username + user.Password);
                                user.CreatedAt = DateTime.Now;
                                user.CreatedBy = _userIdentity.Id;

                                _context.Users.Add(user);
                                _context.SaveChanges();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_log] {0},{1},{2}", user.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log add user can not saved!");
                                dbContextTransaction.Commit();

                                return user;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateUser(Users data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {

                            var user_exists = _context.Users.AsNoTracking().SingleOrDefault(x => x.Uuid == data.Uuid);
                            if (user_exists == null)
                            {
                                return BadRequest("Uuid not found");
                            }

                            Encryption enc = new Encryption();
                            data.Id = user_exists.Id;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;
                            data.Password = enc.ComputeSha512Hash(user_exists.Username + data.Password);
                            data.Status = 1;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.Uuid).IsModified = false;
                            _context.SaveChanges();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log add user can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
            }    
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public ActionResult<AuthorizationModel> Authenticate(ClsLogin users)
        {
             
            // get user role from Users table

            //var get_user_role = _context.Users.Where(x => x.Email.ToLower() == email).FirstOrDefault();
            // var LdapAuth = _authService.Login(users.Username, users.Password);
            // if (LdapAuth == null)  return BadRequest("Invalid Username or password");

            //var user = _context.VUserLoggedIn.AsNoTracking().Where(x => x.Email.ToLower() == LdapAuth.Email.ToLower()).ToList();

            Encryption enc = new Encryption();

            string encrypt_pwd = enc.ComputeSha512Hash(users.Username + users.Password);
             

                var userLogin = _context.Users.FirstOrDefault(x => x.Username == users.Username.ToLower() && x.Password == encrypt_pwd && x.Status == 1);

            if (userLogin == null)
            {
                return BadRequest("You are not authorized!");
            }

            var user = _context.VUserLoggedIn.AsNoTracking().Where(x => x.Username.ToLower() == userLogin.Username).ToList();

            //var user = _context.VUserLoggedIn.AsNoTracking().Where(x => x.Username.ToLower() ==users.Username).ToList();

            int i = 0;

            AuthorizationModel am = new AuthorizationModel();
            am.users = _context.Users.Find(user.First().Id);
            am.users.Password = null;
            am.users.PasswordChangeAt = null;

            List<Claim> claims = new List<Claim>();
            string pre_role = "";
            List<object> auth_role = new List<object>();

            foreach (var item in user)
            {
                if (i == 0)
                {
                    claims.Add(new Claim(ClaimTypes.GivenName, item.Username));
                    claims.Add(new Claim(ClaimTypes.Name, item.FullName));
                    claims.Add(new Claim(ClaimTypes.Email, item.Email));
                    claims.Add(new Claim(ClaimTypes.NameIdentifier, Convert.ToString(item.Id)));
                    claims.Add(new Claim(ClaimTypes.Role, "Requester"));
                    auth_role.Add(new { auth_role = "Requester" });
                    i++;
                }

                if (item.UserRole != null && !pre_role.Equals(item.UserRole))
                {
                    claims.Add(new Claim(ClaimTypes.Role, item.UserRole.ToString()));
                    pre_role = item.UserRole;
                    auth_role.Add(new { auth_role = item.UserRole.ToString() });
                }

            }

            //var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.GetSection("AppSettings:Token").Value));
            var key = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_config.GetSection("Jwt:Secret").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

            var tokenDecriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims.ToArray()),
                Expires = DateTime.Now.AddHours(16),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();

            var token = tokenHandler.CreateToken(tokenDecriptor);
           
            am.token = tokenHandler.WriteToken(token);
            
            am.authorizedPageActions = auth_role;

            am.authorizedPages =
                  _context.VUsersPages.Where(x => x.UserId == am.users.Id || x.UserId == null)
                        .Select(s => new VUsersPages
                        {
                            PageId = s.PageId,
                            Title = s.Title,
                            PageName = s.PageName,
                            Url = s.Url,
                            Icon = s.Icon,
                            Type = s.Type,
                            ParentId = s.ParentId,
                            RecStatus = s.RecStatus,
                            Ordering = s.Ordering,
                            CreatedBy = s.CreatedBy,
                            CreatedAt = s.CreatedAt,
                            UserId = 0
                        }).OrderBy(x=>x.Ordering).Distinct().ToList();

            ClsDistribute.SaveSessionLog(_httpContextAccessor.HttpContext, am.token, am.users.Id);
            return am;

        }

        private async Task<ActionResult<AuthorizationModel>> AuthenticateSSO(ClsLogin users)
        {

            var userLogin = _context.Users.FirstOrDefault(x => x.Username == users.Username && x.Status == 1);

            if (userLogin == null)
            {
                return BadRequest("You are not authorized!");
            } 

            var user = _context.VUserLoggedIn.AsNoTracking().Where(x => x.Username.ToLower() == userLogin.Username).ToList();

            //var user = _context.VUserLoggedIn.AsNoTracking().Where(x => x.Username.ToLower() ==users.Username).ToList();

            int i = 0;

            AuthorizationModel am = new AuthorizationModel();
            am.users = _context.Users.Find(user.First().Id);
            am.users.Password = null;
            am.users.PasswordChangeAt = null;

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim("sso_token", users.Token));
            string pre_role = "";
            List<object> auth_role = new List<object>();

            foreach (var item in user)
            {
                if (i == 0)
                {
                    claims.Add(new Claim(ClaimTypes.GivenName, item.Username));
                    claims.Add(new Claim(ClaimTypes.Name, item.FullName));
                    claims.Add(new Claim(ClaimTypes.Email, item.Email));
                    claims.Add(new Claim(ClaimTypes.NameIdentifier, Convert.ToString(item.Id)));
                    claims.Add(new Claim(ClaimTypes.Role, "Requester"));
                    auth_role.Add(new { auth_role = "Requester" });
                    i++;
                }

                if (item.UserRole != null && !pre_role.Equals(item.UserRole))
                {
                    claims.Add(new Claim(ClaimTypes.Role, item.UserRole.ToString()));
                    pre_role = item.UserRole;
                    auth_role.Add(new { auth_role = item.UserRole.ToString() });
                }

            }

            //var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.GetSection("AppSettings:Token").Value));
            var key = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_config.GetSection("Jwt:Secret").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

            var tokenDecriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims.ToArray()),
                Expires = DateTime.Now.AddHours(16),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();

            var token = tokenHandler.CreateToken(tokenDecriptor);

            am.token = tokenHandler.WriteToken(token);

            am.authorizedPageActions = auth_role;

            am.authorizedPages =
                  _context.VUsersPages.Where(x => x.UserId == am.users.Id || x.UserId == null)
                        .Select(s => new VUsersPages
                        {
                            PageId = s.PageId,
                            Title = s.Title,
                            PageName = s.PageName,
                            Url = s.Url,
                            Icon = s.Icon,
                            Type = s.Type,
                            ParentId = s.ParentId,
                            RecStatus = s.RecStatus,
                            Ordering = s.Ordering,
                            CreatedBy = s.CreatedBy,
                            CreatedAt = s.CreatedAt,
                            UserId = 0
                        }).OrderBy(x => x.Ordering).Distinct().ToList();
            
              ClsDistribute.SaveSessionLog(_httpContextAccessor.HttpContext, am.token, am.users.Id);
              return am;

        }

        [AllowAnonymous]
        [HttpPost("sso")]
        public async Task<ActionResult<AuthorizationModel>> GetSSO(VeriedCode veriedCode)
        {
            try
            {
                //_SDKConfiguration.RedirectUri = veriedCode.RedirectUri;
                _clientApi = new ClientApi(_SDKConfiguration);

                SSOAccessOwner oauthToken = await _clientApi.GetSSOAccessOwner(veriedCode.Code);

                var _user = await _context.Users.FirstOrDefaultAsync(x => x.Username == oauthToken.Username && x.Status == 1);

                var user = new ClsLogin();

                user.Username = oauthToken.Username;

                user.Token = oauthToken.AccessToken;

                user.Password = null;

                user.Email = oauthToken.Email;

                if (_user == null)
                {
                    var users = new Users();
                    users.Username = oauthToken.Username;
                    users.Email = oauthToken.Email;

                    users.FullName = oauthToken.Username;

                    users.Status = 1;
                    users.Uuid = Guid.NewGuid();
                    users.Department = 1;

                    _context.Users.Add(users);

                    _context.SaveChanges();
                }

                return await AuthenticateSSO(user);

            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpPost("sso/activate")]
        public async Task<ActionResult<AuthorizationModel>> Activate(ClsLogin sSOLogin)
        {
            try
            {

                sSOLogin.Username = sSOLogin.Username.ToLower().Trim();

                var user_exists = await _context.Users.FirstOrDefaultAsync(x => x.Username == sSOLogin.Username && x.Status == 1);

                if (user_exists != null)
                {
                    return await AuthenticateSSO(sSOLogin);
                }

                var user = new Users();

                user.Username = sSOLogin.Username;

                user.FullName = sSOLogin.Username;

                user.Email = sSOLogin.Email;

                user.Uuid = Guid.NewGuid();

                user.PhoneNumber = null;

                user.Password = null;

                user.Status = 1;

                _context.Users.Add(user);

                await _context.SaveChangesAsync();

                return await AuthenticateSSO(sSOLogin);

            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [AllowAnonymous]
        [HttpPost("logout")]
        public async Task<ActionResult> logoutAccount()
        {
            string remote_ip = HttpContext.Connection.RemoteIpAddress?.ToString();
            //int user_id = _userIdentity.Id;
            var result = await _context.Database.ExecuteSqlRawAsync($"exec sp_logout '{remote_ip}'");
            if (result == -1) return Ok("success");
            else return BadRequest("fail");            
        }

        [AllowAnonymous]
        [HttpPost("ssologin")]
        public ActionResult<AuthorizationModel> GetToken(UserLogIn userLogIn)
        {
            string username = "";
            string email = "";

            byte[] decodedBytes = Convert.FromBase64String(userLogIn.Token);
            string decodedToken = System.Text.Encoding.UTF8.GetString(decodedBytes);


            var client = new RestClient("https://www.camgsm.com.kh/getloginuser.php");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Cookie", "PHPSESSID=" + decodedToken);
            request.AlwaysMultipartFormData = true;
            IRestResponse response = client.Execute(request);

            if (!response.Content.Equals(";"))
            {
                string[] con = response.Content.Split(';');
                if (con.Length > 1)
                {
                    email = con[0].ToLower();
                    username = con[1].ToLower();
                }
            }
            else
            {
                return BadRequest("redirectWP");
            }

            ClsLogin user = new ClsLogin();
            user.Email = email;
            user.Username = username;

            return  Authenticate(user);
        }
        /*
        [AllowAnonymous]
        [HttpGet("getUserFromWebPortal")]
        public IActionResult getUserFromWebPortal([FromQuery(Name = "token")] string token)
        {
            var client = new RestClient("https://www.camgsm.com.kh/getloginuser.php");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            request.AddHeader("Cookie", "PHPSESSID=" + token);
            request.AlwaysMultipartFormData = true;
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);

            return Ok(response.Content);
        }
        */
        // GET: api/Users
        [HttpGet("roles")]
        public async Task<ActionResult<IEnumerable<UsersRoles>>> GetUsersRoles()
        {
            return await _context.UsersRoles.ToListAsync();
        }

        // GET: api/Users/5
        [HttpGet("roles/{id}")]
        public async Task<ActionResult<UsersRoles>> GetUsersRoles(int id)
        {
            var data = await _context.UsersRoles.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("roles/page/{pageId}")]
        public async Task<ActionResult<IEnumerable<VUsersPagesToRoles>>> GetUsersRolesByPage(int pageId)
        {
            var data = await _context.VUsersPagesToRoles.Where(x => x.PageId == pageId).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }


        [Authorize(Roles = "Administrator")]
        [HttpPost("roles/add")]
        public async Task<ActionResult<UsersRoles>> AddUsersRoles(UsersRoles data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                                var valid = _context.UsersRoles.Where(x => x.RoleName == data.RoleName).Any();
                                if (valid == true)
                                {
                                    return BadRequest("User Role already exists");
                                }

                                data.CreatedAt = DateTime.Now;
                                data.CreatedBy = _userIdentity.Id;

                                _context.UsersRoles.Add(data);
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[user_role_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log user role can not saved!");
                                dbContextTransaction.Commit();

                                return data;

                        }catch(Exception ex)
                        {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message); 
                        }
                }
        }

        [HttpPost("roles/update")]
        public async Task<IActionResult> UpdateUsersRoles(UsersRoles data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var userRoles = _context.UsersRoles.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                            if (userRoles == null)
                            {
                                return BadRequest();
                            }

                            _context.Entry(data).State = EntityState.Modified;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[user_role_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log user role can not updated!");
                            dbContextTransaction.Commit();
                            return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
            
        }

        [HttpPost("roles/update-status")]
        public async Task<IActionResult> UpdateUsersRolesStatus(UsersRoles data)
        {
            var userRoles = _context.UsersRoles.SingleOrDefault(x => x.Id == data.Id);
            if (userRoles == null)
            {
                return BadRequest();
            }

            userRoles.RecStatus = data.RecStatus;
            _context.Entry(userRoles).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("dashboard")]
        [Authorize]
        public async Task<ActionResult<DashboardModel>> GetDashboard()
        {
            return new DashboardModel();
        }

        //rbac page
        // GET: api/Users
        [HttpGet("pages")]
        public async Task<ActionResult<IEnumerable<UsersPages>>> GetUsersPages()
        {
            return await _context.UsersPages.OrderBy(x=>x.Ordering).ToListAsync();
        }

        // GET: api/Users/5
        [HttpGet("pages/{id}")]
        public async Task<ActionResult<UsersPages>> GetUsersPages(int id)
        {
            var data = await _context.UsersPages.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("pages/add")]
        public async Task<ActionResult<UsersPages>> AddPages(UsersPages data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;

                            _context.UsersPages.Add(data);

                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[user_pages_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log page can not saved!");
                            dbContextTransaction.Commit();

                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

        }

        [HttpPost("pages/update")]
        public async Task<IActionResult> UpdatePages(UsersPages data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {

                            var valid = _context.UsersPages.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                            if (valid == null)
                            {
                                return BadRequest();
                            }

                            _context.Entry(data).State = EntityState.Modified;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[user_pages_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log page can not updated!");
                            dbContextTransaction.Commit();
                            return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
            }
                 
        }

        [HttpPost("pages/delete")]
        public async Task<IActionResult> DeletePages(UsersPages json)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {

                            var data = await _context.UsersPages.FindAsync(json.Id);
                            if (data == null)
                            {
                                return BadRequest();
                            }
                            _context.UsersPages.Remove(data);
                            _context.SaveChanges();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[user_pages_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log page can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                    }
                    catch (Exception ex)
                    {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                    }
            }
                
        }

        [HttpGet("roles/to-pages/{id}")]
        public async Task<IEnumerable<VRolesToPages>> GetPagesByRole(int id)
        {
            return await _context.VRolesToPages.Where(x => x.RoleId == id).ToListAsync();
        }

        [HttpPost("pages/to-roles/add")]
        public async Task<ActionResult<UsersPagesToRoles>> AddPages(UsersPagesToRoles data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var valid = _context.UsersPagesToRoles.Where(x => x.PageId == data.PageId && x.RoleId == data.RoleId).Any();
                            if (valid == true)
                            {
                                return BadRequest("Page is already assign to role");
                            }
                            data.CreatedBy = _userIdentity.Id;
                            data.CreatedAt = DateTime.Now;
                            _context.UsersPagesToRoles.Add(data);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_pages_to_roles_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log user page to role can not saved!");
                            dbContextTransaction.Commit();
                            return data;

                        }catch(Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("pages/to-roles/delete")]
        public async Task<IActionResult> DeletePages(UsersPagesToRoles data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var pagesToRoles = await _context.UsersPagesToRoles.FindAsync(data.Id);

                            if (pagesToRoles == null)
                            {
                                return BadRequest();
                            }

                            _context.UsersPagesToRoles.Remove(pagesToRoles);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_pages_to_roles_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log user page to role can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("to-roles/add")]
        public async Task<ActionResult<UsersToRoles>> UserToRolesAdd(UsersToRoles data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                            try
                            {

                                    var valid = _context.Users.Where(x => x.Id == data.UserId).Any();
                                    if (valid == false)
                                    {
                                        return BadRequest("User is not exists");
                                    }

                                    valid = _context.UsersRoles.Where(x => x.Id == data.RoleId).Any();

                                    if (valid == false)
                                    {
                                        return BadRequest("Role is not exists");
                                    }

                                    valid = _context.UsersToRoles.Where(x => x.UserId == data.UserId && x.RoleId == data.RoleId).Any();

                                    if (valid == true)
                                    {
                                        return BadRequest("User is already assign to role");
                                    }

                                    data.CreatedBy = _userIdentity.Id;
                                    data.CreatedAt = DateTime.Now;

                                    _context.UsersToRoles.Add(data);
                                    await _context.SaveChangesAsync();

                                    //save to audit log
                                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_to_roles_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                    if (result != -1) throw new Exception("Log user to role can not saved!");
                                    dbContextTransaction.Commit();

                                    return data;

                            }
                            catch (Exception ex)
                            {
                                    dbContextTransaction.Rollback();
                                    return BadRequest(ex.Message);
                            }
                }


        }

        [HttpPost("to-roles/delete")]
        public async Task<IActionResult> UserToRolesDelete(UsersToRoles data)
        {

                    using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                    {
                            try
                            {

                                    var pagesToRoles = await _context.UsersToRoles.FindAsync(data.Id);

                                    if (pagesToRoles == null)
                                    {
                                        return BadRequest();
                                    }
                                    _context.UsersToRoles.Remove(pagesToRoles);
                                    await _context.SaveChangesAsync();

                                    //save to audit log
                                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_to_roles_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                                    if (result != -1) throw new Exception("Log user to role can not deleted!");
                                    dbContextTransaction.Commit();
                                    return Ok();
                            }
                            catch (Exception ex)
                            {
                                    dbContextTransaction.Rollback();
                                    return BadRequest(ex.Message);
                            }
                    }

                    //return NoContent();
        }

        [HttpGet("to-roles")]
        public async Task<ActionResult<IEnumerable<VGetUserRoles>>> VGetUserRoles()
        {
            return await _context.VGetUserRoles.ToListAsync();
        }

        [HttpGet("to-roles/user/{userId}")]
        public async Task<ActionResult<IEnumerable<VGetUserRoles>>> VGetUserRoles(int userId)
        {
            var data = await _context.VGetUserRoles.Where(x => x.UserId == userId).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("to-roles/role/{roleId}")]
        public async Task<ActionResult<IEnumerable<VGetUserRoles>>> VGetUserRolesByRole(int roleId)
        {
            var data = await _context.VGetUserRoles.Where(x => x.RoleId == roleId).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("to-projects/add")]
        public async Task<ActionResult<UsersToProjects>> UserToProjectsAdd(UsersToProjects data)
        {

                    using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                    {
                                try
                                {

                                    var valid = _context.Users.Where(x => x.Id == data.UserId).Any();

                                    if (valid == false)
                                    {
                                        return BadRequest("User is not exists");
                                    }

                                    valid = _context.Projects.Where(x => x.Id == data.ProjectId).Any();

                                    if (valid == false)
                                    {
                                        return BadRequest("Project is not exists");
                                    }

                                    valid = _context.UsersToProjects.Where(x => x.UserId == data.UserId && x.ProjectId == data.ProjectId).Any();

                                    if (valid == true)
                                    {
                                        return BadRequest("User is already assign to project");
                                    }

                                    data.CreatedBy = _userIdentity.Id;
                                    data.CreatedAt = DateTime.Now;
                                    _context.UsersToProjects.Add(data);
                                    await _context.SaveChangesAsync();

                                    //save to audit log
                                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_to_projects_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                    if (result != -1) throw new Exception("Log user to project can not saved!");
                                    dbContextTransaction.Commit();

                                    return data;

                                }
                                catch (Exception ex)
                                {
                                    dbContextTransaction.Rollback();
                                    return BadRequest(ex.Message);
                                }
                    }   

        }

        [HttpPost("to-projects/delete")]
        public async Task<IActionResult> UserToProjectsDelete(UsersToProjects data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                                var usersToProjects = await _context.UsersToProjects.FindAsync(data.Id);
                                if (usersToProjects == null)
                                {
                                    return BadRequest();
                                }

                                _context.UsersToProjects.Remove(usersToProjects);
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[users_to_projects_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log user to project can not deleted!");
                                dbContextTransaction.Commit();
                                return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }   
                    
        }

        [HttpGet("to-projects")]
        public async Task<IEnumerable<VUserToProjects>> VUserToProjects()
        {           
            return await _context.VUserToProjects.ToListAsync();
        }

        [HttpGet("to-projects/project/{projectId}")]
        public async Task<ActionResult<IEnumerable<VUserToProjects>>> VUserToProjects(int projectId)
        {
            var data = await _context.VUserToProjects.Where(x => x.ProjectId == projectId).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("to-projects/user/{userId}")]
        public async Task<ActionResult<IEnumerable<VUserToProjects>>> VUserToProjectsByUser(int userId)
        {
            var data = await _context.VUserToProjects.Where(x => x.UserId == userId).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [Authorize(Roles = "IT_Admin")]
        [HttpPost("resetUserPassword")]
        public async Task<IActionResult> ResetAllUserPassword(ClsLogin clsLogin)
        {
            Encryption enc = new Encryption();
            //string default_pwd = "User@2021$";
            string default_pwd = clsLogin.Password;

            try
            {
                var users = _context.Users.Where(x => x.Username.ToLower() == clsLogin.Username.ToLower()).ToList();
                //var users = _context.Users.ToList();

                foreach (var user in users)
                {
                    string encrypt_pwd = enc.ComputeSha512Hash(user.Username + default_pwd);
                    user.Password = encrypt_pwd;
                    user.PasswordChangeAt = DateTime.Now;
                    user.UpdatedAt = DateTime.Now;
                    user.UpdatedBy = null;
                }

                await _context.SaveChangesAsync();

                return Ok("Successful");
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpPost("changePassword")]
        public async Task<IActionResult> ChangePassword(UserChangePassword user)
        {


            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    /* Encryption enc = new Encryption();
                     var getUser = _context.Users.FirstOrDefault(x => x.Uuid == user.Uuid);

                     if (getUser == null)
                     {
                         return BadRequest("User not found");
                     }

                     string encrypt_pwd = enc.ComputeSha512Hash(getUser.Username + user.OldPassword);

                     if (encrypt_pwd != getUser.Password)
                     {
                         return BadRequest("Incorrect old password");
                     }

                     encrypt_pwd = enc.ComputeSha512Hash(getUser.Username + user.NewPassword);

                     getUser.Password = encrypt_pwd;
                     getUser.PasswordChangeAt = DateTime.Now;
                     getUser.UpdatedBy = _userIdentity.Id;
                     getUser.UpdatedAt = DateTime.Now;

                     await _context.SaveChangesAsync(); */

                    var _user = new OauthUserPassword { CurrentPassword = user.OldPassword, Password = user.NewPassword };

                    await _clientApi.ChangePassword(_userIdentity.SSOToken, _user);

                    return Ok("Successful");
                }
                catch (Exception ex)
                {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                }
            }
           
        }

    }

 

}
