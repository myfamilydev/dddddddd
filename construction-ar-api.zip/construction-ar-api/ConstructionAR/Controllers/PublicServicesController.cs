﻿using AutoMapper.Configuration;
using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Web.Parameters;

namespace Web.Controllers
{
    [Route("api/v1/publicservices")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class PublicServicesController : ControllerBase
    {
        private readonly MayuraContext _context;
        // private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public PublicServicesController(MayuraContext context, IHttpContextAccessor httpContextAccessor)
        {          
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            // _config = config;

            //if ( _httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);

        }

        [HttpGet]
        public async Task<ActionResult<object>> GetAllPublicServices([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VPublicService>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetByIdPublicServices(int id)
        {

            var data = await _context.PublicServices.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.public_services", data.Id, _userIdentity.Id);

            var schedule = await _context.VPublicServiceSchedules.Where(x => x.PublicServiceId == id).OrderByDescending(x=>x.PaymentDate).ToArrayAsync();
            object public_service = new
            {
                PublicService = data,
                Schedule = schedule
            };

            wf.workflowModel.Data = public_service;

            return wf.workflowModel;

        }

        [HttpGet("{id}/schedules")]
        public async Task<ActionResult<object>> GetAllPublicServicesSchedules(int id)
        {
            return await _context.PublicServiceSchedules.Where(x=>x.PublicServiceId == id && x.Status==1).ToArrayAsync();
        }

        [HttpGet("house/{houseid}/schedules")]
        public async Task<ActionResult<object>> GetAllPublicServicesSchedulesByHouse(int houseid)
        {
            //return await _context.PublicServiceSchedules.Where(x => x.HouseId == houseid && x.Status==1).ToArrayAsync();        
            //return await _context.VPublicServiceSchedules.Where(x => x.HouseId == houseid).OrderBy(y => y.PaymentDate).ToArrayAsync();
            return _context.VPublicServiceSchedules.FromSqlRaw("exec dbo.sp_get_public_service_schedule {0}", houseid).AsEnumerable().ToList();
        }

        [HttpGet("contract/{contract_id}/schedules")]
        public async Task<ActionResult<object>> GetAllPublicServicesSchedulesByContract(int contract_id)
        {
            //return await _context.PublicServiceSchedules.Where(x => x.HouseId == houseid && x.Status==1).ToArrayAsync();        
            //return await _context.VPublicServiceSchedules.Where(x => x.HouseId == houseid).OrderBy(y => y.PaymentDate).ToArrayAsync();
            return _context.VPublicServiceSchedules.FromSqlRaw("exec dbo.sp_get_public_service_schedule_1 {0}", contract_id).AsEnumerable().ToList();
        }

        [HttpPost("approved/{id}")]
        public async Task<ActionResult> ApprovedPublicService(int id)
        {
            var public_service = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_public_service_approve {0},{1}", id, _userIdentity.Id);
            if (public_service == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpPost("add")]
        public async Task<ActionResult<object>> AddPublicServices(PublicServices data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var public_service = _context.PublicServices.AsNoTracking().FirstOrDefault(x => x.ContractId == data.ContractId && x.RecStatus <= 2 && x.Status == 1);
                    if (public_service != null)
                    {
                        return BadRequest("Public service already exist, but not yet approved!");
                    }
                    var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                    if (contract == null) return BadRequest("There is no contract for this house!");

                    data.Status = 1;
                    data.ContractId = contract.Id;
                    data.BookingId = contract.BookingId;
                    CrudLib<PublicServices> crud = new CrudLib<PublicServices>(_context, _userIdentity.Id);
                    data = (PublicServices)await crud.Add(data, "dbo.public_services");

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[public_service_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log public service can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("delete")]
        public async Task<IActionResult> DeletePublicServices(DeleteModel data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {
                    var data_delete = await _context.PublicServices.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);

                    if (data_delete == null)
                    {
                        return BadRequest();
                    }

                    data_delete.Status = 0;
                    _context.SaveChanges();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[public_service_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log public service can not deleted!");
                    dbContextTransaction.Commit();

                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }


        [HttpGet("info/house/{house_id}")]
        public async Task<ActionResult<object>> GetPublicServicesInfoByHouseId(int house_id)
        {

            var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == house_id && x.RecStatus == 3 && x.Status == 1);
            if (contract == null) return BadRequest("There is no contract for this house");
            var data = _context.PublicServices.AsNoTracking().Where(x => x.ContractId == contract.Id && x.RecStatus == 3 && x.Status == 1).FirstOrDefault();
            return data;

        }

        [HttpPost("update-price/approved/{id}")]
        public async Task<ActionResult> ApprovedPublicServiceUpdatePrice(int id)
        {
            var public_service = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_public_service_update_price_approve {0},{1}", id, _userIdentity.Id);
            if (public_service == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpGet("update-price")]
        public async Task<ActionResult<object>> PublicServicesUpdatePrice([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VPublicServicesUpdatePrice>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("update-price/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetPublicServicesUpdatePrice(int id)
        {

            var data = await _context.PublicServicesUpdatePrice.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.public_services_update_price", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("update-price/add")]
        public async Task<ActionResult<object>> AddPublicServicesUpdatePrice(PublicServicesUpdatePrice data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {

                    var public_service = _context.PublicServices.AsNoTracking().FirstOrDefault(x => x.Id == data.PublicServiceId && x.RecStatus == 3 && x.Status == 1);
                    if (public_service == null)
                    {
                        return BadRequest("Public service not available!");
                    }

                    //var ps_update = new PublicServicesUpdatePrice();
                    data.ProjectId = public_service.ProjectId;
                    data.ContractId = public_service.ContractId;
                    data.BookingId = public_service.BookingId;
                    data.HouseId = public_service.HouseId;
                    data.Step = public_service.Step;
                    data.MonthlyFee = public_service.MonthlyFee;
                    data.EffectiveDate = public_service.EffectiveDate;
                    data.NewMonthlyFee = data.NewMonthlyFee;
                    data.NewEffectiveDate = data.NewEffectiveDate;
                    data.Status = 1;

                    CrudLib<PublicServicesUpdatePrice> crud = new CrudLib<PublicServicesUpdatePrice>(_context, _userIdentity.Id);
                    data = (PublicServicesUpdatePrice)await crud.Add(data, "dbo.public_services_update_price");

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[public_service_update_price_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log public service update price can not saved!");
                    dbContextTransaction.Commit();
                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("update-price/update")]
        public async Task<ActionResult<object>> UpdatePublicServicesUpdatePrice(PublicServicesUpdatePrice data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var ps_update_price = _context.PublicServicesUpdatePrice.AsNoTracking().FirstOrDefault(x => x.Id == data.PublicServiceId && x.RecStatus == 1 && x.Status == 1);
                    if (ps_update_price == null)
                    {
                        return BadRequest("Public service update price not available!");
                    }


                    ps_update_price.NewMonthlyFee = data.NewMonthlyFee;
                    ps_update_price.NewEffectiveDate = data.NewEffectiveDate;
                    ps_update_price.Status = 1;


                    CrudLib<PublicServicesUpdatePrice> crud = new CrudLib<PublicServicesUpdatePrice>(_context, _userIdentity.Id);
                    data = (PublicServicesUpdatePrice)await crud.Update(data);

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[public_service_update_price_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log public service update price can not updated!");
                    dbContextTransaction.Commit();

                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("update-price/delete")]
        public async Task<IActionResult> DeletePublicServicesUpdatePrice(DeleteModel data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {

                    var data_delete = await _context.PublicServicesUpdatePrice.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);

                    if (data_delete == null)
                    {
                        return BadRequest();
                    }

                    data_delete.Status = 0;
                    _context.SaveChanges();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[public_service_update_price_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log public service update price can not deleted!");
                    dbContextTransaction.Commit();

                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpGet("noschedule/list")]
        public async Task<IEnumerable<object>> NoSchedulePublicServiceList()
        {
            return await _context.VPublicServiceNoSchedule.
                Select(x => new { x.ProjectShort,x.HouseId,x.HouseNumber,x.EffectiveDate,x.Installment,x.Remark})
                .ToListAsync();
        }

        [HttpGet("noschedule/{project_id}")]
        public async Task<IEnumerable<object>> NoSchedulePublicServiceByProjectId(int project_id)
        {
            return await _context.VPublicServiceHouseInfo.Where(x => x.ProjectId == project_id).ToListAsync();
        }

        [HttpPost("import")]
        public async Task<ActionResult<UploadResult>> ImportPublicService(IFormFile file)
        {

            int total_records = 0;
            Guid batch_code = Guid.NewGuid();
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    reader.Read(); //ignore first row

                    while (reader.Read()) //Each ROW
                    {
                        PublicServiceBatch tem = new PublicServiceBatch();
                        tem.ProjectShort = reader.GetValue(0).ToString();
                        tem.HouseId = Convert.ToInt16(reader.GetValue(1).ToString());
                        tem.HouseNo = reader.GetValue(2).ToString();
                        tem.Step = Convert.ToInt16(reader.GetValue(3).ToString());
                        tem.EffectiveDate = Convert.ToDateTime(reader.GetValue(4).ToString());
                        tem.Installment = Convert.ToInt16(reader.GetValue(5).ToString());
                        tem.Remark = reader.GetValue(6).ToString();
                        tem.CreatedAt = created_at;
                        tem.CreatedBy = _userIdentity.Id;
                        tem.BatchCode = batch_code;

                        _context.PublicServiceBatch.Add(tem);
                        await _context.SaveChangesAsync();

                        total_records++;
                    }
                }
            }

            string sql = "exec dbo.sp_public_service_batch @batch_code,@user_id,@result out";
            SqlParameter[] param ={
                                    new SqlParameter("@batch_code",SqlDbType.UniqueIdentifier) { Value =batch_code},
                                    new SqlParameter("@user_id", SqlDbType.Int) { Value= _userIdentity.Id},
                                    new SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output }
                                   };
                          
            await _context.Database.ExecuteSqlRawAsync(sql, param);
            int TotalInsertRecords = (int)param[2].Value;

            //string sql = "exec dbo.sp_house_import @batch_code = '" + batch_code + "'";
            return new UploadResult { TotalUploadRecords = total_records, TotalInsertRecords = TotalInsertRecords };

        }

        [HttpPost("more-schedule")]
        public async Task<IActionResult> PublicServiceMoreSchedule(ClsPublicServiceMoreSchedule data)
        {

            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec [dbo].[sp_public_service_more_schedule] {0},{1}", data.HouseId, _userIdentity.Id);
                if (result != -1) throw new Exception("More Schedule is not available!");
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
