﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/bookings")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class BookingsController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public BookingsController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        //Houses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetBookings([FromQuery] BookingPaginationFilter filter)
        {

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            
            string sql = "exec dbo.get_booking_by_option {0},{1},{2},{3}";

            var vbooking = _context.VBookingsFullJoin
                               .FromSqlRaw(sql, filter.expire, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = vbooking.Count();

            var pagedData =     vbooking.OrderByDescending(x => x.BookingDate)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .Select(x => new
                               {
                                   x.BookingId,
                                   x.ProjectShort,
                                   x.HouseId,
                                   x.HouseNumber,
                                   x.Cus1NameKh,
                                   x.Cus1MobilePhone,
                                   x.Cus2NameKh,
                                   x.Cus2MobilePhone,
                                   x.BookingAmount,
                                   x.BookingDate,
                                   x.ExpireDate,
                                   x.StaffName,
                                   x.CreatedAt,
                                   x.RecStatus,
                                   x.HousePrice,
                                   x.HouseType,
                                   StatusName=x.Status
                               })                               
                               .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("paid-report")]
        public async Task<ActionResult<IEnumerable<object>>> GetBookingsPaidReport([FromQuery] BookingPaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            /*string criteria = " and t1.booking_date>='";
            if (filter.expire == 0) criteria += " and t1.expire_date>=GETDATE() and (t1.rec_status<=2)"; //get pay
            else if (filter.expire == 1) criteria += "​​ and t1.expire_date<GETDATE() and (t1.rec_status<=2 )"; //no pay and expired
            else criteria += "​​ and t1.rec_status=3"; //paid 

            string sql = @" select t1.*
                            from dbo.v_bookings_full_join t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id where t2.user_id = {0}" + criteria; 
            
              .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))*/

            var pagedData = _context.VBookingsFullJoin
                               .FromSqlRaw("exec dbo.get_booking_paid_unpaid {0},{1},{2}", filter.expire, _userIdentity.Id, filter.Search).AsEnumerable()
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .Select(x => new
                               {
                                   x.BookingId,
                                   x.ProjectShort,
                                   x.HouseId,
                                   x.HouseNumber,
                                   x.Cus1NameKh,
                                   x.Cus1MobilePhone,
                                   x.Cus2NameKh,
                                   x.Cus2MobilePhone,
                                   x.BookingAmount,
                                   x.BookingDate,
                                   x.ExpireDate,
                                   x.StaffName,
                                   x.CreatedAt,
                                   x.RecStatus,
                                   x.Status
                               })
                               .OrderByDescending(x=>x.BookingDate)
                               .ToList();

            validFilter.TotalRecords =
                 _context.VBookingsFullJoin.FromSqlRaw("exec dbo.get_booking_paid_unpaid {0},{1},{2}", filter.expire, _userIdentity.Id, filter.Search).AsEnumerable().Count();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetBookings(int id)
        {
            var data = await _context.VBookingHouseTypes.FirstOrDefaultAsync(x=>x.Id==id);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.bookings", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpGet("{id}/full")]
        public async Task<ActionResult<IEnumerable<VBookingsFullJoin>>> GetFullBookings(int id)
        {
            var data = await _context.VBookingsFullJoin.Where(x => x.BookingId == id).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("full/house/{id}")]
        public async Task<ActionResult<IEnumerable<VBookingsFullJoin>>> GetFullBookingsUniqueHouse(int id)
        {
            var data = await _context.VBookingsFullJoin
                    .Where(x => x.HouseId == id)
                    .OrderByDescending(x => x.CreatedAt)
                    .Take(1)
                    .ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("other-collection/house/{id}")]
        public async Task<ActionResult<IEnumerable<VOtherCollectionInfo>>> GetOtherCollectionInfo(int id)
        {

            var data =  _context.VOtherCollectionInfo.FromSqlRaw("exec dbo.get_other_collection_info {0}",id).AsEnumerable().ToList();
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Bookings>> AddBooking(Bookings data)
        {


            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {

                            var booking = await _context.Bookings.SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus <= 2 && x.Status == 1);
                            if (booking != null) return BadRequest("House is already booked");

                            var house = _context.Houses.SingleOrDefault(x => x.Id == data.HouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.AVAILABLE);
                            if (house == null) return BadRequest("House is not available");
                            // var bookingExpiryDays = 



                            data.CurrentCustomer1Id = data.Customer1Id;
                            data.CurrentCustomer2Id = data.Customer2Id;
                            data.CurrentCustomerRelationship = data.CustomerRelationship;

                            var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                            data.Customer1Id = customer_history1?.Id;
                            data.Customer2Id = customer_history2?.Id;
                            data.Status = 1;
                            data.FirstHouseId = data.HouseId;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            data.RecStatus = 0;
                            data.ProjectId = house.ProjectId;
                            data.HousePrice = house.Price;
                            data.NetHousePrice = house.Price - (data.HouseDiscount);
                            //  data.ExpireDate = data.ExpireDate;        //Convert.ToDateTime(data.Date).AddDays(bookingExpiryDays);
                            data.FirstHouseDiscount = data.HouseDiscount;

                            _context.Bookings.Add(data);
                            await _context.SaveChangesAsync();

                            house.RecStatus = WorkflowStatusModel.BOOKED;
                            _context.Entry(data).State = EntityState.Modified;
                            await _context.SaveChangesAsync();

                            //Add Workflow History draft
                            WorkflowDetailModel wf = new WorkflowDetailModel();
                            var workflowhistory = wf.WorkflowHistoryDraft("dbo.bookings", data.Id, _userIdentity.Id);
                            _context.WorkflowHistory.Add(workflowhistory);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[bookings_log] {0},{1},{2}", data.Id,"Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking can not saved!");

                            dbContextTransaction.Commit();
                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }

                        //return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpPost("approved/{booking_id}")]
        public async Task<IActionResult> BookingApproved(int booking_id)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.booking_approved {0},{1}", booking_id, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpPost("rejected/{booking_id}")]
        public async Task<IActionResult> RejectBooking(int booking_id)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.booking_rejected {0},{1}", booking_id, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateBooking(Bookings data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                            try
                            {

                                var booking = _context.Bookings.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                                if (booking == null)
                                {
                                    return BadRequest("Booking is not found!");
                                }

                                _context.Entry(data).State = EntityState.Modified;

                                data.NetHousePrice = booking.HousePrice - data.HouseDiscount;
                                //change to new house
                                if (booking.HouseId != data.HouseId)
                                {

                                    var house = _context.Houses.SingleOrDefault(x => x.Id == data.HouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.AVAILABLE);
                                    if (house == null) return BadRequest("New House is not available!");

                                    house.RecStatus = WorkflowStatusModel.BOOKED; //change new house to book
                                    var oldhouse = _context.Houses.SingleOrDefault(x => x.Id == booking.HouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.BOOKED);
                                    oldhouse.RecStatus = WorkflowStatusModel.AVAILABLE; //change old house to available                        
                                    data.ProjectId = house.ProjectId;
                                    data.HousePrice = house.Price;
                                    data.NetHousePrice = house.Price - data.HouseDiscount;
                                }

                                data.CurrentCustomer1Id = data.Customer1Id;
                                data.CurrentCustomer2Id = data.Customer2Id;
                                data.CurrentCustomerRelationship = data.CustomerRelationship;

                                // data.Customer1Id = booking.Customer1Id;
                                // data.Customer2Id = booking.Customer2Id;

                                var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                                data.Customer1Id = customer_history1?.Id;
                                data.Customer2Id = customer_history2?.Id;

                                data.Status = 1;
                                data.FirstHouseId = data.HouseId;
                                data.UpdatedAt = DateTime.Now;
                                data.UpdatedBy = _userIdentity.Id;
                                data.RecStatus = 0;
                                data.FirstHouseDiscount = data.HouseDiscount;
                                // data.ExpireDate = data.ExpireDate;


                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[bookings_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log booking can not update!");
                                dbContextTransaction.Commit();

                                return Ok();
                            }
                            catch (Exception ex)
                            {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                            }
                }
            
        }

        [HttpPost("delete")]
        public async Task<IActionResult> DeleteBooking(DeleteModel data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                    try
                    {
                            var data_delete = await _context.Bookings.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (data_delete == null)
                            {
                                return BadRequest("No, Booking can not be deleted!");
                            }

                            var houses = await _context.Houses.SingleOrDefaultAsync(x => x.Id == data_delete.HouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.BOOKED);
                            if (houses != null) houses.RecStatus = WorkflowStatusModel.AVAILABLE;

                            //_context.Bookings.Remove(data_delete);  
                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[bookings_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking can not deleted!");
                            dbContextTransaction.Commit();

                            return Ok();
                    }
                    catch (Exception ex)
                    {
                        
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
            //return NoContent();
        }

        [HttpGet("delays")]
        public async Task<ActionResult<IEnumerable<object>>> GetBookingsDelay([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = @"select t1.*
                            from dbo.v_bookings_delays t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}";

            var pagedData = _context.VBookingsDelays
                               .FromSqlRaw(sql, _userIdentity.Id)
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VBookingsDelays.FromSqlRaw(sql, _userIdentity.Id)
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("delays/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetBookingsDelayById(int id)
        {

            var data = await _context.BookingsDelays.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status!=0);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.bookings_delays", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("delays/add")]
        public async Task<ActionResult<BookingsDelays>> AddBookingsDelay(BookingsDelays data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var delay = _context.BookingsDelays.AsNoTracking().FirstOrDefault(x => x.BookingId == data.BookingId && x.RecStatus <= 2 && x.Status == 1);
                            if (delay != null)
                            {
                                return BadRequest("Booking is already delay, but not yet approved!");
                            }

                            var data_exists = _context.Bookings.AsNoTracking().SingleOrDefault(x => x.Id == data.BookingId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);

                            if (data_exists == null)
                            {
                                return BadRequest("Booking is not available");
                            }

                            /* if (data_exists.ExpireDate < DateTime.Now)
                             {
                                 return BadRequest("Booking is expired");
                             } */

                            var customer_history1 = data_exists.CurrentCustomer1Id == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data_exists.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var customer_history2 = data_exists.CurrentCustomer2Id == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data_exists.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                            data.Customer1Id = customer_history1?.Id;
                            data.Customer2Id = customer_history2?.Id;

                            data.Status = 1;
                            data.DelayDate = DateTime.Now;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            data.RecStatus = 0;
                            data.ProjectId = data_exists.ProjectId;


                            _context.BookingsDelays.Add(data);
                            await _context.SaveChangesAsync();

                            //Add Workflow History draft
                            WorkflowDetailModel wf = new WorkflowDetailModel();
                            var workflowhistory = wf.WorkflowHistoryDraft("dbo.bookings_delays", data.Id, _userIdentity.Id);
                            _context.WorkflowHistory.Add(workflowhistory);                            
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_delay_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking delay can not saved!");

                            dbContextTransaction.Commit();
                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
                //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("delays/approved/{refId}")]
        public async Task<ActionResult> ApprovedBookingsDelay(int refId)
        {

            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_booking_delay_approved {0},{1}", refId, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");

            /*var data_exists = _context.BookingsDelays.SingleOrDefault(x => x.Id == refId && x.RecStatus == WorkflowStatusModel.APPROVED);

            if (data_exists == null)
            {
                return BadRequest("Booking is not available");
            }

            var data = _context.Bookings.SingleOrDefault(x => x.Id == data_exists.BookingId && x.RecStatus == WorkflowStatusModel.APPROVED);

            if (data.ExpireDate < DateTime.Now)
            {
                return BadRequest("Booking is expired");
            }

            byte? old_status = data.RecStatus;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _userIdentity.Id;
            data.ExpireDate = data_exists.ExtendTo;
            data.DelayBookingDay = (short)(data_exists.ExtendTo - data_exists.ExpireDate).Days;
           // data.RecStatus = WorkflowStatusModel.DELAYED;

            try
            {
                _context.Entry(data).State = EntityState.Modified;
               // await _context.SaveChangesAsync();

                WorkflowHistory wf = new WorkflowHistory()
                {
                    WorkflowId = 3,
                    RefId = refId,
                    RecStatus = old_status,
                    PostStatus = WorkflowStatusModel.DELAYED,
                    Comment = "Booking Delayed",
                    IsDone = 1,
                    CreatedAt = DateTime.Now,
                    CreatedBy = _userIdentity.Id
                };

                _context.WorkflowHistory.Add(wf);
                await _context.SaveChangesAsync();

                return Ok();

            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }*/

        }

        [HttpPost("delays/update")]
        public async Task<IActionResult> Update(BookingsDelays data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var booking = _context.BookingsDelays.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);

                            if (booking == null)
                            {
                                return BadRequest("Booking is not found!");
                            }

                            data.Customer1Id = booking.Customer1Id;
                            data.Customer2Id = booking.Customer2Id;
                            data.Status = 1;
                            data.DelayDate = booking.DelayDate;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;
                            data.ProjectId = booking.ProjectId;
                            data.RecStatus = 0;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_delay_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking delay can not updated!");
                            dbContextTransaction.Commit();    

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
            
        }

        [HttpPost("delays/delete")]
        public async Task<IActionResult> Delete(DeleteModel data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {
                        var data_delete = await _context.BookingsDelays.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                        if (data_delete == null)
                        {
                            return BadRequest("No, booking delay can not be deleted!");
                        }                       
                        data_delete.Status = 0;
                        await _context.SaveChangesAsync();

                        //save to audit log
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_delay_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log booking delay can not deleted!");

                        dbContextTransaction.Commit();
                        return Ok();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }

            //return NoContent();
        }

        //Booking Change Owner
        [HttpGet("change/owners")]
        public async Task<ActionResult<IEnumerable<object>>> GetBookingsChangeOwner([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = @"select t1.*
                            from dbo.v_bookings_change_owners t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}";

            var pagedData = _context.VBookingsChangeOwners
                               .FromSqlRaw(sql, _userIdentity.Id)
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VBookingsChangeOwners.FromSqlRaw(sql, _userIdentity.Id)
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("change/owners/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetBookingsChangeOwnersById(int id)
        {
            string sql = $"select * from v_bookings_change_owners_by_id where id={id}";
            var data = await _context.VBookingsChangeOwners.FromSqlRaw(sql).FirstOrDefaultAsync();

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.bookings_change_owners", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }
        //add more status
        [HttpPost("change/owners/add")]
        public async Task<ActionResult<BookingsChangeOwners>> AddBookingsChangeOwners(BookingsChangeOwners data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                            var change_owner = _context.BookingsChangeOwners.AsNoTracking().FirstOrDefault(x => x.BookingId == data.BookingId && x.RecStatus <= 2 && x.Status == 1);
                            if (change_owner != null)
                            {
                                return BadRequest("Booking change ownership already exist, but not yet approved!");
                            }
                            var data_exists = _context.Bookings.AsNoTracking().SingleOrDefault(x => x.Id == data.BookingId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);

                            if (data_exists == null)
                            {
                                return BadRequest("Booking is not available");
                            }

                            if (data_exists.ExpireDate < DateTime.Today)
                            {
                                return BadRequest("Booking is expired");
                            }
                            try
                            {

                                var from_cus1 = data.FromCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var from_cus2 = data.FromCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var to_cus1 = data.ToCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var to_cus2 = data.ToCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                                data.FromCustomer1 = from_cus1?.Id;
                                data.FromCustomer2 = from_cus2?.Id;
                                data.ToCustomer1 = to_cus1?.Id;
                                data.ToCustomer2 = to_cus2?.Id;

                                data.Status = 1;
                                data.CreatedAt = DateTime.Now;
                                data.CreatedBy = _userIdentity.Id;
                                data.RecStatus = 0;
                                data.ProjectId = data_exists.ProjectId;
                                data.ChangeDate = DateTime.Today;

                                _context.BookingsChangeOwners.Add(data);
                                await _context.SaveChangesAsync();

                                //Add Workflow History draft
                                WorkflowDetailModel wf = new WorkflowDetailModel();
                                var workflowhistory = wf.WorkflowHistoryDraft("dbo.bookings_change_owners", data.Id, _userIdentity.Id);
                                _context.WorkflowHistory.Add(workflowhistory);
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_change_ownership_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log booking change ownership can not saved!");

                                
                                dbContextTransaction.Commit();

                                return data;

                            }
                            catch (Exception ex)
                            {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                            }
                }


       //     return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("change/owners/approved/{refId}")]
        public async Task<ActionResult> ApprovedBookingsChangeOwners(int refId)
        {
           
            try
            {
               
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_booking_change_ownership_approved {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");

                /*string form_url = _context.WorkflowNotifContent.AsNoTracking().Single(x => x.NotifFunction == "BookingsChangeOwner").NotifTo;

                WorkflowHistory wf = new WorkflowHistory()
                {
                    WorkflowId = 3,
                    RefId = refId,
                    RecStatus = WorkflowStatusModel.APPROVED,
                    PostStatus = WorkflowStatusModel.APPROVED,
                    Comment = "<a href=\"/" + form_url + data.Id + "\">Change Owner</a>",
                    IsDone = 1,
                    CreatedAt = DateTime.Now,
                    CreatedBy = _userIdentity.Id
                };

                _context.WorkflowHistory.Add(wf);
                await _context.SaveChangesAsync();

                return Ok();*/

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("change/owners/update")]
        public async Task<IActionResult> UpdateBookingChangeOwners(BookingsChangeOwners data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                    try
                    {
                            var booking = _context.BookingsChangeOwners.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);
                            if (booking == null)
                            {
                                return BadRequest("Booking is not found!");
                            }

                            var house = _context.Houses.SingleOrDefault(x => x.Id == data.HouseId && x.Status == 1);

                            if (house == null)
                            {
                                return BadRequest("House is not available!");
                            }


                            var from_cus1 = data.FromCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var from_cus2 = data.FromCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var to_cus1 = data.ToCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var to_cus2 = data.ToCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                            data.FromCustomer1 = from_cus1?.Id;
                            data.FromCustomer2 = from_cus2?.Id;
                            data.ToCustomer1 = to_cus1?.Id;
                            data.ToCustomer2 = to_cus2?.Id;

                            data.Status = 1;
                            data.ChangeDate = booking.ChangeDate;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;
                            data.RecStatus = 0;
                            data.ProjectId = house.ProjectId;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

                            await _context.SaveChangesAsync();
                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_change_ownership_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking change ownership can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
           
        }

        [HttpPost("change/owners/delete")]
        public async Task<IActionResult> DeleteBookingChangeOwners(DeleteModel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            var data_delete = await _context.BookingsChangeOwners.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (data_delete == null)
                            {
                                return BadRequest("No,booking change ownership can not be deleted!");
                            }

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_change_ownership_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking change ownership can not delete!");

                            dbContextTransaction.Commit();

                            return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

            //return NoContent();
        }

        //Booking Change House
        [HttpGet("change/houses")]
        public async Task<ActionResult<IEnumerable<object>>> GetBookingsChangeHouses([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = @"select t1.*
                            from [dbo].[v_bookings_change_house1] t1
                            inner join dbo.users_to_projects t2 
                                on t1.FromProjectId = t2.project_id and t2.user_id = {0}";

            var pagedData = _context.VBookingsChangeHouse1
                               .FromSqlRaw(sql, _userIdentity.Id)
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.FromHouseNo == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ToProjectId == filter.ProId)
                               ))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)                              
                               .ToList();

            validFilter.TotalRecords =
                await _context.VBookingsChangeHouse1.FromSqlRaw(sql, _userIdentity.Id)
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.ToHouseNo == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ToProjectId == filter.ProId)
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("change/houses/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetBookingsChangeHousesById(int id)
        {

            var data = await _context.VBookingsChangeHouseById.SingleOrDefaultAsync(x=>x.Id==id);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.bookings_change_house", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("change/houses/add")]
        public async Task<ActionResult<BookingsChangeHouse>> AddBookingsChangeHouses(BookingsChangeHouse data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                    try
                    {
                            //get Booking data
                            data.HouseChangeDate = DateTime.Now;
                            var change_houses = _context.BookingsChangeHouse.AsNoTracking().FirstOrDefault(x => x.BookingId == data.BookingId && x.RecStatus <= 2 && x.Status == 1);
                            if (change_houses != null)
                            {
                                return BadRequest("Booking change house already exist but not yet approved!");
                            }
                            var booking_exists = await _context.Bookings.SingleOrDefaultAsync(x => x.Id == data.BookingId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                            if (booking_exists == null)
                            {
                                return BadRequest("Booking is not available");
                            }

                            if (booking_exists.ExpireDate < DateTime.Today)
                            {
                                return BadRequest("Booking is expired");
                            }
                            var new_house = await _context.Houses.SingleOrDefaultAsync(x => x.Id == data.NewHouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.AVAILABLE); //|| x.RecStatus == WorkflowStatusModel.BOOKED
                            if (new_house == null)
                            {
                                return BadRequest("New house is not available");
                            }

                            var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                            data.Customer1Id = customer_history1?.Id;
                            data.Customer2Id = customer_history2?.Id;

                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;
                            data.RecStatus = WorkflowStatusModel.DRAFT;
                            data.ProjectId = booking_exists.ProjectId;
                            //var transaction = _context.Database.BeginTransaction();


                            _context.BookingsChangeHouse.Add(data);
                            new_house.RecStatus = WorkflowStatusModel.BOOKED;
                            await _context.SaveChangesAsync();

                            //Add Workflow History draft
                            WorkflowDetailModel wf = new WorkflowDetailModel();
                            var workflowhistory = wf.WorkflowHistoryDraft("dbo.bookings_change_house", data.Id, _userIdentity.Id);
                            _context.WorkflowHistory.Add(workflowhistory);

                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_change_house_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking change house can not saved!");
                            dbContextTransaction.Commit();
                            //transaction.Commit();
                            return data;

                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
                // return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("change/houses/approved/{refId}")]
        public async Task<ActionResult> ApprovedBookingsChangeHouses(int refId)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_booking_changehouse_approved {0},{1}", refId, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }
        [HttpPost("change/houses/rejected/{refId}")]
        public async Task<ActionResult> RejectedBookingsChangeHouses(int refId)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_booking_changehouse_rejected {0},{1}", refId, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }
        [HttpPost("change/houses/update")]
        public async Task<IActionResult> UpdateBookingChangeHouses(BookingsChangeHouse data)
        {

                    using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                    {

                                try
                                {
                                    var booking = _context.BookingsChangeHouse.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                                    if (booking == null)
                                    {
                                        return BadRequest("Booking change house is not available!");
                                    }
                                    if (data.NewHouseId != booking.NewHouseId)
                                    {
                                        var oldhouses = await _context.Houses.SingleOrDefaultAsync(x => x.Id == booking.NewHouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.BOOKED);
                                        if (oldhouses == null) return BadRequest("Old house not booked");
                                        var newhouses = await _context.Houses.SingleOrDefaultAsync(x => x.Id == data.NewHouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.AVAILABLE);
                                        if (oldhouses == null) return BadRequest("Selected house not available");
                                        oldhouses.RecStatus = WorkflowStatusModel.AVAILABLE;
                                        newhouses.RecStatus = WorkflowStatusModel.BOOKED;
                                    }

                                    /*   var house = _context.Houses.SingleOrDefault(x => x.Id == data.HouseId);

                                       if (house == null)
                                       {
                                           return BadRequest("House is not available!");
                                       } */

                                    var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                    var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                                    data.Customer1Id = customer_history1?.Id;
                                    data.Customer2Id = customer_history2?.Id;

                                    data.Status = 1;
                                    data.HouseChangeDate = DateTime.Now;
                                    data.UpdatedAt = DateTime.Now;
                                    data.UpdatedBy = _userIdentity.Id;
                                    data.RecStatus = WorkflowStatusModel.DRAFT;
                                    //data.ProjectId = house.ProjectId;

                                    _context.Entry(data).State = EntityState.Modified;
                                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                    
                                     var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_change_house_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                     if (result != -1) throw new Exception("Log booking change house can not update!");

                                    await _context.SaveChangesAsync();
                                    dbContextTransaction.Commit();
                                    return Ok();
                                }
                                catch (Exception ex)
                                {
                                    dbContextTransaction.Rollback();
                                    return BadRequest(ex.Message);
                                }
                                //return Ok();
                    }
        }

        [HttpPost("change/houses/delete")]
        public async Task<IActionResult> DeleteBookingChangeHouses(DeleteModel data)
        {
                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var data_delete = await _context.BookingsChangeHouse.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (data_delete == null)
                            {
                                return BadRequest("Invalid booking change house id");
                            }
                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_change_house_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking change house can not delete!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }            
        }

        //Booking Cancel
        [HttpGet("cancel")]
        public async Task<ActionResult<IEnumerable<object>>> GetBookingsCancel([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = @"select t1.*
                            from dbo.v_bookings_cancel t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id and t2.user_id = {0}";

            var pagedData = _context.VBookingsCancel
                               .FromSqlRaw(sql, _userIdentity.Id)
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VBookingsCancel.FromSqlRaw(sql, _userIdentity.Id)
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("cancel/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetBookingsCancelById(int id)
        {

            var data = await _context.BookingsCancel.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.bookings_cancel", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("cancel/add")]
        public async Task<ActionResult<BookingsCancel>> AddBookingsCancel(BookingsCancel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                
                        try
                        {

                                var booking_cancel = _context.BookingsCancel.AsNoTracking().FirstOrDefault(x => x.BookingId == data.BookingId && x.RecStatus <= 2 && x.Status == 1);
                                if (booking_cancel != null)
                                {
                                    return BadRequest("Booking cancel already exist, but not yet approved!");
                                }
                                var data_exists = _context.Bookings.SingleOrDefault(x => x.Id == data.BookingId && x.Status==1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                                if (data_exists == null)
                                {
                                    return BadRequest("Booking is not available");
                                }

                                var customer1 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data_exists.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var customer2 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data_exists.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                data.Customer1Id = customer1?.Id;
                                data.Customer2Id = customer2?.Id;

                                data.Status = 1;
                                data.CreatedAt = DateTime.Now;
                                data.CreatedBy = _userIdentity.Id;
                                data.RecStatus = 0;
                                data.ProjectId = data_exists.ProjectId;

           
                                _context.BookingsCancel.Add(data);
                                await _context.SaveChangesAsync();

                                //Add Workflow History draft
                                WorkflowDetailModel wf = new WorkflowDetailModel();
                                var workflowhistory = wf.WorkflowHistoryDraft("dbo.bookings_cancel", data.Id, _userIdentity.Id);
                                _context.WorkflowHistory.Add(workflowhistory);
                                await _context.SaveChangesAsync();
                                
                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_cancel_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log booking cancel log can not saved!");

                                dbContextTransaction.Commit();                                
                                return data;
                        }
                        catch(Exception ex)
                        {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                        }
                }
            //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("cancel/approved/{refId}")]
        public async Task<ActionResult> ApprovedBookingsCancel(int refId)
        {
            try
            {
                    var booking_cancel = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_bookings_cancel_approve {0},{1}", refId, _userIdentity.Id);
                    if (booking_cancel == -1) return Ok("success");
                    else return BadRequest("operation fail");

                   /* string form_url = _context.WorkflowNotifContent.AsNoTracking().Single(x => x.NotifFunction == "BookingsCancel").NotifTo;

                    WorkflowHistory wf = new WorkflowHistory()
                    {
                        WorkflowId = 3,
                        RefId = refId,
                        RecStatus = 3,
                        PostStatus = 3,
                        Comment = "<a href=\"" + form_url + refId + "\">Booking Cancel</a>",
                        IsDone = 1,
                        CreatedAt = DateTime.Now,
                        CreatedBy = _userIdentity.Id
                    };

                    _context.WorkflowHistory.Add(wf);
                    await _context.SaveChangesAsync();

                    return Ok();*/

            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("cancel/update")]
        public async Task<IActionResult> UpdateCancel(BookingsCancel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var booking = _context.BookingsCancel.AsNoTracking().Single(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (booking == null)
                            {
                                return BadRequest("Booking Cancel is not found!");
                            }

                            var data_exists = _context.Bookings.SingleOrDefault(x => x.Id == data.BookingId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                            if (data_exists == null)
                            {
                                return BadRequest("Booking is not available");
                            }

                            var customer1 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data_exists.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var customer2 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data_exists.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            data.Customer1Id = customer1?.Id;
                            data.Customer2Id = customer2?.Id;

                            data.Status = 1;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;
                            data.RecStatus = 0;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_cancel_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking cancel can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
           
        }

        [HttpPost("cancel/delete")]
        public async Task<IActionResult> DeleteBookingCancel(DeleteModel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var data_delete = await _context.BookingsCancel.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (data_delete == null)
                            {
                                return BadRequest("Invalid booking cancel id");
                            }
                            //_context.BookingsCancel.Remove(data_delete);
                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();
                            
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_cancel_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log booking cancel can not delete!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
            
        }

        //  [HttpPost("changehouse/list")]

        [HttpGet("house/{id}")]

        public async Task<IActionResult> GetBookingByHouseId(int id)
        {
            var booking =  _context.BookingCustomerInfo.FromSqlRaw("exec dbo.get_booking_customer_info {0}",id).AsEnumerable().SingleOrDefault();
            if (booking == null) return BadRequest("Invalid house id");
            else return Ok(booking);
        }

        [HttpGet("total/house/{id}")]

        public async Task<object> GetTotalBookingByHouseId(int id)
        {
            var result = new Microsoft.Data.SqlClient.SqlParameter("@total", SqlDbType.Float) { Direction = ParameterDirection.Output };
            await _context.Database.ExecuteSqlRawAsync("exec dbo.get_total_booking {0},@total={1} out", id, result);
            return new { TotalBooking=result.Value };
        }

    }
}
