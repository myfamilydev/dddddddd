﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/contracts")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class ContractsController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public ContractsController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;


            // if ( _httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        //Contract
        [HttpGet]
        public async Task<ActionResult<object>> GetContracts([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            string sql = "exec dbo.get_contracts_filter {0},{1},{2}";

            var vcontract = _context.VContracts
                               .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = vcontract.Count();
            var pagedData = vcontract.OrderByDescending(x => x.ContractDate)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)                               
                               .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

           return await new CrudLib<VContracts>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("house/{id}")]
        public async Task<ActionResult<VContracts>> GetContractByHouse(int id)
        {
            var vcontract=await _context.VContracts.SingleOrDefaultAsync(x => x.HouseId == id);
            if (vcontract == null) BadRequest("Invalid contract id");
            return Ok(vcontract);
        }

        [HttpGet("house/current-info/{id}")]
        public async Task<ActionResult<VContracts>> GetContractByHouseCurrentInfo(int id)
        {
            var vcontract = await _context.VContractsCurrentInfo.SingleOrDefaultAsync(x => x.HouseId == id);
            if (vcontract == null) BadRequest("Invalid contract id");
            return Ok(vcontract);
        }

        [HttpGet("house/current-info1/{contract_id}")]
        public async Task<ActionResult<VContracts>> GetContractByContractCurrentInfo(int contract_id)
        {
            var vcontract = _context.VContractsCurrentInfo.FromSqlRaw("exec get_sp_contracts_current_info_1 {0}", contract_id).AsEnumerable().FirstOrDefault();
            if (vcontract == null) BadRequest("Invalid contract id");
            return Ok(vcontract);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetContracts(int id)
        {
            var data = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status!=0);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.contracts", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("sale-manager/approved/{contract_id}")]
        public async Task<IActionResult> SaleManagerApproveContract(int contract_id)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.contract_sale_manager_approved {0},{1}", contract_id, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpPost("rejected/{contract_id}")]
        public async Task<IActionResult> RejectContract(int contract_id)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.contract_rejected {0},{1}", contract_id, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpGet("house/{id}/outstanding")]
        public async Task<ActionResult<object>> GetContractsOutstanding(int id)
        {
           
            var contract = _context.Contracts.Where(x => x.HouseId == id && x.Status==1).OrderByDescending(x => x.CreatedAt).FirstOrDefault();

            if(contract == null)
            {
                ApiResponse res = new ApiResponse();
                res.status = "failed";
                res.message = "This house not found in Approved Contract.";
                return res;
            }

            var data = await _context.VContractOutstandingBalance.Where(x=>x.ContractId == contract.Id).ToListAsync();
            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Contracts>> ContractsAdd(Contracts data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {

                            var contract = _context.Contracts.AsNoTracking().SingleOrDefault(x => x.HouseId == data.HouseId && x.Status == 1);
                            if (contract != null) BadRequest("House already exist");

                            var house = _context.Houses.SingleOrDefault(x => x.Id == data.HouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.BOOKED);
                            if (house == null)
                            {
                                return BadRequest("House status is not BOOKED");
                            }

                            //var booking = _context.Bookings.SingleOrDefault(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                            var booking = _context.VBookingHouses.SingleOrDefault(x => x.HouseId == data.HouseId);
                            if (booking == null)
                            {
                                return BadRequest("House not yet booking");
                            }

                            house.RecStatus = WorkflowStatusModel.CONTRACTED;
                            await _context.SaveChangesAsync();

                            var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var payment_term = await _context.PaymentTerms.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.PaymentTermId && x.Status == 1);

                            data.Condition = payment_term.Remark;
                            data.CurrentCustomer1Id = data.Customer1Id;
                            data.CurrentCustomer2Id = data.Customer2Id;
                            data.OwnerCustomerRelationship = booking.CurrentCustomerRelationship;
                            data.CustomerRelationship = booking.CurrentCustomerRelationship;

                            data.Customer1Id = customer_history1?.Id;
                            data.Customer2Id = customer_history2?.Id;
                            data.Status = 1;
                            data.ContractAmount = Math.Round(data.ContractAmount ?? 0, 0);
                            data.PaymentType = 0; //0: auto; 1: manual
                            data.RescheduleCount = 1;
                            CrudLib<Contracts> crud = new CrudLib<Contracts>(_context, _userIdentity.Id);
                            data = (Contracts)await crud.Add(data, "dbo.contracts", true, "create contract");
                            
                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract can not saved!");
                            dbContextTransaction.Commit();
                            return data;
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
            }
        }

        [HttpPost("update")]
        public async Task<ActionResult<Contracts>> ContractsUpdate(Contracts data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                                var contracts = _context.Contracts.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);
                                if (contracts == null)
                                {
                                    return BadRequest("Contract Id not found!");
                                }

                               // var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                               // var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var payment_term = await _context.PaymentTerms.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.PaymentTermId && x.Status == 1);

                                data.Condition = payment_term.Remark;

                                data.CurrentCustomer1Id = data.Customer1Id;
                                data.CurrentCustomer2Id = data.Customer2Id;
                                data.OwnerCustomerRelationship = data.CustomerRelationship;

                                //data.CurrentCustomer1Id = contracts.CurrentCustomer1Id; //data.Customer1Id;
                                //data.CurrentCustomer2Id = contracts.CurrentCustomer2Id;
                                //data.OwnerCustomerRelationship = contracts.OwnerCustomerRelationship;

                                var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.Customer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                                data.Customer1Id = customer_history1?.Id;
                                data.Customer2Id = customer_history2?.Id;
                                data.CustomerRelationship = contracts.CustomerRelationship;

                                //data.Customer1Id = contracts.Customer1Id;
                                //data.Customer2Id = contracts.Customer2Id;
                                //data.CustomerRelationship = contracts.CustomerRelationship;

                                data.Status = 1;
                                data.ContractAmount = Math.Round(data.ContractAmount ?? 0, 0);
                                data.PaymentType = 0; //0: auto; 1: manual 
                                data.RescheduleCount = 1;
                                CrudLib<Contracts> crud = new CrudLib<Contracts>(_context ,_userIdentity.Id);
                                data = (Contracts)await crud.Update(data);

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log contract can not updated!");
                                dbContextTransaction.Commit();

                                return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        //Houses
        [HttpGet("adhoc-discount")]
        public async Task<ActionResult<object>> AdhocDiscountGet([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VAdhocDiscountStatus>(_context ,_userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("adhoc-discount/{id}")]
        public async Task<ActionResult<WorkflowModel>> Get(int id)
        {
            var data = await _context.AdhocDiscounts.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status!=0);
            
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.adhoc_discounts", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpGet("adhoc-discount/house/{house_id}")]
        public async Task<ActionResult<AdhocDiscounts>> GetAdhocByHouseId(int house_id)
        {
            var data = await _context.AdhocDiscounts.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == house_id && x.Status==1 && x.RecStatus == 3);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("adhoc-discount/add")]
        public async Task<ActionResult<AdhocDiscounts>> AdHocDiscountAdd(AdhocDiscounts data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                                var adhoc_discount = _context.AdhocDiscounts.AsNoTracking().FirstOrDefault(x => x.BookingId == data.BookingId && x.RecStatus <= 2 && x.Status == 1);
                                if (adhoc_discount != null)
                                {
                                    return BadRequest("Adhoc discount already exist, but not yet approved!");
                                }

                                //update
                                var booking = _context.Bookings.AsNoTracking().SingleOrDefault(x => x.Id == data.BookingId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                                if (booking == null)
                                {
                                    return BadRequest("There is no booking for this houses!");
                                }
                                var customer1 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == booking.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var customer2 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == booking.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                data.Customer1Id = customer1?.Id;
                                data.Customer2Id = customer2?.Id;

                                data.Status = 1;
                                CrudLib<AdhocDiscounts> crud = new CrudLib<AdhocDiscounts>(_context, _userIdentity.Id);
                                data = (AdhocDiscounts)await crud.Add(data, "dbo.adhoc_discounts", true, "create adhoc discount");

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[adhoc_discount_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log adhoc discount can not saved!");

                                dbContextTransaction.Commit();
                                return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

            //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("adhoc-discount/approved/{refId}")]
        public async Task<ActionResult> AdHocDiscountApproved(int refId)
        {
            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_adhoc_discount_approved {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");
                
               /* var adhocdiscount = _context.AdhocDiscounts.SingleOrDefault(x => x.Id == refId && x.RecStatus == WorkflowStatusModel.APPROVED);
                if (adhocdiscount == null) return BadRequest("Adhoc discount ID not available");

                var booking = await _context.Bookings.SingleOrDefaultAsync(x => x.Id == adhocdiscount.BookingId && x.RecStatus == WorkflowStatusModel.APPROVED);
                if(booking==null) return BadRequest("Booking ID not available");
                booking.HouseDiscount = booking.HouseDiscount + adhocdiscount.DiscountAmount;
                booking.NetHousePrice = booking.HousePrice - booking.HouseDiscount;
                await _context.SaveChangesAsync();
                return Ok(); */
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }

            //return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("adhoc-discount/update")]
        public async Task<ActionResult<AdhocDiscounts>> AdHocDiscountUpdate(AdhocDiscounts data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var adhoc = _context.AdhocDiscounts.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.RecStatus == WorkflowStatusModel.DRAFT && x.Status == 1);
                            if (adhoc == null)
                            {
                                return BadRequest("Invalid Adhoc-Discount to update!");
                            }

                            var booking = _context.Bookings.AsNoTracking().SingleOrDefault(x => x.Id == data.BookingId && x.RecStatus == WorkflowStatusModel.APPROVED && x.Status == 1);
                            if (booking == null)
                            {
                                return BadRequest("There is no booking for this houses!");
                            }
                            var customer1 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == booking.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var customer2 = await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == booking.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            data.Customer1Id = customer1?.Id;
                            data.Customer2Id = customer2?.Id;

                            data.Status = 1;
                            CrudLib<AdhocDiscounts> crud = new CrudLib<AdhocDiscounts>(_context, _userIdentity.Id);
                            data = (AdhocDiscounts)await crud.Update(data, "_");

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[adhoc_discount_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log adhoc discount can not updated!");
                            dbContextTransaction.Commit();

                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        //Houses
        [HttpGet("ownerships/list")]
        public async Task<ActionResult<IEnumerable<object>>> OwnershipGetAll ([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VContractsOwnerships
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VContractsOwnerships
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("ownerships/{id}")]
        public async Task<ActionResult<WorkflowModel>> OwnershipGet(int id)
        {

            string sql = $"select * from v_contracts_ownerships_by_id where id={id}";
            var data = await _context.VContractsOwnerships.FromSqlRaw(sql).FirstOrDefaultAsync();
            if (data == null)
            {
                return NoContent();
            }

            int index = 0;
            if (data.RequestType == 2) index = 1;
            else if(data.RequestType == 3) index = 2;
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.contracts_ownerships", data.Id, _userIdentity.Id,index);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("ownerships/approved/{refId}")]
        public async Task<ActionResult> ContractOwnershipApproved(int refId)
        {

            try
            {

                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_contract_ownership_approved {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");
                /*  var ownerships = _context.ContractsOwnerships.AsNoTracking().SingleOrDefault(x => x.Id == refId && x.RecStatus == WorkflowStatusModel.APPROVED);
                  if (ownerships == null) return BadRequest("Ownership Id is not available");
                  var contract = _context.Contracts.SingleOrDefault(x => x.Id == ownerships.ContractId && x.RecStatus == WorkflowStatusModel.APPROVED);
                  if (contract == null) return BadRequest("Contract Id is not available");

                  // _context.Entry(data_exists).State = EntityState.Modified;              

                  if (contract.Fcustomer1Id == null && contract.Fcustomer2Id == null)
                  {
                      //_context.Entry(contract).State = EntityState.Modified;

                      contract.Fcustomer1Id = contract.Customer1Id;
                      contract.Fcustomer2Id = contract.Customer2Id;
                      contract.FcustomerRelationship = contract.CustomerRelationship;
                  }
                  if (ownerships.RequestType == 1)
                  {
                      contract.Customer2Id = ownerships.ToCustomer1 == null ? ownerships.ToCustomer2 : ownerships.ToCustomer1;

                  }
                  else if (ownerships.RequestType == 2)
                  {
                      contract.Customer1Id = ownerships.ToCustomer1 == null ? ownerships.ToCustomer2 : ownerships.ToCustomer1;
                      contract.Customer2Id = ownerships.ToCustomer1 == null ? null : ownerships.ToCustomer2;
                  }
                  else if (ownerships.RequestType == 3)
                  {
                      if (contract.Customer1Id != null && contract.Customer2Id != null)
                      {
                          int? customerid = ownerships.ToCustomer1 == null ? ownerships.ToCustomer2 : ownerships.ToCustomer1;
                          if (contract.Customer1Id == customerid)
                          {
                              contract.Customer1Id = contract.Customer2Id;
                              contract.Customer2Id = null;
                          }
                          else if (contract.Customer2Id == customerid)
                          {
                              contract.Customer2Id = null;
                          }
                      }
                  }

                  await _context.SaveChangesAsync();

                  return Ok(); */
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpPost("ownerships/add")]
        public async Task<ActionResult<ContractsOwnerships>> OwnershipAdd(ContractsOwnerships data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                                var contract_ownership = _context.ContractsOwnerships.AsNoTracking().FirstOrDefault(x => x.ContractId == data.ContractId && x.RecStatus <= 2 && x.Status == 1);
                                if (contract_ownership != null)
                                {
                                    return BadRequest("Contract ownership already exists, but not yet approved!");
                                }
                                var contract = _context.Contracts.SingleOrDefault(x => x.Id == data.ContractId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                                if (contract == null) return BadRequest("Contract Id is not available");
                                string workflow_title = "";

                                if (data.RequestType == 1)
                                {
                                    if (Convert.ToInt32(contract.Customer1Id) > 0 && Convert.ToInt32(contract.Customer2Id) > 0)
                                    {
                                        return BadRequest("Ownership support 2 person only!");
                                    }
                                    workflow_title = "add contract ownership";
                                }
                                else if (data.RequestType == 2) workflow_title = "change contract ownership";
                                else if (data.RequestType == 3) workflow_title = "remove contract ownership";

                                var from1 = data.FromCustomer1 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var from2 = data.FromCustomer2 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var to1 = data.ToCustomer1 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                var to2 = data.ToCustomer2 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                                data.FromCustomer1 = from1?.Id;
                                data.FromCustomer2 = from2?.Id;
                                data.ToCustomer1 = to1?.Id;
                                data.ToCustomer2 = to2?.Id;

                                data.Status = 1;
                                data.RecStatus = 0;
                                data.CreatedAt = DateTime.Now;
                                data.CreatedBy = _userIdentity.Id;
                                data.HouseId = contract.HouseId;
                                data.BookingId = contract.BookingId;

                                CrudLib<ContractsOwnerships> crud = new CrudLib<ContractsOwnerships>(_context, _userIdentity.Id);
                                data = (ContractsOwnerships)await crud.Add(data, "dbo.contracts_ownerships", true, workflow_title);

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_ownership_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log contract ownership can not saved!");
                                dbContextTransaction.Commit();
                                return data;

                        }
                        catch (Exception ex)
                        {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("ownerships/update")]
        public async Task<ActionResult<ContractsOwnerships>> OwnershipUpdate(ContractsOwnerships data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var ownership = _context.ContractsOwnerships.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (ownership == null) return BadRequest("Ownership Id not available");

                            var from1 = data.FromCustomer1 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var from2 = data.FromCustomer2 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.FromCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var to1 = data.ToCustomer1 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var to2 = data.ToCustomer2 == null ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.ToCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                            data.FromCustomer1 = from1?.Id;
                            data.FromCustomer2 = from2?.Id;
                            data.ToCustomer1 = to1?.Id;
                            data.ToCustomer2 = to2?.Id;

                            data.Status = 1;
                            data.RecStatus = 0;
                            data.HouseId = ownership.HouseId;
                            data.BookingId = ownership.BookingId;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;

                            CrudLib<ContractsOwnerships> crud = new CrudLib<ContractsOwnerships>(_context, _userIdentity.Id);
                            data = (ContractsOwnerships)await crud.Update(data);

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_ownership_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract ownership can not updated!");
                            dbContextTransaction.Commit();

                            return data;
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("c2c/approved/{refId}")]
        public async Task<ActionResult> C2CApproved(int refId)
        {

            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_contract_c2c_approved {0},{1}", refId, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");

            /* var c2c = _context.ContractsC2c.AsNoTracking().SingleOrDefault(x => x.Id == refId && x.RecStatus == WorkflowStatusModel.APPROVED);
             if (c2c == null) return BadRequest("C2C Id not available");
             var contract = _context.Contracts.SingleOrDefault(x => x.Id == c2c.ContractId && x.RecStatus == WorkflowStatusModel.APPROVED);
             if (contract == null) return BadRequest("Contract Id is not available");

             if (contract.Fcustomer1Id == null && contract.Fcustomer2Id == null)
             {
                 //_context.Entry(contract).State = EntityState.Modified;

                 contract.Fcustomer1Id = contract.Customer1Id;
                 contract.Fcustomer2Id = contract.Customer2Id;
                 contract.FcustomerRelationship = contract.CustomerRelationship;
             }
             contract.Customer1Id = c2c.NewCustomer1;
             contract.Customer2Id = c2c.NewCustomer2;
             contract.CustomerRelationship = c2c.CustomerRelationship;
             await _context.SaveChangesAsync();
             return Ok(); */

        }
        [HttpGet("c2c")]
        public async Task<ActionResult<IEnumerable<object>>> GetC2C([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VC2c
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VC2c
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }
        [HttpGet("c2c/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetC2CById(int id)
        {
            string sql = $"select * from v_c2c_by_id where id={id}";
            var data = await _context.VC2c.FromSqlRaw(sql).FirstOrDefaultAsync();
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.contracts_c2c", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("c2c/add")]
        public async Task<ActionResult<ContractsC2c>> C2CAdd(ContractsC2c data)
        {
                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                            try
                            {
                                    var contract_c2c = _context.ContractsC2c.AsNoTracking().FirstOrDefault(x => x.ContractId == data.ContractId && x.RecStatus <= 2 && x.Status == 1);
                                    if (contract_c2c != null)
                                    {
                                        return BadRequest("Contract C2C already exist, but not yet approved!");
                                    }
                                    var contract = _context.Contracts.AsNoTracking().SingleOrDefault(x => x.Id == data.ContractId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                                    if (contract == null) return BadRequest("Contract Id not available");

                                    var CurrentCustomer_1 = data.CurrentCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.CurrentCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                    var CurrentCustomer_2 = data.CurrentCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.CurrentCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                    var NewCustomer_1 = data.NewCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.NewCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                                    var NewCustomer_2 = data.NewCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.NewCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                                    data.CurrentCustomer1 = CurrentCustomer_1?.Id;
                                    data.CurrentCustomer2 = CurrentCustomer_2?.Id;
                                    data.NewCustomer1 = NewCustomer_1?.Id;
                                    data.NewCustomer2 = NewCustomer_2?.Id;
                                    data.BookingId = contract.BookingId;
                                    data.Status = 1;
                                    data.C2cNo = 0;
                                    data.C2cIndex = 0;
                                    data.RecStatus = 0;

                                    CrudLib<ContractsC2c> crud = new CrudLib<ContractsC2c>(_context, _userIdentity.Id);
                                    data = (ContractsC2c)await crud.Add(data, "dbo.contracts_c2c", true, "contract c2c");

                                    //save to audit log
                                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                    if (result != -1) throw new Exception("Log contract can not saved!");
                                    dbContextTransaction.Commit();
                                    return data;

                            }
                            catch (Exception ex)
                            {
                                return BadRequest(ex.Message);
                            }
                }
        }

        [HttpPost("c2c/update")]
        public async Task<ActionResult<ContractsC2c>> C2CUpdate(ContractsC2c data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                        try
                        {
                            var c2c = _context.ContractsC2c.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (c2c == null) return BadRequest("Contract C2C Id not available");

                            var CurrentCustomer_1 = data.CurrentCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.CurrentCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var CurrentCustomer_2 = data.CurrentCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.CurrentCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var NewCustomer_1 = data.NewCustomer1 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.NewCustomer1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                            var NewCustomer_2 = data.NewCustomer2 == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == data.NewCustomer2).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();

                            data.CurrentCustomer1 = CurrentCustomer_1?.Id;
                            data.CurrentCustomer2 = CurrentCustomer_2?.Id;
                            data.NewCustomer1 = NewCustomer_1?.Id;
                            data.NewCustomer2 = NewCustomer_2?.Id;
                            data.BookingId = c2c.BookingId;
                            data.Status = 1;
                            data.C2cNo = 0;
                            data.C2cIndex = 0;
                            data.RecStatus = 0;
                            CrudLib<ContractsC2c> crud = new CrudLib<ContractsC2c>(_context, _userIdentity.Id);
                            data = (ContractsC2c)await crud.Update(data);

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract can not updated!");
                            dbContextTransaction.Commit();
                            return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
            }
        }

        [HttpGet("terms")]
        public async Task<ActionResult<object>> GetContractsTerms([FromQuery] PaginationFilter filter)
        {          

            return await new CrudLib<VContractsTerms>(_context, _userIdentity.Id).GetDataPro(filter);
        }

        [HttpGet("terms_1")]
        public async Task<ActionResult<object>> GetContractsTerms_1([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_contracts_term_filter {0},{1},{2}";

            var data = _context.VContractsTerms_1
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("terms/{id}")]
        public async Task<ActionResult<ContractsTerms>> GetContractsTermsById(int id)
        {
            var data = await _context.ContractsTerms.SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("terms/add")]
        public async Task<ActionResult<ContractsTerms>> AddContractsTerms(ContractsTerms data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            data.Status = 1;
                            data.CreatedAt = DateTime.Now;
                            data.CreatedBy = _userIdentity.Id;

                            if (data.IsSpecial ?? false)
                            {
                                var house = await _context.Houses.FindAsync(data.HouseId);
                                if (house != null) data.HouseCatId = house.HouseCategoryId;
                            }

                             _context.ContractsTerms.Add(data);
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_terms_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract term can not saved!");
                            dbContextTransaction.Commit();

                             return data;

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
           
        }

        [HttpPost("terms/update")]
        public async Task<IActionResult> UpdateContractsTerms(ContractsTerms data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {

                            var user_exists = _context.ContractsTerms.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);
                            if (user_exists == null)
                            {
                                return BadRequest("Invalid contract term id");
                            }

                            data.Status = 1;
                            data.UpdatedAt = DateTime.Now;
                            data.UpdatedBy = _userIdentity.Id;
                            data.HouseCatId = user_exists.HouseCatId;

                            _context.Entry(data).State = EntityState.Modified;
                            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_terms_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract term can not updated!");
                            dbContextTransaction.Commit();
                            return Ok();

                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
            
        }
        [HttpPost("terms/delete")]
        public async Task<IActionResult> DeleteContractsTerms(ContractsTerms data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            var data_delete = await _context.ContractsTerms.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);

                            if (data_delete == null)
                            {
                                return BadRequest("Invalid Contract term id");
                            }

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_terms_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract term can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpGet("terms/house/{house_id}")]
        public async Task<ActionResult<ContractsTerms>> GetContractsTermsHouseById(int house_id)
        {
                try
                {
                    var result = await _context.ContractsTerms.FromSqlRaw("exec get_contract_term_by_houseid {0}", house_id).ToListAsync();
                    return Ok(result);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }

        [HttpPost("termination/approved/{refId}")]
        public async Task<ActionResult> TerminationApproved(int refId)
        {
            try
            {
                var booking_cancel = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_contracts_terminate_approve {0},{1}", refId, _userIdentity.Id);
                if (booking_cancel == -1) return Ok("success");
                else return BadRequest("operation fail");
            }
            catch(Exception ex)
            {
               return BadRequest(ex.Message);
            }            

        }
        [HttpGet("termination")]
        public async Task<ActionResult<IEnumerable<object>>> GetTermination([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VContractTermination
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search)) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               )
                               .OrderByDescending(x=>x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VContractTermination
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }
        [HttpGet("termination/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetTerminationById(int id)
        {
            var data = await _context.VContractTermination.SingleOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.contracts_terminations", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("termination/add")]
        public async Task<ActionResult<ContractsTerminations>> TerminationAdd(ContractsTerminations data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {
                            var contract_terminate = _context.ContractsTerminations.AsNoTracking().FirstOrDefault(x => x.ContractId == data.ContractId && x.RecStatus <= 2 && x.Status == 1);
                            if (contract_terminate != null)
                            {
                                return BadRequest("Contract termination already exist, but not yet approved");
                            }

                            if (data.TerminationType == 2 && data.HouseIdTransfer != null)
                            {
                                var contract_transfer = _context.Contracts.SingleOrDefault(x => x.HouseId == data.HouseIdTransfer && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                                data.ContractIdTransfer = contract_transfer.Id;
                            }
                            //if (contracts == null) return BadRequest("Contract Id not available");                

                            data.Status = 1;

                            CrudLib<ContractsTerminations> crud = new CrudLib<ContractsTerminations>(_context, _userIdentity.Id);
                            data = (ContractsTerminations)await crud.Add(data, "dbo.contracts_terminations", true, "contract termination");

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_termination_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log contract termination can not saved!");
                            dbContextTransaction.Commit();

                            return data;
                    }
                    catch (Exception ex)
                    {
                           dbContextTransaction.Rollback(); 
                           return BadRequest(ex.Message);
                    }
            }
        }

        [HttpPost("termination/update")]
        public async Task<ActionResult<ContractsTerminations>> TerminationUpdate(ContractsTerminations data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                    try
                    {
                        var termination = _context.ContractsTerminations.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                        if (termination == null) return BadRequest("Contract Termination Id not available");

                        if (data.TerminationType == 2 && data.HouseIdTransfer != null)
                        {
                            var contract_transfer = _context.Contracts.AsNoTracking().SingleOrDefault(x => x.HouseId == data.HouseIdTransfer && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                            data.ContractIdTransfer = contract_transfer.Id;
                        }

                        data.Status = 1;
                        CrudLib<ContractsTerminations> crud = new CrudLib<ContractsTerminations>(_context, _userIdentity.Id);
                        data = (ContractsTerminations)await crud.Update(data);
                        
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[contracts_termination_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log contract termination can not saved!");
                        dbContextTransaction.Commit();
                        return data;
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
        }

        [HttpGet("termination/addon-project/{contracts_terminations_id}")]
        public async Task<ActionResult<object>> GetTerminationAddonProjectByContractTerminationId(int contracts_terminations_id)
        {

            return await _context.VContractTerminationAddon.AsNoTracking().Where(x => x.ContractsTerminationsId == contracts_terminations_id && x.Status == 1).ToListAsync();

            // return await _context.ReschedulesSubterm.ToListAsync();
        }

        [HttpPost("termination/addon-project/add")]
        public async Task<ActionResult<ContractsTerminationsAddonProject>> TerminationAddonProjectAdd(ContractsTerminationsAddonProject data)
        {
            try
            {
                var contracts_termination = _context.ContractsTerminations
                    .SingleOrDefault(x => x.Id == data.ContractsTerminationsId && x.Status == 1);
                if (contracts_termination == null) return BadRequest("Contract Termination not available");

                data.Status = 1;
                _context.ContractsTerminationsAddonProject.Add(data);
                await _context.SaveChangesAsync();

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("termination/addon-project/update")]
        public async Task<ActionResult<ContractsTerminationsAddonProject>> TerminationAddonProjectUpdate(ContractsTerminationsAddonProject data)
        {
            try
            {
                var contracts_termination_addon = _context.ContractsTerminationsAddonProject.AsNoTracking().SingleOrDefault(x => x.Id == data.Id && x.Status == 1);
                if (contracts_termination_addon == null) return BadRequest("Contract Termination addon project is not available");

                data.Status = 1;
                _context.Entry(data).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("termination/addon-project/delete")]
        public async Task<ActionResult<ContractsTerminationsAddonProject>> TerminationAddonProjectDelete(ContractsTerminationsAddonProject data)
        {
            try
            {
                var contracts_termination_addon = _context.ContractsTerminationsAddonProject.SingleOrDefault(x => x.Id == data.Id && x.Status == 1);
                if (contracts_termination_addon == null) return BadRequest("Contract Termination addon project is not available");

                contracts_termination_addon.Status = 0;
                await _context.SaveChangesAsync();
                return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("houses/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> ContractHouseByProjectId(int proId)
        {
            var contract = await _context.VContractsHouse.
                Where(x =>x.ProjectId == proId && x.RecStatus == 3).ToListAsync();
            if (contract != null) return Ok(contract);
            else return BadRequest("Invalid project id");
        }

        [HttpGet("houses-collection/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> ContractHouseCollectionByProjectId(int proId)
        {
            var contract = await _context.VContractsHouse.
                Where(x => x.ProjectId == proId && (x.RecStatus == 3 || x.RecStatus == 2 )).ToListAsync();
            if (contract != null) return Ok(contract);
            else return BadRequest("Invalid project id");
        }

        [HttpGet("houses-termination/project/{proId}")]
        public async Task<ActionResult<IEnumerable<object>>> ContractHouseTerminationByProjectId(int proId)
        {
            var result = await _context.VContractsHouse.FromSqlRaw("exec dbo.get_house_termination_by_project_id {0}", proId).ToListAsync();
            return result;
        }

        [HttpGet("paid-report")]
        public async Task<ActionResult<IEnumerable<object>>> GetContractsPaidReport([FromQuery] BookingPaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            /*string criteria = " and t1.booking_date>='";
            if (filter.expire == 0) criteria += " and t1.expire_date>=GETDATE() and (t1.rec_status<=2)"; //get pay
            else if (filter.expire == 1) criteria += "​​ and t1.expire_date<GETDATE() and (t1.rec_status<=2 )"; //no pay and expired
            else criteria += "​​ and t1.rec_status=3"; //paid 

            string sql = @" select t1.*
                            from dbo.v_bookings_full_join t1
                            inner join dbo.users_to_projects t2 
                                on t1.project_id = t2.project_id where t2.user_id = {0}" + criteria; 
            
              .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == validFilter.Search) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)
                               ))*/

            string sql = "exec dbo.contract_paid_unpaid {0},{1}";

            var vcontract = _context.VContractTracking
                               .FromSqlRaw(sql, filter.expire, filter.Search).AsEnumerable();

            validFilter.TotalRecords = vcontract.Count();
            var pagedData = vcontract.OrderByDescending(x => x.ContractDate)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();


            /*  var pagedData = _context.VContractTracking
                                 .FromSqlRaw("exec dbo.contract_paid_unpaid {0},{1}", filter.expire, filter.Search).AsEnumerable()
                                 .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                 .Take(validFilter.PageSize)
                                 .Select(x => new
                                 {
                                     x.ContractId,
                                     x.ProjectShort,
                                     x.HouseId,
                                     x.HouseNumber,
                                     x.Cus1NameKh,
                                     x.Cus1MobilePhone,
                                     x.Cus2NameKh,
                                     x.Cus2MobilePhone,
                                     x.ContractAmount,
                                     x.ContractDate,
                                     x.InitialPayment,
                                     x.StaffName,
                                     x.CreatedAt,
                                     x.RecStatus
                                 })
                                 .OrderByDescending(x => x.ContractDate)
                                 .ToList();

              validFilter.TotalRecords =
                   _context.VContractTracking.FromSqlRaw("exec dbo.contract_paid_unpaid {0}", filter.expire).AsEnumerable().Count(); */

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

    }
}
