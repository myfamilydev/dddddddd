﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/directsalers")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class DirectSalersController : Controller
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public DirectSalersController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            //if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DirectSalers>>> GetDirectSale()
        {
            return await _context.DirectSalers.Where(x=>x.Status==1).ToListAsync();
        }

        [HttpGet("paging")]
        public async Task<ActionResult<IEnumerable<object>>> GetDirectSalePaging([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = _context.DirectSalers
                                .Where(x => (String.IsNullOrEmpty(filter.Search) || 
                                            (x.Fullname.Contains(validFilter.Search) || x.Phone.Contains(x.Phone))
                                       ))
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .OrderByDescending(x => x.Id)
                                .ToList();

            validFilter.TotalRecords =
                await _context.DirectSalers
                              .Where(x => (String.IsNullOrEmpty(filter.Search) ||
                                            (x.Fullname.Contains(validFilter.Search) || x.Phone.Contains(x.Phone))
                                    )).CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<DirectSalers>> GetDirectSaleById(int id)
        {

            var data = await _context.DirectSalers.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null) return BadRequest("Invalid direct sale id");
            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<DirectSalers>> AddDirectSale(DirectSalers data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                            try
                            {
                                data.CreatedAt = DateTime.Now;
                                data.CreatedBy = _userIdentity.Id;
                                data.Status = 1;

                                _context.DirectSalers.Add(data);
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[direct_sale_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log direct sale can not saved!");
                                dbContextTransaction.Commit();

                                return data;

                            }
                            catch (Exception ex)
                            {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                            }
                }

        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateDirectSale(DirectSalers data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                            try
                            {

                                var directsale = _context.DirectSalers.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                                if (directsale == null) return BadRequest("Direct sale id not found");

                                data.Status = 1;
                                data.UpdatedAt = DateTime.Now;
                                data.UpdatedBy = _userIdentity.Id;

                                _context.Entry(data).State = EntityState.Modified;
                                _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                                _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                                await _context.SaveChangesAsync();

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[direct_sale_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log direct sale can not updated!");
                                dbContextTransaction.Commit();
                                return Ok();

                            }
                            catch (Exception ex)
                            {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                            }
                }
                        
        }


        [HttpPost("delete")]
        public async Task<IActionResult> DeleteDirectSale(DirectSalers data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var directsale = await _context.DirectSalers.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (directsale == null) return BadRequest("Invalid direct sale id");

                            directsale.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[direct_sale_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log direct sale can not deleted!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }       
            
        }


        [HttpGet("permission/check")]
        public async Task<object> GetSalerPermission()
        {
            string sql = "exec [dbo].[sp_sale_access_permission] @result={0} out";           
            var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
            await _context.Database.ExecuteSqlRawAsync(sql, result);
            return new { permission = result.Value };

        }

        [HttpGet("permission/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetSaleAccessPermissionBasic()
        {
            var pagedData = await _context.SaleAccessPermission.Where(x=>x.IsRemoved==false)
                                    .Select(x => new
                                    {
                                        x.Id,
                                        x.DateFrom,
                                        x.DateTo,
                                        x.Remark
                                    }).OrderByDescending(x=>x.Id)
                                    .ToListAsync();

            return Ok(pagedData);

        }

        [HttpGet("permission/{id}")]
        public async Task<ActionResult<SaleAccessPermission>> GetSaleAccessPermission(int id)
        {
            var data = await _context.SaleAccessPermission.SingleOrDefaultAsync(x => x.Id == id && x.IsRemoved == false);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("permission/add")]
        public async Task<ActionResult<SaleAccessPermission>> AddSaleAccessPermission(SaleAccessPermission data)
        {

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _userIdentity.Id;
            try
            {
                _context.SaleAccessPermission.Add(data);
                await _context.SaveChangesAsync();
                return data;

            }
            catch
            {

            }

            return StatusCode(StatusCodes.Status500InternalServerError);
        }

        [HttpPost("permission/update")]
        public async Task<IActionResult> UpdateSaleAccessPermission(SaleAccessPermission data)
        {

            var user_exists = _context.SaleAccessPermission.AsNoTracking().SingleOrDefault(x => x.Id == data.Id  && x.IsRemoved==false);

            if (user_exists == null)
            {
                return BadRequest("Data not found");
            }

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _userIdentity.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.IsRemoved).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            return Ok();
        }
        [HttpPost("permission/delete")]
        public async Task<IActionResult> DeleteSaleAccessPermission(SaleAccessPermission data)
        {

            var user_exists = _context.SaleAccessPermission.SingleOrDefault(x => x.Id == data.Id && x.IsRemoved==false);
            if (user_exists == null)
            {
                return BadRequest("Data not found");
            }
            try
            {
                user_exists.IsRemoved = true;
                user_exists.UpdatedAt = DateTime.Now;
                user_exists.UpdatedBy = _userIdentity.Id;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            return Ok();
        }

        [HttpGet("commission")]
        public async Task<ActionResult<object>> GetCommissionById([FromQuery] PaginationFilter filter)
        {

            //return await new CrudLib<VCommissionRequest>(_userIdentity.Id).GetDataProHouse(filter);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = _context.VCommissionRequest
                                .Where(x => (String.IsNullOrEmpty(filter.Search) ||
                                            (x.Fullname.StartsWith(validFilter.Search)))
                                 )
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .OrderByDescending(x => x.Id)
                                .ToList();

            validFilter.TotalRecords =
                await _context.VCommissionRequest
                    .Where(x => (String.IsNullOrEmpty(filter.Search) ||
                                            (x.Fullname.StartsWith(validFilter.Search)))
                                 )
                    .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("commission/{commission_id}")]
        public async Task<ActionResult<WorkflowModel>> GetCommissionPagination(int commission_id)
        {
            // return await _context.CommissionRequest.Where(x => x.Id == commission_id && x.Status==1).AsNoTracking().ToListAsync();
            var data = await _context.CommissionRequest.AsNoTracking().SingleOrDefaultAsync(x => x.Id == commission_id && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.commission_request", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("commission/approved/{id}")]
        public async Task<ActionResult> CommissionApprove(int id)
        {
            var public_service = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_commission_approved {0},{1}", id, _userIdentity.Id);
            if (public_service == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpPost("commission/add")]
        public async Task<ActionResult<object>> AddCommissionRequest(CommissionRequest data)
        {

            try
            {

                //var saleinfo =await _context.DirectSalers.SingleOrDefaultAsync(x => x.Id == data.DirectSaleId && x.Status == 1);
                //if (saleinfo == null) return BadRequest("There is no sale information");
                //check commission detail
                var commission_tmp = await _context.CommissionRequestDetailTmp.FirstOrDefaultAsync(x => x.UserId == _userIdentity.Id && x.DirectSaleId == data.DirectSaleId);
                if (commission_tmp == null) return BadRequest("There is no commission for selected sale!");


                data.RequestDate = DateTime.Now;
                data.Status = 1;
                CrudLib<CommissionRequest> crud = new CrudLib<CommissionRequest>(_context, _userIdentity.Id);
                data = (CommissionRequest)await crud.Add(data, "dbo.commission_request");
                //prepare save detail
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_add_commission_request_detail {0},{1}", data.Id, _userIdentity.Id);
                //tran.Complete();
                return data;


            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("commission/update")]
        public async Task<ActionResult<object>> UpdateCommissionRequest(CommissionRequest data)
        {

            try
            {

                var commission = await _context.CommissionRequest.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.RecStatus == 1 && x.Status == 1);
                if (commission == null)
                {
                    return BadRequest("Commission is not available!");
                }


                var commission_tmp = await _context.CommissionRequestDetailTmp.FirstOrDefaultAsync(x => x.UserId == _userIdentity.Id && x.DirectSaleId == data.DirectSaleId);
                if (commission_tmp == null) return BadRequest("There is no commission for selected sale!");

                data.RequestDate = DateTime.Now;
                data.Status = 1;
                CrudLib<CommissionRequest> crud = new CrudLib<CommissionRequest>(_context, _userIdentity.Id);
                data = (CommissionRequest)await crud.Update(data);
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_add_commission_request_detail {0},{1}", data.Id, _userIdentity.Id);

                // tran.Complete();
                return Ok();


            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("commission/delete")]
        public async Task<ActionResult<object>> DeleteCommissionRequest(CommissionRequest data)
        {

            try
            {

                var commission = await _context.CommissionRequest.FirstOrDefaultAsync(x => x.Id == data.Id && x.RecStatus == 0 && x.Status == 1);
                if (commission == null)
                {
                    return BadRequest("Commission is not available!");
                }

                commission.Status = 0;
                await _context.SaveChangesAsync();
                return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("commission/detail/{commission_request_id}")]
        public async Task<ActionResult<object>> GetCommissionDetail(int commission_request_id)
        {
            return await _context.CommissionRequestDetail.Where(x => x.CommissionRequestId == commission_request_id)
                .AsNoTracking()
                .OrderBy(x => x.DirectSaleName).ThenBy(x => x.BookingDate)
                .ToListAsync();
        }

        [HttpGet("commission/generate/{project_id}/{direct_sale_id}")]
        public async Task<ActionResult<object>> GetCommissionDetailGenerate(int project_id, int direct_sale_id)
        {
            return _context.CommissionRequestDetailTmp.FromSqlRaw("exec dbo.get_commission_request_detail {0},{1},{2}", _userIdentity.Id, project_id, direct_sale_id).AsEnumerable().ToList();
        }

        [HttpGet("customer/walk-in")]
        public async Task<ActionResult<IEnumerable<object>>> GetCustomerWalkInPaging([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_customer_walk_in_filter {0},{1},{2}";

            var data = _context.VCustomerWalkIn
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("customer/walk-in/project")]
        public async Task<ActionResult<IEnumerable<VCustomerWalkInProject>>> GetProjectsCustomerWalkIn()
        {
            return await _context.VCustomerWalkInProject.ToListAsync();
        }

        [HttpGet("customer/walk-in/{id}")]
        public async Task<ActionResult<CustomerWalkIn>> GetCustomerWalkInById(int id)
        {

            var data = await _context.CustomerWalkIn.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid customer walk-in");
            return data;
        }

        [HttpPost("customer/walk-in/add")]
        public async Task<ActionResult<CustomerWalkIn>> AddCustomerWalkIn(CustomerWalkIn data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.Status = 1;

                    _context.CustomerWalkIn.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customer_walk_in_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log customer walk-in can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("customer/walk-in/update")]
        public async Task<IActionResult> UpdateCustomerWalkIn(CustomerWalkIn data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var walkIn = _context.CustomerWalkIn.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                    if (walkIn == null) return BadRequest("Customer walk-in not found");

                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customer_walk_in_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log walk-in have problem!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }


        [HttpPost("customer/walk-in/delete")]
        public async Task<IActionResult> DeleteCustomerWalkIn(CustomerWalkIn data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    var walkIn = await _context.CustomerWalkIn.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                    if (walkIn == null) return BadRequest("Invalid customer walk-in");

                    walkIn.Status = 0;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[customer_walk_in_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log customer walk-in have problem!");
                    dbContextTransaction.Commit();

                    return Ok();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpGet("calling")]
        public async Task<ActionResult<IEnumerable<object>>> GetCallingPaging([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_sale_calling_filter {0},{1},{2}";

            var data = _context.VSaleCallingFilter
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("calling/{id}")]
        public async Task<ActionResult<VSaleCalling>> GetCallingById(int id)
        {

            var data = await _context.VSaleCalling.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid calling request");
            return data;
        }

        [HttpPost("calling/add")]
        public async Task<ActionResult<SaleCalling>> AddCalling(SaleCalling data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.Status = 1;

                    _context.SaleCalling.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_calling_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log calling request can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("calling/update")]
        public async Task<IActionResult> UpdateCalling(SaleCalling data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var walkIn = _context.SaleCalling.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                    if (walkIn == null) return BadRequest("calling request not found");

                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_calling_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log sale calling have problem!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("complaint/request")]
        public async Task<ActionResult<IEnumerable<object>>> GetComplaintRequest([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_sale_complaint_request_filter {0},{1},{2}";

            var data = _context.VSaleComplaintRequestFilter
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("complaint/request/{id}")]
        public async Task<ActionResult<VSaleComplaintRequest>> GetComplaintRequestById(int id)
        {

            var data = await _context.VSaleComplaintRequest.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid complain request");
            return data;
        }

        [HttpPost("complaint/request/add")]
        public async Task<ActionResult<SaleComplaintRequest>> AddComplaintRequest(SaleComplaintRequest data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.Status = 1;

                    _context.SaleComplaintRequest.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_complaint_request_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log complaint request can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("complaint/request/update")]
        public async Task<IActionResult> UpdateComplaintRequest(SaleComplaintRequest data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var walkIn = _context.SaleComplaintRequest.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                    if (walkIn == null) return BadRequest("complaint request not found");

                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_complaint_request_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log complaint request have problem!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }


        [HttpGet("permission/request")]
        public async Task<ActionResult<IEnumerable<object>>> GetpermissionRequest([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_sale_permission_request_filter {0},{1},{2}";

            var data = _context.VSalePermissionRequestFilter
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("permission/request/{id}")]
        public async Task<ActionResult<VSalePermissionRequest>> GetpermissionRequestById(int id)
        {

            var data = await _context.VSalePermissionRequest.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid permission request");
            return data;
        }

        [HttpPost("permission/request/add")]
        public async Task<ActionResult<SalePermissionRequest>> AddPermissionRequest(SalePermissionRequest data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.Status = 1;

                    _context.SalePermissionRequest.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_permission_request_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log permission request can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("permission/request/update")]
        public async Task<IActionResult> UpdatePermissionRequest(SalePermissionRequest data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var walkIn = _context.SalePermissionRequest.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                    if (walkIn == null) return BadRequest("permission request not found");

                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_permission_request_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log permission request problem!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("planting/request")]
        public async Task<ActionResult<IEnumerable<object>>> GetPlantingRequest([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_sale_planting_request_filter {0},{1},{2}";

            var data = _context.VSalePlantingRequestFilter
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("planting/request/{id}")]
        public async Task<ActionResult<VSalePlantingRequest>> GetPlantingRequestById(int id)
        {

            var data = await _context.VSalePlantingRequest.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null) return BadRequest("Invalid plainting request");
            return data;
        }

        [HttpPost("planting/request/add")]
        public async Task<ActionResult<SalePlantingRequest>> AddPlantingRequest(SalePlantingRequest data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.Status = 1;

                    _context.SalePlantingRequest.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_planting_request_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log plainting request can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("planting/request/update")]
        public async Task<IActionResult> UpdatePlantingRequest(SalePlantingRequest data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var walkIn = _context.SalePlantingRequest.AsNoTracking().SingleOrDefault(x => x.Id == data.Id);
                    if (walkIn == null) return BadRequest("Plainting request not found!");

                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[sale_planting_request_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log plainting request have problem!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }


    }
}
