﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Models;
using Library.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/attachments")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class AttachmentsController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public AttachmentsController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;
            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity= new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AttachmentsModel>>> GetAttachments()
        {
            using (var _manualCtx = new ManualDbContext())
            {
                string sql = @" select File_UUID,FILE_NAME,FILE_EXT,FILE_SIZE,FILE_REF,FILE_REF_ID,CREATED_AT,CREATED_BY
                            from dbo.attachments where status=1";

                return await _manualCtx.AttachmentsModel.FromSqlRaw(sql).AsNoTracking().ToListAsync();
            }
        }

        [HttpGet("download/{fileUuId}")]
        public async Task<FileContentResult> GetAttachments(Guid fileUuId)
        {
            ClsAttachment att = new ClsAttachment(_context);
            return await att.DownloadAttachFileAsync(fileUuId);
        }
        [HttpGet("image/{fileUuId}")]
        public async Task<string> GetImageData(Guid fileUuId)
        {
            ClsAttachment att = new ClsAttachment(_context);
            return await att.ReadAttachFileAsync(fileUuId);
        }
        [HttpGet("{file_ref}/{file_ref_id}")]
        public async Task<ActionResult<IEnumerable<AttachmentsModel>>> GetAttachmentsByRefId(string file_ref, int file_ref_id)
        {
            using (var _manualCtx = new ManualDbContext())
            {
                string sql = @" select File_UUID,FILE_NAME,FILE_EXT,FILE_SIZE,FILE_REF,FILE_REF_ID,CREATED_AT,CREATED_BY
                            from dbo.attachments
                            where status=1 and FILE_REF = {0}
                            and FILE_REF_ID = {1}";

                return await _manualCtx.AttachmentsModel.FromSqlRaw(sql, file_ref, file_ref_id).AsNoTracking().ToListAsync();
            }
        }

        [HttpPost("upload/{file_ref}/{file_ref_id}")]
        public async Task<IActionResult> UploadFile(IFormFile file, string file_ref, int file_ref_id)
        {
            var fullname = User.Identity.Name;
            ClsAttachment att = new Library.Class.ClsAttachment(_context);
            await att.SaveBinaryFileAsync(file_ref, file_ref_id, file, fullname);

            return Ok("Record have been saved");

        }

        [HttpPost("delete")]
        public async Task<IActionResult> DeleteAttachments(Attachments attachments)
        {
            var Attachments = await _context.Attachments.SingleOrDefaultAsync(x => x.FileUuid == attachments.FileUuid && x.Status==1);
            if (Attachments == null)
            {
                return NotFound();
            }

            attachments.Status = 0;
            //_context.Attachments.Remove(Attachments);
            await _context.SaveChangesAsync();

            return Ok("Record have been deleted");
        }

        private bool AttachmentsExists(Guid fileUuId)
        {
            return _context.Attachments.Any(e => e.FileUuid == fileUuId && e.Status==1);
        }

    }
}
