﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Entities.Customize;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/export")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class OfficeExportController : Controller
    {

        private readonly ARContext _arcontext;
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public OfficeExportController(ARContext arcontext, MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {           
            _httpContextAccessor = httpContextAccessor;
            _arcontext = arcontext;
            _context = context;
            _config = config;

            //if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }
        [HttpGet("final-payment-request/{id}")]
        public object FinalPaymentRequest(int id)
        {
            var info = _arcontext.FinalPaymentInfo.FromSqlRaw("exec ar.get_final_payment_info {0}", id).AsEnumerable().SingleOrDefault();
            var contract_ref = _arcontext.ContractReferences.FromSqlRaw("exec ar.get_contract_reference {0}", id).AsEnumerable().ToList();
            return new { finalInfo=info, ContractRef = contract_ref }; 
        }


    }
}
