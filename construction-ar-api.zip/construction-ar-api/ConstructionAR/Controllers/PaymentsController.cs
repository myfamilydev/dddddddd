﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using RestSharp;
using Newtonsoft.Json;
using Web.Parameters;
using System.Data;
using DataAccess.Entities.Customize;
using System.Transactions;

namespace Web.Controllers
{
    [Route("api/v1/payments")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class PaymentsController : ControllerBase
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public PaymentsController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
           
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;


            //if ( _httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet("terms-special")]
        public async Task<ActionResult<object>> PaymentTermSpecial([FromQuery] PaginationFilter filter)
        {

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_payment_terms_special_filter {0},{1},{2}";

            var terms = _context.VPaymentTermsSpecial
                               .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = terms.Count();

            var pagedData = terms.OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
            //return await new CrudLib<VPaymentTermsSpecial>(_userIdentity.Id).GetDataPro(filter);

        }

        [HttpGet("terms-special/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetHousePriceById(int id)
        {

            var data = await _context.PaymentTerms.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null) return BadRequest("Invalid payment term id");

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.payment_terms", data.Id, _userIdentity.Id, 1);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("terms-special/add")]
        public async Task<ActionResult<PaymentTerms>> PaymentTermSpecialAdd(PaymentTerms data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                            try
                            {

                                var payment_term = _context.PaymentTerms.AsNoTracking().FirstOrDefault(x => x.HouseId == data.HouseId && x.InType == 1 && x.RecStatus <= 2 && x.Status == 1);
                                if (payment_term != null)
                                {
                                    return BadRequest("Payment term-special already exist, but not yet approved!");
                                }
                                data.Status = 1;
                                data.HouseCateId = null;
                                data.InType = 1;
                                data.RecStatus = 0;
                                CrudLib<PaymentTerms> crud = new CrudLib<PaymentTerms>(_context, _userIdentity.Id);
                                data = (PaymentTerms)await crud.Add(data, "dbo.payment_terms", true, "create payment term");
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.save_payment_term_rule {0},{1}", data.Id, _userIdentity.Id);

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_term_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log special payment term can not saved!");
                                dbContextTransaction.Commit();
                                return data;

                            }
                            catch (Exception ex)
                            {
                                dbContextTransaction.Rollback();
                                return BadRequest(ex.Message);
                            }
                }
        }
              

        [HttpPost("terms-special/update")]
        public async Task<IActionResult> PaymentTermSpecialUpdate(PaymentTerms data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var payment = await _context.PaymentTerms.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == 0);
                            if (payment == null) return BadRequest("Invalid PaymentTermId");
                            data.Status = 1;
                            data.RuleNo = payment.RuleNo;
                            data.HouseCateId = payment.HouseCateId;
                            data.InType = payment.InType;
                            data.RecStatus = 0;
                            CrudLib<PaymentTerms> crud = new CrudLib<PaymentTerms>(_context, _userIdentity.Id);
                            await crud.Update(data, "dbo.payment_terms");

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_term_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log special payment term can not updated!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpGet("terms")]
        public async Task<ActionResult<object>> TermGet([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_payment_terms_filter {0},{1},{2}";

            var terms = _context.VPaymentTerms
                               .FromSqlRaw(sql,_userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = terms.Count();

            var pagedData = terms.OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
            //return await new CrudLib<VPaymentTerms>(_userIdentity.Id).GetDataPro(filter);
        }

        [HttpGet("terms/{id}")]
        public async Task<ActionResult<WorkflowModel>> Get(int id)
        {

            var data = await _context.PaymentTerms.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.payment_terms", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;

        }

        [HttpPost("terms/add")]
        public async Task<ActionResult<PaymentTerms>> PaymentTermAdd(PaymentTerms data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                    try
                    {
                        data.Status = 1;
                        data.HouseId = null;
                        data.BookingId = null;
                        data.InType = 0;
                        data.RecStatus = 0;

                        CrudLib<PaymentTerms> crud = new CrudLib<PaymentTerms>(_context, _userIdentity.Id);
                        data = (PaymentTerms)await crud.Add(data, "dbo.payment_terms", true, "create payment term");
                        var myresult= await _context.Database.ExecuteSqlRawAsync("exec dbo.save_payment_term_rule {0},{1}", data.Id, _userIdentity.Id);
                        if (myresult != -1) throw new Exception("Can not save payment term rule!");

                        //save to audit log
                        var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_term_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                        if (result != -1) throw new Exception("Log payment term can not saved!");
                        dbContextTransaction.Commit();

                        return data;
                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        return BadRequest(ex.Message);
                    }
            }
        }

        [HttpPost("terms/update")]
        public async Task<IActionResult> UpdateHouses(PaymentTerms data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            var payment = await _context.PaymentTerms.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == 0);
                            if (payment == null) return BadRequest("Invalid PaymentTermId");
                            data.Status = 1;
                            data.HouseId = payment.HouseId;
                            data.BookingId = payment.BookingId;
                            data.InType = payment.InType;
                            data.RuleNo = payment.RuleNo;
                            CrudLib<PaymentTerms> crud = new CrudLib<PaymentTerms>(_context, _userIdentity.Id);
                            await crud.Update(data, "dbo.payment_terms");

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_term_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log payment term can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("terms/delete")]
        public async Task<IActionResult> DeleteHouses(DeleteModel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            var data_delete = await _context.PaymentTerms.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (data_delete == null)
                            {
                                return BadRequest("No, payment term can not be deleted!");
                            }

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_term_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log payment term can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpGet("terms/{id}/items")]
        public async Task<ActionResult<IEnumerable<PaymentTermsItems>>> GetItems(int id)
        {
            var data = await _context.PaymentTermsItems.Where(x => x.PaymentTermId == id && x.Status==1).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("terms/items/{itemid}")]
        public async Task<ActionResult<PaymentTermsItems>> GetItems(int id, int itemid)
        {
            var data = await _context.PaymentTermsItems.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==itemid && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("terms/house/{house_id}")]
        public async Task<ActionResult<PaymentTerms>> GetPaymentTermByHouseId(int house_id)
        {
            try
            {
                var result = await _context.PaymentTerms.FromSqlRaw("exec dbo.get_payment_term_by_houseid {0}", house_id).ToListAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("terms-interest/items/{id}")]
        public async Task<ActionResult<PaymentTermsItems>> GetItemsInterest(int id)
        {

            var data = await _context.PaymentTermsItems.AsNoTracking().FirstOrDefaultAsync(x => x.PaymentTermId == id && x.Status==1 && x.InterestPercentMonth > 0);
            if (data == null)
            {
                return BadRequest("There is no payment term item for this id");
            }
            return data;
        }

        [HttpPost("terms/items/add")]
        public async Task<ActionResult<object>> AddPaymentTermsItems(PaymentTermsItems data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {

                            if (!_context.PaymentTerms.Where(x => x.Id == data.PaymentTermId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT).Any())
                            {
                                return BadRequest(new ApiResponse("failed", "Payment Term status not allow to edit"));
                            }

                            data.Status = 1;
                            CrudLib<PaymentTermsItems> crud = new CrudLib<PaymentTermsItems>(_context, _userIdentity.Id);
                            data = (PaymentTermsItems)await crud.Add(data);

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_terms_items_log] {0},{1},{2}", data.Id, "Add Subterm", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log payment term subitem can not saved!");
                            dbContextTransaction.Commit();

                            return data;
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpPost("terms/items/delete")]
        public async Task<IActionResult> RemovePaymentTermsItems(PaymentTermsItems data)
        {
                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var data_delete = await _context.PaymentTermsItems.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (data_delete == null) return BadRequest("No, payment term can not be deleted!");

                            var payment_term = await _context.PaymentTerms.SingleOrDefaultAsync(x => x.Id == data_delete.PaymentTermId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);
                            if (payment_term == null) return BadRequest(new ApiResponse("failed", "Payment Term status not draft"));

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[payment_terms_items_log] {0},{1},{2}", data.Id, "Delete Subterm", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log payment term subitem can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        //Penalties
        [HttpGet("penalties")]
        public async Task<ActionResult<object>> GetPenalties([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<Penalties>(_context, _userIdentity.Id).GetDataPro(filter);
        }

        [HttpGet("penalties/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetPenalties(int id)
        {

            var data = await _context.Penalties.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.penalties", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("penalties/add")]
        public async Task<ActionResult<Penalties>> PenaltiesAdd(Penalties data)
        {
            try
            {
                CrudLib<Penalties> crud = new CrudLib<Penalties>(_context, _userIdentity.Id);
                data = (Penalties)await crud.Add(data, "dbo.penalties", true, "create penalty");

                return data;
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("penalties/update")]
        public async Task<IActionResult> PenaltiesUpdate(Penalties data)
        {
            try
            {
                CrudLib<Penalties> crud = new CrudLib<Penalties>(_context, _userIdentity.Id);
                await crud.Update(data, "dbo.penalties");

                return Ok();
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("penalties/delete")]
        public async Task<IActionResult> PenaltiesDelete(DeleteModel data)
        {
            var data_delete = _context.Penalties.SingleOrDefault(x => x.Id == data.Id && x.RecStatus == WorkflowStatusModel.DRAFT);

            if (data_delete == null)
            {
                return BadRequest("No, payment term can not be deleted!");
            }

            _context.Penalties.Remove(data_delete);

            var data_rule_delete = _context.PenaltiesRules.Where(x => x.PenaltyId == data_delete.Id).ToList<PenaltiesRules>();
            _context.PenaltiesRules.RemoveRange(data_rule_delete);

            if (data_delete == null)
            {
                return BadRequest("No, penaly rule can not be deleted!");
            }

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NoContent();
            }
        }

        [HttpGet("penalties/rules")]
        public async Task<ActionResult<IEnumerable<PenaltiesRules>>> PenaltiesRuleGet([FromQuery] PaginationFilter filter)
        {
            var data = await _context.PenaltiesRules
                               .Skip((filter.PageNumber - 1) * filter.PageSize)
                               .Take(filter.PageSize)
                               .ToListAsync();

            return data;
        }

        [HttpGet("penalties/{id}/rules")]
        public async Task<ActionResult<IEnumerable<PenaltiesRules>>> PenaltiesRuleGet(int id)
        {
            var data = await _context.PenaltiesRules.Where(x => x.PenaltyId == id).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("penalties/rules/{id}")]
        public async Task<ActionResult<PenaltiesRules>> PenaltiesRuleGetDetail(int id)
        {
            var data = await _context.PenaltiesRules.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("penalties/rules/add")]
        public async Task<ActionResult<object>> PenaltiesRuleAdd(PenaltiesRules data)
        {

            if (!_context.Penalties.Where(x => x.Id == data.PenaltyId && x.RecStatus == WorkflowStatusModel.DRAFT).Any())
            {
                return BadRequest(new ApiResponse("failed", "Penalties status not allow to edit"));
            }

            try
            {
                CrudLib<PenaltiesRules> crud = new CrudLib<PenaltiesRules>(_context, _userIdentity.Id);
                data = (PenaltiesRules)await crud.Add(data);

                return data;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("penalties/rules/delete")]
        public async Task<IActionResult> PenaltiesRuleRemove(DeleteModel data)
        {

            var data_delete = await _context.PenaltiesRules.FindAsync(data.Id);            

            if (data_delete == null)
            {
                return BadRequest("No, penalty rule can not be deleted!");
            }

            if (!_context.Penalties.Where(x => x.Id == data_delete.PenaltyId && x.RecStatus == WorkflowStatusModel.DRAFT).Any())
            {
                return BadRequest(new ApiResponse("failed", "Penalties status not allow to edit"));
            }

            _context.PenaltiesRules.Remove(data_delete);

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        //Penalties
        [HttpGet("collection/methods")]
        public async Task<ActionResult<object>> GetCollectionMethods([FromQuery] PaginationFilter filter)
        {            
            return await new CrudLib<CollectionMethods>(_context, _userIdentity.Id).GetDataPro(filter);
        }

        [HttpGet("collection/methods_1")]
        public async Task<ActionResult<object>> GetCollectionMethods_1([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_collection_method_filter {0},{1},{2}";

            var data = _context.VCollectionMethodFilter
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable().ToList();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("collection/methods/{id}")]
        public async Task<ActionResult<CollectionMethods>> GetCollectionMethods(int id)
        {

            var data = await _context.CollectionMethods.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && (x.Status==1 || x.Status == 2));
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("collection/methods/add")]
        public async Task<ActionResult<CollectionMethods>> CollectionMethodsAdd(CollectionMethods data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {
                        try
                        {
                            data.Status = 1;
                            CrudLib<CollectionMethods> crud = new CrudLib<CollectionMethods>(_context, _userIdentity.Id);
                            data = (CollectionMethods)await crud.Add(data);

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[collection_methods_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log collection method can not saved!");
                            dbContextTransaction.Commit();

                            return data;
                        }
                        catch(Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

        }

        [HttpPost("collection/methods/update")]
        public async Task<IActionResult> CollectionMethodsUpdate(CollectionMethods data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var col_method = _context.CollectionMethods.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (col_method == null) return BadRequest("Invalid collection method id");

                            data.Status = 1;
                            CrudLib<CollectionMethods> crud = new CrudLib<CollectionMethods>(_context, _userIdentity.Id);
                            await crud.Update(data);

                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[collection_methods_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log collection method can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }

        }

        [HttpPost("collection/methods/delete")]
        public async Task<IActionResult> PCollectionMethodsDelete(DeleteModel data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                        try
                        {
                            var data_delete = await _context.CollectionMethods.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                            if (data_delete == null)
                            {
                                return BadRequest("No, collection method can not deleted!");
                            }

                            data_delete.Status = 0;
                            await _context.SaveChangesAsync();
                            
                            //save to audit log
                            var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[collection_methods_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                            if (result != -1) throw new Exception("Log collection method can not deleted!");
                            dbContextTransaction.Commit();
                            return Ok();
                        }
                        catch (Exception ex)
                        {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                        }
                }
        }

        [HttpGet("transaction_types")]
        public async Task<ActionResult<object>> TransactionType()
        {
            var tran = await
                        (from t in _context.TransactionTypes
                         where t.Status == 2
                         select new { t.Id, t.TransactionName })
                       .ToListAsync();

            return tran;
            //return await _context.TransactionTypes.Where(x => x.Status == 2 || x.Status == 3).Select(x=> new { Id=Id }.ToListAsync();
        }

        [HttpPost("schedule/generate/{ContractId}")]
        [Obsolete]
        public async Task<ActionResult<object>> GeneratePaymentSchedule(int ContractId)
        {
            
            ApiResponse res = new ApiResponse();

            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_schedule_generate {0},{1}", ContractId, _userIdentity.Id);
            if (result == -1)
            {
                res.status = "success";
                res.code = "200";
                res.message = "execute successfully";
            }
            else
            {
                res.status = "fail";
                res.code = "-1";
                res.message = "operation fail";
            }
            return Ok(res);
            /* int counter = _context.PaymentSchedules.Where(x => x.ContractId == ContractId).Count();
             if (counter > 0)
             {
                 res.status = "success";
                 res.code = "200";
                 res.message = "contract already exist";
                 return Ok(res);
             }

             var contracts = await _context.Contracts.FindAsync(ContractId);

             float PropertyValue = (float)contracts.ContractAmount - (float)contracts.InitialPayment;
             int HouseId = (int)contracts.HouseId;

             var items = await _context.PaymentTermsItems.Where(x => x.PaymentTermId == contracts.PaymentTermId).ToListAsync();

             if (items == null)
             {
                 return BadRequest();
             }

             float? loanAmount = 0;
             float? remaining = PropertyValue;
             short? PaymentMonths = 0;
             int itemCount = items.Count();
             int index = 0;
             DateTime? startMonth = contracts.ContractDate;
             if (contracts.InitialPayment > 0) startMonth = startMonth?.AddMonths(1);

             foreach (var item in items)
             {
                 PaymentMonths = item.PaidOffTermMonthMax == item.PaidOffTermMonthMin ? item.PaidOffTermMonthMin : contracts.PaymentTermMonth;

                 if (item.PaidOffType.Equals("%"))
                 {
                     loanAmount = (float)(PropertyValue * (item.PaidOffAmount / 100));
                 }
                 else
                 {
                     loanAmount = item.PaidOffAmount;
                 }

                 if (++index == itemCount)
                 {
                     loanAmount = remaining;
                 }

                 string sql = "exec [dbo].[sp_Amortization360] " +
                                 " @PropertyVal = " + PropertyValue + "," +
                                 " @LoanAmount = " + loanAmount + "," +
                                 " @TermMonth = " + PaymentMonths + "," +
                                 " @InterestRateMonth = " + item.InterestPercentMonth + "," +
                                 " @StartPaymentDate = '" + startMonth.ToString() + "'," +
                                 " @contract_id = " + ContractId + "," +
                                 " @house_id = " + HouseId + "," +
                                 " @paymenttermid = " + item.Id + "," +
                                 " @user_id = " + _userIdentity.Id + "," +
                                 " @reschedule_id = null";

                 _ = _context.Database.ExecuteSqlCommand(sql);

                 startMonth = startMonth?.AddMonths((int)PaymentMonths);

                 remaining -= loanAmount;
             }

             if (remaining == 0)
             {
                 var penalty = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_booking_payment_to_schedule {0}", HouseId);
                 if (penalty == -1)
                 {
                     res.status = "success";
                     res.code = "200";
                     res.message = "success";
                 }
                 else
                 {
                     res.status = "success";
                     res.code = "200";
                     res.message = "success";
                 }

             }
             else
             {
                 if (remaining > 0)
                 {
                     res.status = "failed";
                     res.code = "400";
                     res.message = "Term payment is not completely 100%";
                 }
                 else
                 {
                     res.status = "failed";
                     res.code = "400";
                     res.message = "Principle is negative";
                 }
             }

             return Ok(res); */
        }

        [HttpGet("schedule/{contractId}")]
        public async Task<ActionResult<object>> GetRegularCollection(int contractId)
        {
            return await _context.VPaymentSchedule.Where(x => x.ContractId == contractId).OrderBy(x => x.PaymentDate).ToListAsync();
        }

        [HttpPost("schedule/{contractId}/approved")]
        public async Task<ActionResult<object>> GetPaymentSchedule(int contractId)
        {

            var schedule_info =await _context.PaymentSchedulesInfo.AsNoTracking()
                                       .OrderByDescending(x => x.Id)
                                       .FirstOrDefaultAsync(x => x.ContractId == contractId && x.Status==1);

            return await _context.PaymentSchedules.Where(x => x.PaymentScheduleInfoId == schedule_info.Id && x.Status==1)
                .Select(x => new { x.PaymentNo, x.StartBalance, x.EndBalance, x.Payment, x.Principle, x.Interest, x.PaymentDate,
                    x.AccumulatePrinciple, x.AccumulateInterest })
                .ToListAsync();
        }

        [HttpPost("schedule-generate/approved/{refId}")]
        public async Task<ActionResult<object>> PaymentScheduleApproved(int refId)
        {
            var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.schedule_approved {0},{1}", refId, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");
        }

        [HttpGet("regular/collection")]
        public async Task<ActionResult<object>> GetRegularCollection([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_regular_collection {0},{1},{2},{3}";

            var data = _context.VRegularCollection
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "", filter.option).AsEnumerable();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.OrderByDescending(x => x.CreatedAt)
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("regular/collection/{id}")]
        public async Task<ActionResult<object>> GetRegularCollectionById(int id)
        {
            var regular = _context.VRegularCollection.Where(x => x.Id == id).FirstOrDefault();

            if (regular == null)
            {
                return NoContent();
            }

            var detail = await _context.VRegularCollectionDetails.Where(x => x.RegularCollectionId == id).ToListAsync();

            object data = new
            {
                data = regular,
                detail = detail
            };

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.regular_collections", id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }
        /*
        [HttpGet("regular/collection/{id}/detail")]
        public async Task<ActionResult<object>> GetRegularCollectionDetailById(int id)
        {
            var regular = await _context.VRegularCollectionDetails.Where(x => x.RegularCollectionId == id).ToListAsync();

            return regular;
        }
        */
        [HttpPost("regular/collection/add")]
        public async Task<ActionResult<RegularCollections>> AddRegularCollection(RegularCollections data)
        {
            try
            {  

                var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1);
                if (contract == null) return BadRequest("There is no contract for this house!");


                data.Status = 1;
                data.IsMoved = 0;
                data.DueDate = DateTime.Now;
                data.PaidDate = DateTime.Now;
                data.ContractId = contract.Id;
                data.Customer1Id = contract.CurrentCustomer1Id;
                data.Customer2Id = contract.CurrentCustomer2Id;

                CrudLib<RegularCollections> crud = new CrudLib<RegularCollections>(_context, _userIdentity.Id);
                data.RecStatus = 3;
                data = (RegularCollections)await crud.Add(data, "dbo.regular_collections");

                return data;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("regular/collection/update")]
        public async Task<IActionResult> UpdateRegularCollection(RegularCollections data)
        {
            try
            {

                var collection = await _context.RegularCollections.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1);
                if (collection == null) return BadRequest("Invalid regular collection id!");

                var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1);
                if (contract == null) return BadRequest("There is no contract for this house!");

                data.Status = 1;
                data.IsMoved = 0;
                data.DueDate = DateTime.Now;
                data.PaidDate = DateTime.Now;               
                data.ContractId = contract.Id;
                data.Customer1Id = contract.CurrentCustomer1Id;
                data.Customer2Id = contract.CurrentCustomer2Id;
                data.RecStatus = 3;

                CrudLib<RegularCollections> crud = new CrudLib<RegularCollections>(_context, _userIdentity.Id);                
                await crud.Update(data, "dbo.regular_co llections");

                return Ok();
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

       /* [HttpPost("regular/collection/approved/{refId}")]
        public async Task<ActionResult<object>> RegularCollectionApproved(int refId)
        {

            ApiResponse res = new ApiResponse();

            var data_exists = _context.RegularCollections.SingleOrDefault(x => x.Id == refId && x.RecStatus == WorkflowStatusModel.APPROVED);

            if (data_exists == null)
            {
                return BadRequest("Regular Collection is not available");
            }

            try
            {
                TransactionTypesModel trans = new TransactionTypesModel();
                var detail = await _context.RegularCollectionsDetails.Where(x => x.RegularCollectionId == data_exists.Id).ToListAsync();
                foreach (var item in detail)
                {
                    if (item.TransactionTypeId == trans.PRINCIPLE)
                    {
                        var p = _context.PaymentSchedules.Find(item.RefId);
                        p.PaidPrinciple = (p.PaidPrinciple == null ? 0 : p.PaidPrinciple) + item.Amount;
                        if (p.PaidPrinciple + p.PaidInterest >= p.Payment)
                        {
                            p.RecStatus = WorkflowStatusModel.PAID;
                        }
                        item.RecStatus = WorkflowStatusModel.APPROVED;
                        await _context.SaveChangesAsync();
                    } else if (item.TransactionTypeId == trans.INTEREST)
                    {
                        var p = _context.PaymentSchedules.Find(item.RefId);
                        p.PaidInterest = (p.PaidInterest == null ? 0 : p.PaidInterest) + item.Amount;
                        if (p.PaidPrinciple + p.PaidInterest >= p.Payment)
                        {
                            p.RecStatus = WorkflowStatusModel.PAID;
                        }
                        item.RecStatus = WorkflowStatusModel.APPROVED;
                        await _context.SaveChangesAsync();
                    } else if (item.TransactionTypeId == trans.PUBLIC_SERVICE)
                    {
                        var p = _context.PublicServiceSchedules.Find(item.RefId);
                        if (p.RecStatus == WorkflowStatusModel.APPROVED)
                        {
                            p.RecStatus = WorkflowStatusModel.PAID;
                            item.RecStatus = WorkflowStatusModel.APPROVED;
                        }
                        else
                        {
                            item.RecStatus = WorkflowStatusModel.REJECTED;
                        }

                        await _context.SaveChangesAsync();
                    }
                }
            }
            catch
            {
                res.status = "failed";
                res.code = "500";
                res.message = "Internal Server Error";
                return res;
            }

            return res;
        }*/

        [HttpPost("regular/collection/detail/add")]
        public async Task<ActionResult<object>> AddRegularCollectionItem(RegularCollectionsDetails data)
        {
            ApiResponse res = new ApiResponse();
            data.Status = 1;
            data.RecStatus = 3;

            var regCol = _context.RegularCollections.FirstOrDefault(x => x.Id == data.RegularCollectionId && x.Status==1 && x.RecStatus == WorkflowStatusModel.DRAFT);

            if (regCol == null)
            {
                res.code = "400";
                res.status = "failed";
                res.message = "Regular Collection not found";
                return BadRequest(res);
            }

            DateTime createdAt = DateTime.Now;
            TransactionTypesModel trans = new TransactionTypesModel();

            RegularCollectionsDetails overPaid = new RegularCollectionsDetails()
            {
                RegularCollectionId = data.RegularCollectionId,
                TransactionTypeId = trans.OVER_PAYMENT,
                CreatedAt = createdAt,
                Status=1
            };

            try
            {
                decimal amount = data.Amount;
                if (data.TransactionTypeId == trans.PRINCIPLE)
                {

                    var contracts = await _context.Contracts.FromSqlRaw("select top 1  c.* from contracts c inner join dbo.regular_collections " +
                                           "rc on  c.house_id = rc.house_id where c.status=1 and c.rec_status=12 and rc.id = {0} " +
                                           "order by c.id desc", data.RegularCollectionId).SingleOrDefaultAsync();

                    RegularCollectionsDetails col = new RegularCollectionsDetails()
                    {
                        RegularCollectionId = data.RegularCollectionId,
                        TransactionTypeId = trans.PRINCIPLE,
                        Amount = data.Amount,
                        RefId = null,
                        CreatedAt = createdAt,
                        Status=1
                    };
                    _context.RegularCollectionsDetails.Add(col);
                    await _context.SaveChangesAsync();

                    if (contracts != null)
                    {
                        string AppBaseUrl = this.Request.Scheme + "://" + this.Request.Host + this.Request.PathBase + "/api/v1/workflows/submit";

                        var client = new RestClient(AppBaseUrl);
                        client.Timeout = -1;
                        var request = new RestRequest(Method.POST);

                        request.AddHeader("Authorization", this.Request.Headers["Authorization"]);
                        request.AddHeader("Content-Type", "application/json");
                        var datasent = new
                        {
                            WfDetailUuid = "8bbfcae5-091a-47fe-8247-248b66ff718e",
                            RefId = contracts.Id,
                            Comment = "Completely paid"
                        };
                        string str = JsonConvert.SerializeObject(datasent);
                        request.AddParameter("application/json", JsonConvert.SerializeObject(datasent), ParameterType.RequestBody);
                        IRestResponse response = client.Execute(request);
                    }


                }
                if (data.TransactionTypeId == trans.HOUSE_PAYMENT) // House Payment
                {
                    PaymentSchedules paymentSch = new PaymentSchedules();

                    while (amount > 0)
                    {
                        string sql = "select top 1 * from payment_schedules where rec_status in(3,16) and  house_id={0} " +
                         " and id> (select case when  max(ref_id) is null then 0 else max(ref_id) end from regular_collections_details rcd " +
                         " inner join regular_collections rc on rc.id = rcd.regular_collection_id  where rc.house_id = {0}) order by id asc";

                        paymentSch = _context.PaymentSchedules.FromSqlRaw(sql, regCol.HouseId).FirstOrDefault();

                        RegularCollectionsDetails col = new RegularCollectionsDetails()
                        {
                            RegularCollectionId = data.RegularCollectionId,
                            TransactionTypeId = trans.INTEREST, //Interest
                            RefId = (int?)paymentSch.Id,
                            CreatedAt = createdAt,
                            Status=1
                        };

                        decimal payment = paymentSch.Interest??0;

                        if (payment <= amount)
                        {
                            if (paymentSch.Interest > 0)
                            {
                                col.Amount = payment;
                                amount -= payment;
                                paymentSch.PaidInterest = payment;

                                _context.RegularCollectionsDetails.Add(col);
                                _context.SaveChanges();
                            }
                        }
                        else
                        {
                            overPaid.Amount = amount;
                            col = overPaid;
                            amount = 0;
                            _context.RegularCollectionsDetails.Add(col);
                            _context.SaveChanges();
                        }

                        if (amount > 0)
                        {

                            col.TransactionTypeId = trans.PRINCIPLE; //Principle
                            payment = paymentSch.Principle??0;

                            if (payment <= amount)
                            {
                                col.Amount = payment;
                                amount -= payment;
                                paymentSch.PaidPrinciple = payment;
                                col.Id = 0;
                                _context.RegularCollectionsDetails.Add(col);
                                _context.SaveChanges();
                            }
                            else
                            {
                                overPaid.Amount = amount;
                                col = overPaid;
                                amount = 0;
                                col.Id = 0;
                                _context.RegularCollectionsDetails.Add(col);
                                _context.SaveChanges();

                            }
                        }
                    }

                }

                else if (data.TransactionTypeId == trans.PUBLIC_SERVICE)
                {
                    while (amount > 0)
                    {
                        var publicService = _context.PublicServiceSchedules.Where(x => x.HouseId == regCol.HouseId && x.Status==1 && x.RecStatus == WorkflowStatusModel.APPROVED).OrderBy(x => x.PaymentDate).FirstOrDefault();

                        RegularCollectionsDetails col = new RegularCollectionsDetails()
                        {
                            RegularCollectionId = data.RegularCollectionId,
                            TransactionTypeId = trans.PUBLIC_SERVICE,
                            Amount = publicService.MonthlyFee,
                            RefId = publicService.Id,
                            CreatedAt = createdAt,
                            Status=1
                        };

                        decimal payment = publicService.MonthlyFee;

                        if (payment <= amount)
                        {
                            col.Amount = payment;
                            amount -= payment;
                        }
                        else
                        {
                            overPaid.Amount = amount;
                            col = overPaid;
                            amount = 0;
                        }

                        _context.RegularCollectionsDetails.Add(col);
                        await _context.SaveChangesAsync();

                    }
                }

                else if (data.TransactionTypeId == trans.FINAL_PAYMENT)
                {
                    // var contract = _context.Contracts.Where(x => x.HouseId == regCol.HouseId && x.RecStatus == WorkflowStatusModel.APPROVED).OrderByDescending(x => x.CreatedAt).FirstOrDefault();

                    var finalPay = _context.FinalPayments.Where(x => x.HouseId == regCol.HouseId && x.Status==1 && x.RecStatus == WorkflowStatusModel.APPROVED).OrderByDescending(x => x.CreatedAt).FirstOrDefault();

                    if (finalPay == null)
                    {
                        res.status = "failed";
                        res.message = "Final Payment not found";
                        return BadRequest(res);
                    }

                    if ((decimal) amount != finalPay.FinalPayAmount)
                    {
                        res.status = "failed";
                        res.message = "Final Payment amount not matched payment";
                        return BadRequest(res);
                    }

                    RegularCollectionsDetails col = new RegularCollectionsDetails()
                    {
                        RegularCollectionId = data.RegularCollectionId,
                        Amount = finalPay.FinalPayAmount??0,
                        TransactionTypeId = trans.FINAL_PAYMENT,
                        RefId = finalPay.Id,
                        CreatedAt = createdAt,
                        Status=1
                    };

                    _context.RegularCollectionsDetails.Add(col);
                    await _context.SaveChangesAsync();
                }

                var regular = await _context.VRegularCollectionDetails.Where(x => x.RegularCollectionId == regCol.Id).ToListAsync();

                return regular;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("regular/collection/{regId}/detail/clear")]
        public async Task<ActionResult<object>> DeleteRegularCollection(int regId)
        {
            ApiResponse res = new ApiResponse();
            var reg = _context.RegularCollections.AsNoTracking().FirstOrDefault(x => x.Id == regId && x.Status==1 && x.RecStatus == WorkflowStatusModel.DRAFT);

            if (reg == null)
            {
                res.status = "failed";
                res.message = "Regular Collection found or status is not Draft";
                return BadRequest(res);
            }

            var detail = await _context.RegularCollectionsDetails.Where(x => x.RegularCollectionId == regId && x.Status==1 && x.RecStatus == WorkflowStatusModel.DRAFT).ToListAsync();
            detail.ForEach(x => x.Status = 0);
            _context.RegularCollectionsDetails.UpdateRange(detail);
            await _context.SaveChangesAsync();

            res.status = "success";
            res.message = "success";
            return Ok(res);
        }

        [HttpGet("regular/collection/payee")]
        public async Task<ActionResult<object>> GetPayee([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<RegularCollectionPayees>(_context, _userIdentity.Id).GetDataHouse(filter);
        }

        [HttpGet("regular/collection/payee/{id}")]
        public async Task<ActionResult<object>> GetContracts(int id)
        {
            var data = await _context.RegularCollectionPayees.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("regular/collection/payee/houseId/{id}")]
        public async Task<ActionResult<object>> GetPayeeByHouseId(int id)
        {

            var data = await _context.RegularCollectionPayees.Where(x => x.HouseId == id && x.Status==1).ToListAsync();
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }


        [HttpPost("regular/collection/payee/add")]
        public async Task<ActionResult<RegularCollectionPayees>> ContractsAdd(RegularCollectionPayees data)
        {
            ApiResponse res = new ApiResponse();
            var payee = _context.RegularCollectionPayees.AsNoTracking()
                    .FirstOrDefault(
                        x => x.HouseId == data.HouseId &&
                        x.PayeeName == data.PayeeName &&
                        x.IdentityType == data.IdentityType &&
                        x.IdentityNo == data.IdentityNo &&
                        x.PayeeAddress == data.PayeeAddress &&
                        x.RelationshipStatus == data.RelationshipStatus && 
                        x.Status==1
                    );

            if (payee != null)
            {
                res.status = "failed";
                res.message = "Payee already exists";
                return BadRequest(res);
            }

            try
            {
                data.Status = 1;
                CrudLib<RegularCollectionPayees> crud = new CrudLib<RegularCollectionPayees>(_context, _userIdentity.Id);
                data = (RegularCollectionPayees)await crud.Add(data);

                return data;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("regular/collection/payee/update")]
        public async Task<ActionResult<object>> AdHocDiscountUpdate(RegularCollectionPayees data)
        {
            try
            {

                ApiResponse res = new ApiResponse();
                var payee = _context.RegularCollectionPayees.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status==1);

                if (payee == null)
                {
                    res.status = "failed";
                    res.message = "Payee Id not found for update";
                    return BadRequest(res);
                }

                data.Status = 1;
                CrudLib<RegularCollectionPayees> crud = new CrudLib<RegularCollectionPayees>(_context, _userIdentity.Id);
                data = (RegularCollectionPayees)await crud.Update(data);

                res.status = "success";
                res.message = "success";

                return Ok(res);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpGet("waive")]
        public async Task<ActionResult<object>> GetWaive([FromQuery] PaginationFilter filter)
        {

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_waive_payments_filter {0},{1},{2}";
            var terms = _context.VWaivePayment
                               .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = terms.Count();

            var pagedData = terms.OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
            //return await new CrudLib<WaivePayments>(_userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("waive/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetWaive(int id)
        {
            var data = await _context.WaivePayments.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.waive_payments", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        /* [HttpGet("waive/house/{house_id}")]
         public async Task<ActionResult<IEnumerable<ClsWaiveInfo>>> GetWaiveInfoByHouseId(int house_id)
         {
             string sql = "";
             var data = await _context.WaiveInfo.FromSqlRaw(sql).ToListAsync();            
             return data;
         } */
        [HttpPost("waive/add")]
        public async Task<ActionResult<WaivePayments>> WaiveAdd(WaivePayments data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    var contract = await _context.Contracts.AsNoTracking()
                       .OrderByDescending(x => x.Id)
                       .FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                    if (contract == null) return BadRequest("There is no contract for this house!");

                    data.Status = 1;
                    data.ContractId = contract.Id;
                    data.BookingId = contract.BookingId;
                    CrudLib<WaivePayments> crud = new CrudLib<WaivePayments>(_context, _userIdentity.Id);
                    data = (WaivePayments)await crud.Add(data, "dbo.waive_payments");

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[waive_payments_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log waive payment can not saved!");
                    dbContextTransaction.Commit();

                    return data;
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("waive/update")]
        public async Task<ActionResult<object>> WaiveUpdate(WaivePayments data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    ApiResponse res = new ApiResponse();

                    var waive = await _context.WaivePayments.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == 0);

                    if (waive == null)
                    {
                        res.status = "failed";
                        res.message = "Waive Payment Id is not found";
                        return BadRequest(res);
                    }

                    /* var contract = await _context.Contracts.AsNoTracking()
                           .OrderByDescending(x => x.Id)
                           .FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status==1 && x.RecStatus == 3);

                     if (contract == null) return BadRequest("There is no contract for this house!"); */


                    data.Status = 1;
                    data.ContractId = waive.ContractId;
                    data.BookingId = waive.BookingId;
                    CrudLib<WaivePayments> crud = new CrudLib<WaivePayments>(_context, _userIdentity.Id);
                    data = (WaivePayments)await crud.Update(data);
                    res.status = "success";
                    res.message = "success";

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[waive_payments_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log waive payment can not updated!");
                    dbContextTransaction.Commit();
                    return Ok(res);

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("final")]
        public async Task<ActionResult<object>> GetFinal([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VFinalPayment>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpPost("final/approved/{refId}")]
        public async Task<ActionResult> FinalPaymentApprove(int refId)
        {
            try
            {
                var penalty = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_final_payment_approved {0},{1}", refId, _userIdentity.Id);
                if (penalty == -1) return Ok("success");
                else return BadRequest("operation fail");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("final/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetFinal(int id)
        {
            var data = await _context.VFinalPayment.SingleOrDefaultAsync(x=>x.Id==id);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.final_payments", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }


        [HttpPost("final/add")]
        public async Task<ActionResult<FinalPayments>> FinalPaymentAdd(FinalPayments data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var contract = await _context.Contracts.AsNoTracking()
                        .OrderByDescending(x => x.Id)
                        .FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                    if (contract == null) return BadRequest("There is no contract for this house!");


                    var customer_history1 = data.Customer1Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == contract.CurrentCustomer1Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                    var customer_history2 = data.Customer2Id == 0 ? null : await _context.CustomersHistory.AsNoTracking().Where(x => x.CustomerId == contract.CurrentCustomer2Id).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                    data.PaidOffPercentage = Math.Round(data.PaidOffPercentage ?? 0, 2);
                    data.Customer1Id = customer_history1.Id;
                    data.Customer2Id = customer_history2?.Id;
                    data.Status = 1;
                    //  data.FinalPaymentDate = DateTime.Now;
                    data.WaiveInterest = 0;
                    data.ContractId = contract.Id;
                    data.BookingId = contract.BookingId;
                    CrudLib<FinalPayments> crud = new CrudLib<FinalPayments>(_context, _userIdentity.Id);
                    data = (FinalPayments)await crud.Add(data, "dbo.final_payments");

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[final_payment_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log final payment can not saved!");
                    dbContextTransaction.Commit();

                    return data;
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("final/update")]
        public async Task<ActionResult<object>> FinalPaymentUpdate(FinalPayments data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    ApiResponse res = new ApiResponse();
                    var finalpayment = await _context.FinalPayments.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == 0);

                    if (finalpayment == null)
                    {
                        res.status = "failed";
                        res.message = "Final Payment Id is not found";
                        return BadRequest(res);
                    }

                    data.Status = 1;
                    // data.FinalPaymentDate = finalpayment.FinalPaymentDate;
                    data.WaiveInterest = 0;
                    data.ContractId = finalpayment.ContractId;
                    data.BookingId = finalpayment.BookingId;
                    CrudLib<FinalPayments> crud = new CrudLib<FinalPayments>(_context, _userIdentity.Id);
                    data = (FinalPayments)await crud.Update(data);
                    res.status = "success";
                    res.message = "success";

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[final_payment_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log final payment can not updated!");
                    dbContextTransaction.Commit();

                    return Ok(res);
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("adjustments")]
        public async Task<ActionResult<object>> GetAdjustments([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<Adjustments>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("adjustments/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetAdjustments(int id)
        {

            var data = await _context.Adjustments.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.adjustments", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }


        [HttpPost("adjustments/add")]
        public async Task<ActionResult<Adjustments>> AdjustmentsAdd(Adjustments data)
        {

            try
            {
                var contract = await _context.Contracts.AsNoTracking()
                    .OrderByDescending(x=>x.Id)
                    .FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status==1 && x.RecStatus == 3);
                if (contract == null) return BadRequest("There is no contract for source house id:"+data.HouseId);

                var dest_contract = await _context.Contracts.AsNoTracking()
                    .OrderByDescending(x => x.Id)
                    .FirstOrDefaultAsync(x => x.HouseId ==data.DestHouseId && x.Status==1 && x.RecStatus == 3);
                if (contract == null) return BadRequest("There is no contract for destination house id:" + data.DestHouseId);

                data.Status = 1;
                data.RecStatus = 0;
                data.ContractId = contract.Id;
                data.BookingId = contract.BookingId;
                data.DestContractId = dest_contract.Id;
                CrudLib<Adjustments> crud = new CrudLib<Adjustments>(_context, _userIdentity.Id);
                data = (Adjustments)await crud.Add(data, "dbo.adjustments");

                return data;
            }
            catch(Exception ex)
            {
                return  BadRequest(ex.Message);
            }
        }

        [HttpPost("adjustments/update")]
        public async Task<ActionResult<object>> AdjustmentsUpdate(Adjustments data)
        {
            try
            {

                ApiResponse res = new ApiResponse();
                var adjustment =await _context.Adjustments.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1 && x.RecStatus==0);

                if (adjustment == null)
                {
                    res.status = "failed";
                    res.message = "Adjustment Id is not found";
                    return BadRequest(res);
                }

                data.Status = 1;
                data.RecStatus = 0;
                data.BookingId = adjustment.BookingId;
                data.ContractId = adjustment.ContractId;
                data.DestContractId = adjustment.DestContractId;
                CrudLib<Adjustments> crud = new CrudLib<Adjustments>(_context, _userIdentity.Id);
                data = (Adjustments)await crud.Update(data);

                res.status = "success";
                res.message = "success";
                return Ok(res);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        [HttpPost("adjustments/approved/{refId}")]
        public async Task<ActionResult> AdjustmentsApprove(int refId)
        {
            try
            {
                var penalty = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_adjustment_approved {0},{1}", refId, _userIdentity.Id);
                if (penalty == -1) return Ok("success");
                else return BadRequest("operation fail");

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("penalties/calculation")]
        public async Task<ActionResult<object>> GetPenalty([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<PenaltiesCalculation>(_context,_userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("penalties/calculation/{id}")]
        public async Task<ActionResult<object>> GetPenalty(int id)
        {
            var data = await _context.PenaltiesCalculation.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }


            return data;
        }

        [HttpPost("penalties/calculation/add")]
        public async Task<ActionResult<PenaltiesCalculation>> PenaltyAdd(PenaltiesCalculation data)
        {

            try
            {
                CrudLib<PenaltiesCalculation> crud = new CrudLib<PenaltiesCalculation>(_context ,_userIdentity.Id);
                data = (PenaltiesCalculation)await crud.Add(data);

                return data;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("penalties/calculation/update")]
        public async Task<ActionResult<object>> PenaltyUpdate(PenaltiesCalculation data)
        {

                try
                {

                    ApiResponse res = new ApiResponse();
                    var waive = _context.PenaltiesCalculation.AsNoTracking().FirstOrDefault(x => x.Id == data.Id);

                    if (waive == null)
                    {
                        res.status = "failed";
                        res.message = "Penalty Id is not found";
                        return BadRequest(res);
                    }

                    CrudLib<PenaltiesCalculation> crud = new CrudLib<PenaltiesCalculation>(_context, _userIdentity.Id);
                    data = (PenaltiesCalculation)await crud.Update(data);

                    res.status = "success";
                    res.message = "success";
                    return Ok(res);
                }
                catch(Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }

        [HttpPost("penalties/calculation/delete")]
        public async Task<IActionResult> DeletePenalites(DeleteModel data)
        {
            var data_delete = await _context.PenaltiesCalculation.FindAsync(data.Id);

            if (data_delete == null)
            {
                return BadRequest();
            }

            _context.PenaltiesCalculation.Remove(data_delete);

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NoContent();
            }
        }

        [HttpGet("reschedules")]
        public async Task<ActionResult<object>> GetReschedule([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VReschedule>(_context ,_userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("reschedules/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetReschedules(int id)
        {

            var data = await _context.Reschedules.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==id && x.Status==1);

            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.reschedules", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("reschedules/add")]
        public async Task<ActionResult<object>> ReschedulesyAdd(Reschedules data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {

                    var contract = _context.Contracts.AsNoTracking().SingleOrDefault(x => x.Id == data.ContractId && x.Status == 1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                    if (contract == null) return BadRequest("Contract Id not available");

                    data.BookingId = contract.BookingId;
                    data.Status = 1;
                    CrudLib<Reschedules> crud = new CrudLib<Reschedules>(_context, _userIdentity.Id);
                    data = (Reschedules)await crud.Add(data, "dbo.reschedules", true, "create reschedule");

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[reschedule_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log reschedule can not saved!");
                    dbContextTransaction.Commit();

                    return data;

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("reschedules/update")]
        public async Task<ActionResult<object>> ReschedulesUpdate(Reschedules data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    ApiResponse res = new ApiResponse();
                    var reschedule = await _context.Reschedules.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);

                    if (reschedule == null)
                    {
                        res.status = "failed";
                        res.message = "Penalty Id is not found";
                        return BadRequest(res);
                    }

                    data.BookingId = reschedule.BookingId;
                    data.Status = 1;
                    CrudLib<Reschedules> crud = new CrudLib<Reschedules>(_context, _userIdentity.Id);
                    data = (Reschedules)await crud.Update(data);
                    res.status = "success";
                    res.message = "success";

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[reschedule_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log reschedule can not updated!");
                    dbContextTransaction.Commit();

                    return Ok(res);
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("reschedules/delete")]
        public async Task<IActionResult> DeleteReschedules(DeleteModel data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {

                    var data_delete = await _context.Reschedules.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1 && x.RecStatus == WorkflowStatusModel.DRAFT);

                    if (data_delete == null)
                    {
                        return BadRequest("No, reschedule can not be deleted!");
                    }

                    data_delete.Status = 0;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[reschedule_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log reschedule can not deleted!");
                    dbContextTransaction.Commit();

                    return Ok();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpGet("reschedules/subterm")]
        public async Task<ActionResult<object>> GetRescheduleSubterm()
        {
            return await _context.ReschedulesSubterm.ToListAsync();
        }

        [HttpGet("reschedules/subterm/{id}")]
        public async Task<ActionResult<object>> GetRescheduleSubtermById(int id)
        {
            var data = await _context.ReschedulesSubterm.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status == 1);
            if (data == null)
            {
                return NoContent();
            }

            return data;
            // return await _context.ReschedulesSubterm.ToListAsync();
        }

        [HttpGet("reschedules/subterm-reschedule-id/{reschedule_id}")]
        public async Task<ActionResult<object>> GetRescheduleSubtermByRescheduleId(int reschedule_id)
        {

            return await _context.ReschedulesSubterm.AsNoTracking().Where(x => x.RescheduleId == reschedule_id && x.Status == 1).ToListAsync();

            // return await _context.ReschedulesSubterm.ToListAsync();
        }


        [HttpPost("reschedules/subterm/add")]
        public async Task<ActionResult<object>> ReschedulesSubtermAdd(ReschedulesSubterm data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {
                try
                {
                    data.Status = 1;
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    _context.ReschedulesSubterm.Add(data);
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[reschedule_subterm_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log reschedule subterm can not saved!");
                    dbContextTransaction.Commit();

                    return data;
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpPost("reschedules/subterm/update")]
        public async Task<ActionResult<object>> ReschedulesSubtermUpdate(ReschedulesSubterm data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var subterms = await _context.ReschedulesSubterm.AsNoTracking().SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
                    if (subterms == null)
                    {
                        return BadRequest("Uuid not found");
                    }

                    data.Status = 1;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;

                    _context.Entry(data).State = EntityState.Modified;
                    _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
                    _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[reschedule_subterm_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log reschedule subterm can not updated!");
                    dbContextTransaction.Commit();
                    return Ok();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
            //return Ok();

        }
        [HttpPost("reschedules/subterm/delete")]
        public async Task<ActionResult<object>> ReschedulesSubtermDelete(ReschedulesSubterm data)
        {
            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var data_delete = await _context.ReschedulesSubterm.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);

                    if (data_delete == null)
                    {
                        return BadRequest();
                    }

                    data_delete.Status = 0;
                    await _context.SaveChangesAsync();

                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[reschedule_subterm_log] {0},{1},{2}", data.Id, "Delete", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log reschedule subterm can not deleted!");
                    dbContextTransaction.Commit();
                    return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("reschedules/approved/{refId}")]
        public async Task<ActionResult> ReschedulesApproved(int refId)
        {
            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_reschedule_approved {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpPost("reschedules/rejected/{refId}")]
        public async Task<ActionResult> ReschedulesRejected(int refId)
        {
            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_reschedule_rejected {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpPost("reschedules/generate/{refId}")]        
        public async Task<ActionResult<object>> ReschedulesGenerate(int refId)
        {

            ApiResponse res = new ApiResponse();

            try
            {                

                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_reschedule_generate {0},{1}", refId, _userIdentity.Id);
                if (result == -1)
                {
                    res.status = "success";
                    res.code = "200";
                    res.message = "execute successfully";
                }
                else
                {
                    res.status = "fail";
                    res.code = "-1";
                    res.message = "operation fail";
                }
                return Ok(res);
            }
            catch (Exception ex)
            {
                res.status = "failed";
                res.message = ex.Message;
            }

            return res;

        }
        [HttpGet("booking/collection")]
        public async Task<ActionResult<IEnumerable<object>>> GetBookingCollection([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VBookingCollection
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Housenumber == validFilter.Search || s.PreprintedNumber== validFilter.Search.Trim()) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId) //&& s.IsBooking==true
                               ))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .OrderByDescending(x => x.Id)
                               .ToList();

            validFilter.TotalRecords = 
                await _context.VBookingCollection
                            .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Housenumber == validFilter.Search || s.PreprintedNumber == validFilter.Search.Trim())) &&
                                    (!filter.ProId.HasValue || s.ProjectId == filter.ProId)// && s.IsBooking==true
                               )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("booking/collection/{id}")]
        public async Task<ActionResult<object>> GetBookingCollectionById(int id)
        {
            var data = await _context.RegularCollections.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status==1);
            if (data == null) return BadRequest("Booking colection id not found");
            return data;
        }

        [HttpPost("booking/collection/add")]
        public async Task<ActionResult<RegularCollections>> AddBookingCollection(RegularCollections data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var booking = await _context.Bookings.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.RecStatus == 3 && x.Status == 1);
                    if (booking == null) return BadRequest("There is no booking for this house");
                    string pre_printed_number = data.PreprintedNumber;

                    /*  string sql = "exec [dbo].[get_auto_number] @result={0} out";
                      var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
                      _context.Database.ExecuteSqlRaw(sql, result);
                      int auto_number = (int)result.Value;

                      string pre_printed_number = data.PreprintedNumber;

                      if (data.ProjectId > 1)
                      {
                          sql = "exec [dbo].[sp_generate_preprinted_number]  {0}, @result={1} out";
                          result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.VarChar, 30) { Direction = ParameterDirection.Output };
                          _context.Database.ExecuteSqlRaw(sql, data.ProjectId, result);
                          pre_printed_number = result.Value.ToString();

                      } */

                    data.Status = 1;
                    data.IsMoved = 0;
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _userIdentity.Id;
                    data.DueDate = DateTime.Now;
                    data.PaidDate = DateTime.Now;
                    data.RecStatus = 3;
                    data.BookingId = booking.Id;
                    data.Customer1Id = booking.CurrentCustomer1Id;
                    data.Customer2Id = booking.CurrentCustomer2Id;
                    data.TransactionNo = 0; // Convert.ToInt64(DateTime.Today.ToString("yyMMdd") + auto_number.ToString("0000"));
                    data.PreprintedNumber = pre_printed_number;
                    data.NumberOfChange = 0;
                    //data.IsBooking = true;
                    _context.Add(data);
                    await _context.SaveChangesAsync();

                    var reg_detail = new RegularCollectionsDetails();
                    reg_detail.RegularCollectionId = data.Id;
                    reg_detail.Status = 1;
                    reg_detail.IsResolved = 0;
                    reg_detail.Amount = data.TotalAmount ?? 0;
                    reg_detail.CreatedAt = DateTime.Now;
                    reg_detail.TransactionTypeId = 5;
                    reg_detail.RecStatus = 3;
                    _context.Add(reg_detail);
                    await _context.SaveChangesAsync();

                    await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_regular_collection_detail_method {0}", data.Id);

                    //_context.Database.ExecuteSqlRaw("exec dbo.sp_regular_collection_detail_method {0}", data.Id);

                    //  lock(new object())
                    // {
                    await _context.Database.ExecuteSqlRawAsync("exec dbo.update_transaction_no {0},{1}", data.Id, data.ProjectId);
                    // tran.Complete();
                    //}  
                    await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_move_booking_after_contract {0},{1}", booking.Id, _userIdentity.Id);
                    //save to audit log
                    var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_collection_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (result != -1) throw new Exception("Log booking collection can not saved!");
                    dbContextTransaction.Commit();

                    return data;


                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("booking/collection/update")]
        public async Task<ActionResult> UpdateBookingCollection(RegularCollections value)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                    var data = await _context.RegularCollections.SingleOrDefaultAsync(x => x.Id == value.Id && x.Status == 1);
                    if (data == null) BadRequest("Invalid regular collection id");

                    var booking = await _context.Bookings.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == value.HouseId && x.RecStatus == 3 && x.Status == 1);
                    if (booking == null) return BadRequest("There is no booking for this house");

                    //data.BookingId = value.BookingId;
                    //data.ProjectId = value.ProjectId;
                    //data.HouseId = value.HouseId;
                    data.CollectionClass = value.CollectionClass;
                    data.PayeeId = value.PayeeId;
                    data.TotalAmount = value.TotalAmount;
                    data.Method1Id = value.Method1Id;
                    data.Method1Amount = value.Method1Amount;
                    data.Method2Id = value.Method2Id;
                    data.Method2Amount = value.Method2Amount;
                    data.Method3Id = value.Method3Id;
                    data.Method3Amount = value.Method3Amount;
                    data.Remark = value.Remark;
                    data.UpdatedAt = DateTime.Now;
                    data.UpdatedBy = _userIdentity.Id;
                    //data.Customer1Id = booking.CurrentCustomer1Id;
                    //data.Customer2Id = booking.CurrentCustomer2Id;
                    data.NumberOfChange = data.NumberOfChange ?? 0 + 1;

                    var detail = _context.RegularCollectionsDetails.FirstOrDefault(x => x.RegularCollectionId == value.Id && x.Status == 1);
                    detail.Amount = value.TotalAmount ?? 0;
                    await _context.SaveChangesAsync();


                    string sql = "exec [dbo].[is_change_collection_method] " + data.Id + ",@result={0} out";
                    var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    await _context.Database.ExecuteSqlRawAsync(sql, result);

                    int nrow = (int)result.Value;
                    if (nrow > 0) //if collection method change 
                    {
                        await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_regular_collection_detail_method {0}", data.Id);
                    }

                    //tran.Complete();
                    //save to audit log
                    var audit_result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[booking_collection_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                    if (audit_result != -1) throw new Exception("Log booking collection can not updated!");
                    dbContextTransaction.Commit();

                    return Ok();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpGet("booking/collection/detail/{id}")]
        public async Task<ActionResult<RegularCollectionsDetails>> AddBookingCollectionDetail(int id)
        {
            var data = await _context.RegularCollectionsDetails.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id && x.Status==1 && x.TransactionTypeId == 5);
            if (data == null) BadRequest("Invalid Regular Collection Detail Id");
            return data;
        }

        [HttpPost("booking/collection/detail/add")]
        public async Task<ActionResult<RegularCollectionsDetails>> AddBookingCollectionDetail(RegularCollectionsDetails data)
        {
                try
                {

                    //booking.RecStatus=3;
                    data.Status = 1;
                    data.IsResolved = 0;
                    data.CreatedAt = DateTime.Now;
                    data.TransactionTypeId = 5;
                    data.RecStatus = 3;                
                    _context.Add(data);
                    _context.SaveChanges();
                    _context.Database.ExecuteSqlRaw("exec dbo.sp_regular_collection_detail_method {0}", data.RegularCollectionId);

                    return data;
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }


        [HttpPost("booking/collection/detail/update")]
        public async Task<ActionResult> UpdateBookingCollectionDetail(RegularCollectionsDetails value)
        {
            try
            {
                var data = await _context.RegularCollectionsDetails.SingleOrDefaultAsync(x=>x.Id==value.Id && x.Status==1 && x.TransactionTypeId==5);
                if (data == null) BadRequest("Invalid regular collection detail id");
                data.RegularCollectionId = value.RegularCollectionId;
                data.Amount = value.Amount;
                _context.SaveChanges();
                _context.Database.ExecuteSqlRaw("exec dbo.sp_regular_collection_detail_method {0}", data.RegularCollectionId);
                return Ok();
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        [HttpGet("houses-payment/schedule/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetHousePaidSchedule(int house_id)
        {
            try
            {
                var housepayment = await _context.HousePaymentSchedule.FromSqlRaw("exec dbo.sp_get_house_payment_schedule {0}", house_id).ToListAsync();
                if (housepayment == null) return BadRequest("No house payment schedule for this house!");
                return Ok(housepayment);

            }catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }
        [HttpGet("houses/info/{house_id}/{option}")]
        public ActionResult<object> GetHousePaymentInfo(int house_id,int option)
        {
            try
            {
                var housepayment = _context.HousePayment.FromSqlRaw("exec dbo.sp_get_house_payment {0},{1}", house_id, option).AsEnumerable().FirstOrDefault();
                if (housepayment == null) return BadRequest("No house payment for house!");
                return Ok(housepayment);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
           

        }

        [HttpGet("houses-interest/info/{house_id}")]
        public ActionResult<object> GetHouseInterestPaymentInfo(int house_id)
        {
            try
            {
                var housepayment = _context.HouseInterestPayment.FromSqlRaw("exec dbo.get_interest_house_payment {0}", house_id).AsEnumerable().FirstOrDefault();
                if (housepayment == null) return BadRequest("No Interest for this house!");
                return Ok(housepayment);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
           

        }

        [HttpGet("public_services/info/{house_id}")]
        public ActionResult<object> GetPublicServiceInfo(int house_id)
        {
            try
            {
                var publicservice = _context.PublicServicePayment.FromSqlRaw("exec dbo.sp_get_public_service_payment {0}", house_id).AsEnumerable().FirstOrDefault();
                if (publicservice == null) return BadRequest("No public service for this house!");
                return Ok(publicservice);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("penalty/info/{house_id}/{option}")]
        public ActionResult<object> GetPenaltyInfo(int house_id, int option)
        {
            try
            {
                var penalty = _context.PenaltySummary.FromSqlRaw("exec dbo.sp_get_penalty_summary {0},{1}", house_id, option).AsEnumerable().FirstOrDefault();
                if (penalty == null) return BadRequest("No penalty for this house!");
                return Ok(penalty);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("penalty/waive-info/{house_id}")]
        public ActionResult<object> GetPenaltyWaiveInfo(int house_id)
        {
            try
            {
                //int user_id = _userIdentity.Id;
                var penalty = _context.PenaltySummary.FromSqlRaw("exec dbo.sp_get_penalty_waive_info {0}", house_id).AsEnumerable().FirstOrDefault();
                if (penalty == null) return BadRequest("No waive penalty for this house!");
                return Ok(penalty);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("penalty/generate")]
        public async Task<ActionResult> PenaltyGenerate(PenaltyGenerateInput input)
        {
            try
            {
                var penalty = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_penalty_generate {0},{1},{2}", input.HouseId, input.PaidDate, _userIdentity.Id) ;
                if (penalty == -1) return Ok(new { result = "success" });
                else return BadRequest(new { result = "operation fail" });

            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("penalty/list/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetPenaltyList(int house_id)
        {
            try
            {
                var penalty = _context.PenaltyList.FromSqlRaw("exec dbo.sp_get_penalty_list {0}", house_id).AsEnumerable().ToList();
                if (penalty == null) return BadRequest("No penalty for this house!");
                return Ok(penalty);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }            

            //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
        }

        [HttpGet("final/info/{house_id}")]
        public ActionResult<object> GetFinalPayment(int house_id)
        {
            try
            {
                var finalpayment = _context.FinalPayment.FromSqlRaw("exec dbo.sp_get_final_payment {0}", house_id).AsEnumerable().FirstOrDefault();
                if (finalpayment == null) return BadRequest("No final payment for this house!");
                return Ok(finalpayment);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("reschedule/interest/{house_id}")]
        public ActionResult<object> GetRescheduleInterest(int house_id)
        {
            try
            {
                var finalpayment = _context.RescheduleInterest.FromSqlRaw("exec dbo.sp_get_reschedule_interest {0}", house_id).AsEnumerable().FirstOrDefault();
                if (finalpayment == null) return BadRequest("No Reschedule Interest for this house!");
                return Ok(finalpayment);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("final-calculation/info/{house_id}")]
        public ActionResult<object> GetFinalPaymentCalculation(int house_id)
        {
            try
            {
                var finalpayment = _context.FinalPaymentCalculation.FromSqlRaw("exec dbo.get_final_payment_calculation_by_houseid {0}", house_id).AsEnumerable().FirstOrDefault();
                if (finalpayment == null) return BadRequest("No final payment for this house!");
                return Ok(finalpayment);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpPost("final-calculation/info-bydate")]
        public ActionResult<object> GetFinalPaymentCalculationByDate(FinalPaymentInput info)
        {
            try
            {
                var finalpayment = _context.FinalPaymentCalculation.FromSqlRaw("exec dbo.get_final_payment_calculation {0},{1}", info.HouseId, info.finalPaymentDate).AsEnumerable().FirstOrDefault();
                if (finalpayment == null) return BadRequest("No final payment for this house!");
                return Ok(finalpayment);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost("termination-transfer/info")]
        public ActionResult<object> GetTerminationTransferInfo(FinalPaymentInput info)
        {
            try
            {
                var termination = _context.TerminationTransferInfo.FromSqlRaw("exec dbo.get_termination_transfer_info {0},{1}", info.HouseId, info.finalPaymentDate).AsEnumerable().FirstOrDefault();
                if (termination == null) return BadRequest("No termination transfer info for this house!");
                return Ok(termination);

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("final-principle/info/{house_id}")]
        public ActionResult<object> GetFinalPrinciple(int house_id)
        {
            //this calculation for principle only
            try
            {
                var finalprinciple = _context.FinalPrinciple.FromSqlRaw("exec dbo.sp_get_final_principle {0}", house_id).AsEnumerable().FirstOrDefault();
                if (finalprinciple == null) return BadRequest("No final payment for this house!");
                return Ok(finalprinciple);

            }catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("first-extra-principle/info/{house_id}")]
        public ActionResult<object> GetFirstExtraPrinciplePayment(int house_id)
        {
            try
            {
                var finalpayment = _context.ExtraPrinciple.FromSqlRaw("exec dbo.sp_get_first_extra_principle_payment {0}", house_id).AsEnumerable().FirstOrDefault();
                if (finalpayment == null) return BadRequest("No first extra principle  for this house!");
                return Ok(finalpayment);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }        

        [HttpGet("extra-principle/info/{house_id}")]
        public ActionResult<object> GetExtraPrinciplePayment(int house_id)
        {
            try
            {
                var finalpayment = _context.ExtraPrinciple.FromSqlRaw("exec dbo.sp_get_extra_principle_payment {0}", house_id).AsEnumerable().FirstOrDefault();
                if (finalpayment == null) return BadRequest("No extra principle  for this house!");
                return Ok(finalpayment);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("list")]
        public async Task<IEnumerable<object>> GetPaymentList()
        {
            var payment = await _context.VCollectionTransactionType.Where(x => x.Status == 1)
                                        .OrderBy(x => x.Ordering)
                                        .Select(x => new { Id = x.Id, TransactionName = x.TransactionName, Remark = x.Remark, CreatedAt = x.CreatedAt, PaidDate = "", Payment = 0, PaidAmount = 0 })
                                        .ToListAsync();
            return payment;
        }

        [HttpGet("paid/{regular_collection_id}")]
        public async Task<ActionResult<ClsPaidModel>> GetPaidById(int regular_collection_id)
        {

            try
            {

                var collection = await _context.RegularCollections.AsNoTracking().SingleOrDefaultAsync(x => x.Id == regular_collection_id && x.Status==1);
                if (collection == null) BadRequest("Regular collection id is not available");
                ClsPaidModel model = new ClsPaidModel();
                model.RegularCollectionId = collection.Id;
                model.ProjectId = collection.ProjectId;
                model.HouseId = collection.HouseId??0;
                model.CollectionClass = collection.CollectionClass;
                model.PayeeId = collection.PayeeId;
                model.TotalAmount = collection.TotalAmount;
                model.Method1Id = collection.Method1Id;
                model.Method1Amount = collection.Method1Amount;
                model.Method2Id = collection.Method2Id;
                model.Method2Amount = collection.Method2Amount;
                model.Method3Id = collection.Method3Id;
                model.Method3Amount = collection.Method3Amount;
                model.Remark = collection.Remark;
                model.PrePrintedNumber = collection.PreprintedNumber;
                model.PaidDate = collection.PaidDate ?? DateTime.Now;
                model.HousePaid = 0;
                model.PublicServicePaid = 0;
                model.PenaltyPaid = 0;
                model.FirstExtraPrinciplePaid = 0;
                model.ExtraPrinciplePaid = 0;
                model.InterestPaid = 0;
                model.FinalPaymentPaid = 0;
                model.RefNo1 = collection.RefNo1;
                model.RefNo2 = collection.RefNo2;
                model.RefNo3 = collection.RefNo3;
                model.RefDate1 = collection.RefDate1;
                model.RefDate2 = collection.RefDate2;
                model.RefDate3 = collection.RefDate3;
                model.AccountNumber1 = collection.AccountNumber1;
                model.AccountNumber2 = collection.AccountNumber2;
                model.AccountNumber3 = collection.AccountNumber3;
                model.PublicServiceDiscountPaid = -collection.PublicServiceDiscount??0;

                var collection_details = _context.RegularCollectionDetailSummary.FromSqlRaw("exec dbo.get_regular_collection_detail {0}", regular_collection_id).AsEnumerable().ToList();
                if (collection_details != null)
                {
                    foreach (var detail in collection_details)
                    {
                        switch (detail.TransactionType)
                        {
                            case 1: model.HousePaid = detail.Payment; break;  //house payment
                            case 2: model.PenaltyPaid = detail.Payment; break; //penalty
                            case 3: model.PublicServicePaid = detail.Payment; break; //public service   
                            case 6: model.OverFinalPayment = detail.Payment; break; //First Extra payment    
                            case 7: model.FirstExtraPrinciplePaid = detail.Payment; break; //First Extra payment    
                            case 8: model.InterestPaid = detail.Payment; break; //First Extra payment
                            case 9: model.ExtraPrinciplePaid = detail.Payment; break; //Extra Principle
                            case 13: model.FinalPaymentPaid = detail.Payment; break; //final payment

                        }
                    }
                }

                return Ok(model);

            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpGet("count-receiptno/{ProjectId}/{PrePrintedNumber}")]
        public int CountReceiptNo(int ProjectId, string PrePrintedNumber)
        {
            int counter = _context.RegularCollections.Where(x => x.ProjectId == ProjectId && x.TotalAmount>0 && x.PreprintedNumber.Trim() == PrePrintedNumber.Trim()).Count();
            return counter;
        }

        [HttpGet("HousePaymentValidation/{HouseId}/{PenaltyPaid}/{HousePaid}")]
        public int GetHousePaymentValidation(int HouseId, decimal PenaltyPaid, decimal HousePaid)
        {
            string sql = "exec [dbo].[sp_house_payment_validation] " + HouseId + "," + PenaltyPaid + "," + HousePaid + ",@is_validate={0} out";
            var result = new Microsoft.Data.SqlClient.SqlParameter("@is_validate", SqlDbType.Int) { Direction = ParameterDirection.Output };
            _context.Database.ExecuteSqlRaw(sql, result);

            return (int)result.Value;
        }
      
         //using (var mem = new MemoryDbContext())
         //   {

         //       var reserveData = await mem.MemoryReserve.FirstOrDefaultAsync(x => x.user_id == _userIdentity.Id);
         //       if (reserveData != null)
         //       {
         //           if (reserveData.house_id == PaidModel.HouseId && reserveData.preprinted_number == PaidModel.PrePrintedNumber)
         //               return BadRequest("Double Transaction");
         //           else
         //           {
         //               reserveData.house_id = PaidModel.HouseId;
         //               reserveData.preprinted_number = PaidModel.PrePrintedNumber;
         //               await mem.SaveChangesAsync();
         //           }
         //       }
         //       else
         //       {
         //           mem.Add(new MemoryReserve { user_id = _userIdentity.Id, house_id = PaidModel.HouseId, preprinted_number = PaidModel.PrePrintedNumber });
         //           await mem.SaveChangesAsync();
         //       }
         //   }

        [HttpPost("paid/add")]
        public async Task<ActionResult<ClsPaidModel>> PaidAdd(ClsPaidModel PaidModel)
        {


            var user = ClsReserveUser.getUserDic(_userIdentity.Id);
            if (user == null)
            {
                ClsReserveUser.addUserDic(_userIdentity.Id, new ClsReserve { houseId = PaidModel.HouseId, prePrintedNumber = PaidModel.PrePrintedNumber });
            }
            else
            {
                if (user.houseId == PaidModel.HouseId && user.prePrintedNumber == PaidModel.PrePrintedNumber)
                {
                    return null;//BadRequest("Double Transaction");
                }

                ClsReserveUser.updateUserDic(_userIdentity.Id, new ClsReserve { houseId = PaidModel.HouseId, prePrintedNumber = PaidModel.PrePrintedNumber });
            }

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                    try
                    {

                        var reg1 = await _context.RegularCollections.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == PaidModel.HouseId && x.CreatedAt > DateTime.Today && x.PreprintedNumber == PaidModel.PrePrintedNumber.Trim() && x.Status == 1);
                        if (reg1 != null) return BadRequest("Today, This house has already pre-printed number!");


                        var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == PaidModel.HouseId && x.Status == 1);
                        if (contract == null) return BadRequest("There is no contract id for this house!");
                        int payment_type = contract.PaymentType ?? 0;
                        string pre_printed_number = PaidModel.PrePrintedNumber;


                        var collection = new RegularCollections()
                        {
                            ProjectId = PaidModel.ProjectId,
                            ContractId = contract.Id,
                            BookingId = contract.BookingId,
                            HouseId = PaidModel.HouseId,
                            CollectionClass = PaidModel.CollectionClass,
                            PayeeId = PaidModel.PayeeId,
                            TotalAmount = PaidModel.TotalAmount,
                            Method1Id = PaidModel.Method1Id,
                            Method1Amount = PaidModel.Method1Amount,
                            Method2Id = PaidModel.Method2Id,
                            Method2Amount = PaidModel.Method2Amount,
                            Method3Id = PaidModel.Method3Id,
                            Method3Amount = PaidModel.Method3Amount,
                            Remark = PaidModel.Remark,
                            RecStatus = 3,
                            CreatedAt = DateTime.Now,
                            CreatedBy = _userIdentity.Id,
                            PaidDate = DateTime.Now,
                            DueDate = DateTime.Now,
                            PreprintedNumber = pre_printed_number,
                            TransactionNo = 0, //Convert.ToInt64(DateTime.Today.ToString("yyMMdd") + auto_number.ToString("0000")),
                            RefNo1 = PaidModel.RefNo1,
                            RefNo2 = PaidModel.RefNo2,
                            RefNo3 = PaidModel.RefNo3,
                            RefDate1 = PaidModel.RefDate1,
                            RefDate2 = PaidModel.RefDate2,
                            RefDate3 = PaidModel.RefDate3,
                            AccountNumber1 = PaidModel.AccountNumber1,
                            AccountNumber2 = PaidModel.AccountNumber2,
                            AccountNumber3 = PaidModel.AccountNumber3,
                            Customer1Id = contract.CurrentCustomer1Id,
                            Customer2Id = contract.CurrentCustomer2Id,
                            PublicServiceDiscount = -PaidModel.PublicServiceDiscountPaid,
                            OverFinalPayment = PaidModel.OverFinalPayment,
                            IsMoved = 0,
                            Status = 1,
                            NumberOfChange = 0
                        };

                        _context.Add(collection);
                        await _context.SaveChangesAsync();

                        PaidModel.RegularCollectionId = collection.Id;
                        bool is_match_condition = false;

                        if (collection.Id > 0)
                        {

                            if (PaidModel.PenaltyPaid > 0)
                            {
                                if (payment_type == 0) await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_penalty_payment {0},{1},{2},1,{3}", collection.Id, collection.HouseId, PaidModel.PenaltyPaid, _userIdentity.Id);
                                else await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_penalty_payment_manual {0},{1},{2},1", collection.Id, collection.HouseId, PaidModel.PenaltyPaid);
                                is_match_condition = true;
                            }

                            if (PaidModel.HousePaid > 0)
                            {

                                if (payment_type == 0) await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_house_payment {0},{1},{2},{3},1", collection.Id, collection.HouseId, PaidModel.HousePaid, PaidModel.MovePrepaidOver);
                                else await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_house_payment_manual {0},{1},{2},1", collection.Id, collection.HouseId, PaidModel.HousePaid);
                                is_match_condition = true;
                            }
                            if (PaidModel.PublicServicePaid > 0)
                            {
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_public_service_payment {0},{1},{2},{3},1", collection.Id, collection.HouseId, PaidModel.PublicServicePaid, PaidModel.PublicServiceDiscountPaid);
                                is_match_condition = true;
                            }

                            if (PaidModel.FinalPaymentPaid > 0)
                            {
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_final_payment {0},{1},{2},{3},{4},1", collection.Id, collection.HouseId, PaidModel.FinalPaymentPaid, PaidModel.InterestPaid, PaidModel.OverFinalPayment);
                                is_match_condition = true;
                            }
                            if (PaidModel.FirstExtraPrinciplePaid > 0)
                            {
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_first_extra_principle_payment {0},{1},{2},1", collection.Id, collection.HouseId, PaidModel.FirstExtraPrinciplePaid);
                                is_match_condition = true;
                            }
                            if (PaidModel.ExtraPrinciplePaid > 0)
                            {
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_extra_principle_payment {0},{1},{2},{3}, 1", collection.Id, collection.HouseId, PaidModel.ExtraPrinciplePaid, PaidModel.InterestPaid);
                                is_match_condition = true;
                            }
                            // if (PaidModel.InterestPaid > 0) await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_interest_payment {0},{1},{2},1", collection.Id, collection.HouseId, PaidModel.InterestPaid);

                            if (is_match_condition)
                            {
                                //refresh penalty
                                if (PaidModel.HousePaid > 0 || PaidModel.PenaltyPaid > 0)
                                {
                                    await _context.Database.ExecuteSqlRawAsync($"exec dbo.sp_penalty_generate {PaidModel.HouseId},'{DateTime.Today.ToString("yyyy-MM-dd")}',{_userIdentity.Id}");                                
                                }

                                await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_regular_collection_detail_method {0}", collection.Id);
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.update_transaction_no {0},{1}", collection.Id, PaidModel.ProjectId);

                                //save to audit log
                                var result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_collection_log] {0},{1},{2}", collection.Id, "Save", _userIdentity.Id);
                                if (result != -1) throw new Exception("Log house collection can not saved!");
                                dbContextTransaction.Commit();

                                return Ok(new { regularCollectionId = collection.Id });
                            }

                        }//else return BadRequest("Transaction flooding, save not success, pls try again."); 
                       
                        dbContextTransaction.Rollback();
                        throw new Exception("Invalid Operation!");

                    }
                    catch (Exception ex)
                    {  //end try

                        ClsReserveUser.updateUserDic(_userIdentity.Id, user);
                        dbContextTransaction.Rollback();
                        return BadRequest("Transaction flooding, save not success, pls try again.");
                    }
                }
           

        }

        [HttpPost("paid/update")]
        public async Task<ActionResult> PaidUpdate(ClsPaidModel PaidModel)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    //using (TransactionScope tran = new TransactionScope())
                    //{

                    var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == PaidModel.HouseId && x.Status == 1);
                    if (contract == null) return BadRequest("There is no contract id for this house!");
                    int payment_type = contract.PaymentType ?? 0;

                    var collection = await _context.RegularCollections.SingleOrDefaultAsync(x => x.Id == PaidModel.RegularCollectionId && x.Status == 1);
                    if (collection == null) return BadRequest("Regular collection id not available");

                   /* collection.ProjectId = PaidModel.ProjectId;
                    collection.HouseId = PaidModel.HouseId;
                    collection.CollectionClass = PaidModel.CollectionClass;
                    collection.PayeeId = PaidModel.PayeeId;
                    collection.TotalAmount = PaidModel.TotalAmount;
                    collection.Method1Id = PaidModel.Method1Id;
                    collection.Method1Amount = PaidModel.Method1Amount;
                    collection.Method2Id = PaidModel.Method2Id;
                    collection.Method2Amount = PaidModel.Method2Amount;
                    collection.Method3Id = PaidModel.Method3Id;
                    collection.Method3Amount = PaidModel.Method3Amount; */
                    collection.Remark = PaidModel.Remark;
                    collection.UpdatedAt = DateTime.Now;
                    collection.UpdatedBy = _userIdentity.Id;
                    // collection.PaidDate = DateTime.Now;
                    // collection.PublicServiceDiscount = PaidModel.PublicServiceDiscountPaid;

                    if (collection.PreprintedNumber.Length == 6)
                    {
                        collection.PreprintedNumber = PaidModel.PrePrintedNumber;
                    }


                   /* collection.RefNo1 = PaidModel.RefNo1;
                    collection.RefNo2 = PaidModel.RefNo2;
                    collection.RefNo3 = PaidModel.RefNo3;
                    collection.RefDate1 = PaidModel.RefDate1;
                    collection.RefDate2 = PaidModel.RefDate2;
                    collection.RefDate3 = PaidModel.RefDate3;
                    collection.AccountNumber1 = PaidModel.AccountNumber1;
                    collection.AccountNumber2 = PaidModel.AccountNumber2;
                    collection.AccountNumber3 = PaidModel.AccountNumber3;
                    collection.Customer1Id = contract.CurrentCustomer1Id;
                    collection.Customer2Id = contract.CurrentCustomer2Id; */
                    collection.NumberOfChange += 1;

                    await _context.SaveChangesAsync();

                    string sql = "exec [dbo].[is_change_collection_method] " + collection.Id + ",@result={0} out";
                    var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    await _context.Database.ExecuteSqlRawAsync(sql, result);

                    int nrow = (int)result.Value;
                    if (nrow > 0) //if collection method change 
                    {
                        await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_regular_collection_detail_method {0}", collection.Id);
                    }

                    //tran.Complete();
                    //save to audit log
                    var audit_result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[house_collection_log] {0},{1},{2}", collection.Id, "Update", _userIdentity.Id);
                    if (audit_result != -1) throw new Exception("Log house collection can not updated!");
                    dbContextTransaction.Commit();

                    return Ok(new { regularCollectionId = collection.Id });

                    //}
                }
                catch (Exception ex)
                {                    
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("paid/delete")]
        public ActionResult PaidDelete(ClsPaidModel PaidModel)
        {

            int result = _context.Database.ExecuteSqlRaw("exec dbo.sp_remove_receipt {0},{1}", PaidModel.RegularCollectionId, _userIdentity.Id);
            if (result == -1) return Ok("success");
            else return BadRequest("operation fail");   
        }

        [HttpGet("waive/transaction-type")]
        public async Task<IEnumerable<object>> WaiveTransactionType()
        {
               return await _context.WaiveTransactionType.Select(x => new { Id = x.Id, TransactionType = x.WaiveTransactionType1 }).ToListAsync();
        }
        [HttpPost("waive/approved/{ref_id}")]
        public async Task<ActionResult> PaymentWaiveApproved(int ref_id)
        {
            try
            {
                    var waive_payment = await _context.WaivePayments.AsNoTracking().SingleOrDefaultAsync(x => x.Id == ref_id && x.Status==1 && x.RecStatus == WorkflowStatusModel.APPROVED);
                    byte waive_type = waive_payment.WaiveTransactionTypeId ?? 0;
                    int house_id = waive_payment.HouseId ?? 0;
                    decimal waive_amount = waive_payment.WaiveAmount ?? 0;
                    int waive_payment_id = waive_payment.Id;

                    int result = 0;
                    switch (waive_type)
                    {
                        case 1: //house interest

                            result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_waive_house_interest {0},{1},{2}", house_id, waive_amount, waive_payment_id);
                            break;

                        case 2: //final interest

                            result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_waive_final_interest {0},{1},{2}", house_id, waive_amount, waive_payment_id);
                            break;

                        case 3: //Penalty
                            result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_waive_penalty {0},{1},{2}", house_id, waive_amount, waive_payment_id);
                            break;

                        case 4: //Public Service
                            result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_waive_public_service {0},{1},{2}", house_id, waive_amount, waive_payment_id);
                            break;

                        case 5: //Reschedule Interest
                        result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_waive_reschedule_interest {0},{1},{2}", house_id, waive_amount, waive_payment_id);
                        break;

                }

                    if (result == -1) return Ok("success");
                    else return BadRequest("operation fail");

            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }                
           
        }
        [HttpGet("regular-collection/house/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetRegularCollectionByHouseId(int house_id)
        {
            return Ok(await _context.VRegularCollectionByHouse.Where(x => x.HouseId == house_id && x.TotalAmount>0)
                   .Select(x => new { RegularCollectionId = x.Id, TransactionNo = x.TransactionNo,TotalPaid =""+x.TotalAmount??0.ToString("$ #,##0.00"),
                                      Method1=x.MethodName1+": "+x.Method1Amount??0.ToString("$ #,##0.00"),
                                      Method2=(x.MethodName2==null?"": x.MethodName2 + ": " + x.Method2Amount??0.ToString("$ #,##0.00")),
                                      Method3=(x.MethodName3==null?"": x.MethodName3 + ": " + x.Method3Amount??0.ToString("$ #,##0.00")),
                                      PaidDate = x.PaidDate, PreprintedNumber = x.PreprintedNumber
                   })
                   .OrderByDescending(x => x.PaidDate).ThenByDescending(x => x.RegularCollectionId)
                   .Take(10)                   
                   .ToListAsync());
        }
        [HttpGet("regular-collection/detail/{regular_collection_id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetRegularCollectionDetailById(int regular_collection_id)
        {
            return Ok(await _context.VRegularCollectionDetails.Where(x=>x.RegularCollectionId==regular_collection_id)
                      .Select(x=>new {RegularCollectionDetailId=x.Id, TransactionType=x.TransactionName,Paid=""+x.Amount??0.ToString("$ #,##0.00") })
                      .ToListAsync()
                    );
        }
                

       [HttpGet("manual/house/{house_id}")]
        public async Task<ActionResult<IEnumerable<object>>> ManualByHouse(int house_id)
        {
            try
            {
                var data = _context.PaymentSchedulesManual.FromSqlRaw("exec dbo.sp_get_payment_manual_by_houseid {0}", house_id).AsEnumerable().ToList();
                if (data == null) return BadRequest("No manual payment for this house!");
                return Ok(data);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            

            //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
        }

        [HttpGet("manual")]
        public async Task<ActionResult<object>> ManualGetPagination([FromQuery] PaginationFilter filter)
        {
            return await new CrudLib<VPaymentSchedulesInfoAll>(_context, _userIdentity.Id).GetDataProHouse(filter);
        }

        [HttpGet("manual/{id}")]
        public async Task<ActionResult<WorkflowModel>> ManualGet(int id)
        {
            var data = await _context.VPaymentSchedulesInfoAll.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.payment_schedules_info", data.Id, _userIdentity.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("manual/add")]
        public async Task<ActionResult<PaymentSchedulesInfo>> PaymentManualAdd(PaymentSchedulesInfo data)
        {
            try
            {
                var contract = await _context.Contracts.AsNoTracking().SingleOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status==1 && x.RecStatus == 3);
                if (contract == null) return BadRequest("house payment manual is not available!");

                data.Status = 1;
                data.RecStatus = 0;
                data.ContractId = contract.Id;
                data.RescheduleNo = contract.RescheduleCount + 1;

                data.AddPrinciple = 0;
                data.PaidOffAmount = 0;
                data.PaidOffType = "m";
                data.InterestPercentMonth = 1;
                
                CrudLib<PaymentSchedulesInfo> crud = new CrudLib<PaymentSchedulesInfo>(_context, _userIdentity.Id);
                data = (PaymentSchedulesInfo)await crud.Add(data, "dbo.payment_schedules_info", true, "create payment term");

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("manual/update")]
        public async Task<ActionResult<PaymentSchedulesInfo>> PaymentManualUpdate(PaymentSchedulesInfo data)
        {
            try
            {

                var manual = await _context.PaymentSchedulesInfo.AsNoTracking().SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1);
                if(manual==null)
                {
                    return BadRequest("Invalid house payment manual id to update!");
                }
                data.Status = 1;
                data.RecStatus = 0;
                data.ContractId = manual.ContractId;
                data.RescheduleNo = manual.RescheduleNo;

                data.AddPrinciple = manual.AddPrinciple;
                data.PaidOffAmount = 0;
                data.PaidOffType = "m";
                data.InterestPercentMonth = 1;

                CrudLib<PaymentSchedulesInfo> crud = new CrudLib<PaymentSchedulesInfo>(_context, _userIdentity.Id);
                data = (PaymentSchedulesInfo) await crud.Update(data, "dbo.payment_schedules_info");

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("manual/delete")]
        public async Task<IActionResult> PaymentManualDelete(HousePaymentManual data)
        {
           
            try
            {

                var data_delete = await _context.PaymentSchedulesInfo.SingleOrDefaultAsync(x=>x.Id==data.Id && x.Status==1 && x.RecStatus==WorkflowStatusModel.DRAFT);

                if (data_delete == null)
                {
                    return BadRequest();
                }

                data_delete.Status = 0;                
                await _context.SaveChangesAsync();
                return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("manual/rejected/{refId}")]
        public async Task<IActionResult> PaymentManualRejected(int refId)
        {

            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_house_payment_manual_rejected {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("manual/approved/{refId}")]
        public async Task<IActionResult> PaymentManualApproved(int refId)
        {

            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_house_payment_manual_approved {0},{1}", refId, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("operation fail");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("manual-schedule/manual/{id}")]
        public async Task<ActionResult<IEnumerable<object>>> ManualSchedulwByManualId(int id)
        {
            try
            {
                var data = _context.PaymentSchedulesManual.FromSqlRaw("exec dbo.sp_get_payment_manual_by_manualid {0}", id).AsEnumerable().ToList();
                if (data == null) return BadRequest("No manual-schedule for this id!");
                return Ok(data);

            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
            //return await _context.PenaltyPayment.Where(x => x.HouseId == house_id && x.Penalty > 0 && x.Penalty != x.Paid).ToListAsync();
        }

        [HttpPost("manual-schedule/update/{id}")]
        public async Task<IActionResult> PaymentManualScheduleUpdate(int id, List<PaymentSchedulesManual> data)
        {

            try
            {

                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_payment_manual_schedule_check {0}", id);
                if (result != -1) return BadRequest("operation fail");

                foreach (PaymentSchedulesManual item in data)
                {
                     item.PaymentScheduleInfoId = id;
                     item.PaidInterest = 0;
                     item.PaidPrinciple = 0;
                     item.PaidFreezPenalty = 0;
                     item.ReceiptNo = 0;
                     item.RefNo = 0;
                     item.PaidDate = null;                     
                     item.CurrentPaidPrinciple = 0;
                     item.CurrentPaidInterest = 0;
                     item.CurrentPaidFreezPenalty = 0;                     
                     _context.PaymentSchedulesManual.Add(item);
                }
                await _context.SaveChangesAsync(); 
                return Ok("success");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
         }


        [HttpPost("other-collection/add")]
        public async Task<ActionResult<object>> OtherCollectionAdd(ClsOtherCollections data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {
                    /* double minute=100;   
                    var reg1 = _context.RegularCollections.AsNoTracking().Where(x => x.HouseId == data.HouseId && x.Status == 1).OrderByDescending(x => x.CreatedAt).FirstOrDefault();                        
                    if (reg1 != null) { TimeSpan? ts = DateTime.Now - (DateTime?)reg1.CreatedAt; minute = ts.Value.TotalMinutes; }
                    if (minute >= 1) 
                    {  */
                    int? contract_id = null;
                    int? booking_id = null;
                    int? customer_id1 = null;
                    int? customer_id2 = null;

                    data.HouseId = data.HouseId ?? 0;
                    if (data.HouseId != 0)
                    {
                        var contracts = await _context.Contracts.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                        if (contracts != null)
                        {
                            contract_id = contracts.Id;
                            booking_id = contracts.BookingId;
                            customer_id1 = contracts.CurrentCustomer1Id;
                            customer_id2 = contracts.CurrentCustomer2Id;
                        }
                        else
                        {
                            var bookings = await _context.Bookings.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                            if (bookings != null)
                            {
                                booking_id = bookings.Id;
                                customer_id1 = bookings.CurrentCustomer1Id;
                                customer_id2 = bookings.CurrentCustomer2Id;
                            }
                        }
                    }

                    string sql = "exec [dbo].[get_auto_number] @result={0} out";
                    var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
                    await _context.Database.ExecuteSqlRawAsync(sql, result);
                    int auto_number = (int)result.Value;

                    string pre_printed_number = data.PreprintedNumber;

                    if (data.ProjectId > 1)
                    {
                        sql = "exec [dbo].[sp_generate_preprinted_number]  {0}, @result={1} out";
                        result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.VarChar, 30) { Direction = ParameterDirection.Output };
                        await _context.Database.ExecuteSqlRawAsync(sql, data.ProjectId, result);
                        pre_printed_number = result.Value.ToString();

                    }

                    var reg = new RegularCollections()
                    {
                        ProjectId = data.ProjectId,
                        HouseId = data.HouseId ?? 0,
                        BookingId = booking_id,
                        ContractId = contract_id,
                        CollectionClass = null,
                        PayeeId = null,
                        TotalAmount = data.TotalAmount,
                        Method1Id = data.Method1Id,
                        Method1Amount = data.Method1Amount,
                        Method2Id = data.Method2Id,
                        Method2Amount = data.Method2Amount,
                        Method3Id = data.Method3Id,
                        Method3Amount = data.Method3Amount,
                        RefNo1 = data.RefNo1,
                        RefNo2 = data.RefNo2,
                        RefNo3 = data.RefNo3,
                        RefDate1 = data.RefDate1,
                        RefDate2 = data.RefDate2,
                        RefDate3 = data.RefDate3,
                        Remark = data.Remark,
                        RecStatus = 3,
                        ReceivedBy = _userIdentity.Id,
                        CreatedAt = DateTime.Now,
                        CreatedBy = _userIdentity.Id,
                        PaidDate = DateTime.Now,
                        DueDate = DateTime.Now,
                        PreprintedNumber = pre_printed_number,
                        TransactionNo = Convert.ToInt64(DateTime.Today.ToString("yyMMdd") + auto_number.ToString("0000")),
                        AccountNumber1 = data.AccountNumber1,
                        AccountNumber2 = data.AccountNumber2,
                        AccountNumber3 = data.AccountNumber3,
                        Customer1Id = customer_id1,
                        Customer2Id = customer_id2,
                        IsMoved = 0,
                        Status = 1,
                        NumberOfChange = 0
                    };

                    _context.RegularCollections.Add(reg);
                    await _context.SaveChangesAsync();

                    var other = new OtherCollectionInfo()
                    {
                        RegularCollectionId = reg.Id,
                        TransactionCategoryId = data.TransactionCategoryId,
                        OtherCustomer = data.OtherCustomer,
                        PhoneContact = data.PhoneContract,
                        Status = 1
                    };

                    _context.OtherCollectionInfo.Add(other);

                    var collection_detail = new RegularCollectionsDetails()
                    {
                        RegularCollectionId = reg.Id,
                        Amount = data.TotalAmount,
                        TransactionTypeId = data.TransactionTypeId,
                        RecStatus = 3,
                        CreatedAt = DateTime.Now,
                        Status = 1
                    };

                    _context.RegularCollectionsDetails.Add(collection_detail);
                    //_context.RegularCollectionsDetails.

                    await _context.SaveChangesAsync();
                    data.Id = reg.Id;

                    await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_regular_collection_detail_method {0}", data.Id);
                    //  lock(new object())
                    // {
                    await _context.Database.ExecuteSqlRawAsync("exec dbo.update_transaction_no {0},{1}", data.Id, data.ProjectId);
                    //tran.Complete();
                    //}  
                    //save to audit log
                    var audit_result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[other_collection_log] {0},{1},{2}", data.Id, "Save", _userIdentity.Id);
                    if (audit_result != -1) throw new Exception("Log other collection can not saved!");
                    dbContextTransaction.Commit();

                    return Ok(data);
                    // }                       

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPost("other-collection/update")]
        public async Task<ActionResult<object>> OtherCollectionUpdate(ClsOtherCollections data)
        {

            using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
            {

                try
                {

                            var reg = await _context.RegularCollections.SingleOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);

                            if (reg == null)
                            {
                                return BadRequest("Invalid regular collection id");
                            }

                            int? contract_id = null;
                            int? booking_id = null;
                            int? customer_id1 = null;
                            int? customer_id2 = null;

                            data.HouseId = data.HouseId ?? 0;
                            if (data.HouseId != 0)
                            {
                                var contracts = _context.Contracts.AsNoTracking().FirstOrDefault(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                                var bookings = _context.Bookings.AsNoTracking().FirstOrDefault(x => x.HouseId == data.HouseId && x.Status == 1 && x.RecStatus == 3);
                                if (contracts != null)
                                {
                                    contract_id = contracts.Id;
                                    customer_id1 = contracts.CurrentCustomer1Id;
                                    customer_id2 = contracts.CurrentCustomer2Id;
                                }
                                if (bookings != null)
                                {
                                    booking_id = bookings.Id;
                                    customer_id1 = bookings.CurrentCustomer1Id;
                                    customer_id2 = bookings.CurrentCustomer1Id;
                                }
                            }

                            var other = await _context.OtherCollectionInfo.SingleOrDefaultAsync(x => x.RegularCollectionId == data.Id && x.Status == 1);
                            var collection_detail = await _context.RegularCollectionsDetails.SingleOrDefaultAsync(x => x.RegularCollectionId == data.Id && x.Status == 1);

                            reg.ProjectId = data.ProjectId;
                            reg.HouseId = data.HouseId ?? 0;
                            reg.BookingId = booking_id;
                            reg.ContractId = contract_id;
                            reg.TotalAmount = data.TotalAmount;
                            reg.Method1Id = data.Method1Id;
                            reg.Method1Amount = data.Method1Amount;
                            reg.Method2Id = data.Method2Id;
                            reg.Method2Amount = data.Method2Amount;
                            reg.Method3Id = data.Method3Id;
                            reg.Method3Amount = data.Method3Amount;
                            reg.RefNo1 = data.RefNo1;
                            reg.RefNo2 = data.RefNo2;
                            reg.RefNo3 = data.RefNo3;
                            reg.RefDate1 = data.RefDate1;
                            reg.RefDate2 = data.RefDate2;
                            reg.RefDate3 = data.RefDate3;
                            reg.Remark = data.Remark;
                            reg.ReceivedBy = _userIdentity.Id;
                            reg.UpdatedAt = DateTime.Now;
                            // reg.PaidDate = DateTime.Now;
                            reg.UpdatedBy = _userIdentity.Id;
                            reg.PreprintedNumber = data.PreprintedNumber;
                            reg.AccountNumber1 = data.AccountNumber1;
                            reg.AccountNumber2 = data.AccountNumber2;
                            reg.AccountNumber3 = data.AccountNumber3;
                            reg.Customer1Id = customer_id1;
                            reg.Customer2Id = customer_id2;
                            reg.NumberOfChange += 1;

                            other.OtherCustomer = data.OtherCustomer;
                            other.PhoneContact = data.PhoneContract;
                            other.TransactionCategoryId = data.TransactionCategoryId;

                            collection_detail.TransactionTypeId = data.TransactionTypeId;
                            collection_detail.Amount = data.TotalAmount;

                            await _context.SaveChangesAsync();

                            string sql = "exec [dbo].[is_change_collection_method] " + data.Id + ",@result={0} out";
                            var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
                            await _context.Database.ExecuteSqlRawAsync(sql, result);

                            int nrow = (int)result.Value;
                            if (nrow > 0) //if collection method change 
                            {
                                await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_regular_collection_detail_method {0}", data.Id);
                                //_context.Database.ExecuteSqlRaw("exec dbo.sp_regular_collection_detail_method {0}", collection.Id);
                            }

                            var audit_result = await _context.Database.ExecuteSqlRawAsync("exec [audit].[other_collection_log] {0},{1},{2}", data.Id, "Update", _userIdentity.Id);
                            if (audit_result != -1) throw new Exception("Log other collection can not updated!");
                            dbContextTransaction.Commit();

                            return Ok();

                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    return BadRequest(ex.Message);
                }
            }

        }

        [HttpGet("other-collection")]
        public async Task<ActionResult<object>> GetOtherCollection([FromQuery] PaginationFilter filter)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string sql = "exec dbo.get_other_regular_collection_filter {0},{1},{2}";

            var data = _context.VOtherCollection
                                .FromSqlRaw(sql, _userIdentity.Id, filter.ProId ?? 0, validFilter.Search ?? "").AsEnumerable();

            validFilter.TotalRecords = data.Count();

            var pagedData = data.OrderByDescending(x => x.CreatedAt)
                                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                                .Take(validFilter.PageSize)
                                .ToList();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("other-collection/{id}")]
        public async Task<ActionResult<object>> GetOtherCollectionById(int id)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            var collection = await _context.VOtherCollection.FirstOrDefaultAsync(x => x.Id == id);
            if (collection == null)
            {
                return BadRequest("Invalid regular collection id:"+id);
            }
            return Ok(collection);
            
        }

        [HttpPost("cancel-receipt/{id}")]
        public async Task<ActionResult<object>> CancelCollectionById(int id)
        {
            //return await new CrudLib<VRegularCollection>(_userIdentity.Id).GetDataProHouse(filter);
            try
            {
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.cancel_regular_collection_receipt {0},{1}", id, _userIdentity.Id);
                if (result == -1) return Ok("success");
                else return BadRequest("Receipt can not be cancelled");

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        /* [HttpPost("manual-schedule/paid")]
         public async Task<IActionResult> PaymentManualScheduleSave(List<PaymentSchedulesManual> data)
         {

             try
             {              

                 foreach (PaymentSchedulesManual item in data)
                 {
                     if (item.IsUpdated == 1)
                     {
                         var psm = await _context.PaymentSchedulesManual.FindAsync(item.Id);
                         psm.PaidInterest = item.PaidInterest;
                         psm.PaidPrinciple = item.PaidPrinciple;
                         psm.ReceiptNo = item.ReceiptNo;
                         psm.RefNo = item.RefNo;
                         psm.PaidDate = item.PaidDate;
                         psm.ReceivedAmount = item.ReceivedAmount;
                         psm.Remark = item.Remark;
                         psm.PaidFreezPenalty=item.paid
                         await _context.SaveChangesAsync();
                     }
                 }
                 //await _context.SaveChangesAsync();
                 return Ok("success");
             }
             catch (Exception ex)
             {
                 return BadRequest(ex.Message);
             }
         }*/

    }
}