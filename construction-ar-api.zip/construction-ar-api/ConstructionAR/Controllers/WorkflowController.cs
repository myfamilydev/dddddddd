﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Libraries;
using DataAccess.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using Telegram.Bot;

namespace ConstructionAR.Controllers
{
    [Route("api/v1/workflows")]
    [ApiController]
    [Authorize]
    //[Web.Models.CustomAuthorize()]
    public class WorkflowController : Controller
    {
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;
        public WorkflowController(MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {           
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _config = config;

            // if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpPost("submit")]
        [Obsolete]
        public async Task<ActionResult<WorkflowDetail>> WorkflowSubmit(WorkflowSubmit data)
        {

                using (var dbContextTransaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable))
                {

                    try
                    {

                            var wf = await _context.WorkflowDetail.AsNoTracking().SingleOrDefaultAsync(x => x.WfDetailUuid == data.WfDetailUuid);

                            if (wf != null)
                            {
                                var workflow = _context.Workflow.AsNoTracking().SingleOrDefault(x => x.Id == wf.WorkflowId);
                                string action_label = wf.ActionLabel;
                                string workflow_name = wf.WorkflowLabel;
                                string content1 = wf.Content1;
                
                                string table_name = _context.Workflow.AsNoTracking().SingleOrDefault(x => x.Id == wf.WorkflowId).WorkflowName;
                                string sql = "exec dbo.sp_workflow_submit  @table_name = '" + table_name + "', @ref_id = " + data.RefId + ", @rec_status = " + wf.PostStatus;
                                List<ExecuteAffectedRow> result;

                                using (var _manual = new ManualDbContext())
                                {
                                    result = _manual.ExecuteAffectedRow.FromSqlRaw(sql).ToList();
                                    if (result[0].affected_row == 0) return BadRequest("Can not update workflow status!");
                                }

                                try
                                {

                                  /*  if (wf.Id == 145) //Cashier submit waive
                                    {
                                        var waive_payment =await _context.WaivePayments.FindAsync(data.RefId);
                                        content1 = ", Let AR Manager Approve";
                                        if (waive_payment.WaiveAmount > 500)
                                        {                            
                                            content1 = ", Let CFO Approve";
                                            waive_payment.RecStatus = 2;
                                            _context.SaveChanges();
                                        }
                                    } */

                                    byte? is_done = 1;

                                    // update status in workflow history
                                    if (wf.PostStatus == 0)
                                    {
                                        is_done = null;

                                        sql = @" update dbo.workflow_history
                                                        set is_done = null
                                                        where workflow_id = {0}
                                                        and ref_id = {1}";

                                        _ = _context.Database.ExecuteSqlCommand(sql, wf.WorkflowId, data.RefId);
                                    }

                                    WorkflowHistory workflowHistory = new WorkflowHistory
                                    {
                                        WorkflowId = wf.WorkflowId,
                                        RefId = data.RefId,
                                        RecStatus = wf.CurStatus,
                                        PostStatus = wf.PostStatus,
                                        IsDone = is_done,
                                        Comment = data.Comment,
                                        CreatedAt = DateTime.Now,
                                        CreatedBy = _userIdentity.Id
                                    };

                                    _context.WorkflowHistory.Add(workflowHistory);
                                    await _context.SaveChangesAsync();

                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine(e.Message);
                                    return StatusCode(StatusCodes.Status500InternalServerError);
                                }

                                //var postStatusName = _context.WorkflowStatus.Find(wf.PostStatus).StatusName;
                                var notif = await _context.WorkflowNotifContent.FindAsync(wf.EmailContentId);

                                string subject = notif.NotifSubject;

                                NotifModel notifModel = new NotifModel();

                                if (!notif.ParamJson.Equals(""))
                                {
                                    using (var _manual = new ManualDbContext())
                                    {
                                        notifModel = await _manual.NotifModel.FromSqlRaw(notif.ParamJson, data.RefId).SingleAsync();
                                    }
                                }

                                if (wf.ExecuteApiId != null)
                                {
                                    string AppBaseUrl = this.Request.Scheme + "://" + this.Request.Host + this.Request.PathBase + "/api/v1/";
                                    var api = _context.WorkflowApi.Find(wf.ExecuteApiId);

                                    var client = new RestClient(AppBaseUrl + api.Url + data.RefId);
                                    client.Timeout = -1;
                                    var request = new RestRequest(Method.POST);

                                    request.AddHeader("Authorization", this.Request.Headers["Authorization"]);
                                    client.Execute(request);
                                    //IRestResponse response = client.Execute(request);
                                    //return StatusCode((int)response.StatusCode);
                                }

                                if (wf.WorkflowId == 14)
                                {
                                    var waives = await _context.WaivePayments.Join(
                                                                                     _context.WaiveTransactionType,
                                                                                     wp => wp.WaiveTransactionTypeId,
                                                                                     wtt => wtt.Id,
                                                                                     (wp, wtt) => new
                                                                                     {
                                                                                         WaivePaymentId = wp.Id,
                                                                                         WaiveTransactionType = wtt.WaiveTransactionType1
                                                                                     }
                                                                                   ).SingleOrDefaultAsync(x => x.WaivePaymentId == data.RefId);

                                    workflow_name = "Waive " + waives.WaiveTransactionType;


                                }

                                subject = subject.Replace("{user_full_name}", _userIdentity.FullName);
                                subject = subject.Replace("{status}", action_label);
                                subject = subject.Replace("{action_label}", workflow_name);
                                subject = subject.Replace("{house_type}", notifModel.HouseType);
                                subject = subject.Replace("{house_no}", notifModel.HouseNo);
                                subject = subject.Replace("{project}", notifModel.Project);
                                subject = subject.Replace("{content1}", content1);

                                //subject += "\nComment: " + data.Comment + "\n<a href=\"" + notif.NotifTo + data.RefId +"\">Click here</a>";
                                string url_real = "http://192.168.1.88:4002/#/pages/" + notif.NotifTo + data.RefId;
                                string url = "https://app.bvmpp.com:8081/%23/pages/" + notif.NotifTo + data.RefId;
                                string telURL = "https://senoirreport.page.link/?link="+url+"&apn=com.bvmpp.approval&afl="+url;
                                string comment = "Comment: " + data.Comment;

                                var wf_role = await _context.WorkflowDetail.AsNoTracking().FirstOrDefaultAsync(x => x.WorkflowId==wf.WorkflowId && x.CurStatus==wf.PostStatus);
                
                
                                _context.TelegramLog.Add(new TelegramLog()
                                {
                                    RefId = data.RefId,
                                    WorkflowId = wf.WorkflowId,
                                    TelegramContent = subject,
                                    TelegramGroupId = wf.SmsContentId,
                                    CreatedAt = DateTime.Now,
                                    CreatedBy = _userIdentity.Id,
                                    RoleId = wf_role == null ? wf.CurRole : wf_role.CurRole,
                                    Comment = comment,
                                    UserName = _userIdentity.FullName,
                                    ActionLabel = action_label,
                                    WorkflowName = workflow_name,
                                    HouseType = notifModel.HouseType,
                                    HouseNo = notifModel.HouseNo,
                                    Project = notifModel.Project,
                                    Content1 = content1,
                                    Url = url_real
                                });

                                _context.AuditLog.Add(new AuditLog()
                                {
                                    ProjectId = notifModel.ProjectId,
                                    HouseId = notifModel.HouseId,
                                    Project = notifModel.Project,
                                    HouseNumber = notifModel.HouseNo,
                                    BookingId = notifModel.BookingId,
                                    ContractId = notifModel.ContractId,
                                    Action = action_label + "-Workflow",
                                    UserPageId = workflow.UserPageId,
                                    ModuleName = workflow.ModuleName,
                                    CustomerName1 = notifModel.CustomerName1,
                                    CustomerName2 = notifModel.CustomerName2,
                                    CustomerRelationship = notifModel.CustomerRelationship,
                                    Description = comment,
                                    RefId = data.RefId,
                                    CreatedAt = DateTime.Now,
                                    InDate = DateTime.Now,
                                    CreatedBy = _userIdentity.Id,
                                    CreatedByName = _userIdentity.UserName,
                                    Remark = ""
                                });

                                await _context.SaveChangesAsync();
                                dbContextTransaction.Commit();
                                //Push notification to telegram bot group
                                //Comment old logic notify by UserRole

                                //var botGroupId = _context.UsersRoles.SingleOrDefault(x => x.Id == wf.CurRole);

                                //if (botGroupId != null && botGroupId.TelegramGroupId != null)
                                if (wf.SmsContentId != null)
                                {

                                        int TelegramGroupId = (int) wf.SmsContentId;
                                        TelegramBot tele = new TelegramBot();                                 
                                        subject+= "\n<i>Comment: " + data.Comment + "</i>\n<a target='_blank' href='" + telURL + "'>" + HttpUtility.UrlDecode(url) + "</a>";


                                        if (TelegramGroupId== -574962292) //AR + Sale Group
                                        {
                                            //sent direct to Sale Group
                                            await tele.bot.SendTextMessageAsync(-590782977, subject, Telegram.Bot.Types.Enums.ParseMode.Html);
                                            await tele.bot.SendTextMessageAsync(-595777155, subject, Telegram.Bot.Types.Enums.ParseMode.Html);
                                        }
                                        else
                                        {
                                            await tele.bot.SendTextMessageAsync(TelegramGroupId, subject, Telegram.Bot.Types.Enums.ParseMode.Html);
                                        }
                                 
                                }
                                
                                return Ok();

                         } //end if wf!=null

                    }catch(Exception ex)
                    {
                            dbContextTransaction.Rollback();
                            return BadRequest(ex.Message);
                    }
                    return BadRequest("Invalid workflow operation!");
                            
                } //end using

        }

        [HttpPost("notifications/update-check")]
        public async Task<IActionResult> NotificationCheck(DeleteModel data)
        {
            var notif = _context.WorkflowNotifications.SingleOrDefault(x => x.Id == data.Id && x.IsCheck == 0 && x.ToUserId == _userIdentity.Id);

            if (notif == null)
            {
                return NoContent();
            }

            notif.IsCheck = 1;
            notif.UpdatedAt = DateTime.Now;

            try
            {
                _context.Entry(notif).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch
            {
                throw;
            }

            return Ok();

        }

        [HttpPost("notifications/mark-as-read")]
        [Obsolete]
        public IActionResult NotificationMaskAsRead()
        {
            string sql = @" update dbo.workflow_notifications
                            set is_check = 1,
                                updated_at = getdate()
                            where to_user_id = {0}
                            and is_check = 0
                        ";


            try
            {
                _ = _context.Database.ExecuteSqlCommand(sql, _userIdentity.Id);
            }
            catch
            {
                throw;
            }

            return Ok();

        }

        [HttpPost("notifications/clear-all")]
        [Obsolete]
        public IActionResult NotificationClearAll()
        {
            string sql = @" delete
                            from dbo.workflow_notifications
                            where to_user_id = {0}
                            and is_check = 1
                        ";

            try
            {
                _ = _context.Database.ExecuteSqlCommand(sql, _userIdentity.Id);
            }
            catch
            {
                throw;
            }

            return Ok();

        }

        [HttpPost("notifications/delete")]
        [Obsolete]
        public async Task<IActionResult> NotificationClearAllAsync(DeleteModel data)
        {
            var data_delete = await _context.WorkflowNotifications.FindAsync(data.Id);

            try
            {
                _context.WorkflowNotifications.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("notifications")]
        public async Task<ActionResult<IEnumerable<VWorkflowNotifications>>> GetAllNotification()
        {
            return await _context.VWorkflowNotifications.Where(x => x.ToUserId == _userIdentity.Id).ToListAsync();
        }

        [HttpGet("notifications/top")]
        public async Task<ActionResult<IEnumerable<VWorkflowNotifications>>> GetNotificationTop()
        {
            return await _context.VWorkflowNotifications.Where(x => x.ToUserId == _userIdentity.Id).Take(20).ToListAsync();
        }

        [HttpPost("notifications/telegram")]
        [Obsolete]
        public async Task<IActionResult> NotificationTelegram(Projects data)
        {
            TelegramBot tele = new TelegramBot();

            try
            {
                await tele.bot.SendTextMessageAsync(-420540540, data.Remark, Telegram.Bot.Types.Enums.ParseMode.Html);
            }
            catch
            {
                throw;
            }


            return Ok();

        }
    }

}
