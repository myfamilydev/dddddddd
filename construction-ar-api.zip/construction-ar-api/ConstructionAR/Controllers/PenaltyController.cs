﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Entities.Customize;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/penalty")]
    [ApiController]
    [Authorize]
    //[Models.CustomAuthorize()]
    public class PenaltyController : Controller
    {
        private readonly ARContext _arcontext;
        private readonly MayuraContext _context;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private userIdentity _userIdentity;

        public PenaltyController(ARContext arcontext, MayuraContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            
            _httpContextAccessor = httpContextAccessor;
            _arcontext = arcontext;
            _context = context;
            _config = config;

            //if (_httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
            _userIdentity = new userIdentity();
            _userIdentity.SetUserByClaim(_httpContextAccessor.HttpContext.User.Identity as ClaimsIdentity);
        }

        [HttpGet("penalty-list/{house_id}")]
        public ActionResult<IEnumerable<object>> Penaltylist(int house_id)
        {
            return _context.PenaltySchedule.FromSqlRaw("exec dbo.sp_get_penalty_schedule {0}", house_id).AsEnumerable().ToList();
        }

        [HttpGet("penalty-list1/{contract_id}")]
        public ActionResult<IEnumerable<object>> Penaltylist1(int contract_id)
        {
            return _context.PenaltySchedule.FromSqlRaw("exec dbo.sp_get_penalty_schedule_1 {0}", contract_id).AsEnumerable().ToList();
        }

        [HttpGet("penalty-detail/{house_id}")]
        public ActionResult<IEnumerable<object>> Penaltydetail(int house_id)
        {
            return _context.PenaltyScheduleDetail.FromSqlRaw("exec dbo.sp_get_penalty_schedule_detail {0}", house_id).AsEnumerable().ToList();
        }

        [HttpGet("penalty-detail1/{contract_id}")]
        public ActionResult<IEnumerable<object>> Penaltydetail1(int contract_id)
        {
            return _context.PenaltyScheduleDetail.FromSqlRaw("exec dbo.sp_get_penalty_schedule_detail_1 {0}", contract_id).AsEnumerable().ToList();
        }

        [HttpPost("change-enddate")]
        public async Task<ActionResult<object>> ChangeEnddate(ClsChangeEnddate data)
        {
            try
            {
                ApiResponse res = new ApiResponse();
                var result = await _context.Database.ExecuteSqlRawAsync("exec dbo.sp_penalty_change_enddate {0},{1},{2},{3}", data.PenaltyPaymentId, data.EndDate, data.option, _userIdentity.Id);
                if (result == -1)
                {
                    res.code = "0";
                    res.message = "success";
                    return Ok(res);
                }
                else
                {
                    res.code = "5400";
                    res.message = "Can not change end date";
                    return BadRequest(res);
                }


            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("date-test")]
        public ActionResult<object> PenaltyDateTest(ClsPenaltyTestDateInput data)
        {
            return _context.PenaltyTestDateResult.FromSqlRaw("exec dbo.get_penalty_test_date {0},{1}", data.PenaltyPaymentId, data.TestDate).AsEnumerable().SingleOrDefault();
        }

        [HttpGet("total-info/{house_id}")]
        public ActionResult<object> PenaltyTotalLateDay(int house_id)
        {
            return _context.TotalInfo.FromSqlRaw("exec dbo.sp_get_total_info {0}", house_id).AsEnumerable().SingleOrDefault();
        }

    }
}
