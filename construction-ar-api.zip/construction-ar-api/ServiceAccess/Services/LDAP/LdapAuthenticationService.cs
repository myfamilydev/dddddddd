﻿using aspnetcore.ldap.Models;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Novell.Directory.Ldap;
using System.Text.RegularExpressions;

namespace aspnetcore.ldap.Services
{
    public class LdapAuthenticationService : IAuthenticationService
    {
        private const string MemberOfAttribute = "memberOf";
        private const string DisplayNameAttribute = "displayName";
        private const string SAMAccountNameAttribute = "sAMAccountName";
        private const string MailAttribute = "mail";

        private readonly LdapConfig _config;
        private readonly LdapConnection _connection;

        public LdapAuthenticationService(IOptions<LdapConfig> configAccessor)
        {
            _config = configAccessor.Value;
            _connection = new LdapConnection();
        }

        public IAppUser Login(string username, string password)
        {
            _connection.Connect(_config.Url, LdapConnection.DefaultPort);
            _connection.Bind(_config.Username, _config.Password);

            var searchFilter = String.Format(_config.SearchFilter, username);
            var result = _connection.Search(
                _config.SearchBase,
                LdapConnection.ScopeSub,
                searchFilter,
                new[] {
                    MemberOfAttribute,
                    DisplayNameAttribute,
                    SAMAccountNameAttribute,
                    MailAttribute
                },
                false
            );

            try
            {
                var user = result.Next();
                if (user != null)
                {
                    _connection.Bind(user.Dn, password);
                    if (_connection.Bound)
                    {
                        var roles = user.GetAttributeSet().Where(x => x.Key == MemberOfAttribute).ToList();                        
                        var accountNameAttr = user.GetAttribute(SAMAccountNameAttribute).StringValue;
                        var displayNameAttr = user.GetAttribute(DisplayNameAttribute).StringValue;
                        var emailAttr = user.GetAttribute(MailAttribute).StringValue;
                        
                        return new AppUser
                        {
                            DisplayName = displayNameAttr,
                            Username = accountNameAttr,
                            Email = emailAttr                                
                        };

                        _connection.Disconnect();
                    }
                }

            }catch(Exception ex)
            {

            }           
            return null;
        }

        private string GetGroup(string value)
        {
            Match match = Regex.Match(value, "^CN=([^,]*)");
            if (!match.Success)
            {
                return null;
            }

            return match.Groups[1].Value;
        }
    }
}
