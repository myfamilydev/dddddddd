﻿

Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities\AR -tables v_payment_schedules_info, vprint_schedule -Schemas ar -contextdir DBcontexts -context ARContext  -DataAnnotations -Force


Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities -Schemas dbo -contextdir DBcontexts -DataAnnotations -Force

Scaffold-DbContext "data source=192.168.1.88;initial catalog=AP_System;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities/AP -Schemas dbo -contextdir DBcontexts -DataAnnotations -Force
