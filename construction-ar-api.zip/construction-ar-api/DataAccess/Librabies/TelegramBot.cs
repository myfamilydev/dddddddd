﻿using Telegram.Bot;

namespace DataAccess.Libraries
{
    public class TelegramBot
    {

        //private static string telegramToken = "847476086:AAH8LKOya8e362iu7myVkxUoRdInxlU9rH0";
       // private static string telegramToken = "1641109947:AAF_ojNNGbqK-YRjipJRiLkL9QTP-RkcI9s";
        private static string telegramToken = "1641109947:AAHaxdvYPPyTLqzQyc3oyDrRSylx15bKmLs";
        
        public TelegramBotClient bot;

        public TelegramBot()
        {
            bot = new TelegramBotClient(telegramToken);            
        }

    }
}
