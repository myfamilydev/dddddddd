﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Librabies
{
    public static  class ClsReserveUser
    {
        private static Dictionary<int, ClsReserve> userDic = new Dictionary<int, ClsReserve>();

        public static void addUserDic(int key, ClsReserve value)
        {
            if (!userDic.ContainsKey(key))
            {
                userDic.Add(key, value);
            }
        }

        public static ClsReserve getUserDic(int key)
        {
            if(!userDic.ContainsKey(key))
            {
                return null;
            }
            return userDic[key];
        }

        public static void updateUserDic(int key, ClsReserve value)
        {
            if (userDic.ContainsKey(key))
            {
                userDic[key] = value;
            }
        }
    }

    public class ClsReserve
    {
        public int houseId { get; set; }

        public string prePrintedNumber { set; get; }
    }
}
