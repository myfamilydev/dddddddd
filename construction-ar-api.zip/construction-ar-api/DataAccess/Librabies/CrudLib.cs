﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess.Librabies
{
    public class CrudLib<T> where T : class
    {
        private int _userId { get; set; }
        private MayuraContext _context;

        public CrudLib(MayuraContext context, int UserId)
        {
            this._userId = UserId;
            this._context = context;
        }

        public CrudLib()
        {
        }

        public virtual async Task<PagedResponse<object>> GetDataPro(PaginationFilter filter = null)
        {
            if (filter == null)
                filter = new PaginationFilter();

            // using (var _context = new MayuraContext())
            //{
            var datas = await (
                                 from data in _context.Set<T>()
                                 join p in _context.Set<Projects>()
                                          on EF.Property<short>(data, "ProjectId") equals p.Id into tbl1
                                 from t1 in tbl1.DefaultIfEmpty()
                                 join user1 in _context.Set<Users>()
                                          on EF.Property<int>(data, "CreatedBy") equals user1.Id into tbl2
                                 from t2 in tbl2.DefaultIfEmpty()
                                 join user2 in _context.Set<Users>()
                                          on EF.Property<int>(data, "UpdatedBy") equals user2.Id into tbl3
                                 from t3 in tbl3.DefaultIfEmpty()
                                 select new { data, t1.ProjectShort, CreatedByName = t2.FullName, UpdatedByName = t3.FullName }

                              )

                           .Where(s => (
                                        (EF.Property<short>(s.data, "Status") == 1 || EF.Property<short>(s.data, "Status") == 2) &&
                                        (!filter.ProId.HasValue || EF.Property<short>(s.data, "ProjectId") == filter.ProId)
                           ))
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();
            ;

            filter.TotalRecords = datas.Count();

            return new PagedResponse<object>(datas, filter);
            //}

        }

        public virtual async Task<PagedResponse<object>> GetDataProHouse(PaginationFilter filter = null)
        {
            if (filter == null)
                filter = new PaginationFilter();

            //using (var _context = new MayuraContext())
            //{
            var datas = await (
                                 from data in _context.Set<T>()
                                 join p in _context.Set<Projects>()
                                          on EF.Property<short>(data, "ProjectId") equals p.Id into tbl1
                                 from t1 in tbl1.DefaultIfEmpty()
                                 join user1 in _context.Set<Users>()
                                          on EF.Property<int>(data, "CreatedBy") equals user1.Id into tbl2
                                 from t2 in tbl2.DefaultIfEmpty()
                                 join user2 in _context.Set<Users>()
                                          on EF.Property<int>(data, "UpdatedBy") equals user2.Id into tbl3
                                 from t3 in tbl3.DefaultIfEmpty()
                                 join house in _context.Set<Houses>()
                                          on EF.Property<int>(data, "HouseId") equals house.Id into tbl4
                                 from t4 in tbl4.DefaultIfEmpty()
                                 select new { data, t1.ProjectShort, CreatedByName = t2.FullName, UpdatedByName = t3.FullName, HouseNumber = t4.Number }

                              )
                           .Where(s => (
                                (!filter.ProId.HasValue || EF.Property<short>(s.data, "ProjectId") == filter.ProId)) &&
                                (!filter.HouseId.HasValue || EF.Property<short>(s.data, "HouseId") == filter.HouseId) &&
                                (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == filter.Search)
                           )
                           .OrderByDescending(x => EF.Property<short>(x.data, "CreatedAt"))
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync()
            ;

            filter.TotalRecords
                = await (
                        from data in _context.Set<T>()
                        join p in _context.Set<Projects>()
                                on EF.Property<short>(data, "ProjectId") equals p.Id into tbl1
                        from t1 in tbl1.DefaultIfEmpty()
                        join user1 in _context.Set<Users>()
                                on EF.Property<int>(data, "CreatedBy") equals user1.Id into tbl2
                        from t2 in tbl2.DefaultIfEmpty()
                        join user2 in _context.Set<Users>()
                                on EF.Property<int>(data, "UpdatedBy") equals user2.Id into tbl3
                        from t3 in tbl3.DefaultIfEmpty()
                        join house in _context.Set<Houses>()
                                on EF.Property<int>(data, "HouseId") equals house.Id into tbl4
                        from t4 in tbl4.DefaultIfEmpty()
                        select new { data, t1.ProjectShort, CreatedByName = t2.FullName, UpdatedByName = t3.FullName, HouseNumber = t4.Number }

                    )
                .CountAsync()
            ;

            return new PagedResponse<object>(datas, filter);
            // }

        }

        public virtual async Task<PagedResponse<object>> GetDataHouse(PaginationFilter filter = null)
        {
            if (filter == null)
                filter = new PaginationFilter();

            //using (var _context = new MayuraContext())
            //{
            var datas = await (
                                 from data in _context.Set<T>()
                                 join user1 in _context.Set<Users>()
                                          on EF.Property<int>(data, "CreatedBy") equals user1.Id into tbl2
                                 from t2 in tbl2.DefaultIfEmpty()
                                 join user2 in _context.Set<Users>()
                                          on EF.Property<int>(data, "UpdatedBy") equals user2.Id into tbl3
                                 from t3 in tbl3.DefaultIfEmpty()
                                 join house in _context.Set<Houses>()
                                          on EF.Property<int>(data, "HouseId") equals house.Id into tbl4
                                 from t4 in tbl4.DefaultIfEmpty()
                                 select new { data, CreatedByName = t2.FullName, UpdatedByName = t3.FullName, HouseNumber = t4.Number }

                              )
                           .Where(s => (
                                (String.IsNullOrEmpty(filter.Search) || s.HouseNumber == filter.Search)
                           ))
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync()
            ;

            filter.TotalRecords
                = await (
                        from data in _context.Set<T>()
                        join user1 in _context.Set<Users>()
                                on EF.Property<int>(data, "CreatedBy") equals user1.Id into tbl2
                        from t2 in tbl2.DefaultIfEmpty()
                        join user2 in _context.Set<Users>()
                                on EF.Property<int>(data, "UpdatedBy") equals user2.Id into tbl3
                        from t3 in tbl3.DefaultIfEmpty()
                        join house in _context.Set<Houses>()
                                on EF.Property<int>(data, "HouseId") equals house.Id into tbl4
                        from t4 in tbl4.DefaultIfEmpty()
                        select new { data, CreatedByName = t2.FullName, UpdatedByName = t3.FullName, HouseNumber = t4.Number }

                    )
                .CountAsync()
            ;

            return new PagedResponse<object>(datas, filter);
            //}

        }

        public virtual async Task<object> Add(object obj, string workflow_name = "", bool createdAt = true, string workflow_title = "")
        {
            if (createdAt)
            {
                obj.GetType().GetProperty("CreatedAt").SetValue(obj, DateTime.Now);
                obj.GetType().GetProperty("CreatedBy").SetValue(obj, _userId);

                if (!workflow_name.Equals(""))
                {
                    obj.GetType().GetProperty("RecStatus").SetValue(obj, (byte)0);
                }
            }

            try
            {
                //using (var _context = new MayuraContext())
                //{
                _context.Set<T>().Add((T)obj);
                await _context.SaveChangesAsync();

                if (!workflow_name.Equals(""))
                {
                    //Add Workflow History draft
                    int dataId = Convert.ToInt32(obj.GetType().GetProperty("Id").GetValue(obj, null));
                    int dataProjectId = Convert.ToInt32(obj.GetType().GetProperty("ProjectId").GetValue(obj, null));
                    WorkflowDetailModel wf = new WorkflowDetailModel();
                    var workflowhistory = wf.WorkflowHistoryDraft(workflow_name, dataId, _userId);
                    _context.WorkflowHistory.Add(workflowhistory);

                    await _context.SaveChangesAsync();
                }

                return obj;
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public virtual async Task<object> Update(object obj, string workflow_name = "", bool createdAt = true)
        {
            if (createdAt)
            {
                obj.GetType().GetProperty("UpdatedAt").SetValue(obj, DateTime.Now);
                obj.GetType().GetProperty("UpdatedBy").SetValue(obj, _userId);

                if (!workflow_name.Equals(""))
                {
                    obj.GetType().GetProperty("RecStatus").SetValue(obj, (byte)0);
                }
            }

            try
            {
                //using (var _context = new MayuraContext())
                //{
                _context.Entry((T)obj).State = EntityState.Modified;
                _context.Entry((T)obj).Property("CreatedAt").IsModified = false;
                _context.Entry((T)obj).Property("CreatedBy").IsModified = false;

                await _context.SaveChangesAsync();

                return obj;
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public virtual async Task<object> Remove(object obj, string workflow_name = "", bool createdAt = true)
        {
            try
            {
                //using (var _context = new MayuraContext())
                //{
                _context.Set<T>().Remove((T)obj);

                await _context.SaveChangesAsync();

                return obj;
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
