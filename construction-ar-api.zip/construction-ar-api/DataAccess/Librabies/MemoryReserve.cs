﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Librabies
{
    public  class MemoryReserve
    {
        [Key]
        public int user_id { set; get; }
        public int house_id { set; get; }
        public string preprinted_number { set; get; }
    }
}
