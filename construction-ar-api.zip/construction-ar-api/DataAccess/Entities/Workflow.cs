﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow")]
    public partial class Workflow
    {
        [Key]
        [Column("id")]
        public byte Id { get; set; }
        [Column("uuid")]
        public Guid? Uuid { get; set; }
        [Column("workflow_name")]
        [StringLength(50)]
        public string WorkflowName { get; set; }
        [Column("workflow_title")]
        [StringLength(100)]
        public string WorkflowTitle { get; set; }
        [Column("form_url")]
        [StringLength(200)]
        public string FormUrl { get; set; }
        [Column("indexing")]
        public short? Indexing { get; set; }
        [Column("user_page_id")]
        public int? UserPageId { get; set; }
        [Column("module_name")]
        [StringLength(50)]
        public string ModuleName { get; set; }
    }
}
