﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("revenue")]
    public partial class Revenue
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("amount")]
        public decimal? Amount { get; set; }
        [Column("method_id")]
        public int? MethodId { get; set; }
        [Column("transaction_type_id")]
        public int? TransactionTypeId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
