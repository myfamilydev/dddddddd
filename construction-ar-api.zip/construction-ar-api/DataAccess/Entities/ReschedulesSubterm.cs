﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("reschedules_subterm")]
    public partial class ReschedulesSubterm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("reschedule_id")]
        public int? RescheduleId { get; set; }
        [Column("paid_off_amount")]
        public float? PaidOffAmount { get; set; }
        [Column("paid_off_type")]
        [StringLength(10)]
        public string PaidOffType { get; set; }
        [Column("paid_off_term_month")]
        public short? PaidOffTermMonth { get; set; }
        [Column("interest_percent_month")]
        public float? InterestPercentMonth { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }

        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }

        [Column("status")]
        public short? Status { get; set; }
    }
}
