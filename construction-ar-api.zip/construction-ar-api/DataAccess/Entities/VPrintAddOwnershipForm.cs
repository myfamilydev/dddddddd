﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VPrintAddOwnershipForm
    {
        [Required]
        [Column("logo")]
        [StringLength(49)]
        public string Logo { get; set; }
        [Column("booking_ownership_id")]
        public int BookingOwnershipId { get; set; }
        [Column("ins_day")]
        public int? InsDay { get; set; }
        [Column("ins_month")]
        public int? InsMonth { get; set; }
        [Column("ins_year")]
        public int? InsYear { get; set; }
        [Column("fc1_name")]
        [StringLength(150)]
        public string Fc1Name { get; set; }
        [Column("fc1_day")]
        public int? Fc1Day { get; set; }
        [Column("fc1_month")]
        public int? Fc1Month { get; set; }
        [Column("fc1_year")]
        public int? Fc1Year { get; set; }
        [Column("fc1_nationality")]
        [StringLength(50)]
        public string Fc1Nationality { get; set; }
        [Column("fc1_id_card_no")]
        [StringLength(50)]
        public string Fc1IdCardNo { get; set; }
        [Column("fc1_house_number")]
        [StringLength(50)]
        public string Fc1HouseNumber { get; set; }
        [Column("fc1_st_no")]
        [StringLength(150)]
        public string Fc1StNo { get; set; }
        [Column("fc1_village")]
        [StringLength(150)]
        public string Fc1Village { get; set; }
        [Column("fc1_district")]
        [StringLength(150)]
        public string Fc1District { get; set; }
        [Column("fc1_commune")]
        [StringLength(150)]
        public string Fc1Commune { get; set; }
        [Column("fc1_province")]
        [StringLength(150)]
        public string Fc1Province { get; set; }
        [Column("fc1_phone_number")]
        [StringLength(42)]
        public string Fc1PhoneNumber { get; set; }
        [Column("fc2_name")]
        [StringLength(150)]
        public string Fc2Name { get; set; }
        [Column("fc2_day")]
        public int? Fc2Day { get; set; }
        [Column("fc2_month")]
        public int? Fc2Month { get; set; }
        [Column("fc2_year")]
        public int? Fc2Year { get; set; }
        [Column("fc2_nationality")]
        [StringLength(50)]
        public string Fc2Nationality { get; set; }
        [Column("fc2_id_card_no")]
        [StringLength(50)]
        public string Fc2IdCardNo { get; set; }
        [Column("fc2_house_number")]
        [StringLength(50)]
        public string Fc2HouseNumber { get; set; }
        [Column("fc2_st_no")]
        [StringLength(150)]
        public string Fc2StNo { get; set; }
        [Column("fc2_village")]
        [StringLength(150)]
        public string Fc2Village { get; set; }
        [Column("fc2_district")]
        [StringLength(150)]
        public string Fc2District { get; set; }
        [Column("fc2_commune")]
        [StringLength(150)]
        public string Fc2Commune { get; set; }
        [Column("fc2_province")]
        [StringLength(150)]
        public string Fc2Province { get; set; }
        [Column("fc2_phone_number")]
        [StringLength(42)]
        public string Fc2PhoneNumber { get; set; }
        [Column("tc1_name")]
        [StringLength(150)]
        public string Tc1Name { get; set; }
        [Column("tc1_day")]
        public int? Tc1Day { get; set; }
        [Column("tc1_month")]
        public int? Tc1Month { get; set; }
        [Column("tc1_year")]
        public int? Tc1Year { get; set; }
        [Column("tc1_nationality")]
        [StringLength(50)]
        public string Tc1Nationality { get; set; }
        [Column("tc1_id_card_no")]
        [StringLength(50)]
        public string Tc1IdCardNo { get; set; }
        [Column("tc1_house_number")]
        [StringLength(50)]
        public string Tc1HouseNumber { get; set; }
        [Column("tc1_st_no")]
        [StringLength(150)]
        public string Tc1StNo { get; set; }
        [Column("tc1_village")]
        [StringLength(150)]
        public string Tc1Village { get; set; }
        [Column("tc1_district")]
        [StringLength(150)]
        public string Tc1District { get; set; }
        [Column("tc1_commune")]
        [StringLength(150)]
        public string Tc1Commune { get; set; }
        [Column("tc1_province")]
        [StringLength(150)]
        public string Tc1Province { get; set; }
        [Column("tc1_phone_number")]
        [StringLength(42)]
        public string Tc1PhoneNumber { get; set; }
        [Column("tc2_name")]
        [StringLength(150)]
        public string Tc2Name { get; set; }
        [Column("tc2_day")]
        public int? Tc2Day { get; set; }
        [Column("tc2_month")]
        public int? Tc2Month { get; set; }
        [Column("tc2_year")]
        public int? Tc2Year { get; set; }
        [Column("ttc2_nationality")]
        [StringLength(50)]
        public string Ttc2Nationality { get; set; }
        [Column("tc2_id_card_no")]
        [StringLength(50)]
        public string Tc2IdCardNo { get; set; }
        [Column("tc2_house_number")]
        [StringLength(50)]
        public string Tc2HouseNumber { get; set; }
        [Column("tc2_st_no")]
        [StringLength(150)]
        public string Tc2StNo { get; set; }
        [Column("tc2_village")]
        [StringLength(150)]
        public string Tc2Village { get; set; }
        [Column("tc2_district")]
        [StringLength(150)]
        public string Tc2District { get; set; }
        [Column("tc2_commune")]
        [StringLength(150)]
        public string Tc2Commune { get; set; }
        [Column("tc2_province")]
        [StringLength(150)]
        public string Tc2Province { get; set; }
        [Column("tc2_phone_number")]
        [StringLength(42)]
        public string Tc2PhoneNumber { get; set; }
        [Column("number_")]
        [StringLength(50)]
        public string Number { get; set; }
        [Column("types_")]
        [StringLength(100)]
        public string Types { get; set; }
    }
}
