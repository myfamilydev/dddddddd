﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("house_payment_manual")]
    public partial class HousePaymentManual
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column("solution_date", TypeName = "date")]
        public DateTime? SolutionDate { get; set; }
        [Column("cutoff_penalty_date", TypeName = "date")]
        public DateTime? CutoffPenaltyDate { get; set; }
        [Column("n_month")]
        public int? NMonth { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("reschedule_no")]
        public int? RescheduleNo { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
