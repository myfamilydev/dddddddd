﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("users_departments")]
    public partial class UsersDepartments
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("department")]
        [StringLength(100)]
        public string Department { get; set; }
    }
}
