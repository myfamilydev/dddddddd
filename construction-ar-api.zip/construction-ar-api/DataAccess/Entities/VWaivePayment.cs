﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VWaivePayment
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("waive_amount")]
        public decimal? WaiveAmount { get; set; }
        [Column("waive_transaction_type")]
        [StringLength(50)]
        public string WaiveTransactionType { get; set; }
        [Column("payment")]
        public decimal? Payment { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
    }
}
