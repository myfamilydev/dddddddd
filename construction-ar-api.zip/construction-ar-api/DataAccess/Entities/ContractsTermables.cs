﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("contracts_termables")]
    public partial class ContractsTermables
    {
        [Column("contract_term_id")]
        public int? ContractTermId { get; set; }
        [Column("contract_termable_id")]
        public int? ContractTermableId { get; set; }
        [Column("contract_termable_type")]
        [StringLength(50)]
        public string ContractTermableType { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
