﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VUserLoggedIn
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("uuid")]
        public Guid? Uuid { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("email")]
        [StringLength(100)]
        public string Email { get; set; }
        [StringLength(50)]
        public string UserRole { get; set; }
        [StringLength(200)]
        public string FullName { get; set; }
    }
}
