﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VWorkflowNotifications
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("to_user_id")]
        public int ToUserId { get; set; }
        [Required]
        [Column("notif_title")]
        [StringLength(300)]
        public string NotifTitle { get; set; }
        [Column("is_check")]
        public byte IsCheck { get; set; }
        [Required]
        [Column("url")]
        [StringLength(250)]
        public string Url { get; set; }
    }
}
