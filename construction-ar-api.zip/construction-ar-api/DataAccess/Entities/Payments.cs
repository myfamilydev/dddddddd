﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("payments")]
    public partial class Payments
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("staff_id")]
        public int? StaffId { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("due_date", TypeName = "datetime")]
        public DateTime? DueDate { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("payment_type")]
        [StringLength(50)]
        public string PaymentType { get; set; }
        [Column("amount")]
        public double? Amount { get; set; }
        [Column("date", TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [Column("expire_date", TypeName = "datetime")]
        public DateTime? ExpireDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
