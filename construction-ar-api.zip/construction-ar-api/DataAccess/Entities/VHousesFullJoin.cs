﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VHousesFullJoin
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_type_id")]
        public int? HouseTypeId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("block")]
        [StringLength(10)]
        public string Block { get; set; }
        [Column("road_type")]
        [StringLength(30)]
        public string RoadType { get; set; }
        [Column("house_no")]
        [StringLength(10)]
        public string HouseNo { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("house_price")]
        public decimal? HousePrice { get; set; }
        [Column("street_id")]
        public int? StreetId { get; set; }
        [Column("phase")]
        [StringLength(10)]
        public string Phase { get; set; }
        [Column("remarks")]
        [StringLength(500)]
        public string Remarks { get; set; }
        [Column("payproref")]
        [StringLength(30)]
        public string Payproref { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [Column("billercode")]
        [StringLength(30)]
        public string Billercode { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("village")]
        [StringLength(250)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(250)]
        public string Commune { get; set; }
        [Column("district")]
        [StringLength(250)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(250)]
        public string Province { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_width")]
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [Column("house_length")]
        [StringLength(10)]
        public string HouseLength { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("category_name")]
        [StringLength(250)]
        public string CategoryName { get; set; }
        [Column("land_width")]
        [StringLength(10)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        public string LandLength { get; set; }
        [Column("land_size")]
        [StringLength(21)]
        public string LandSize { get; set; }
        [Column("house_status")]
        [StringLength(50)]
        public string HouseStatus { get; set; }
    }
}
