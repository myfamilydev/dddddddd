﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_notifications")]
    public partial class WorkflowNotifications
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("workflow_id")]
        public int WorkflowId { get; set; }
        [Required]
        [Column("ref_id")]
        [StringLength(50)]
        public string RefId { get; set; }
        [Required]
        [Column("notif_title")]
        [StringLength(300)]
        public string NotifTitle { get; set; }
        [Column("from_user_id")]
        public int? FromUserId { get; set; }
        [Column("to_user_id")]
        public int ToUserId { get; set; }
        [Column("to_role_id")]
        public int ToRoleId { get; set; }
        [Column("is_check")]
        public byte IsCheck { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
