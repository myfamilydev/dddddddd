﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VPrintContractForm
    {
        [Required]
        [Column("logo")]
        [StringLength(49)]
        public string Logo { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("ins_day")]
        public int? InsDay { get; set; }
        [Column("ins_month")]
        public int? InsMonth { get; set; }
        [Column("ins_year")]
        public int? InsYear { get; set; }
        [Column("cus1_name")]
        [StringLength(150)]
        public string Cus1Name { get; set; }
        [Column("cus1_dob_day")]
        public int? Cus1DobDay { get; set; }
        [Column("cus1_dob_month")]
        public int? Cus1DobMonth { get; set; }
        [Column("cus1_dob_year")]
        public int? Cus1DobYear { get; set; }
        [Column("cus1_nationality")]
        [StringLength(50)]
        public string Cus1Nationality { get; set; }
        [Column("cus1_id_card_no")]
        [StringLength(50)]
        public string Cus1IdCardNo { get; set; }
        [Column("cus1_house_number")]
        [StringLength(50)]
        public string Cus1HouseNumber { get; set; }
        [Column("cus1_st_no")]
        [StringLength(150)]
        public string Cus1StNo { get; set; }
        [Column("cus1_village")]
        [StringLength(150)]
        public string Cus1Village { get; set; }
        [Column("cus1_district")]
        [StringLength(150)]
        public string Cus1District { get; set; }
        [Column("cus1_commune")]
        [StringLength(150)]
        public string Cus1Commune { get; set; }
        [Column("cus1_province")]
        [StringLength(150)]
        public string Cus1Province { get; set; }
        [Column("cus1_phone_number")]
        [StringLength(42)]
        public string Cus1PhoneNumber { get; set; }
        [Column("cus1_relationship")]
        [StringLength(50)]
        public string Cus1Relationship { get; set; }
        [Column("cus2_name")]
        [StringLength(150)]
        public string Cus2Name { get; set; }
        [Column("cus2_dob_day")]
        public int? Cus2DobDay { get; set; }
        [Column("cus2_dob_month")]
        public int? Cus2DobMonth { get; set; }
        [Column("cus2_dob_year")]
        public int? Cus2DobYear { get; set; }
        [Column("cus2_nationality")]
        [StringLength(50)]
        public string Cus2Nationality { get; set; }
        [Column("cus2_id_card_no")]
        [StringLength(50)]
        public string Cus2IdCardNo { get; set; }
        [Column("cus2_house_number")]
        [StringLength(50)]
        public string Cus2HouseNumber { get; set; }
        [Column("cus2_st_no")]
        [StringLength(150)]
        public string Cus2StNo { get; set; }
        [Column("cus2_village")]
        [StringLength(150)]
        public string Cus2Village { get; set; }
        [Column("cus2_district")]
        [StringLength(150)]
        public string Cus2District { get; set; }
        [Column("cus2_commune")]
        [StringLength(150)]
        public string Cus2Commune { get; set; }
        [Column("cus2_province")]
        [StringLength(150)]
        public string Cus2Province { get; set; }
        [Column("cus2_phone_number")]
        [StringLength(42)]
        public string Cus2PhoneNumber { get; set; }
        [Required]
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("land_width")]
        [StringLength(100)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(100)]
        public string LandLength { get; set; }
        [Column("house_width")]
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [Column("house_length")]
        [StringLength(10)]
        public string HouseLength { get; set; }
        [Column("house_village")]
        [StringLength(150)]
        public string HouseVillage { get; set; }
        [Column("house_district")]
        [StringLength(150)]
        public string HouseDistrict { get; set; }
        [Column("house_commune")]
        [StringLength(150)]
        public string HouseCommune { get; set; }
        [Column("house_province")]
        [StringLength(150)]
        public string HouseProvince { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("house_price_word")]
        [StringLength(300)]
        public string HousePriceWord { get; set; }
        [Column("construction_period")]
        public int? ConstructionPeriod { get; set; }
        [Column("payment_term_schedule")]
        public string PaymentTermSchedule { get; set; }
    }
}
