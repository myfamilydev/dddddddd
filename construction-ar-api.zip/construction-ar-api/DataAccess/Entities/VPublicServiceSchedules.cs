﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VPublicServiceSchedules
    {
        [Column("schedule_id")]
        public int ScheduleId { get; set; }
        [Column("public_service_id")]
        public int PublicServiceId { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime PaymentDate { get; set; }
        [Column("monthly_fee")]
        public decimal MonthlyFee { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("preprinted_number")]
        [StringLength(20)]
        public string PreprintedNumber { get; set; }
        public int? ReceiptNo { get; set; }
        [Column("discount_amount")]
        public decimal? DiscountAmount { get; set; }
        public decimal? NetPay { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("waive")]
        public decimal? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        public int HouseId { get; set; }

        [Column("adjustment_id")]
        public int? AdjustmentId { set; get; }
        [Column("adjustment_type")]
        public short? AdjustmentType { set; get; }
        [Column("termination_transfer")]
        public int? TerminationTransfer { set; get; }
        [Column("adjustment_status")]
        public short? AdjustmentStatus { set; get; }        
        public int RIndex { get; set; }
        public int RowSpan { get; set; }
    }
}
