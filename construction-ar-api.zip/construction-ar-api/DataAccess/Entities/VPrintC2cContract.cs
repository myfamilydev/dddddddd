﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VPrintC2cContract
    {
        [Column("c2c_day")]
        public int? C2cDay { get; set; }
        [Column("c2c_month")]
        public int? C2cMonth { get; set; }
        [Column("c2c_year")]
        public int? C2cYear { get; set; }
        [Column("cus1_name")]
        [StringLength(150)]
        public string Cus1Name { get; set; }
        [Column("cus1_dob", TypeName = "datetime")]
        public DateTime? Cus1Dob { get; set; }
        [Column("cus1_nationality")]
        [StringLength(50)]
        public string Cus1Nationality { get; set; }
        [Column("cus1_idno")]
        [StringLength(50)]
        public string Cus1Idno { get; set; }
        [Column("cus1_house_no")]
        [StringLength(50)]
        public string Cus1HouseNo { get; set; }
        [Column("cus1_st_no")]
        [StringLength(150)]
        public string Cus1StNo { get; set; }
        [Column("cus1_village")]
        [StringLength(150)]
        public string Cus1Village { get; set; }
        [Column("cus1_commune")]
        [StringLength(150)]
        public string Cus1Commune { get; set; }
        [Column("cus1_district")]
        [StringLength(150)]
        public string Cus1District { get; set; }
        [Column("cus1_province")]
        [StringLength(150)]
        public string Cus1Province { get; set; }
        [Column("cus1_mobile_phone")]
        [StringLength(20)]
        public string Cus1MobilePhone { get; set; }
        [Column("cus2_name")]
        [StringLength(150)]
        public string Cus2Name { get; set; }
        [Column("cus2_dob", TypeName = "datetime")]
        public DateTime? Cus2Dob { get; set; }
        [Column("cus2_nationality")]
        [StringLength(50)]
        public string Cus2Nationality { get; set; }
        [Column("cus2_idno")]
        [StringLength(50)]
        public string Cus2Idno { get; set; }
        [Column("cus2_house_no")]
        [StringLength(50)]
        public string Cus2HouseNo { get; set; }
        [Column("cus2_st_no")]
        [StringLength(150)]
        public string Cus2StNo { get; set; }
        [Column("cus2_village")]
        [StringLength(150)]
        public string Cus2Village { get; set; }
        [Column("cus2_commune")]
        [StringLength(150)]
        public string Cus2Commune { get; set; }
        [Column("cus2_district")]
        [StringLength(150)]
        public string Cus2District { get; set; }
        [Column("cus2_province")]
        [StringLength(150)]
        public string Cus2Province { get; set; }
        [Column("cus2_mobile_phone")]
        [StringLength(20)]
        public string Cus2MobilePhone { get; set; }
        [Required]
        [Column("cus1_relationship")]
        [StringLength(7)]
        public string Cus1Relationship { get; set; }
        [Column("cus3_name")]
        [StringLength(150)]
        public string Cus3Name { get; set; }
        [Column("cus3_dob", TypeName = "datetime")]
        public DateTime? Cus3Dob { get; set; }
        [Column("cus3_nationality")]
        [StringLength(50)]
        public string Cus3Nationality { get; set; }
        [Column("cus3_idno")]
        [StringLength(50)]
        public string Cus3Idno { get; set; }
        [Column("cus3_house_no")]
        [StringLength(50)]
        public string Cus3HouseNo { get; set; }
        [Column("cus3_st_no")]
        [StringLength(150)]
        public string Cus3StNo { get; set; }
        [Column("cus3_village")]
        [StringLength(150)]
        public string Cus3Village { get; set; }
        [Column("cus3_commune")]
        [StringLength(150)]
        public string Cus3Commune { get; set; }
        [Column("cus3_district")]
        [StringLength(150)]
        public string Cus3District { get; set; }
        [Column("cus3_province")]
        [StringLength(150)]
        public string Cus3Province { get; set; }
        [Column("cus3_mobile_phone")]
        [StringLength(20)]
        public string Cus3MobilePhone { get; set; }
        [Column("cus4_name")]
        [StringLength(150)]
        public string Cus4Name { get; set; }
        [Column("cus4_dob", TypeName = "datetime")]
        public DateTime? Cus4Dob { get; set; }
        [Column("cus4_nationality")]
        [StringLength(50)]
        public string Cus4Nationality { get; set; }
        [Column("cus4_idno")]
        [StringLength(50)]
        public string Cus4Idno { get; set; }
        [Column("cus4_house_no")]
        [StringLength(50)]
        public string Cus4HouseNo { get; set; }
        [Column("cus4_st_no")]
        [StringLength(150)]
        public string Cus4StNo { get; set; }
        [Column("cus4_village")]
        [StringLength(150)]
        public string Cus4Village { get; set; }
        [Column("cus4_commune")]
        [StringLength(150)]
        public string Cus4Commune { get; set; }
        [Column("cus4_district")]
        [StringLength(150)]
        public string Cus4District { get; set; }
        [Column("cus4_province")]
        [StringLength(150)]
        public string Cus4Province { get; set; }
        [Column("cus4_mobile_phone")]
        [StringLength(20)]
        public string Cus4MobilePhone { get; set; }
        [Required]
        [Column("cus3_relationship")]
        [StringLength(7)]
        public string Cus3Relationship { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("l_width")]
        [StringLength(100)]
        public string LWidth { get; set; }
        [Column("l_length")]
        [StringLength(100)]
        public string LLength { get; set; }
        [Column("h_width")]
        [StringLength(10)]
        public string HWidth { get; set; }
        [Column("h_length")]
        [StringLength(10)]
        public string HLength { get; set; }
        [Column("house_village")]
        [StringLength(150)]
        public string HouseVillage { get; set; }
        [Column("house_commune")]
        [StringLength(150)]
        public string HouseCommune { get; set; }
        [Column("house_district")]
        [StringLength(150)]
        public string HouseDistrict { get; set; }
        [Column("house_province")]
        [StringLength(150)]
        public string HouseProvince { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("house_price_word")]
        [StringLength(1024)]
        public string HousePriceWord { get; set; }
        [Required]
        [Column("remaining_payment")]
        [StringLength(7)]
        public string RemainingPayment { get; set; }
        [Required]
        [Column("remaining_payment_word")]
        [StringLength(7)]
        public string RemainingPaymentWord { get; set; }
        [Column("con_day")]
        public int? ConDay { get; set; }
        [Column("con_month")]
        public int? ConMonth { get; set; }
        [Column("con_year")]
        public int? ConYear { get; set; }
    }
}
