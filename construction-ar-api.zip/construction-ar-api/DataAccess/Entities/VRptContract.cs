﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptContract
    {
        [Column("contract_created_at", TypeName = "datetime")]
        public DateTime? ContractCreatedAt { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("ct_id")]
        [StringLength(10)]
        public string CtId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("road_no")]
        [StringLength(150)]
        public string RoadNo { get; set; }
        [Column("road_type")]
        [StringLength(100)]
        public string RoadType { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("contact_number")]
        [StringLength(20)]
        public string ContactNumber { get; set; }
        [Column("contract_date", TypeName = "datetime")]
        public DateTime? ContractDate { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("house_discount")]
        public double? HouseDiscount { get; set; }
        [Column("ad_hoc_discount")]
        public double? AdHocDiscount { get; set; }
        [Column("net_house_price")]
        public double? NetHousePrice { get; set; }
        [Column("booking_amount")]
        public double? BookingAmount { get; set; }
        [Column("booking_remark")]
        public string BookingRemark { get; set; }
        [Column("contract_remark")]
        public string ContractRemark { get; set; }
        [Column("bk_id")]
        [StringLength(20)]
        public string BkId { get; set; }
    }
}
