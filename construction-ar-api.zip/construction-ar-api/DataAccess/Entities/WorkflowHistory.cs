﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_history")]
    public partial class WorkflowHistory
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("workflow_id")]
        public byte WorkflowId { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("post_status")]
        public byte? PostStatus { get; set; }
        [Column("comment")]
        [StringLength(250)]
        public string Comment { get; set; }
        [Column("is_done")]
        public byte? IsDone { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
