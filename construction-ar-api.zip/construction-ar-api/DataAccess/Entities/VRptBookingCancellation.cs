﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptBookingCancellation
    {
        [Column("cancel_date", TypeName = "datetime")]
        public DateTime? CancelDate { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("projectName")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [StringLength(23)]
        public string Expr1 { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("booking_amount")]
        public double? BookingAmount { get; set; }
        [Column("staff_name")]
        [StringLength(255)]
        public string StaffName { get; set; }
        [Column("cancel_reason")]
        public string CancelReason { get; set; }
    }
}
