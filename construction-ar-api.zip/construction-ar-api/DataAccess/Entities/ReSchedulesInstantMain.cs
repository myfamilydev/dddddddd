﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("re_schedules_instant_main")]
    public partial class ReSchedulesInstantMain
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("outstanding_principle", TypeName = "decimal(10, 2)")]
        public decimal? OutstandingPrinciple { get; set; }
        [Column("interest_period_month")]
        public int? InterestPeriodMonth { get; set; }
        [Column("monthly_interest", TypeName = "decimal(8, 7)")]
        public decimal? MonthlyInterest { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
