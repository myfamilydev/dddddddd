﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("forms_printing")]
    public partial class FormsPrinting
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("form_name")]
        [StringLength(50)]
        public string FormName { get; set; }
        [Column("html_content", TypeName = "ntext")]
        public string HtmlContent { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("created_by", TypeName = "datetime")]
        public DateTime? CreatedBy { get; set; }
        [Column("updated_by", TypeName = "datetime")]
        public DateTime? UpdatedBy { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
    }
}
