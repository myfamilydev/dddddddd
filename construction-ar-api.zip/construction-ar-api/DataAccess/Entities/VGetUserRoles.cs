﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VGetUserRoles
    {
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("role_created_by")]
        [StringLength(50)]
        public string RoleCreatedBy { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        public string RoleName { get; set; }
        [Column("role_created_at")]
        [StringLength(30)]
        public string RoleCreatedAt { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("user_status")]
        public byte? UserStatus { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("user_to_role_id")]
        public int UserToRoleId { get; set; }
        [Column("telegram_group_id")]
        public int? TelegramGroupId { get; set; }
    }
}
