﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("commission_request_detail_tmp")]
    public partial class CommissionRequestDetailTmp
    {
        [Column("user_id")]
        public int UserId { get; set; }
        [Column("direct_sale_id")]
        public int DirectSaleId { get; set; }
        [Column("direct_sale_name")]        
        public string DirectSaleName { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("customer_name")]
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("booking_date", TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("commission_amount", TypeName = "decimal(5, 2)")]
        public decimal? CommissionAmount { get; set; }
        [Column("contract_amount", TypeName = "decimal(15, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("paid_principle", TypeName = "decimal(15, 2)")]
        public decimal? PaidPrinciple { get; set; }
        [Column("paid_principle_percent")]
        public double? PaidPrinciplePercent { get; set; }
    }
}
