﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("contracts_terminations_addon_project")]
    public partial class ContractsTerminationsAddonProject
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contracts_terminations_id")]
        public int? ContractsTerminationsId { get; set; }
        [Column("contract_id_transfer")]
        public int? ContractIdTransfer { get; set; }
        [Column("project_id_transfer")]
        public int? ProjectIdTransfer { get; set; }
        [Column("house_id_transfer")]
        public int? HouseIdTransfer { get; set; }
        [Column("transfer_amount", TypeName = "decimal(15, 2)")]
        public decimal? TransferAmount { get; set; }

        [Column("outstanding_transfer")]
        public decimal? OutstandingTransfer { get; set; }
        [Column("interest_transfer")]
        public decimal? InterestTransfer { get; set; }
        [Column("penalty_transfer")]
        public decimal? PenaltyTransfer { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
