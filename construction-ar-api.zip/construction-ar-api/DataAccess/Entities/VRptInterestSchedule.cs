﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptInterestSchedule
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("payment_no")]
        public int? PaymentNo { get; set; }
        [Column("start_balance")]
        public double? StartBalance { get; set; }
        [Column("payment_date", TypeName = "datetime")]
        public DateTime? PaymentDate { get; set; }
        [Column("full_principle")]
        public double? FullPrinciple { get; set; }
        [Column("full_interest")]
        public double? FullInterest { get; set; }
        [Column("accumulate_principle")]
        public double? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest")]
        public double? AccumulateInterest { get; set; }
        [Column("end_balance")]
        public double? EndBalance { get; set; }
        [Column("receipt_no")]
        public int? ReceiptNo { get; set; }
        [Column("actual_paid_date", TypeName = "date")]
        public DateTime? ActualPaidDate { get; set; }
        [Column("actual_paid")]
        public double? ActualPaid { get; set; }
    }
}
