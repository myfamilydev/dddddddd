﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("paymentables")]
    public partial class Paymentables
    {
        [Column("booking_id")]
        public int BookingId { get; set; }
        [Column("bookingable_id")]
        public int BookingableId { get; set; }
        [Required]
        [Column("bookingable_type")]
        [StringLength(50)]
        public string BookingableType { get; set; }
    }
}
