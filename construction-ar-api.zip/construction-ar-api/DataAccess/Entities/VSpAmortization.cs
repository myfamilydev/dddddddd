﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VSpAmortization
    {
        [Column("payment_no")]
        public int? PaymentNo { get; set; }
        [Column("start_balance")]
        public decimal? StartBalance { get; set; }
        [Column("payment")]
        public decimal? Payment { get; set; }
        [Column("interest")]
        public decimal? Interest { get; set; }
        [Column("principle")]
        public decimal? Principle { get; set; }
        [Column("end_balance")]
        public decimal? EndBalance { get; set; }
        [Column("accumulate_principle")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest")]
        public decimal? AccumulateInterest { get; set; }
        [Column("payment_date", TypeName = "datetime")]
        public DateTime? PaymentDate { get; set; }
    }
}
