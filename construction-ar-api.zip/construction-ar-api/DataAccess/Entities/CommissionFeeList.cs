﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("commission_fee_list")]
    public partial class CommissionFeeList
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("commission_criteria_id")]
        public int? CommissionCriteriaId { get; set; }
        [Column("commission", TypeName = "decimal(5, 2)")]
        public decimal? Commission { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
