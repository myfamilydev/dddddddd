﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_status")]
    public partial class WorkflowStatus
    {
        [Key]
        [Column("id")]
        public byte Id { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
    }
}
