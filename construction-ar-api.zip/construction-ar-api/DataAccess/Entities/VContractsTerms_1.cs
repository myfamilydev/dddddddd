﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VContractsTerms_1
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }
        [Column("construction_period")]
        public int? ConstructionPeriod { get; set; }
        [Column("maintenance_period")]
        public int? MaintenancePeriod { get; set; }
        [Column("min_monthly_principle")]
        public decimal? MinMonthlyPrinciple { get; set; }
        [Column("min_principle")]
        public decimal? MinPrinciple { get; set; }
        [Column("other")]
        public string Other { get; set; }
        [Column("effective_date", TypeName = "datetime")]
        public DateTime? EffectiveDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("house_cat_id")]
        public int? HouseCatId { get; set; }
        [Column("project_name")]
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column("house_category_name")]
        [StringLength(250)]
        public string HouseCategoryName { get; set; }
        [Column("house_number")]
        public string HouseNumber { get; set; }
        public short? Status { get; set; }
        [Column("is_special")]
        public bool? is_special { get; set; }
        
    }
}
