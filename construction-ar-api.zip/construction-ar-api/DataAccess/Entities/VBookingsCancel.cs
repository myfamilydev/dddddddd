﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VBookingsCancel
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("houseNumber")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("cus1NameEn")]
        [StringLength(150)]
        public string Cus1NameEn { get; set; }
        [Column("cus1MobilePhone")]
        [StringLength(30)]
        public string Cus1MobilePhone { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
