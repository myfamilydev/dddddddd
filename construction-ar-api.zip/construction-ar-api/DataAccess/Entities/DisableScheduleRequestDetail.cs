﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("disable_schedule_request_detail")]
    public partial class DisableScheduleRequestDetail
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("disable_schedule_request_id")]
        public int? DisableScheduleRequestId { get; set; }
        [Column("payment_schedule_info_id")]
        public int? PaymentScheduleInfoId { get; set; }
        [Column("outstanding_principle", TypeName = "decimal(15, 2)")]
        public decimal? OutstandingPrinciple { get; set; }
        [Column("n_month")]
        public short? NMonth { get; set; }
        [Column("paid_off_type")]
        [StringLength(10)]
        public string PaidOffType { get; set; }
        [Column("interest_percent_month")]
        public double? InterestPercentMonth { get; set; }
        [Column("start_payment_date", TypeName = "date")]
        public DateTime? StartPaymentDate { get; set; }
        [Column("monthly_payment", TypeName = "decimal(15, 2)")]
        public decimal? MonthlyPayment { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("selected")]
        public bool? Selected { get; set; }
    }
}
