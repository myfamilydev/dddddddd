﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptDiscount
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("road_type")]
        [StringLength(100)]
        public string RoadType { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("customer_name")]
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("contact_number")]
        [StringLength(20)]
        public string ContactNumber { get; set; }
        [Column("booking_date", TypeName = "datetime")]
        public DateTime? BookingDate { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("discount")]
        public double? Discount { get; set; }
        [Column("net_sale")]
        public double? NetSale { get; set; }
        [Column("booking_amount")]
        public double? BookingAmount { get; set; }
        [Column("contract_date", TypeName = "datetime")]
        public DateTime? ContractDate { get; set; }
    }
}
