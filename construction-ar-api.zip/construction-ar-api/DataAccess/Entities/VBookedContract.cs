﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VBookedContract
    {
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
    }
}
