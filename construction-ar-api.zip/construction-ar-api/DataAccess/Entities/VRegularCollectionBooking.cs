﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRegularCollectionBooking
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("collection_class")]
        [StringLength(20)]
        public string CollectionClass { get; set; }
        [Column("payee_id")]
        public int? PayeeId { get; set; }
        [Column("total_amount")]
        public float? TotalAmount { get; set; }
        [Column("method_1_id")]
        public int? Method1Id { get; set; }
        [Column("method_1_amount")]
        public float? Method1Amount { get; set; }
        [Column("method_2_id")]
        public int? Method2Id { get; set; }
        [Column("method_2_amount")]
        public float? Method2Amount { get; set; }
        [Column("method_3_id")]
        public int? Method3Id { get; set; }
        [Column("method_3_amount")]
        public float? Method3Amount { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
    }
}
