﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("customers_history")]
    public partial class CustomersHistory
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("vdate", TypeName = "datetime")]
        public DateTime? Vdate { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("gender")]
        [StringLength(50)]
        public string Gender { get; set; }
        [Column("dob", TypeName = "date")]
        public DateTime? Dob { get; set; }
        [Column("nationality")]
        [StringLength(50)]
        public string Nationality { get; set; }
        [Column("occupation")]
        [StringLength(150)]
        public string Occupation { get; set; }
        [Column("email")]
        [StringLength(128)]
        public string Email { get; set; }
        [Column("house_no")]
        [StringLength(50)]
        public string HouseNo { get; set; }
        [Column("street")]
        [StringLength(150)]
        public string Street { get; set; }
        [Column("village")]
        [StringLength(150)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(150)]
        public string Commune { get; set; }
        [Column("district")]
        [StringLength(150)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(150)]
        public string Province { get; set; }
        [Column("customer_type")]
        [StringLength(50)]
        public string CustomerType { get; set; }
        [Column("contact_type")]
        [StringLength(50)]
        public string ContactType { get; set; }
        [Column("phone_contract")]
        [StringLength(30)]
        public string PhoneContract { get; set; }
        [Column("phone_call")]
        [StringLength(30)]
        public string PhoneCall { get; set; }
        [Column("facebook")]
        [StringLength(255)]
        public string Facebook { get; set; }
        [Column("id_type")]
        [StringLength(100)]
        public string IdType { get; set; }
        [Column("id_no")]
        [StringLength(50)]
        public string IdNo { get; set; }
        [Column("id_expiry_date", TypeName = "date")]
        public DateTime? IdExpiryDate { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("telegram_number")]
        [StringLength(30)]
        public string TelegramNumber { get; set; }
        [Column("other")]
        [StringLength(500)]
        public string Other { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
