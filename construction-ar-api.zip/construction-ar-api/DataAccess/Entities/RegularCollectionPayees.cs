﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("regular_collection_payees")]
    public partial class RegularCollectionPayees
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("payee_name")]
        [StringLength(100)]
        public string PayeeName { get; set; }
        [Column("identity_type")]
        public byte? IdentityType { get; set; }
        [Column("identity_no")]
        [StringLength(30)]
        public string IdentityNo { get; set; }
        [Column("payee_address")]
        [StringLength(200)]
        public string PayeeAddress { get; set; }
        [Column("relationship_status")]
        [StringLength(100)]
        public string RelationshipStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
