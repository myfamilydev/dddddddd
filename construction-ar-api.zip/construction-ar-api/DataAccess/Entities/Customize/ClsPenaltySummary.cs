﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataAccess.Entities.Customize
{
    public class ClsPenaltySummary
    {
        public int? HouseId { set; get; }
       
        public decimal? Payment { set; get; }
        public int? PaymentType { set; get; }

        [Column("ref_date", TypeName = "date")]
        public DateTime? RefDate { set; get; }
        [Column("count_penalty")]
        public int? CountPenalty { get; set; }


    }
    public class ClsPenaltyList
    {
       public int HouseId { set; get; }
       public DateTime ScheduleDate { set; get; }
       public DateTime EndDate { set; get; }
       public int TotalLateDay { set; get; }
       public double Penalty { set; get; }
       public double PenaltyPrinciple { set; get; }
    }
    public class ClsHousePayment
    {
        public int HouseId { set; get; }
        public decimal Payment { set; get; }
        public int PaymentType { set; get; }
        [Column("move_prepaid_over")]
        public int MovePrepaidOver { set; get; }
    }
    public class ClsHouseInterestPayment
    {
        public int HouseId { set; get; }
        public int PaymentType { set; get; }
        public double Interest { set; get; }
    }
    public class ClsPublicServicePayment
    {
        public int HouseId { set; get; }
        public decimal Payment { set; get; }
        public DateTime DateFrom { set; get; }
        public DateTime DateTo { set; get; }
        public decimal MonthlyFee { set; get; }
    }
    public class ClsFinalPayment
    {
        public int HouseId { set; get; }
        public decimal Payment { set; get; }
        public decimal Interest { set; get; }
        public decimal OverFinalPayment { set; get; }
    }

    public class ClsRescheduleInterest
    {
        public int HouseId { set; get; }        
        public decimal Interest { set; get; }        
    }
    public class ClsFinalPrinciple
    {
      
        public decimal ContractAmount { set; get; }
        public decimal TotalPaidPrinciple { set; get; }
        public decimal TotalPaidInterest { set; get; }
        public decimal TotalPaidPenalty { set; get; }
        public decimal TotalPublicService { set; get; }
        public decimal TotalPaidOffDiscount { set; get; }
        public decimal OutstandingPrinciple { set; get; }
       // public double Interest { set; get; }

    }
    public class ClsFinalPaymentCalculation
    {
        public int ContractId { set; get; }
        public string CustomerName1 { set; get; }
        public string CustomerName2 { set; get; }
        public decimal Payment { set; get; }
        public decimal Interest { set; get; }
        public DateTime? StartDate { set; get; }
        public int? CustomerId1 { set; get; }
        public int? CustomerId2 { set; get; }
        public int? NDayInterest { set; get; }
        public decimal? NonInterestRemain { set; get; }

    }
    public class ClsTerminationTransferInfo
    {
        public int HouseId { set; get; }
        public int ContractId { set; get; }
        public decimal OutstandingPrinciple { set; get; }
        public decimal Penalty { set; get; }
        public decimal Interest { set; get; }

    }
    public class ClsExtraPrinciple
    {
        public DateTime PaymentDate { set; get; }
        public decimal Payment { set; get; }
        public decimal Interest { set; get; }
    }
    public class ClsRegularCollectionDetailSummary
    {
       public int TransactionType { set; get; }
       public decimal Payment { set; get; }
    }
    public class ClsHousePaymentSchedule
    {
        public long ScheduleId { set; get; }
        public DateTime PaymentDate { set; get; }
        public float Payment { set; get; }
        public float Principle { set; get; }
        public float Interest { set; get; }
        public float Paid { set; get; }
        public float Pay { set; get; }
    }
    public class ClsHouseHistory
    {
        [Column("customer_name")]
        public string CustomerName { set; get; }
        [Column("action_name")]
        public string ActionName { set; get; }
        [Column("in_date")]
        public DateTime Date { set; get; }
        public string Description { set; get; }
        [Column("link_url")]
        public string LinkUrl { set; get; }
        public string Remark { set; get; }
    }
    public class ClsHistoryContract
    {
        public int ContractId { set; get; }
        public DateTime Date { set; get; }
        public string CustomerName { set; get; }
        public string Action { set; get; }
        public string Description { set; get; }
        public string Remark { set; get; }
    }

    public class ClsTelegramLog
    {

        [Column("id", TypeName = "bigint")]
        public long Id { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [StringLength(1000)]
        public string Title { get; set; }
        [Column("comment")]
        [StringLength(300)]
        public string Comment { get; set; }
        [Column("url")]
        public string Url { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
    }
    public class ClsDashboardSummary
    {
        [Column("house_count")]
        public int HouseCount { set; get; }
        [Column("contract_count")]
        public int ContractCount { set; get; }
        [Column("booking_outstanding")]
        public int BookingOutStanding { set; get; }
        [Column("house_available")]
        public int HouseAvailable { set; get; }
        [Column("house_penalty")]
        public int HousePenalty { set; get; }

    }
    public class ClsDashboardSummaryByProject
    {
        [Column("project_short")]
        public string ProjectShort { set; get; }
        [Column("house_count")]
        public int HouseCount { set; get; }
        [Column("contract_count")]
        public int ContractCount { set; get; }
        [Column("booking_outstanding")]
        public int BookingOutStanding { set; get; }
        [Column("house_available")]
        public int HouseAvailable { set; get; }
        [Column("house_penalty")]
        public int HousePenalty { set; get; }

    }
    public class ClsOtherCollections
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]      
        public decimal TotalAmount { get; set; }
        [Column("method_1_id")]
        public int? Method1Id { get; set; }
        [Column("method_1_amount")]
        public decimal? Method1Amount { get; set; }
        [Column("ref_no1")]
        [StringLength(130)]
        public string RefNo1 { get; set; }
        [Column("ref_date1", TypeName = "date")]
        public DateTime? RefDate1 { get; set; }
        [Column("method_2_id")]
        public int? Method2Id { get; set; }
        [Column("method_2_amount")]
        public decimal? Method2Amount { get; set; }
        [Column("ref_no2")]
        [StringLength(130)]
        public string RefNo2 { get; set; }
        [Column("ref_date2", TypeName = "date")]
        public DateTime? RefDate2 { get; set; }
        [Column("method_3_id")]
        public int? Method3Id { get; set; }
        [Column("method_3_amount")]
        public decimal? Method3Amount { get; set; }
        [Column("ref_no3")]
        [StringLength(130)]
        public string RefNo3 { get; set; }
        [Column("ref_date3", TypeName = "date")]
        public DateTime? RefDate3 { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }          
        public string PreprintedNumber { get; set; }
        [Column("account_number1")]        
        public string AccountNumber1 { get; set; }
        [Column("account_number2")]        
        public string AccountNumber2 { get; set; }
        [Column("account_number3")]        
        public string AccountNumber3 { get; set; }
        public string OtherCustomer { get; set; }
        public string PhoneContract { get; set; }
        public byte TransactionTypeId { get; set; }
        public int? TransactionCategoryId { get; set; }

    }
    public class ClsBookingCustomerInfo
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        public int? CustomerId1 { get; set; }
        public int? CustomerId2 { get; set; }
        [StringLength(150)]
        public string Customer1 { get; set; }
        [StringLength(150)]
        public string Customer2 { get; set; }
        [Column("customer_relationship")]
        [StringLength(50)]
        public string CustomerRelationship { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        public int BookingId { get; set; }
        public decimal? NetHousePrice { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        public int Customer1Completed { set; get; }
        public int Customer2Completed { set; get; }
        [Column("is_transfer")]
        public bool? IsTransfer { set; get; }
    }
    public class ClsScheduleInstant
    {
      
        public decimal? N_MonthlyInterest { set; get; }
       
        public decimal? N_Percent { set; get; }       
        public int? N_PeriodMonth { set; get; }        
        public DateTime? N_ContractDate { set; get; }
       
        public decimal? N_NetAmount { set; get; }
       
        public decimal? N_DiscountAmount { set; get; }
      
        public decimal? MonthlyInterest { set; get; }
      
        public decimal? Percent { set; get; }
        public int? PeriodMonth { set; get; }
        public DateTime? ContractDate { set; get; }
        
        public decimal? NetAmount { set; get; }
        
        public decimal? DiscountAmount { set; get; }
        
        public decimal? BookingAmount { set; get; }
       
        public decimal? InitialPayment { set; get; }

    }

    public class ClsPenaltySchedule
    {
        [Column("schedule_id")]
        public int ScheduleId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }

        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }

        [Column("schedule_payment")]
        public decimal? MonthlyPayment { get; set; }

        [Column("penalty_remain")]
        public decimal? PenaltyRemain { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        public string Status { get; set; }
        public int? Completed { get; set; }


    }

    public class ClsPenaltyScheduleDetail
    {
        [Column("id", TypeName = "bigint")]
        public long? PenaltyPaymentId { get; set; }
        [Column("schedule_id")]
        public int? ScheduleId { get; set; }
        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column("schedule_payment")]
        public decimal? MonthlyPayment { get; set; }
        [Column("schedule_paid")]
        public decimal? MonthlyPaid { get; set; }
        [Column("schedule_remain")]
        public decimal? MonthlyRemain { get; set; }
        [Column("preprinted_number")]
        public string ReceiptNo { get; set; }

        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("schedule_paid_current")]
        public decimal? SchedulePaidCurrent { get; set; }
        [Column("penalty_payment")]
        public decimal? PenaltyPayment { get; set; }
        [Column("pre_penalty_paid")]
        public decimal? PrePenaltyPaid { get; set; }
        [Column("penalty_paid")]
        public decimal? PenaltyPaid { get; set; }
        [Column("penalty_remain")]
        public decimal? PenaltyRemain { get; set; }
        [Column("in_type")]
        public string InType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("waive")]
        public decimal? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        [Column("is_change_end_date")]
        public bool? IsChangeEndDate { get; set; }

        [Column("adjustment_id")]
        public int? AdjustmentId { set; get; }
        [Column("adjustment_type")]
        public short? AdjustmentType { set; get; }
        [Column("termination_transfer")]
        public int? TerminationTransfer { set; get; }
        [Column("adjustment_status")]
        public short? AdjustmentStatus { set; get; }
    }
    public class ClsChangeEnddate
    {
        public int PenaltyPaymentId { set; get; }
        public DateTime EndDate { set; get; }
        public byte option { set; get; }

    }
    public class ClsPenaltyTestDateInput
    {
        public int PenaltyPaymentId { set; get; }
        public DateTime TestDate { set; get; }

    }
    public class ClsPenaltyTestDateResult
    {
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("penalty_payment")]
        public decimal? PenaltyPayment { get; set; }
    }
    public class ClsTotalInfo
    {
        public int? ContractId { set; get; }
        public int? TotalPenaltyDay { set; get; }
        public int? NMonth { set; get; }

    }

    public class ClsFixSchedule
    {
        public int house_id { set; get; }
        public DateTime error_date { set; get; }
    }
    public class ClsFixAdjustment
    {
        public int house_id { set; get; }
        public DateTime payment_date { set; get; }
        public decimal amount { set; get; }
    }
    public class ClsWaiveInfo
    {
        [Column("monthly_payment")]
        public decimal? MonthlyPayment { get; set; }

        [Column("nday_interest")]
        public int? NDayInterest { get; set; }
        
        [Column("payment_date")]
        public DateTime? PaymentDate { get; set; }

        [Column("last_paid_date")]
        public DateTime? LastPaymentDate { get; set; }

    }

}
