﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_api")]
    public partial class WorkflowApi
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("API_name")]
        [StringLength(100)]
        public string ApiName { get; set; }
        [Column("URL")]
        [StringLength(200)]
        public string Url { get; set; }
        [Column("payload")]
        [StringLength(2000)]
        public string Payload { get; set; }
    }
}
