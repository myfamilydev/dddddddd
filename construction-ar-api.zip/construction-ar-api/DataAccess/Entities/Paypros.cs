﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("paypros")]
    public partial class Paypros
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_type_id")]
        public int? HouseTypeId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("h_id")]
        [StringLength(50)]
        public string HId { get; set; }
        [Column("block")]
        [StringLength(2)]
        public string Block { get; set; }
        [Column("road_type")]
        [StringLength(100)]
        public string RoadType { get; set; }
        [Column("no")]
        [StringLength(50)]
        public string No { get; set; }
        [Column("number")]
        [StringLength(50)]
        public string Number { get; set; }
        [Column("street")]
        [StringLength(50)]
        public string Street { get; set; }
        [Column("village")]
        [StringLength(255)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(255)]
        public string Commune { get; set; }
        [Column("district")]
        [StringLength(255)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(255)]
        public string Province { get; set; }
        [Column("phase")]
        [StringLength(2)]
        public string Phase { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
        [Column("payproref")]
        [StringLength(100)]
        public string Payproref { get; set; }
        [Column("payproaccid")]
        [StringLength(100)]
        public string Payproaccid { get; set; }
        [Column("billercode")]
        [StringLength(100)]
        public string Billercode { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
