﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{

    [Table("payment_schedules_instant_main")]
    public partial class PaymentSchedulesInstantMain
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("house_price", TypeName = "decimal(10, 2)")]
        public decimal? HousePrice { get; set; }
        [Column("booking_amount", TypeName = "decimal(10, 2)")]
        public decimal? BookingAmount { get; set; }
        [Column("discount_percent")]
        public double? DiscountPercent { get; set; }
        [Column("discount_amount", TypeName = "decimal(10, 2)")]
        public decimal? DiscountAmount { get; set; }
        [Column("contract_amount", TypeName = "decimal(10, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("initial_payment", TypeName = "decimal(10, 2)")]
        public decimal? InitialPayment { get; set; }
        [Column("n_percent")]
        public double? NPercent { get; set; }
        [Column("n_amount", TypeName = "decimal(10, 2)")]
        public decimal? NAmount { get; set; }
        [Column("n_period_month")]
        public int? NPeriodMonth { get; set; }
        [Column("interest_percent")]
        public double? InterestPercent { get; set; }
        [Column("interest_amount", TypeName = "decimal(10, 2)")]
        public decimal? InterestAmount { get; set; }
        [Column("interest_period_month")]
        public int? InterestPeriodMonth { get; set; }
        [Column("monthly_interest", TypeName = "decimal(8, 7)")]
        public decimal? MonthlyInterest { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }

}
