﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VWorkflowAction
    {
        [Column("workflow_id")]
        public byte WorkflowId { get; set; }
        [Column("workflow_name")]
        [StringLength(50)]
        public string WorkflowName { get; set; }
        [Column("wf_detail_uuid")]
        public Guid? WfDetailUuid { get; set; }
        [Column("cur_status")]
        public byte? CurStatus { get; set; }
        [Column("role_name")]
        [StringLength(30)]
        public string RoleName { get; set; }
        [Column("btn_action")]
        [StringLength(30)]
        public string BtnAction { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
        [Column("role_order")]
        public byte? RoleOrder { get; set; }
        [Column("cur_role")]
        public int? CurRole { get; set; }
    }
}
