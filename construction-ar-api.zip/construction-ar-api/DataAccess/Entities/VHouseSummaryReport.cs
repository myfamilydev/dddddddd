﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VHouseSummaryReport
    {
        [Required]
        [StringLength(1)]
        public string ProjectShort { get; set; }
        [Required]
        [StringLength(1)]
        public string Name { get; set; }
        public int TotalBooking { get; set; }
        [Required]
        [StringLength(1)]
        public string Sold { get; set; }
    }
}
