﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("contracts_terminations")]
    public partial class ContractsTerminations
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("termination_type")]
        public int? TerminationType { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }

        [Column("booking_id")]
        public int? BookingId { get; set; }

        [Column("contract_id_transfer")]
        public int? ContractIdTransfer { get; set; }

        [Column("contract_amount")]
        public decimal? ContractAmount { get; set; }
        [Column("total_paid_principle")]
        public decimal? TotalPaidPrinciple { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("contract_history_id")]
        public int? ContractHistoryId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("terminate_date")]
        public DateTime? TerminateDate { get; set; }
        [Column("total_paid_interest")]
        public decimal? TotalPaidInterest { get; set; }
        [Column("total_paid_penalty")]
        public decimal? TotalPaidPenalty { get; set; }
        [Column("total_public_service")]
        public decimal? TotalPublicService { get; set; }
        [Column("project_id_transfer")]
        public int? ProjectIdTransfer { get; set; }
        [Column("house_id_transfer")]
        public int? HouseIdTransfer { get; set; }

        [Column("transfer_amount")]
        public decimal? TransferAmount { get; set; }

        [Column("outstanding_principle")]
        public decimal? OutstandingPrinciple { get; set; }
        [Column("mgt_approval_date")]
        public DateTime? MgtApprovalDate { get; set; }
        [Column("outstanding_transfer")]
        public decimal? OutstandingTransfer { get; set; }
        [Column("interest_transfer")]
        public decimal? InterestTransfer { get; set; }
        [Column("penalty_transfer")]
        public decimal? PenaltyTransfer { get; set; }


    }
}
