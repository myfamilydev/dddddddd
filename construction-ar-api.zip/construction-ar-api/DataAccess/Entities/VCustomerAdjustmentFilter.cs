﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VCustomerAdjustmentFilter
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }     
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("name_kh")]
        public string CustomerName { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("adjust_from")]
        public string AdjustFrom { get; set; }
        [Column("adjust_to")]
        public string AdjustTo { get; set; }
        [Column("affect_customer_history")]
        public bool? AffectCustomerHistory { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
    }
}
