﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VContractOutstandingBalance
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer1_name")]
        [StringLength(150)]
        public string Customer1Name { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("customer2_name")]
        [StringLength(150)]
        public string Customer2Name { get; set; }
        [Column("outstanding_balance")]
        public decimal? OutstandingBalance { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
    }
}
