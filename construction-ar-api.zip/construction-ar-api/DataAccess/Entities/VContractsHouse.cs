﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VContractsHouse
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        public string CustomerName { get; set; }
    }
}
