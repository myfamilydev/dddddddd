﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptContractCancellation
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("cancel_date", TypeName = "datetime")]
        public DateTime? CancelDate { get; set; }
        [Column("ct_id")]
        [StringLength(10)]
        public string CtId { get; set; }
        [Column("bk_id")]
        [StringLength(20)]
        public string BkId { get; set; }
        [Column("customer_name")]
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
