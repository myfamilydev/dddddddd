﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("house_block_prices")]
    public partial class HouseBlockPrices
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Required]
        [Column("block")]
        [StringLength(5)]
        public string Block { get; set; }
        [Required]
        [Column("road_type")]
        [StringLength(10)]
        public string RoadType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime UpdatedAt { get; set; }
        [Column("price")]
        public double Price { get; set; }
        [Column("house_category_id")]
        public int HouseCategoryId { get; set; }
        [Column("house_type_id")]
        public int HouseTypeId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
