﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("house_handovers_batch")]
    public partial class HouseHandoversBatch
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("project_short")]
        [StringLength(50)]
        public string ProjectShort { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_no")]
        [StringLength(50)]
        public string HouseNo { get; set; }
        [Column("hand_over_date", TypeName = "datetime")]
        public DateTime? HandOverDate { get; set; }
        [Column("warrenty_end_date", TypeName = "datetime")]
        public DateTime? WarrentyEndDate { get; set; }
        [Column("schedule_date", TypeName = "datetime")]
        public DateTime? ScheduleDate { get; set; }
        [Column("person_handle")]
        [StringLength(100)]
        public string PersonHandle { get; set; }
        [Column("water")]
        [StringLength(50)]
        public string Water { get; set; }
        [Column("electricity")]
        [StringLength(50)]
        public string Electricity { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("batch_code")]
        public Guid? BatchCode { get; set; }
    }
}
