﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("tbl_contract")]
    public partial class TblContract
    {
        [Column("contract_id")]
        public int? ContractId { get; set; }
    }
}
