﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VContractsOwnerships
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }

        [Column("booking_id")]
        public int? BookingId { get; set; }

        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("from_customer_1")]
        public int? FromCustomer1 { get; set; }
        [Column("from_customer_1_name")]
        [StringLength(150)]
        public string FromCustomer1Name { get; set; }
        [Column("from_customer_2")]
        public int? FromCustomer2 { get; set; }
        [Column("from_customer_2_name")]
        [StringLength(150)]
        public string FromCustomer2Name { get; set; }
        [Column("to_customer_1")]
        public int? ToCustomer1 { get; set; }
        [Column("to_customer_1_name")]
        [StringLength(150)]
        public string ToCustomer1Name { get; set; }
        [Column("to_customer_2")]
        public int? ToCustomer2 { get; set; }
        [Column("to_customer_2_name")]
        [StringLength(150)]
        public string ToCustomer2Name { get; set; }
        [Column("relationship")]
        [StringLength(300)]
        public string Relationship { get; set; }
        [Column("charge_fee")]
        public decimal? ChargeFee { get; set; }
        [Column("request_type")]
        public int? RequestType { get; set; }
        [Column("request_date", TypeName = "date")]
        public DateTime? RequestDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_by_name")]
        [StringLength(200)]
        public string CreatedByName { get; set; }
        [Required]
        [Column("request_type_name")]
        [StringLength(8)]
        public string RequestTypeName { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
    }
}
