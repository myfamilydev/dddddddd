﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("payment_terms_items")]
    public partial class PaymentTermsItems
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        [Column("paid_off_amount")]
        public float? PaidOffAmount { get; set; }
        [Column("paid_off_type")]
        [StringLength(10)]
        public string PaidOffType { get; set; }
        [Column("paid_off_term_month_min")]
        public short? PaidOffTermMonthMin { get; set; }
        [Column("paid_off_term_month_max")]
        public short? PaidOffTermMonthMax { get; set; }
        [Column("interest_percent_month")]
        public float? InterestPercentMonth { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
