﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("commission_criteria")]
    public partial class CommissionCriteria
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("criteria")]
        [StringLength(5)]
        public string Criteria { get; set; }
        [Column("value")]
        public double? Value { get; set; }
        [Column("commission_method_id")]
        public int? CommissionMethodId { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
