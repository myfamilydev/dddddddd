﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("dashboard")]
    public partial class Dashboard
    {
        [Column("house_count")]
        public int? HouseCount { get; set; }
        [Column("contract_count")]
        public int? ContractCount { get; set; }
        [Column("booking_outstanding")]
        public int? BookingOutstanding { get; set; }
        [Column("house_available")]
        public int? HouseAvailable { get; set; }
        [Column("house_penalty")]
        public int? HousePenalty { get; set; }
    }
}
