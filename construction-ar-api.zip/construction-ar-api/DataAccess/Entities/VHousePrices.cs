﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VHousePrices
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("price")]
        public decimal Price { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("remarks")]
        [StringLength(1000)]
        public string Remarks { get; set; }
        [Column("project_name")]
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [StringLength(23)]
        public string LandSize { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [StringLength(250)]
        public string HouseCategory { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
