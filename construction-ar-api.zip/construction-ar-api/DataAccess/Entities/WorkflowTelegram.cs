﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_telegram")]
    public partial class WorkflowTelegram
    {
        [Column("Telegram_Group")]
        [StringLength(10)]
        public string TelegramGroup { get; set; }
        [Column("Telegram_Group_Id")]
        public long? TelegramGroupId { get; set; }
    }
}
