﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("sessions_log")]
    public partial class SessionsLog
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("remote_ip")]
        [StringLength(100)]
        public string RemoteIp { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [StringLength(100)]
        public string token { get; set; }
        [Column("status")]
        public short? status { get; set; }        

    }
}
