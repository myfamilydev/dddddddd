﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VCategoryPrice
    {
        public int HouseId { get; set; }
        [Column("name")]
        [StringLength(250)]
        public string Name { get; set; }
        [Column("public_service")]
        public double? PublicService { get; set; }
    }
}
