﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VSaleComplaintRequestFilter
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("house_type")]       
        public string HouseType { get; set; }
        [Column("street_no")]
        public string StreetNo { get; set; }
        [Column("direct_sale_name")]
        [StringLength(50)]
        public string DirectSaleName { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("issue_date", TypeName = "date")]
        public DateTime? IssueDate { get; set; }
        [Column("direct_sale_id")]
        public int? DirectSaleId { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
