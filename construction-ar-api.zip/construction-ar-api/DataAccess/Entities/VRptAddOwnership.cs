﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptAddOwnership
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("pro_ref_no")]
        [StringLength(50)]
        public string ProRefNo { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("contract_amount")]
        public double? ContractAmount { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("paid_amount")]
        public double? PaidAmount { get; set; }
        [Column("from_customer_1")]
        [StringLength(150)]
        public string FromCustomer1 { get; set; }
        [Column("from_customer_2")]
        [StringLength(150)]
        public string FromCustomer2 { get; set; }
        [Column("to_customer_1")]
        [StringLength(150)]
        public string ToCustomer1 { get; set; }
        [Column("to_customer_2")]
        [StringLength(150)]
        public string ToCustomer2 { get; set; }
    }
}
