﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("bank_settlement")]
    public partial class BankSettlement
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("bank_name")]
        [StringLength(500)]
        public string BankName { get; set; }
        [Column("bank_account_name")]
        [StringLength(500)]
        public string BankAccountName { get; set; }
        [Column("bank_account_number")]
        [StringLength(350)]
        public string BankAccountNumber { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("lyhour_card")]
        public byte? LyhourCard { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
