﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("paid_off_discount_terms")]
    public partial class PaidOffDiscountTerms
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        [Column("percentage")]
        public int? Percentage { get; set; }
        [Column("duration")]
        public int? Duration { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
