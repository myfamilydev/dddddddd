﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_configs")]
    public partial class WorkflowConfigs
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Required]
        [Column("model")]
        [StringLength(50)]
        public string Model { get; set; }
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("flows", TypeName = "text")]
        public string Flows { get; set; }
    }
}
