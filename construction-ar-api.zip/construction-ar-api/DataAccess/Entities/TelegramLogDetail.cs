﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("telegram_log_detail")]
    public partial class TelegramLogDetail
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("workflow_id")]
        public int? WorkflowId { get; set; }
        [Column("telegram_content")]
        [StringLength(3000)]
        public string TelegramContent { get; set; }
        [Column("telegram_group_id")]
        public int? TelegramGroupId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
    }
}
