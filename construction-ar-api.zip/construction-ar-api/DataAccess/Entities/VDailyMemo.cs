﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VDailyMemo
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("in_date", TypeName = "date")]
        public DateTime? InDate { get; set; }
        [Column("memo")]
       
        public string Memo { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(200)]
        public string FullName { get; set; }
    }
}
