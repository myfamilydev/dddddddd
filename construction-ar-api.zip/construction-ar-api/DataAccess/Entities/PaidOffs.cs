﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("paid_offs")]
    public partial class PaidOffs
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("amount")]
        [StringLength(50)]
        public string Amount { get; set; }
        [Column("date", TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [Column("expire_date", TypeName = "datetime")]
        public DateTime? ExpireDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("staff_id")]
        public int? StaffId { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
