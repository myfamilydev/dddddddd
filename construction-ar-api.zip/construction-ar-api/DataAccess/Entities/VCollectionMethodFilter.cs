﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VCollectionMethodFilter
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("method_name")]
        [StringLength(50)]
        public string MethodName { get; set; }
        [Column("account")]
        [StringLength(50)]
        public string Account { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by_name")]
        [StringLength(50)]
        public string CreatedByName { get; set; }
    }
}
