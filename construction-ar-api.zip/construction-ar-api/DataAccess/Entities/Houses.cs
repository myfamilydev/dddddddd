﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("houses")]
    public partial class Houses
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("house_type_id")]
        public int? HouseTypeId { get; set; }
        [Column("block")]
        [StringLength(10)]
        public string Block { get; set; }
        [Column("road_type")]
        [StringLength(30)]
        public string RoadType { get; set; }
        [Column("number")]
        [StringLength(10)]
        public string Number { get; set; }
        [Column("street_id")]
        public int? StreetId { get; set; }
        [Column("price")]
        public decimal? Price { get; set; }
        [Column("phase")]
        [StringLength(10)]
        public string Phase { get; set; }
        [Column("remarks")]
        [StringLength(500)]
        public string Remarks { get; set; }
        [Column("payproref")]
        [StringLength(30)]
        public string Payproref { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [Column("billercode")]
        [StringLength(30)]
        public string Billercode { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("land_width")]
        [StringLength(10)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        public string LandLength { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
