﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptHouseRemainingList
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("project_id")]
        public int ProjectId { get; set; }
        [Column("house_type_id")]
        public int? HouseTypeId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("h_id")]
        [StringLength(50)]
        public string HId { get; set; }
        [Column("block")]
        [StringLength(2)]
        public string Block { get; set; }
        [Column("road_type")]
        [StringLength(100)]
        public string RoadType { get; set; }
        [Column("house_no")]
        [StringLength(50)]
        public string HouseNo { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("street_id")]
        public int? StreetId { get; set; }
        [Column("phase")]
        [StringLength(2)]
        public string Phase { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
        [Column("payproref")]
        [StringLength(100)]
        public string Payproref { get; set; }
        [Column("payproaccid")]
        [StringLength(100)]
        public string Payproaccid { get; set; }
        [Column("billercode")]
        [StringLength(100)]
        public string Billercode { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("p_id")]
        [StringLength(50)]
        public string PId { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("pro_ref_no")]
        [StringLength(50)]
        public string ProRefNo { get; set; }
        [Column("pro_desc")]
        public string ProDesc { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("village")]
        [StringLength(150)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(150)]
        public string Commune { get; set; }
        [Column("district")]
        [StringLength(150)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(150)]
        public string Province { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("h_width")]
        [StringLength(10)]
        public string HWidth { get; set; }
        [Column("h_length")]
        [StringLength(10)]
        public string HLength { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("category_name")]
        [StringLength(250)]
        public string CategoryName { get; set; }
    }
}
