﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VBookingHouses
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        public byte ContractStatus { get; set; }
        public int ContractHouseId { get; set; }
        [Column("current_customer_relationship")]
        public string CurrentCustomerRelationship { get; set; }
    }
}
