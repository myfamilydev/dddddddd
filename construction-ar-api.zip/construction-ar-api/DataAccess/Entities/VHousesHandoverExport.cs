﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VHousesHandoverExport
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("number")]
        [StringLength(10)]
        public string Number { get; set; }
        [Column("hand_over_date")]
        public int? HandOverDate { get; set; }
        [Column("warrenty_end_date")]
        public int? WarrentyEndDate { get; set; }
        [Column("schedule_date")]
        public int? ScheduleDate { get; set; }
        [Column("person_handle")]
        public int? PersonHandle { get; set; }
        [Column("water")]
        public int? Water { get; set; }
        [Column("electricity")]
        public int? Electricity { get; set; }
        [Column("remark")]
        public int? Remark { get; set; }
    }
}
