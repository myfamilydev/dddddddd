﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("parameters")]
    public partial class Parameters
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("parameter_type_id")]
        public int ParameterTypeId { get; set; }
        [Required]
        [Column("parameter_value")]
        [StringLength(50)]
        public string ParameterValue { get; set; }
        [Column("parameter_key")]
        [StringLength(50)]
        public string ParameterKey { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime UpdatedAt { get; set; }
    }
}
