﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VBookingsChangeOwners
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("from_customer_1")]
        public int? FromCustomer1 { get; set; }
        [Column("from_customer_2")]
        public int? FromCustomer2 { get; set; }
        [Column("to_customer_1")]
        public int? ToCustomer1 { get; set; }
        [Column("to_customer_2")]
        public int? ToCustomer2 { get; set; }
        [Column("relationship")]
        [StringLength(100)]
        public string Relationship { get; set; }
        [Column("charge_fee")]
        public float? ChargeFee { get; set; }
        [Column("request_at", TypeName = "date")]
        public DateTime? RequestAt { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("from_customer1_name")]
        [StringLength(150)]
        public string FromCustomer1Name { get; set; }
        [Column("from_customer2_name")]
        [StringLength(150)]
        public string FromCustomer2Name { get; set; }
        [Column("to_customer1_name")]
        [StringLength(150)]
        public string ToCustomer1Name { get; set; }
        [Column("to_customer2_name")]
        [StringLength(150)]
        public string ToCustomer2Name { get; set; }
        [Column("created_by_name")]
        [StringLength(200)]
        public string CreatedByName { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
    }
}
