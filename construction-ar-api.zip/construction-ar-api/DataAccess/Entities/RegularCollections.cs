﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("regular_collections")]
    public partial class RegularCollections
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("collection_class")]
        [StringLength(20)]
        public string CollectionClass { get; set; }
        [Column("payee_id")]
        public int? PayeeId { get; set; }
        [Column("total_amount")]
        public decimal? TotalAmount { get; set; }
        [Column("method_1_id")]
        public int? Method1Id { get; set; }
        [Column("method_1_amount")]
        public decimal? Method1Amount { get; set; }
        [Column("ref_no1")]
        [StringLength(130)]
        public string RefNo1 { get; set; }
        [Column("ref_date1", TypeName = "date")]
        public DateTime? RefDate1 { get; set; }
        [Column("method_2_id")]
        public int? Method2Id { get; set; }
        [Column("method_2_amount")]
        public decimal? Method2Amount { get; set; }
        [Column("ref_no2")]
        [StringLength(130)]
        public string RefNo2 { get; set; }
        [Column("ref_date2", TypeName = "date")]
        public DateTime? RefDate2 { get; set; }
        [Column("method_3_id")]
        public int? Method3Id { get; set; }
        [Column("method_3_amount")]
        public decimal? Method3Amount { get; set; }
        [Column("ref_no3")]
        [StringLength(130)]
        public string RefNo3 { get; set; }
        [Column("ref_date3", TypeName = "date")]
        public DateTime? RefDate3 { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("received_by")]
        public int? ReceivedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("due_date", TypeName = "datetime")]
        public DateTime? DueDate { get; set; }
        [Column("transaction_no")]
        public long? TransactionNo { get; set; }
        [Column("adjustment_id")]
        public int? AdjustmentId { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Column("preprinted_number")]
        [StringLength(20)]
        public string PreprintedNumber { get; set; }
        [Column("account_number1")]        
        public string AccountNumber1 { get; set; }
        [Column("account_number2")]        
        public string AccountNumber2 { get; set; }
        [Column("account_number3")]        
        public string AccountNumber3 { get; set; }
        [Column("is_moved")]
        public short? IsMoved { get; set; }
        [Column("number_of_change")]
        public short? NumberOfChange { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("public_service_discount")]
        public decimal? PublicServiceDiscount { get; set; }
        [Column("over_final_payment")]
        public decimal? OverFinalPayment { get; set; }
    }
}
