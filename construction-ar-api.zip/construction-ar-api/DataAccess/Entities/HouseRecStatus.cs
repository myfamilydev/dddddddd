﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("house_rec_status")]
    public partial class HouseRecStatus
    {
        [Column("workflow_status_id")]
        public int? WorkflowStatusId { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [Column("ordering")]
        public int? Ordering { get; set; }
        
    }
}
