﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptSummaryDailyCollection
    {
        [Column("report_date", TypeName = "date")]
        public DateTime? ReportDate { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("transaction_type")]
        [StringLength(255)]
        public string TransactionType { get; set; }
        [Column("total_payment")]
        public double? TotalPayment { get; set; }
    }
}
