﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptPenalty
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("ct_id")]
        [StringLength(10)]
        public string CtId { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("mobile_phone")]
        [StringLength(20)]
        public string MobilePhone { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("transaction_type")]
        [StringLength(255)]
        public string TransactionType { get; set; }
        [Column("amount")]
        public double Amount { get; set; }
    }
}
