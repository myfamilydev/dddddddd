﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRptBookingChangeHouse
    {
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("projectName")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        public int? Expr1 { get; set; }
        [StringLength(100)]
        public string Expr2 { get; set; }
        [StringLength(50)]
        public string Expr3 { get; set; }
        [StringLength(150)]
        public string Expr4 { get; set; }
        [StringLength(23)]
        public string Expr5 { get; set; }
        public double? Expr6 { get; set; }
        [Column("booking_amount")]
        public double? BookingAmount { get; set; }
        [Column("staff_name")]
        [StringLength(255)]
        public string StaffName { get; set; }
        [Column("change_house_reason", TypeName = "text")]
        public string ChangeHouseReason { get; set; }
    }
}
