﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VUserToProjectsBk
    {
        [Column("user_id")]
        public int UserId { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("user_to_project_id")]
        public int UserToProjectId { get; set; }
    }
}
