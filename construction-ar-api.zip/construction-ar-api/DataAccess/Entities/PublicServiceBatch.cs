﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("public_service_batch")]
    public partial class PublicServiceBatch
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("project_short")]
        [StringLength(50)]
        public string ProjectShort { get; set; }
        [Column("house_no")]
        [StringLength(50)]
        public string HouseNo { get; set; }
        [Column("step")]
        public int? Step { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("installment")]
        public int? Installment { get; set; }
        [Column("remark")]
        [StringLength(2000)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("batch_code")]
        public Guid? BatchCode { get; set; }
    }
}
