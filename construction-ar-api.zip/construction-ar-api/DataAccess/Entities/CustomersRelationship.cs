﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("customers_relationship")]
    public partial class CustomersRelationship
    {
        [Key]
        [Column("id")]
        public byte Id { get; set; }
        [Column("relation")]
        [StringLength(200)]
        public string Relation { get; set; }
    }
}
