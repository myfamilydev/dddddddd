﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("closing_periods")]
    public partial class ClosingPeriods
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("closing_date", TypeName = "date")]
        public DateTime? ClosingDate { get; set; }
        [Column("allow_user_id")]
        public int? AllowUserId { get; set; }
        [Column("num_of_change")]
        public short? NumOfChange { get; set; }
        [Column("num_of_used")]
        public short? NumOfUsed { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
