﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("bookings_ownerships")]
    public partial class BookingsOwnerships
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("from_customer_1")]
        public int? FromCustomer1 { get; set; }
        [Column("from_customer_2")]
        public int? FromCustomer2 { get; set; }
        [Column("to_customer_1")]
        public int? ToCustomer1 { get; set; }
        [Column("to_customer_2")]
        public int? ToCustomer2 { get; set; }
        [Column("relationship_id")]
        public int? RelationshipId { get; set; }
        [Column("charge_fee")]
        public double? ChargeFee { get; set; }
        [Column("request_at", TypeName = "datetime")]
        public DateTime? RequestAt { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
    }
}
