﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VAuditLog
    {

        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("number")]
        [StringLength(10)]
        public string Number { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("action")]
        [StringLength(50)]
        public string Action { get; set; }
        [Column("user_page_id")]
        public int? UserPageId { get; set; }
        [Column("page_name")]
        [StringLength(50)]
        public string PageName { get; set; }
        [Column("customer_name1")]
        [StringLength(100)]
        public string CustomerName1 { get; set; }
        [Column("customer_name2")]
        [StringLength(100)]
        public string CustomerName2 { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
    }
}
