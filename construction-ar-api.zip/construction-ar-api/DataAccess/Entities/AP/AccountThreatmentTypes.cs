﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AP
{
    [Table("account_threatment_types")]
    public partial class AccountThreatmentTypes
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("account_threatment_type")]
        [StringLength(100)]
        public string AccountThreatmentType { get; set; }
    }
}
