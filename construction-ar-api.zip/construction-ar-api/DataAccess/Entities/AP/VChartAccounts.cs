﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AP
{
    public partial class VChartAccounts
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public short? CompanyId { get; set; }
        [Column("account_code")]
        [StringLength(7)]
        public string AccountCode { get; set; }
        [Column("account_type_id")]
        public short? AccountTypeId { get; set; }
        [Column("account_name_kh")]
        [StringLength(400)]
        public string AccountNameKh { get; set; }
        [Column("account_name_en")]
        [StringLength(200)]
        public string AccountNameEn { get; set; }
        [Column("sub_account_of_id")]
        public int? SubAccountOfId { get; set; }
        [Column("description")]
        [StringLength(1000)]
        public string Description { get; set; }
        [Column("note")]
        [StringLength(1000)]
        public string Note { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("insert_type")]
        [StringLength(10)]
        public string InsertType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("business_type")]
        [StringLength(200)]
        public string BusinessType { get; set; }
        [Column("company_name")]
        [StringLength(200)]
        public string CompanyName { get; set; }
        [Column("account_type")]
        [StringLength(100)]
        public string AccountType { get; set; }
        [Required]
        [Column("sub_account_of")]
        [StringLength(110)]
        public string SubAccountOf { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [Column("created_by_name")]
        [StringLength(200)]
        public string CreatedByName { get; set; }
        [Column("updated_by_name")]
        [StringLength(200)]
        public string UpdatedByName { get; set; }
    }
}
