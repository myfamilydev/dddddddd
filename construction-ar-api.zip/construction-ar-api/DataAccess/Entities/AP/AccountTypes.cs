﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AP
{
    [Table("account_types")]
    public partial class AccountTypes
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("account_type")]
        [StringLength(100)]
        public string AccountType { get; set; }
    }
}
