﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("audit_log")]
    public partial class AuditLog
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("project")]
        [StringLength(50)]
        public string Project { get; set; }
        [Column("house_number")]
        [StringLength(20)]
        public string HouseNumber { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("action")]
        [StringLength(50)]
        public string Action { get; set; }
        [Column("user_page_id")]
        public int? UserPageId { get; set; }
        [Column("module_name")]
        [StringLength(50)]
        public string ModuleName { get; set; }
        [Column("customer_name1")]
        [StringLength(300)]
        public string CustomerName1 { get; set; }
        [Column("customer_name2")]
        [StringLength(300)]
        public string CustomerName2 { get; set; }
        [Column("customer_relationship")]
        [StringLength(60)]
        public string CustomerRelationship { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("in_date", TypeName = "date")]
        public DateTime? InDate { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_by_name")]
        [StringLength(50)]
        public string CreatedByName { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
