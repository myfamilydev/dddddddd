﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("bookings_discounts")]
    public partial class BookingsDiscounts
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("discount_id")]
        [StringLength(15)]
        public string DiscountId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("discount")]
        public double? Discount { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("date", TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
