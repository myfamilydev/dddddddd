﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VHouseHardTitles
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_hard_no")]
        [StringLength(100)]
        public string HouseHardNo { get; set; }
        [Column("house_hard_register")]
        [StringLength(100)]
        public string HouseHardRegister { get; set; }
        [Column("house_hard_type")]
        public int? HouseHardType { get; set; }
        [Column("PHOR_POR_no")]
        public int? PhorPorNo { get; set; }
        [Column("SPA_loan")]
        [StringLength(50)]
        public string SpaLoan { get; set; }
        [Column("hand_over_date", TypeName = "date")]
        public DateTime? HandOverDate { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
