﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VCommissionRequest
    {
        [Column("id")]
        public int Id { get; set; }        
        [Column("request_date", TypeName = "datetime")]
        public DateTime? RequestDate { get; set; }
        public string Project { get; set; }
        [Column("direct_sale_id")]
        public int? DirectSaleId { get; set; }
        [Column("fullname")]
        [StringLength(50)]
        public string Fullname { get; set; }

        [Column("remark")]
        public string Remark { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
    }
}
