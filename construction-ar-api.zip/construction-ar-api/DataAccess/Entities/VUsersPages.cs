﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VUsersPages
    {
        [Column("page_id")]
        public int PageId { get; set; }
        [Column("title")]
        [StringLength(100)]
        public string Title { get; set; }
        [Column("page_name")]
        [StringLength(50)]
        public string PageName { get; set; }
        [Column("url")]
        [StringLength(200)]
        public string Url { get; set; }
        [Column("icon")]
        [StringLength(50)]
        public string Icon { get; set; }
        [Column("type")]
        [StringLength(50)]
        public string Type { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("ordering")]
        public int? Ordering { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        public string RoleName { get; set; }
    }
}
