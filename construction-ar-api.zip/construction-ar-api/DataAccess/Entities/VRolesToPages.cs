﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRolesToPages
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("page_title")]
        [StringLength(100)]
        public string PageTitle { get; set; }
        [Column("page_name")]
        [StringLength(50)]
        public string PageName { get; set; }
        [Column("page_url")]
        [StringLength(200)]
        public string PageUrl { get; set; }
        [Column("icon_name")]
        [StringLength(50)]
        public string IconName { get; set; }
        [Column("page_type")]
        [StringLength(50)]
        public string PageType { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Column("ordering")]
        public int? Ordering { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        public string RoleName { get; set; }
    }
}
