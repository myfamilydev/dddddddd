﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("bookings_cancel")]
    public partial class BookingsCancel
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("cancel_date", TypeName = "date")]
        public DateTime? CancelDate { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("booking_history_id")]
        public int? BookingHistoryId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
    }
}
