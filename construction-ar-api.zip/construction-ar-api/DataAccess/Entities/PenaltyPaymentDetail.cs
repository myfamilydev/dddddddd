﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("penalty_payment_detail")]
    public partial class PenaltyPaymentDetail
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("schedule_id")]
        public int? ScheduleId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column("schedule_payment")]
        public decimal? SchedulePayment { get; set; }
        [Column("schedule_paid")]
        public decimal? SchedulePaid { get; set; }
        [Column("schedule_remain")]
        public decimal? ScheduleRemain { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("penalty_payment")]
        public decimal? PenaltyPayment { get; set; }
        [Column("pre_penalty_paid")]
        public decimal? PrePenaltyPaid { get; set; }
        [Column("penalty_paid")]
        public decimal? PenaltyPaid { get; set; }
        [Column("current_paid")]
        public decimal? CurrentPaid { get; set; }
        [Column("schedule_paid_current")]
        public decimal? SchedulePaidCurrent { get; set; }
        [Column("waive")]
        public decimal? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("in_type")]
        public int? InType { get; set; }
        [Column("is_change_end_date")]
        public bool? IsChangeEndDate { get; set; }
        [Column("in_date", TypeName = "date")]
        public DateTime? InDate { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
