﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("other_collection_info")]
    public partial class OtherCollectionInfo
    {
        [Key]
        [Column("regular_collection_id")]
        public int RegularCollectionId { get; set; }
        [Column("transaction_category_id")]
        public int? TransactionCategoryId { get; set; }
        [Column("other_customer")]
        [StringLength(150)]
        public string OtherCustomer { get; set; }
        [Column("phone_contact")]
        [StringLength(20)]
        public string PhoneContact { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
