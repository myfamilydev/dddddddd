﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("penalties_rules")]
    public partial class PenaltiesRules
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("percentage")]
        public float? Percentage { get; set; }
        [Column("min_day")]
        public short MinDay { get; set; }
        [Column("max_day")]
        public short MaxDay { get; set; }
        [Column("penalty_id")]
        public short? PenaltyId { get; set; }
        [Column("ordering")]
        public int? Ordering { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
