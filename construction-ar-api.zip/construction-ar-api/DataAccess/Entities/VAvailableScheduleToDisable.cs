﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VAvailableScheduleToDisable
    {
        [Column("payment_schedule_info_id")]
        public int PaymentScheduleInfoId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("outstanding_principle", TypeName = "decimal(15, 8)")]
        public decimal? OutstandingPrinciple { get; set; }
        [Column("n_month")]
        public int? NMonth { get; set; }
        [Column("paid_off_type")]
        [StringLength(10)]
        public string PaidOffType { get; set; }
        [Column("interest_percent_month")]
        public double? InterestPercentMonth { get; set; }
        [Column("start_payment_date", TypeName = "date")]
        public DateTime? StartPaymentDate { get; set; }
        [Column("monthly_payment", TypeName = "decimal(24, 11)")]
        public decimal? MonthlyPayment { get; set; }
        [Column("selected")]
        public bool? Selected { get; set; }
    }
}
