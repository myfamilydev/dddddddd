﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("payment_schedules_history")]
    public partial class PaymentSchedulesHistory
    {
        [Key]
        [Column("schedule_story_id")]
        public long ScheduleStoryId { get; set; }
        [Column("id")]
        public long Id { get; set; }
        [Column("payment_no")]
        public int? PaymentNo { get; set; }
        [Column("start_balance")]
        public decimal? StartBalance { get; set; }
        [Column("end_balance")]
        public decimal? EndBalance { get; set; }
        [Column("payment")]
        public decimal? Payment { get; set; }
        [Column("principle")]
        public decimal? Principle { get; set; }
        [Column("interest")]
        public decimal? Interest { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("paid_principle")]
        public decimal? PaidPrinciple { get; set; }
        [Column("paid_interest")]
        public decimal? PaidInterest { get; set; }
        [Column("accumulate_principle")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest")]
        public decimal? AccumulateInterest { get; set; }
        [Column("paymentterm_id")]
        public int? PaymenttermId { get; set; }
        [Column("remark")]
        [StringLength(200)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("current_paid_principle")]
        public decimal? CurrentPaidPrinciple { get; set; }
        [Column("current_paid_interest")]
        public decimal? CurrentPaidInterest { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("waive_interest")]
        public decimal? WaiveInterest { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
