﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VUserToRole
    {
        [Column("user_id")]
        public int UserId { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("department")]
        public int? Department { get; set; }
    }
}
