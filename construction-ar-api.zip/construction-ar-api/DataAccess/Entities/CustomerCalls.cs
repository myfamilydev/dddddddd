﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("customer_calls")]
    public partial class CustomerCalls
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("call_time", TypeName = "datetime")]
        public DateTime? CallTime { get; set; }
        [Column("phone_number")]
        [StringLength(50)]
        public string PhoneNumber { get; set; }
        [Column("type")]
        [StringLength(20)]
        public string Type { get; set; }
        [Column("purpose")]
        [StringLength(250)]
        public string Purpose { get; set; }
        [Column("note")]
        public string Note { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
