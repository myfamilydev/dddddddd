﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("users_roles")]
    public partial class UsersRoles
    {
        public UsersRoles()
        {
            UsersPagesToRoles = new HashSet<UsersPagesToRoles>();
        }

        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        public string RoleName { get; set; }
        [Column("role_description")]
        [StringLength(1000)]
        public string RoleDescription { get; set; }
        [Column("telegram_group_id")]
        public int? TelegramGroupId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }

        [InverseProperty("Role")]
        public virtual ICollection<UsersPagesToRoles> UsersPagesToRoles { get; set; }
    }
}
