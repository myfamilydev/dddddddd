﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VCustomerAdjustmentHouse
    {
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [Column("customer_name1")]
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column("customer_name2")]
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column("house_type")]        
        public string HouseType { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("current_customer1_id")]
        public int? CurrentCustomer1Id { get; set; }
        [Column("current_customer2_id")]
        public int? CurrentCustomer2Id { get; set; }
    }
}
