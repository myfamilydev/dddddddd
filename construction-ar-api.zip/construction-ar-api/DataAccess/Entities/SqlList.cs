﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("sql_list")]
    public partial class SqlList
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("sql_name")]
        [StringLength(50)]
        public string SqlName { get; set; }
        [Column("sql_content")]
        public string SqlContent { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
