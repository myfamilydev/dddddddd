﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("contracts_history")]
    public partial class ContractsHistory
    {
        [Key]
        [Column("contract_history_id")]
        public int ContractHistoryId { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_term_id")]
        public int? ContractTermId { get; set; }
        [Column("ad_hoc_discount_id")]
        public int? AdHocDiscountId { get; set; }
        [Column("initial_payment")]
        public decimal? InitialPayment { get; set; }
        [Column("payment_term_data")]
        public string PaymentTermData { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        [Column("payment_term_month")]
        public short? PaymentTermMonth { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("customer_relationship")]
        [StringLength(500)]
        public string CustomerRelationship { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("contract_amount")]
        public decimal? ContractAmount { get; set; }
        [Column("merged_houses")]
        [StringLength(250)]
        public string MergedHouses { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("cal_method")]
        public int? CalMethod { get; set; }
        [Column("payment_type")]
        public int? PaymentType { get; set; }
        [Column("reschedule_count")]
        public int? RescheduleCount { get; set; }
        [Column("contract_history_id1")]
        public int? ContractHistoryId1 { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
