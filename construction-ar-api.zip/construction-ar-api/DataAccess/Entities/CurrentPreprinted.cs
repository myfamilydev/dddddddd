﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("current_preprinted")]
    public partial class CurrentPreprinted
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("preprinted_number")]
        [StringLength(30)]
        public string PreprintedNumber { get; set; }
    }
}
