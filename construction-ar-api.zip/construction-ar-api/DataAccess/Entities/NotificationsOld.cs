﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("notifications_old")]
    public partial class NotificationsOld
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("workflow_id")]
        public int WorkflowId { get; set; }
        [Column("ref_id")]
        public int RefId { get; set; }
        [Column("request_from_user_id")]
        public int RequestFromUserId { get; set; }
        [Required]
        [Column("request_title")]
        [StringLength(100)]
        public string RequestTitle { get; set; }
        [Required]
        [Column("request_description")]
        [StringLength(100)]
        public string RequestDescription { get; set; }
        [Column("request_to_role_id")]
        public int RequestToRoleId { get; set; }
        [Column("request_to_user_id")]
        public int RequestToUserId { get; set; }
        [Column("request_from_user_action")]
        public int RequestFromUserAction { get; set; }
        [Column("is_check")]
        public byte IsCheck { get; set; }
        [Column("check_date", TypeName = "date")]
        public DateTime? CheckDate { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
