﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRegularCollectionDetailMethod
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("regular_collection_id")]
        public int RegularCollectionId { get; set; }
        [Column("amount", TypeName = "money")]
        public decimal? Amount { get; set; }
        [Column("transaction_type_id")]
        public int? TransactionTypeId { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("principle1", TypeName = "money")]
        public decimal? Principle1 { get; set; }
        [Column("transaction_type_id1")]
        public int? TransactionTypeId1 { get; set; }
        [Column("method_id")]
        public int? MethodId { get; set; }
    }
}
