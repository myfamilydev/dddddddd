﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRegularCollectionSplitMethod
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("collection_class")]
        [StringLength(20)]
        public string CollectionClass { get; set; }
        [Column("payee_id")]
        public int? PayeeId { get; set; }
        [Column("total_amount")]
        public float? TotalAmount { get; set; }
        [Column("method_id")]
        public int? MethodId { get; set; }
        [Column("method_amount")]
        public float? MethodAmount { get; set; }
        [Column("ref_no")]
        [StringLength(130)]
        public string RefNo { get; set; }
        [Column("ref_date", TypeName = "date")]
        public DateTime? RefDate { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("received_by")]
        public int? ReceivedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("due_date", TypeName = "datetime")]
        public DateTime? DueDate { get; set; }
        [Column("transaction_no")]
        public long? TransactionNo { get; set; }
        [Column("adjustment_id")]
        public int? AdjustmentId { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Column("preprinted_number")]
        [StringLength(20)]
        public string PreprintedNumber { get; set; }
    }
}
