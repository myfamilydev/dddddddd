﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class Testing
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        public float? TotalAmount { get; set; }
        public float? PrincipleAmount { get; set; }
        public float? InterestAmount { get; set; }
        [Column("owing")]
        public float? Owing { get; set; }
        [Column("payment")]
        public float? Payment { get; set; }
        [Column("principle")]
        public float? Principle { get; set; }
        [Column("interest")]
        public float? Interest { get; set; }
        [Column("amount")]
        public float Amount { get; set; }
    }
}
