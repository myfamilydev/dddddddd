﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VBookingsFullJoin
    {
        [Column("booking_id")]
        public int BookingId { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("direct_sale_id")]
        public int? DirectSaleId { get; set; }
        [Column("booking_date", TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column("expire_date", TypeName = "date")]
        public DateTime? ExpireDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("customer_relationship")]
        [StringLength(50)]
        public string CustomerRelationship { get; set; }
        [Column("booking_amount")]
        public decimal? BookingAmount { get; set; }
        [Column("house_price")]
        public decimal? HousePrice { get; set; }
        [Column("house_discount")]
        public decimal? HouseDiscount { get; set; }
        [Column("net_house_price")]
        public decimal? NetHousePrice { get; set; }
        [Column("remark_discount")]
        public string RemarkDiscount { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("pro_desc")]
        public string ProDesc { get; set; }
        [Column("cus1_name_en")]
        [StringLength(150)]
        public string Cus1NameEn { get; set; }
        [Column("cus1_name_kh")]
        [StringLength(150)]
        public string Cus1NameKh { get; set; }
        [Column("cus2_name_en")]
        [StringLength(150)]
        public string Cus2NameEn { get; set; }
        [Column("cus2_name_kh")]
        [StringLength(150)]
        public string Cus2NameKh { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("staff_name")]
        [StringLength(50)]
        public string StaffName { get; set; }
        [Column("cus1_mobile_phone")]
        [StringLength(30)]
        public string Cus1MobilePhone { get; set; }
        [Column("cus2_mobile_phone")]
        [StringLength(30)]
        public string Cus2MobilePhone { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
        [Required]
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [Column("is_transfer")]
        public bool? IsTransfer { get; set; }
    }
}
