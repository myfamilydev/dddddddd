﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("provinces")]
    public partial class Provinces
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Required]
        [Column("name")]
        public string Name { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Required]
        [Column("type")]
        [StringLength(20)]
        public string Type { get; set; }
        [Required]
        [Column("lang")]
        [StringLength(2)]
        public string Lang { get; set; }
        [Column("ref")]
        public int? Ref { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
