﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRegularCollectionDetails
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("regular_collection_id")]
        public int RegularCollectionId { get; set; }
        [Column("transaction_type_id")]
        public int? TransactionTypeId { get; set; }
        [Column("transaction_name")]
        [StringLength(50)]
        public string TransactionName { get; set; }
        [Column("amount")]
        public float Amount { get; set; }
    }
}
