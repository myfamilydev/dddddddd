﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("request_design_infos")]
    public partial class RequestDesignInfos
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("request_id")]
        public int RequestId { get; set; }
        [Required]
        [Column("work_measurement")]
        [StringLength(10)]
        public string WorkMeasurement { get; set; }
        [Required]
        [Column("work_quantity")]
        [StringLength(50)]
        public string WorkQuantity { get; set; }
        [Column("unit_cost")]
        public double UnitCost { get; set; }
        [Column("total_cost")]
        public double TotalCost { get; set; }
        [Required]
        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; }
        [Required]
        [Column("redesign_drawing")]
        [StringLength(250)]
        public string RedesignDrawing { get; set; }
    }
}
