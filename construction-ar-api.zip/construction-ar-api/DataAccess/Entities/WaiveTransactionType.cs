﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("waive_transaction_type")]
    public partial class WaiveTransactionType
    {
        [Key]
        [Column("id")]
        public byte Id { get; set; }
        [Column("waive_transaction_type")]
        [StringLength(50)]
        public string WaiveTransactionType1 { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("active")]
        public byte? Active { get; set; }
    }
}
