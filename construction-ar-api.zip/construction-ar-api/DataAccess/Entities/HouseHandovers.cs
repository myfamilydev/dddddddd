﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("house_handovers")]
    public partial class HouseHandovers
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("customer_id")]
        public int? CustomerId { get; set; }
        [Column("customer_id2")]
        public int? CustomerId2 { get; set; }
        [Column("hand_over_date", TypeName = "datetime")]
        public DateTime? HandOverDate { get; set; }
        [Column("warrenty_end_date", TypeName = "datetime")]
        public DateTime? WarrentyEndDate { get; set; }
        [Column("schedule_date", TypeName = "datetime")]
        public DateTime? ScheduleDate { get; set; }
        [Column("person_handle")]
        [StringLength(200)]
        public string PersonHandle { get; set; }
        [Column("water")]
        [StringLength(50)]
        public string Water { get; set; }
        [Column("electricity")]
        [StringLength(50)]
        public string Electricity { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("customer_relationship")]
        [StringLength(100)]
        public string CustomerRelationship { get; set; }
    }
}
