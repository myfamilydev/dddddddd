﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintPublicServiceDetail
    {
        public int? ReceiptNo { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime PaymentDate { get; set; }
        public double MonthlyFee { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        public float? PaidAmount { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("waive")]
        public double? Waive { get; set; }
        public double GrossAmount { get; set; }
        [Column("discount_amount")]
        public double? DiscountAmount { get; set; }
        public double? NetPay { get; set; }
        [StringLength(50)]
        public string UpdateBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
