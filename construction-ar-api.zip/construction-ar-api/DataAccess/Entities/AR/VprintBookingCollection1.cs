﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintBookingCollection1
    {
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column("RP_No")]
        [StringLength(30)]
        public string RpNo { get; set; }
        public int ReceiptNo { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [StringLength(150)]
        public string ReceivedFrom { get; set; }
        [Required]
        [StringLength(805)]
        public string Address { get; set; }
        [StringLength(4000)]
        public string PaymentMethod { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        public float? PaidAmount { get; set; }
        [StringLength(500)]
        public string PaidAmountInKhmer { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
