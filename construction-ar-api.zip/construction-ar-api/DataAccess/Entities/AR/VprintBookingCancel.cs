﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintBookingCancel
    {
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CancelDate { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        public float? HousePrice { get; set; }
        public float? BookingAmount { get; set; }
        public int FormId { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
    }
}
