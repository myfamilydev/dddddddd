﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintWaivePenalty
    {
        public long PenaltyPaymentId { get; set; }
        public int? WaiveId { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(61)]
        public string PhoneNumber { get; set; }
        [Column("village")]
        [StringLength(250)]
        public string Village { get; set; }
        [Column("district")]
        [StringLength(250)]
        public string District { get; set; }
        [Column("commune")]
        [StringLength(250)]
        public string Commune { get; set; }
        [Column("province")]
        [StringLength(250)]
        public string Province { get; set; }
       
        public decimal? NetAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        public int? DayPayment { get; set; }
        [Column(TypeName = "date")]
        public DateTime? StartDate { get; set; }
        public float? WaiveAmount { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
    }
}
