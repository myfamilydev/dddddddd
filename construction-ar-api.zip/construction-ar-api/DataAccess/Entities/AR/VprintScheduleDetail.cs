﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintScheduleDetail
    {
        public long ScheduleId { get; set; }  //payment_schedule_info_id 
        [Column("payment_schedule_info_id")]
        public int PaymentScheduleInfoId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("PaymentAmount")]
        public decimal? PaymentAmount { get; set; }
        [Column("principle")]
        public decimal? Principle { get; set; }
        [Column("interest")]
        public decimal? Interest { get; set; }
        [Column("accumulate_principle")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest")]
        public decimal? AccumulateInterest { get; set; }
        public int? ReceiptNo { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("PaidAmount")]
        public decimal? PaidAmount { get; set; }

        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("paid_interest")]
        public decimal? PaidInterest { get; set; }
        [Column("paid_principle")]
        public decimal? PaidPrinciple { get; set; }
        [Column("waive_interest")]
        public decimal? WaiveInterest { get; set; }

        [Column("end_balance")]
        public decimal? EndBalance { get; set; }
        [Column("start_balance")]
        public decimal? StartBalance { get; set; }
        public string TransactionNumber { get; set; }
        public string PrePrinted { get; set; }

        [Column("adjustment_id")]
        public int? AdjustmentId { set; get; }
        [Column("adjustment_type")]
        public short? AdjustmentType { set; get; }
        [Column("adjustment_status")]
        public short? AdjustmentStatus { set; get; }

        [Column("termination_transfer")]
        public int? TerminationTransfer { set; get; }

    }

    public class ClsfinalPaymentInfo
    {
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [Column("nationality")]
        [StringLength(50)]
        public string Nationality { get; set; }       
        [StringLength(50)]
        public string Nationality2 { get; set; }
        [Column("id_no")]
        [StringLength(50)]
        public string IdNo { get; set; }
        [StringLength(50)]
        public string IdNo2 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [StringLength(255)]
        public string ProjectProvince { get; set; }
      
        public decimal? ContractAmount { get; set; }
        [StringLength(500)]
        public string ContractAmountInKhmer { get; set; }
        
        public double? PaidOffAmount { get; set; }
        [StringLength(500)]
        public string PaidOffAmountInKhmer { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? FinalPaymentDate { get; set; }
        public string CustomerGender1 { get; set; }
        public string CustomerGender2 { get; set; }
       
        public decimal OverPaid { get; set; }

    }
    public class ClsContractReference
    {
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        public String FromCustomer1 { set; get; }
        public String FromCustomer2 { set; get; }
        public String ToCustomer1 { set; get; }
        public String ToCustomer2 { set; get; }
        public int Order { set; get; }
        public string Type { set; get; }
        public int SortOrder { set; get; }

    }

    public class ClsCollectionBookingInitialPayment
    {
        public int? ReceiptNo { set; get; }
        public DateTime? PaidDate { set; get; }
        public decimal? ReceivedAmount { set; get; }
        public string PrePrintedNumber { set; get; }
        public string TransactionNumber { set; get; }
        public int? TransactionTypeId { set; get; }
    }


}
