﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VrepPrintBookingChangeHouse
    {
        public int BookingChangeHouseId { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [StringLength(50)]
        public string CustomerNationality1 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [StringLength(50)]
        public string CustomerNationality2 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard2 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string HouseStreetNo { get; set; }
        [Column("land_width")]
        [StringLength(10)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        public string LandLength { get; set; }
        [Column("house_width")]
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [Column("house_length")]
        [StringLength(10)]
        public string HouseLength { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectProvince { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [StringLength(4000)]
        public string NetHousePrice { get; set; }
        [StringLength(500)]
        public string NetHousePriceInKhmer { get; set; }
        [StringLength(4000)]
        public string BookingAmount { get; set; }
        [StringLength(500)]
        public string BookingAmountInKhmer { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? BookingHouseChangeDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Required]
        [StringLength(100)]
        public string NewHouseType { get; set; }
        [StringLength(10)]
        public string NewHouseNumber { get; set; }
        [StringLength(100)]
        public string NewProjectName { get; set; }
        [StringLength(4000)]
        public string NewHousePrice { get; set; }
        [StringLength(500)]
        public string NewHousePriceInKhmer { get; set; }
        [StringLength(255)]
        public string NewProjectVillage { get; set; }
        [StringLength(255)]
        public string NewProjectDistrict { get; set; }
        [StringLength(255)]
        public string NewProjectCommune { get; set; }
        [StringLength(255)]
        public string NewProjectProvince { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
        public byte? BookingChangeHouseRecStatus { get; set; }
    }
}
