﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintInterest
    {
        [Column("Contract_Id")]
        public int ContractId { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        public float? AnualInterest { get; set; }
        public short? LoanTerm { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
    }
}
