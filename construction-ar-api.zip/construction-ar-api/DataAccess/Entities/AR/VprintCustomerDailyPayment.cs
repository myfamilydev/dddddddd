﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintCustomerDailyPayment
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("payment")]
        public float? Payment { get; set; }
        public float? PaidPrinciple { get; set; }
        public float? PaidInterest { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [StringLength(30)]
        public string PhoneContact1 { get; set; }
        [StringLength(30)]
        public string PhoneContact2 { get; set; }
        [Column("houseNumber")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        public int ContractId { get; set; }
        [StringLength(150)]
        public string Street { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
    }
}
