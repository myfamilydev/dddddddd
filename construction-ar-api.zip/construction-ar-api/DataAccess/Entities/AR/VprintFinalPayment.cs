﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintFinalPayment
    {
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("id")]
        public long Id { get; set; }
        [Column("amount")]
        public float Amount { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
    }
}
