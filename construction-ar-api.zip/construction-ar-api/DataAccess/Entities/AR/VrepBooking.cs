﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VrepBooking
    {
        [Column("ProjectID")]
        public short ProjectId { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("BookingID")]
        public int BookingId { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string RoadNo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [StringLength(150)]
        public string KhmerName { get; set; }
        [StringLength(30)]
        public string ContactNumber { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingExpireDate { get; set; }
        public float? HousePrice { get; set; }
        public float? HouseDiscount { get; set; }
        public float? HouseNetAmount { get; set; }
        public float? BookingAmount { get; set; }
        [Column("ContractID")]
        public int ContractId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        public string Remark { get; set; }
    }
}
