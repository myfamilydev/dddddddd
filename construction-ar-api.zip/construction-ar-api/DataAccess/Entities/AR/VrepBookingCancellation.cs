﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VrepBookingCancellation
    {
        [Column("ProjectID")]
        public short ProjectId { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CancelDate { get; set; }
        [StringLength(150)]
        public string KhmerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string StreetNo { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        public float? HousePrice { get; set; }
        public float? BookAmount { get; set; }
        public string Reason { get; set; }
    }
}
