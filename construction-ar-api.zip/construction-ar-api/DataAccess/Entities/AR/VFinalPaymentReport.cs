﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VFinalPaymentReport
    {
        public int FinalpaymentId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
      
        public decimal? NetSale { get; set; }
        [Column(TypeName = "money")]
        public decimal? FinalAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal? PaidOffDiscount { get; set; }
        [Column("final_payment_date", TypeName = "date")]
        public DateTime? FinalPaymentDate { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
       
        public decimal? TotalPrincipleAmount { get; set; }
    }
}
