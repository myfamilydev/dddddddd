﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintC2cReport
    {
        [Column("c2c_date", TypeName = "datetime")]
        public DateTime C2cDate { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        
        public decimal? PriceContract { get; set; }
        [StringLength(150)]
        public string OldCustomerName1 { get; set; }
        [StringLength(150)]
        public string OldCustomerName2 { get; set; }
        [StringLength(150)]
        public string NewCustomerName1 { get; set; }
        [StringLength(150)]
        public string NewCustomerName2 { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
      
        public decimal? TotalPaid { get; set; }
      
        public decimal? TotalRemain { get; set; }
    }
}
