﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class ByhouseTotalprinciple
    {
        public double? TotalPaid { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
    }
}
