﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintAccumulateReport
    {
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(25)]
        public string HouseSize { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        public int ContractNumber { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        
        public decimal? NetAmount { get; set; }
        [StringLength(123)]
        public string PhoneNumber { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        
        public decimal? AccPrinciple { get; set; }
        
        public decimal? AccPaidOffDiscount { get; set; }
      
        public decimal? AccInterest { get; set; }
        
        public decimal? AccPenalty { get; set; }
       
        public decimal? AccPublicService { get; set; }
    }
}
