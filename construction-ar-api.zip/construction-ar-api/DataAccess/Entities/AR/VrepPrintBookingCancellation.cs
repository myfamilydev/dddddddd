﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VrepPrintBookingCancellation
    {
        [StringLength(4000)]
        public string BookingAmount { get; set; }
        [StringLength(500)]
        public string BookingAmountInKhmer { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string HouseStreetNo { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingExpire { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        public int BookingCancelId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingCancelDate { get; set; }
        [StringLength(4000)]
        public string HousePrice { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? BookingCancelCreatedDate { get; set; }
        public byte? BookingCancelRecStatus { get; set; }
    }
}
