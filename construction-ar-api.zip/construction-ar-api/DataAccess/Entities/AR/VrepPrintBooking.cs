﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VrepPrintBooking
    {
        [Column("BookingID")]
        public int BookingId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingExpireDate { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [StringLength(780)]
        public string CustomerAddress1 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string HouseStreetNo { get; set; }
        [StringLength(23)]
        public string HouseLandSize { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        public float? HousePrice { get; set; }
        [StringLength(500)]
        public string HousePriceInKhmer { get; set; }
        public float? DiscountAmount { get; set; }
        [StringLength(500)]
        public string DiscountAmountInkhmer { get; set; }
        public float? NewHousePrice { get; set; }
        [StringLength(500)]
        public string NewHousePriceInKhmer { get; set; }
        public float? BookingAmount { get; set; }
        [StringLength(500)]
        public string BookingAmountInKhmer { get; set; }
        public string BookingRemark { get; set; }
        [Column("ProjectID")]
        public short ProjectId { get; set; }
        [Required]
        [StringLength(63)]
        public string CustomerContact { get; set; }
        public byte? BookingRecStatus { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [StringLength(255)]
        public string ProjectProvince { get; set; }
        [StringLength(10)]
        public string HouseLandWidth { get; set; }
        [StringLength(10)]
        public string HouseLandLength { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [Column("house_discount_percent")]
        public double? HouseDiscountPercent { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard1 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard2 { get; set; }
        [Column("remark_discount")]
        public string RemarkDiscount { get; set; }
        public string PaymentTermRemarks { get; set; }
    }
}
