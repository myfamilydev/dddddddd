﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintBookingDelay
    {
        [Column(TypeName = "datetime")]
        public DateTime CreateDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime ExpiredDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime DelayUntil { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        public float? HousePrice { get; set; }
        public float? BookingAmount { get; set; }
        public int FormId { get; set; }
        [Required]
        [Column("reason")]
        public string Reason { get; set; }
    }
}
