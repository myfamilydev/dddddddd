﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintAdhocDiscount
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        public int? ContractNumber { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        public float? HousePrice { get; set; }
        public float DiscountAmount { get; set; }
        public float? NetSale { get; set; }
        public float? BookingAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("discount_date", TypeName = "date")]
        public DateTime DiscountDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
