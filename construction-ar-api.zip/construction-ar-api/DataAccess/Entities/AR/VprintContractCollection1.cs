﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintContractCollection1
    {
        [Column("id")]
        public int Id { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(301)]
        public string CustomerName { get; set; }
        [StringLength(62)]
        public string PhoneCall { get; set; }
        [StringLength(4000)]
        public string PaymentType { get; set; }
        public float? TotalAmount { get; set; }
        [StringLength(500)]
        public string TotalAmountInKhmer { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [StringLength(154)]
        public string BankAccount { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaymentDate { get; set; }
        [Column("transaction_no")]
        public long? TransactionNo { get; set; }
        [Required]
        [StringLength(805)]
        public string Address { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
    }
}
