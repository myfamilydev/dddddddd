﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VrepBookingDelay
    {
        [Column(TypeName = "datetime")]
        public DateTime CreateDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ExpireDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime DelayUntil { get; set; }
        [StringLength(150)]
        public string KhmerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string StreetNo { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        public float? HouseNetPrice { get; set; }
        public float? BookAmount { get; set; }
        [Required]
        [Column("reason")]
        public string Reason { get; set; }
    }
}
