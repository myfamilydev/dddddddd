﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintScheduleDetailInstant
    {
        public int? PaymentScheduleInstantInfoId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
       
        public decimal? PaymentAmount { get; set; }
        [Column("principle")]
        public decimal? Principle { get; set; }
        [Column("interest")]
        public decimal? Interest { get; set; }
        [Column("accumulate_principle")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest")]
        public decimal? AccumulateInterest { get; set; }
        [Column("payment_no")]
        public int? PaymentNo { get; set; }
    }
}
