﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintBookingChangeOwnership
    {
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [StringLength(50)]
        public string Nationality1 { get; set; }
        [StringLength(50)]
        public string IdCard1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [StringLength(50)]
        public string Nationality2 { get; set; }
        [StringLength(50)]
        public string IdCard2 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [Column("village")]
        [StringLength(255)]
        public string Village { get; set; }
        [Column("communue")]
        [StringLength(255)]
        public string Communue { get; set; }
        [Column("district")]
        [StringLength(255)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(255)]
        public string Province { get; set; }
        [StringLength(150)]
        public string NewCustomerName1 { get; set; }
        [StringLength(150)]
        public string NewCustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NewCus1Dob { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NewCus2Dob { get; set; }
        [StringLength(50)]
        public string NewId1 { get; set; }
        [Required]
        [StringLength(50)]
        public string NewId2 { get; set; }
        public byte? Status { get; set; }
        public int BookingChangeOwnerId { get; set; }
    }
}
