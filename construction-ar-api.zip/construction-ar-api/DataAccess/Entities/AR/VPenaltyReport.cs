﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VPenaltyReport
    {
        public int Contractid { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [StringLength(63)]
        public string PhoneNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        public int LateDays { get; set; }
      
        public decimal? Principle { get; set; }
      
        public decimal? PenaltyAmount { get; set; }
      
        public decimal? TotalPayment { get; set; }
    }
}
