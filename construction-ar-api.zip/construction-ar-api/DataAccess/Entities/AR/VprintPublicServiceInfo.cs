﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class VprintPublicServiceInfo
    {
        [StringLength(150)]
        public string CustomerName { get; set; }
        [StringLength(50)]
        public string CustomerIdCard { get; set; }
        [StringLength(50)]
        public string CustomerSex { get; set; }
        [StringLength(4000)]
        public string CustomerDob { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(300)]
        public string CustomerContact { get; set; }
        [StringLength(150)]
        public string HouseStreetNo { get; set; }
        [StringLength(25)]
        public string HouseSize { get; set; }
        [StringLength(300)]
        public string Address { get; set; }
        [StringLength(4000)]
        public string HandOverDate { get; set; }
        [StringLength(4000)]
        public string ScheduleDate { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
    }
}
