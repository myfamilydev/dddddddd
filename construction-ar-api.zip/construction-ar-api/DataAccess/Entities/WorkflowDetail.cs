﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("workflow_detail")]
    public partial class WorkflowDetail
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("workflow_id")]
        public byte WorkflowId { get; set; }
        [Column("workflow_name")]
        [StringLength(50)]
        public string WorkflowName { get; set; }
        [Column("wf_detail_uuid")]
        public Guid? WfDetailUuid { get; set; }
        [Column("cur_status")]
        public byte? CurStatus { get; set; }
        [Column("cur_role")]
        public int? CurRole { get; set; }
        [Column("role_name")]
        [StringLength(30)]
        public string RoleName { get; set; }
        [Column("role_order")]
        public byte? RoleOrder { get; set; }
        [Column("btn_action")]
        [StringLength(30)]
        public string BtnAction { get; set; }
        [Column("cur_label")]
        [StringLength(100)]
        public string CurLabel { get; set; }
        [Column("post_status")]
        public byte? PostStatus { get; set; }
        [Column("email_content_id")]
        public int? EmailContentId { get; set; }
        [Column("sms_content_id")]
        public int? SmsContentId { get; set; }
        [Column("execute_api_id")]
        public int? ExecuteApiId { get; set; }
        [Column("workflow_status")]
        public byte? WorkflowStatus { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
        [Column("action_label")]
        [StringLength(50)]
        public string ActionLabel { get; set; }
        [Column("workflow_label")]
        [StringLength(50)]
        public string WorkflowLabel { get; set; }
        [Column("content1")]
        [StringLength(100)]
        public string Content1 { get; set; }
    }
}
