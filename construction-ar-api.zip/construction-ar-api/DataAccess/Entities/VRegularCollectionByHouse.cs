﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VRegularCollectionByHouse
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [StringLength(50)]
        public string MethodName1 { get; set; }
        [Column("method_1_amount")]
        public float? Method1Amount { get; set; }
        [StringLength(50)]
        public string MethodName2 { get; set; }
        [Column("method_2_amount")]
        public float? Method2Amount { get; set; }
        [StringLength(50)]
        public string MethodName3 { get; set; }
        [Column("method_3_amount")]
        public float? Method3Amount { get; set; }
        [Column("total_amount")]
        public float? TotalAmount { get; set; }
        [Column("transaction_no")]
        public long? TransactionNo { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("preprinted_number")]
        public string PreprintedNumber { get; set; }
    }
}
