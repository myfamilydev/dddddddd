﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VBookingsChangeHouse1
    {
        [Column("id")]
        public int Id { get; set; }
        public short? FromProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("From_ProjectName")]
        [StringLength(100)]
        public string FromProjectName { get; set; }
        [Column("From_HouseNo")]
        [StringLength(10)]
        public string FromHouseNo { get; set; }
        [Column("To_HouseNo")]
        [StringLength(10)]
        public string ToHouseNo { get; set; }
        [Column("To_ProjectName")]
        [StringLength(100)]
        public string ToProjectName { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ChangeHouseDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [StringLength(150)]
        public string KhmerName { get; set; }
        public short ToProjectId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
