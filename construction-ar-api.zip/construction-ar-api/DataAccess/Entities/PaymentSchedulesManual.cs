﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("payment_schedules_manual")]
    public partial class PaymentSchedulesManual
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("payment_schedule_info_id")]
        public int? PaymentScheduleInfoId { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("promise_payment_date", TypeName = "date")]
        public DateTime? PromisePaymentDate { get; set; }
        [Column("freez_penalty")]
        public decimal? FreezPenalty { get; set; }
        [Column("payment")]
        public decimal? Payment { get; set; }
        [Column("principle")]
        public decimal? Principle { get; set; }
        [Column("interest")]
        public decimal? Interest { get; set; }
        [Column("accumulate_principle")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest")]
        public decimal? AccumulateInterest { get; set; }
        [Column("end_balance")]
        public decimal? EndBalance { get; set; }
        [Column("paid_principle")]
        public decimal? PaidPrinciple { get; set; }
        [Column("paid_interest")]
        public decimal? PaidInterest { get; set; }
        [Column("paid_freez_penalty")]
        public decimal? PaidFreezPenalty { get; set; }
        [Column("current_paid_principle")]
        public decimal? CurrentPaidPrinciple { get; set; }
        [Column("current_paid_interest")]
        public decimal? CurrentPaidInterest { get; set; }
        [Column("current_paid_freez_penalty")]
        public decimal? CurrentPaidFreezPenalty { get; set; }
        [Column("receipt_no")]
        public int? ReceiptNo { get; set; }
        [Column("ref_no")]
        public int? RefNo { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
