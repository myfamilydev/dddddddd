﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VContractTermination
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("termination_type")]
        public int? TerminationType { get; set; }
        [Column("termination_type_name")]
        public string TerminationTypeName { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }

        [Column("booking_id")]
        public int? BookingId { get; set; }

        [Column("contract_id_transfer")]
        public int? ContractIdTransfer { get; set; }

        [Column("project_id_transfer")]
        public int? ProjectIdTransfer { get; set; }

        [Column("house_id_transfer")]
        public int? HouseIdTransfer { get; set; }
        [Column("contract_amount")]
        public decimal? ContractAmount { get; set; }

        [Column("transfer_amount")]
        public decimal? TransferAmount { get; set; }

        [Column("total_paid_interest")]
        public decimal? TotalPaidInterest { get; set; }

        [Column("total_paid_penalty")]
        public decimal? TotalPaidPenalty { get; set; }

        [Column("total_public_service")]
        public decimal? TotalPublicService { get; set; }

        [Column("terminate_date")]
        public DateTime? TerminateDate { get; set; }

        [Column("total_paid_principle")]
        public decimal? TotalPaidPrinciple { get; set; }
        [Column("remark")]
        public string Remark { get; set; }

        [Column("outstanding_principle")]
        public decimal? OutstandingPrinciple { get; set; }
        [Column("mgt_approval_date")]
        public DateTime? MgtApprovalDate { get; set; }

        [Column("outstanding_transfer")]
        public decimal? OutstandingTransfer { get; set; }
        [Column("interest_transfer")]
        public decimal? InterestTransfer { get; set; }
        [Column("penalty_transfer")]
        public decimal? PenaltyTransfer { get; set; }

        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }


    }
}
