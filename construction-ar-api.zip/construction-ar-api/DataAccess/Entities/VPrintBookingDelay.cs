﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VPrintBookingDelay
    {
        [Column("cus1_name_kh")]
        [StringLength(150)]
        public string Cus1NameKh { get; set; }
        [Column("cus1_dob", TypeName = "datetime")]
        public DateTime? Cus1Dob { get; set; }
        [Column("cus1_nationality")]
        [StringLength(50)]
        public string Cus1Nationality { get; set; }
        [Column("cus1_idno")]
        [StringLength(50)]
        public string Cus1Idno { get; set; }
        [Column("cus1_mobile_phone")]
        [StringLength(20)]
        public string Cus1MobilePhone { get; set; }
        [Column("cus2_name_kh")]
        [StringLength(150)]
        public string Cus2NameKh { get; set; }
        [Column("cus2_dob", TypeName = "datetime")]
        public DateTime? Cus2Dob { get; set; }
        [Column("cus2_nationality")]
        [StringLength(50)]
        public string Cus2Nationality { get; set; }
        [Column("cus2_idno")]
        [StringLength(50)]
        public string Cus2Idno { get; set; }
        [Column("cus2_mobile_phone")]
        [StringLength(20)]
        public string Cus2MobilePhone { get; set; }
        [Column("house_type")]
        [StringLength(124)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("village")]
        [StringLength(150)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(150)]
        public string Commune { get; set; }
        [Column("district")]
        [StringLength(150)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(150)]
        public string Province { get; set; }
        [Column("net_house_price")]
        [StringLength(1077)]
        public string NetHousePrice { get; set; }
        [Column("amount")]
        [StringLength(1077)]
        public string Amount { get; set; }
        [Column("booking_day")]
        public int? BookingDay { get; set; }
        [Column("booking_month")]
        public int? BookingMonth { get; set; }
        [Column("booking_year")]
        public int? BookingYear { get; set; }
        [Column("expire_day")]
        public int? ExpireDay { get; set; }
        [Column("expire_month")]
        public int? ExpireMonth { get; set; }
        [Column("expire_year")]
        public int? ExpireYear { get; set; }
        [Required]
        [Column("reason")]
        public string Reason { get; set; }
    }
}
