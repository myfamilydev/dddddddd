﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("public_services_update_price")]
    public partial class PublicServicesUpdatePrice
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("public_service_id")]
        public int? PublicServiceId { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }

        [Column("booking_id")]
        public int? BookingId { get; set; }

        [Column("step")]
        public int? Step { get; set; }
        [Column("monthly_fee", TypeName = "decimal(4, 2)")]
        public decimal? MonthlyFee { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("new_monthly_fee", TypeName = "decimal(4, 2)")]
        public decimal? NewMonthlyFee { get; set; }
        [Column("new_effective_date", TypeName = "date")]
        public DateTime? NewEffectiveDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("approval_date", TypeName = "date")]
        public DateTime? ApprovalDate { get; set; }
    }
}
