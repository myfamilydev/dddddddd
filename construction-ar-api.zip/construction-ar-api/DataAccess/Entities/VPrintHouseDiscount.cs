﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    public partial class VPrintHouseDiscount
    {
        [Column("amount")]
        public double? Amount { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("village")]
        [StringLength(150)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(150)]
        public string Commune { get; set; }
        [Column("district")]
        [StringLength(150)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(150)]
        public string Province { get; set; }
        [Column("amount_1")]
        public double? Amount1 { get; set; }
        [Column("house_type_1")]
        [StringLength(100)]
        public string HouseType1 { get; set; }
        [Column("house_number_1")]
        [StringLength(50)]
        public string HouseNumber1 { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("project_name_1")]
        [StringLength(255)]
        public string ProjectName1 { get; set; }
        [Column("l_width")]
        [StringLength(100)]
        public string LWidth { get; set; }
        [Column("l_length")]
        [StringLength(100)]
        public string LLength { get; set; }
        [Column("h_width")]
        [StringLength(10)]
        public string HWidth { get; set; }
        [Column("h_length")]
        [StringLength(10)]
        public string HLength { get; set; }
        [Column("customer_kh_1")]
        [StringLength(150)]
        public string CustomerKh1 { get; set; }
        [Column("dob_day_1")]
        public int? DobDay1 { get; set; }
        [Column("idno_1")]
        [StringLength(50)]
        public string Idno1 { get; set; }
        [Column("customer_kh_2")]
        [StringLength(150)]
        public string CustomerKh2 { get; set; }
        [Column("dob_day_2")]
        public int? DobDay2 { get; set; }
        [Column("idno_2")]
        [StringLength(50)]
        public string Idno2 { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("discount_amount")]
        public double? DiscountAmount { get; set; }
        [Column("net_price")]
        public double? NetPrice { get; set; }
        [Column("dob_month_1")]
        public int? DobMonth1 { get; set; }
        [Column("dob_year_1")]
        public int? DobYear1 { get; set; }
        [Column("dob_month_2")]
        public int? DobMonth2 { get; set; }
        [Column("dob_year_2")]
        public int? DobYear2 { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("discount_id")]
        public int DiscountId { get; set; }
        [Required]
        [Column("land_size")]
        [StringLength(203)]
        public string LandSize { get; set; }
        [Required]
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
    }
}
