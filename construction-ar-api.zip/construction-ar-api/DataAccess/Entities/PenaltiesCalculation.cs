﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("penalties_calculation")]
    public partial class PenaltiesCalculation
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("transaction_type_id")]
        public byte? TransactionTypeId { get; set; }
        [Column("penalty_ref")]
        [StringLength(20)]
        public string PenaltyRef { get; set; }
        [Column("penalty_ref_id")]
        public int? PenaltyRefId { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("calculation_date", TypeName = "date")]
        public DateTime? CalculationDate { get; set; }
        [Column("count_day")]
        public short? CountDay { get; set; }
        [Column("penalty_rule_id")]
        public int? PenaltyRuleId { get; set; }
        [Column("payment_amount")]
        public decimal? PaymentAmount { get; set; }
        [Column("amount")]
        public decimal? Amount { get; set; }
        [Column("partial")]
        public short? Partial { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
