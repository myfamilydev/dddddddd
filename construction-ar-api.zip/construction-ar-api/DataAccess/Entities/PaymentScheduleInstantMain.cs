﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("payment_schedule_instant_main")]
    public partial class PaymentScheduleInstantMain
    {
        [Column("n_monthly_interest")]
        public decimal? NMonthlyInterest { get; set; }
        [Column("n_percent")]
        public double? NPercent { get; set; }
        [Column("n_period_month")]
        public int? NPeriodMonth { get; set; }
        [Column("n_contract_date", TypeName = "date")]
        public DateTime? NContractDate { get; set; }
        [Column("n_net_amount")]
        public decimal? NNetAmount { get; set; }
        [Column("n_discount_amount")]
        public decimal? NDiscountAmount { get; set; }
        [Column("n_contract_amount")]
        public decimal? NContractAmount { get; set; }
        [Column("monthly_interest")]
        public decimal? MonthlyInterest { get; set; }
        [Column("percent")]
        public double? Percent { get; set; }
        [Column("period_month")]
        public int? PeriodMonth { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("net_amount")]
        public decimal? NetAmount { get; set; }
        [Column("discount_amount")]
        public decimal? DiscountAmount { get; set; }
        [Column("contract_amount")]
        public decimal? ContractAmount { get; set; }
        [Column("booking_amount")]
        public decimal? BookingAmount { get; set; }
        [Column("initial_payment")]
        public decimal? InitialPayment { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
    }
}
