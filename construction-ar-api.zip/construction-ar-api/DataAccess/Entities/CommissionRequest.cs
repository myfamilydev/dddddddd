﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities
{
    [Table("commission_request")]
    public partial class CommissionRequest
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }        
        [Column("request_date", TypeName = "datetime")]
        public DateTime? RequestDate { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("direct_sale_id")]
        public int? DirectSaleId { get; set; }                
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
