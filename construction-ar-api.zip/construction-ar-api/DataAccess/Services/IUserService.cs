﻿using DataAccess.Entities;
using System.Collections.Generic;

namespace dCanteen.Services
{
    public interface IUserService
    {
        List<Users> GetUsers();
    }
}
