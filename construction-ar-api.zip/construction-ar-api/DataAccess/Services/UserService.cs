﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using System.Collections.Generic;

namespace dCanteen.Services
{
    public class UserService : IUserService
    {
        private readonly MayuraContext _context;

        public UserService(MayuraContext odsDbContext)
        {

        }
        public List<Users> GetUsers()
        {
            List<Users> tm = new List<Users>();
            return tm;
        }
    }
}
