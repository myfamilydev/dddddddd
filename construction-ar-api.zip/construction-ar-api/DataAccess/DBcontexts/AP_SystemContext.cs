﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.AP;

namespace DataAccess.DBcontexts
{
    public partial class AP_SystemContext : DbContext
    {
        public AP_SystemContext()
        {
        }

        public AP_SystemContext(DbContextOptions<AP_SystemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AccountThreatmentTypes> AccountThreatmentTypes { get; set; }
        public virtual DbSet<AccountTypes> AccountTypes { get; set; }
        public virtual DbSet<ChartAccounts> ChartAccounts { get; set; }
        public virtual DbSet<Companies> Companies { get; set; }
        public virtual DbSet<CompanyCostCenters> CompanyCostCenters { get; set; }
        public virtual DbSet<VChartAccounts> VChartAccounts { get; set; }
        public virtual DbSet<VCompanyCostCenter> VCompanyCostCenter { get; set; }
        public virtual DbSet<VUsers> VUsers { get; set; }
        public virtual DbSet<VWorkflowStatus> VWorkflowStatus { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("data source=192.168.1.88;initial catalog=AP_System;user id=mayura;password=ARSystem@2021");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccountThreatmentTypes>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccountThreatmentType).IsUnicode(false);
            });

            modelBuilder.Entity<AccountTypes>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccountType).IsUnicode(false);
            });

            modelBuilder.Entity<ChartAccounts>(entity =>
            {
                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.AccountNameEn).IsUnicode(false);

                entity.Property(e => e.InsertType).IsUnicode(false);
            });

            modelBuilder.Entity<Companies>(entity =>
            {
                entity.Property(e => e.AccountThreatmentType).IsUnicode(false);

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.CompanyName).IsUnicode(false);
            });

            modelBuilder.Entity<CompanyCostCenters>(entity =>
            {
                entity.Property(e => e.CostCenter).IsUnicode(false);

                entity.Property(e => e.ShareType).IsUnicode(false);
            });

            modelBuilder.Entity<VChartAccounts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_chart_accounts");

                entity.Property(e => e.AccountCode).IsUnicode(false);

                entity.Property(e => e.AccountNameEn).IsUnicode(false);

                entity.Property(e => e.AccountType).IsUnicode(false);

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.CompanyName).IsUnicode(false);

                entity.Property(e => e.CreatedByName).IsUnicode(false);

                entity.Property(e => e.InsertType).IsUnicode(false);

                entity.Property(e => e.StatusName).IsUnicode(false);

                entity.Property(e => e.SubAccountOf).IsUnicode(false);

                entity.Property(e => e.UpdatedByName).IsUnicode(false);
            });

            modelBuilder.Entity<VCompanyCostCenter>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_company_cost_center");

                entity.Property(e => e.AccountThreatmentType).IsUnicode(false);

                entity.Property(e => e.BusinessType).IsUnicode(false);

                entity.Property(e => e.CompanyName).IsUnicode(false);

                entity.Property(e => e.CostCenter).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.ShareType).IsUnicode(false);
            });

            modelBuilder.Entity<VUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_users");

                entity.Property(e => e.Designation).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Password).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VWorkflowStatus>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_workflow_status");

                entity.Property(e => e.StatusName).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
