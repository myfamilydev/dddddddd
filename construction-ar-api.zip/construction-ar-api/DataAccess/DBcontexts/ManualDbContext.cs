﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.DBcontexts
{
    public partial class ManualDbContext : DbContext
    {
        public ManualDbContext()
        {
        }

        public ManualDbContext(DbContextOptions<ManualDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<UserLogIn> UserLogIn { get; set; }
        public virtual DbSet<WorkflowSubmit> WorkflowSubmit { get; set; }
        public virtual DbSet<WorkflowEmail> WorkflowEmail { get; set; }
        public virtual DbSet<ApprovalAction> ApprovalAction { get; set; }
        public virtual DbSet<ApprovalWorkflow> ApprovalWorkflow { get; set; }
        public virtual DbSet<WorkflowHistoryModel> WorkflowHistoryModel { get; set; }
        public virtual DbSet<AttachmentsModel> AttachmentsModel { get; set; }
        public virtual DbSet<NotifModel> NotifModel { get; set; }
        public virtual DbSet<ExecuteAffectedRow> ExecuteAffectedRow { get; set; }
        public virtual DbSet<HouseImportResult> HouseImportResult { get; set; }
        public virtual DbSet<CustomObject> CustomObject { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("data source=192.168.1.88;initial catalog=db_live;user id=mayura;password=ARSystem@2021");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:DefaultSchema", "dbo");
            modelBuilder.Entity<HouseImportResult>().HasNoKey();
            modelBuilder.Entity<WorkflowEmail>().HasNoKey();
            modelBuilder.Entity<WorkflowSubmit>().HasNoKey();
            modelBuilder.Entity<ApprovalAction>().HasNoKey();
            modelBuilder.Entity<ExecuteAffectedRow>().HasNoKey();
            modelBuilder.Entity<NotifModel>().HasNoKey();
            modelBuilder.Entity<ApprovalWorkflow>().HasNoKey();
            modelBuilder.Entity<WorkflowHistoryModel>().HasNoKey();
            modelBuilder.Entity<CustomObject>().HasNoKey();
        }
    }
}