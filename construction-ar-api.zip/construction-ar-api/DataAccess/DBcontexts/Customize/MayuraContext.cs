﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities;
using DataAccess.Entities.Customize;

namespace DataAccess.DBcontexts
{
    public partial class MayuraContext : DbContext
    {
        public virtual DbSet<ClsPenaltySchedule> PenaltySchedule { get; set; }
        public virtual DbSet<ClsPenaltyScheduleDetail> PenaltyScheduleDetail { get; set; }
        public virtual DbSet<ClsPenaltyTestDateResult> PenaltyTestDateResult { get; set; }
        public virtual DbSet<ClsTotalInfo> TotalInfo { get; set; }
        public virtual DbSet<ClsBookingCustomerInfo> BookingCustomerInfo { get; set; }
        public virtual DbSet<ClsOtherCollections> OtherCollections { get; set; }
        public virtual DbSet<ClsTelegramLog> TelegramLogMessage { get; set; }
        public virtual DbSet<ClsDashboardSummary> DashboardSummary { get; set; }
        public virtual DbSet<ClsDashboardSummaryByProject> DashboardSummaryByProject { get; set; }        
        public virtual DbSet<ClsPenaltySummary> PenaltySummary { get; set; }
        public virtual DbSet<ClsPenaltyList> PenaltyList { get; set; }
        public virtual DbSet<ClsHouseHistory> HouseHistory { get; set; }
        //public virtual DbSet<ClsHistoryContract> HistoryContract { get; set; }
        public virtual DbSet<ClsHousePayment> HousePayment { get; set; }
        public virtual DbSet<ClsHouseInterestPayment> HouseInterestPayment { get; set; }
        public virtual DbSet<ClsHousePaymentSchedule> HousePaymentSchedule { get; set; }
        public virtual DbSet<ClsPublicServicePayment> PublicServicePayment { get; set; }
        public virtual DbSet<ClsFinalPayment> FinalPayment { get; set; }
        public virtual DbSet<ClsRescheduleInterest> RescheduleInterest { get; set; }
        public virtual DbSet<ClsFinalPrinciple> FinalPrinciple { get; set; }
        public virtual DbSet<ClsFinalPaymentCalculation> FinalPaymentCalculation { get; set; }
        public virtual DbSet<ClsTerminationTransferInfo> TerminationTransferInfo { get; set; }
        public virtual DbSet<ClsExtraPrinciple> ExtraPrinciple { get; set; }       
        public virtual DbSet<ClsRegularCollectionDetailSummary> RegularCollectionDetailSummary { get; set; }
        public virtual DbSet<ClsWaiveInfo> WaiveInfo { get; set; }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<ClsTotalInfo>().HasNoKey();
            modelBuilder.Entity<ClsPenaltyTestDateResult>().HasNoKey();
            modelBuilder.Entity<ClsPenaltySchedule>().HasNoKey();
            modelBuilder.Entity<ClsPenaltyScheduleDetail>().HasNoKey();
            modelBuilder.Entity<ClsBookingCustomerInfo>().HasNoKey();            
            modelBuilder.Entity<ClsDashboardSummary>().HasNoKey();
            modelBuilder.Entity<ClsDashboardSummaryByProject>().HasNoKey();
            modelBuilder.Entity<ClsTelegramLog>().HasNoKey();
            modelBuilder.Entity<ClsPenaltySummary>().HasNoKey(); 
            modelBuilder.Entity<ClsPenaltyList>().HasNoKey();
            modelBuilder.Entity<ClsHousePayment>().HasNoKey();
            modelBuilder.Entity<ClsHouseInterestPayment>().HasNoKey();
            modelBuilder.Entity<ClsPublicServicePayment>().HasNoKey();
            modelBuilder.Entity<ClsFinalPayment>().HasNoKey();
            modelBuilder.Entity<ClsFinalPaymentCalculation>().HasNoKey();
            modelBuilder.Entity<ClsTerminationTransferInfo>().HasNoKey();
            modelBuilder.Entity<ClsFinalPrinciple>().HasNoKey();
            modelBuilder.Entity<ClsExtraPrinciple>().HasNoKey();
            modelBuilder.Entity<ClsRegularCollectionDetailSummary>().HasNoKey();
            modelBuilder.Entity<ClsHousePaymentSchedule>().HasNoKey();            
            modelBuilder.Entity<ClsHouseHistory>().HasNoKey();
            modelBuilder.Entity<ClsRescheduleInterest>().HasNoKey();
            modelBuilder.Entity<ClsWaiveInfo>().HasNoKey();

        }
    }
}
