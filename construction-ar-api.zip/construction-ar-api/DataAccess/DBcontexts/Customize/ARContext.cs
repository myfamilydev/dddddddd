﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.AR;

namespace DataAccess.DBcontexts
{
    public partial class ARContext : DbContext
    {

        public virtual DbSet<ClsContractReference> ContractReferences { get; set; }
        public virtual DbSet<ClsfinalPaymentInfo> FinalPaymentInfo { get; set; }
        public virtual DbSet<VprintScheduleDetail> VprintScheduleDetail { get; set; }
        public virtual DbSet<ClsCollectionBookingInitialPayment> CollectionBookingInitialPayment { get; set; }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ClsCollectionBookingInitialPayment>().HasNoKey();
            modelBuilder.Entity<ClsContractReference>().HasNoKey();
            modelBuilder.Entity<ClsfinalPaymentInfo>().HasNoKey();
            modelBuilder.Entity<VprintScheduleDetail>().HasNoKey();


        }
    }
}
