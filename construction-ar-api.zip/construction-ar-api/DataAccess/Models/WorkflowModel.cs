﻿using DataAccess.Entities;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public class WorkflowModel
    {
        public WorkflowModel()
        {
            this.ApprovalAction = new List<VWorkflowAction>();
            this.ApprovalWorkflow = new List<ApprovalWorkflowModel>();
            this.WorkflowHistoryModel = new List<WorkflowHistoryModel>();
        }

        public virtual object Data { get; set; }
        public virtual List<VWorkflowAction> ApprovalAction { get; set; }
        public virtual List<ApprovalWorkflowModel> ApprovalWorkflow { get; set; }
        public virtual List<WorkflowHistoryModel> WorkflowHistoryModel { get; set; }
    }
}
