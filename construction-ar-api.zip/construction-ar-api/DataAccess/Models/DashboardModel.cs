﻿namespace DataAccess.Models
{
    public partial class DashboardModel
    {
        public DashboardModel()
        {
            this.total_new_request = 0;
            this.total_in_progress = 0;
            this.total_completed = 0;
            //this.things_to_do = new List<VRequests>();
            //this.req_completed = new List<VRequests>();
            //this.req_in_progress = new List<VRequests>();
        }

        public int? total_new_request { get; set; }
        public int? total_in_progress { get; set; }
        public int? total_completed { get; set; }
        //public List<VRequests> things_to_do { get; set; }
        //public List<VRequests> req_in_progress { get; set; }
        //public List<VRequests> req_completed { get; set; }
    }
}
