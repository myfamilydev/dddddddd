﻿using DataAccess.DBcontexts;
using DataAccess.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class WorkflowDetailModel
    {

        public WorkflowModel workflowModel { get; set; }

        public WorkflowDetailModel()
        {
            //workflowModel = new WorkflowModel();
        }

        public WorkflowDetailModel(string workflowName, int refId, int userId,int index=0)
        {
            workflowModel = new WorkflowModel();
            WorkflowDetail(workflowName, refId, userId,index).Wait();
        }

        private async Task WorkflowDetail(string workflowName, int refId, int userId,int index=0)
        {
            WorkflowModel _workflowModel = new WorkflowModel();

            byte workflowId;

            /*using (var _manual = new MayuraContext())
            {
                workflowId = _manual.Workflow.Single(x => x.WorkflowName == workflowName && x.Indexing==index).Id;

                string sql = @"  select [workflow_id],'' workflow_name, [wf_detail_uuid], [cur_status], [role_name]
                                        , [btn_action], [user_id], [ordering], [role_order], [cur_role]"
                            + " from dbo.v_workflow_action"
                            + " where workflow_id = {0}"
                            + " and cur_status = (select isnull(rec_status,0) from " + workflowName + " where id = {1})"
                            + " and user_id = {2}"
                            + " order by ordering";

                _workflowModel.ApprovalAction = await _manual.VWorkflowAction.FromSqlRaw(sql, workflowId, refId, userId).ToListAsync();

            } */

            using (var _manual = new MayuraContext())
            {
                workflowId = _manual.Workflow.Single(x => x.WorkflowName == workflowName && x.Indexing == index).Id;

                /* string sql = @"  select [workflow_id],'' workflow_name, [wf_detail_uuid], [cur_status], [role_name]
                                         , [btn_action], [user_id], [ordering], [role_order], [cur_role]"
                             + " from dbo.v_workflow_action"
                             + " where workflow_id = {0}"
                             + " and cur_status = (select isnull(rec_status,0) from " + workflowName + " where id = {1})"
                             + " and user_id = {2}"
                             + " order by ordering"; */
                var p_workflow_name = new SqlParameter("@workflowName", workflowName);
                string sql = $"exec dbo.sp_get_workflow_detail {workflowId},@workflowName,{refId},{userId}";
                _workflowModel.ApprovalAction = await _manual.VWorkflowAction.FromSqlRaw(sql, p_workflow_name).ToListAsync();

            }

            List<ApprovalWorkflow> approval = new List<ApprovalWorkflow>();

            using (var _manual = new ManualDbContext())
            {
                List<ApprovalWorkflow> lst = new List<ApprovalWorkflow>();
                string sql = @"exec dbo.sp_getWorkflow @workflow_id={0}, @ref_id={1}";
                lst = await _manual.ApprovalWorkflow.FromSqlRaw(sql, workflowId, refId).ToListAsync();

                string pre_role = "";
                ApprovalWorkflowModel model = new ApprovalWorkflowModel();

                foreach (var item in lst)
                {
                    if (!pre_role.Equals(item.role_name))
                    {
                        if (!pre_role.Equals(""))
                        {
                            _workflowModel.ApprovalWorkflow.Add(model);
                            model = new ApprovalWorkflowModel(); 
                        }
                        pre_role = item.role_name;
                        model.role_name = pre_role;
                    }
                    model.people.Add(item);
                }

                _workflowModel.ApprovalWorkflow.Add(model);

                sql = @"exec dbo.sp_workflow_history @workflow_id={0}, @ref_id={1}";
                _workflowModel.WorkflowHistoryModel = await _manual.WorkflowHistoryModel.FromSqlRaw(sql, workflowId, refId).ToListAsync();
            }

            this.workflowModel = _workflowModel;
        }

        public WorkflowHistory WorkflowHistoryDraft(string workflowName, int refId, int userId,int index=0)
        {
            byte workflowId;
            using (var _manual = new MayuraContext())
            {
                workflowId = _manual.Workflow.Single(x => x.WorkflowName == workflowName && x.Indexing==index).Id;
            }

            WorkflowHistory history = new WorkflowHistory
            {
                WorkflowId = workflowId,
                RefId = refId,
                RecStatus = 0,
                PostStatus = 0,
                Comment = "Saved as draft",
                IsDone = null,
                CreatedAt = DateTime.Now,
                CreatedBy = userId
            };

            return history;
        }

    }
}
