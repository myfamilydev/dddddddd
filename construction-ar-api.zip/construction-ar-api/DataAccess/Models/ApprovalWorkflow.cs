﻿using System;

namespace DataAccess.Models
{
    public class ApprovalWorkflow
    {
        public string role_name { get; set; }
        public string full_name { get; set; }
        public byte? is_done { get; set; }
        public DateTime? action_at { get; set; }
    }
}
