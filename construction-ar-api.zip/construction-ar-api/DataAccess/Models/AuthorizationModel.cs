﻿using DataAccess.Entities;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public class AuthorizationModel
    {
        public AuthorizationModel()
        {
            this.authorizedPageActions = new List<object>();
        }

        public Users users { get; set; }
        public List<object> authorizedPageActions { get; set; }
        public List<VUsersPages> authorizedPages { get; set; }
        public string token { get; set; }
        public string ssoToken { get; set; }

        public bool activate { get; set; } = false;

    }
}