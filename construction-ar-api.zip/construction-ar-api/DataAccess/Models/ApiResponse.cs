﻿namespace DataAccess.Models
{
    public class ApiResponse
    {
        public string status { get; set; }
        public string code { get; set; }
        public string message { get; set; }

        public ApiResponse(string _status, string _message, string _code = "")
        {
            status = _status;
            message = _message;
            code = _code;
        }

        public ApiResponse()
        {

        }

    }
}
