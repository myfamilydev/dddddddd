﻿using System;

namespace DataAccess.Models
{
    public partial class WorkflowSubmit
    {
        public Guid WfDetailUuid { get; set; }
        public int RefId { get; set; }
        public string? Comment { get; set; }
    }

    public class ExecuteAffectedRow
    {
        public int? affected_row { get; set; }
    }

    public class HouseImportResult
    {
        public int? insert_affected_row { get; set; }
        public int? update_affected_row { get; set; }
    }
    public class UploadResult
    {
        public int TotalUploadRecords { get; set; }
        public int TotalInsertRecords { get; set; }
    }
   
}
