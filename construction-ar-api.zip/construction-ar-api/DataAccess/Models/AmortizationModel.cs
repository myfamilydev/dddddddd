﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Models
{
    public class AmortizationModel
    {
        public float PropertyValue { get; set; }
		public float LoanAmount { get; set; }
		public short TermMonth { get; set; }
		public float InterestRateMonth { get; set; }
		public DateTime StartPaymentDate { get; set; }
		public int ContractId { get; set; }
		public int HouseId { get; set; }
		public int PaymentTermId { get; set; }
		public short PaymentMonths { get; set; }
		public string InsertToTable { get; set; }
	}
}
