﻿namespace DataAccess.Models.Filter
{
    public class AdvSearch
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public long TotalRecords { get; set; }
        public int? Status { get; set; }

        public AdvSearch()
        {
            if (this.PageNumber == 0)
            {
                this.PageNumber = 1;
            }

            if (this.PageSize == 0)
            {
                this.PageSize = 20;
            }

        }

        public AdvSearch(int pageNumber, int pageSize)
        {
            this.PageNumber = pageNumber < 1 ? 1 : pageNumber;
            this.PageSize = pageSize > 0 ? pageSize : 20;
        }
    }
}
