﻿using System;

namespace DataAccess.Models.Filter
{
    public class PaginationFilter
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public long TotalRecords { get; set; }
        public string Search { get; set; }
        public int? ProId { get; set; }
        public int? HouseId { get; set; }
        public int? option { get; set; }
        public string? SearchField { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
       

        public PaginationFilter()
        {
            this.PageNumber = 1;
            this.PageSize = 1000000;
        }

        public PaginationFilter(int pageNumber, int pageSize, string Search)
        {
            this.PageNumber = pageNumber < 1 ? 1 : pageNumber;
            this.PageSize = pageSize > 0 ? pageSize : 20;
            this.Search = Search;
        }

    }
    public class BookingPaginationFilter
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public long TotalRecords { get; set; }
        public string Search { get; set; }
        public int? ProId { get; set; }
        public int? HouseId { get; set; }
        public string? SearchField { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public byte expire { set; get; }
        public BookingPaginationFilter()
        {
            this.PageNumber = 1;
            this.PageSize = 1000000;
        }

        public BookingPaginationFilter(int pageNumber, int pageSize, string Search)
        {
            this.PageNumber = pageNumber < 1 ? 1 : pageNumber;
            this.PageSize = pageSize > 0 ? pageSize : 20;
            this.Search = Search;
        }

    }
}
