﻿using DataAccess.Models.Filter;
using System;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public class PagedResponse<T> : Response<T>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public Uri FirstPage { get; set; }
        public Uri LastPage { get; set; }
        public int TotalPages { get; set; }
        public long TotalRecords { get; set; }
        public Uri NextPage { get; set; }
        public Uri PreviousPage { get; set; }

        public PagedResponse(T data, PaginationFilter filter)
        {
            this.PageNumber = filter.PageNumber;
            this.PageSize = filter.PageSize;
            this.TotalRecords = filter.TotalRecords;
            var roundPages = ((double)filter.TotalRecords / (double)filter.PageSize);
            this.TotalPages = Convert.ToInt32(Math.Ceiling(roundPages));
            this.Data = data;

            /*
            this.Message = null;
            this.Succeeded = true;
            this.Errors = null;
            */
        }

        public PagedResponse(IEnumerable<object> data, PaginationFilter filter)
        {
            this.PageNumber = filter.PageNumber;
            this.PageSize = filter.PageSize;
            this.TotalRecords = filter.TotalRecords;
            var roundPages = ((double)filter.TotalRecords / (double)filter.PageSize);
            this.TotalPages = Convert.ToInt32(Math.Ceiling(roundPages));
            this.Data = (T)data;

            /*
            this.Message = null;
            this.Succeeded = true;
            this.Errors = null;
            */
        }

    }
}
