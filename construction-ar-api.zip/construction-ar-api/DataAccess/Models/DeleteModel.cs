﻿using System;

namespace DataAccess.Models
{
    public class DeleteModel
    {
        public int Id { get; set; }
        public Guid Uuid { get; set; }
    }
}
