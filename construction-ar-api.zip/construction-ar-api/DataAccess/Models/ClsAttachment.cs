﻿
using DataAccess.DBcontexts;
using DataAccess.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Threading.Tasks;


namespace Library.Class
{
    public class ClsAttachment
    {
        private readonly MayuraContext _context;

        public ClsAttachment(MayuraContext context)
        {
            _context = context;
        }

        public async Task<string> SaveBinaryFileAsync(string file_ref, int id, IFormFile file, string fullname)
        {

            Byte[] bytes = null;
            await using (MemoryStream ms = new MemoryStream())
            {
                await file.OpenReadStream().CopyToAsync(ms);
                bytes = ms.ToArray();
            }
            Attachments pw = new Attachments();
            pw.FileUuid = Guid.NewGuid();
            pw.FileRef = file_ref;
            pw.FileRefId = id;
            pw.FileName = file.FileName;
            pw.FileSize = (int?)file.Length;
            pw.FileExt = Path.GetExtension(file.FileName)?.Substring(1);
            pw.FileUpload = bytes;
            pw.CreatedBy = fullname;
            pw.CreatedAt = DateTime.Now;
            pw.Status = 1;
            await _context.Attachments.AddAsync(pw);
            await _context.SaveChangesAsync();
            return await Task.FromResult("Successfully Attached");
        }

        public async Task<FileContentResult> DownloadAttachFileAsync(Guid fileUuId)
        {
            var pw = await _context.Attachments.SingleOrDefaultAsync(_ => _.FileUuid == fileUuId && _.Status==1);
            if (pw != null)
            {
                var mimeType = "application/" + pw.FileExt;
                byte[] bytes = (byte[])pw.FileUpload;
                return new FileContentResult(bytes, mimeType)
                {
                    FileDownloadName = pw.FileName
                };

            }
            return null;
            //else return HttpStatusCode.BadRequest;
        }
        public async Task<string> ReadAttachFileAsync(Guid fileUuId)
        {
            var pw = await _context.Attachments.SingleOrDefaultAsync(_ => _.FileUuid == fileUuId && _.Status==1);
            if (pw != null)
            {                
                byte[] bytes = (byte[])pw.FileUpload;
                string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                return "data:image/"+ pw.FileExt + ";base64," + base64String;
            }
            return "";
        }
    }
}
