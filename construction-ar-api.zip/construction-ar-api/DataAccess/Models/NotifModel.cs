﻿using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Models
{
    public class NotifModel
    {
        public NotifModel()
        {
            this.HouseNo = "";
            this.Project = "";
        }
        public string HouseNo { get; set; }
        public string HouseType { set; get; }
        public string Project { get; set; }

        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string CustomerRelationship { get; set; }
    }
}
