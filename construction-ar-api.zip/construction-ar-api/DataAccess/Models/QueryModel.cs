﻿namespace DataAccess.Models
{
    public class QueryModel
    {
        public QueryModel() { }

        public string insert_send_email()
        {
            string query = @"insert into [ESS-DWH].clm.email_schedule (subject
                                  ,receipt_from
                                  ,receipt_to
                                  ,receipt_cc
                                  ,body_content
                                  ,status
                                  ,email_sent_at
                                  ,by_application)
                            values ({0},{1},{2},{3},{4},{5},{6},'SRM')";
            return query;
        }
    }
}
