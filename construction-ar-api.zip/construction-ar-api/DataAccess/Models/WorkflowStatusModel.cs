﻿namespace DataAccess.Models
{
    public static class WorkflowStatusModel
    {
        public static readonly byte DRAFT = 0;
        public static readonly byte SUBMITTED = 1;
        public static readonly byte REVIEWED = 2;
        public static readonly byte APPROVED = 3;
        public static readonly byte PENDING = 4;
        public static readonly byte REJECTED = 5;
        public static readonly byte CANCELLED = 6;
        public static readonly byte AVAILABLE = 7;
        public static readonly byte BOOKED = 8;
        public static readonly byte CONTRACTED = 9;
        public static readonly byte FINALPAY = 10;
        public static readonly byte PRICEUPDATED = 11;
        public static readonly byte WAITINGPAYMENT = 12;
        public static readonly byte VERIFIED = 13;
        public static readonly byte DELAYED = 14;
        public static readonly byte PAID = 15;
        public static readonly byte RESCHEDULED = 16;
        public static readonly byte ACCEPTPAYMENT = 17;
        public static readonly byte TERMINATED = 18;
    }
}
