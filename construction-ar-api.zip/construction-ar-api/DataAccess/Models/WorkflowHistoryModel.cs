﻿using System;

namespace DataAccess.Models
{
    public class WorkflowHistoryModel
    {
        public long Id { get; set; }
        public string Status_name { get; set; }
        public string Comment { get; set; }
        public byte? Is_done { get; set; }
        public string Full_name { get; set; }
        public DateTime Created_at { get; set; }
    }

}
