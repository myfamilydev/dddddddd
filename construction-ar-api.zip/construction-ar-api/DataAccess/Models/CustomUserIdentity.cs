﻿using System.Security.Claims;

namespace DataAccess.Models
{
    public class userIdentity
    {
        public  int Id { get; set; }
        public  string UserName { get; set; }
        public  string FullName { get; set; }
        public  string Email { get; set; }
        public  string Role { get; set; }
        public  string MhID { get; set; }
        public string SSOToken { get; set; }

        public void SetUserByClaim(ClaimsIdentity claimsIdentity)
        {
            Id = int.Parse(claimsIdentity.FindFirst(ClaimTypes.NameIdentifier).Value);
            FullName = claimsIdentity.Name;
            UserName = claimsIdentity.FindFirst(ClaimTypes.GivenName).Value;
            Email = claimsIdentity.FindFirst(ClaimTypes.Email).Value;
            var ssoToken = claimsIdentity.FindFirst(c => c.Type == "sso_token");
            SSOToken = ssoToken == null ? null : ssoToken.Value;
            //this.Role = claimsIdentity.FindAll(ClaimTypes.Role).ToString();
            //this.MhID = claimsIdentity.FindFirst(ClaimTypes.GivenName).Value;
            Role = "";
            var claimRoles = claimsIdentity.FindAll(ClaimTypes.Role);
            foreach (var role in claimRoles)
            {
                Role += role.Value + ",";
            }
        }

    }
}
