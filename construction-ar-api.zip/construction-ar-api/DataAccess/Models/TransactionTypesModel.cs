﻿using System;   
using System.Collections.Generic;
using System.Text;

namespace DataAccess.Models
{
    public class TransactionTypesModel
    {
        public readonly byte HOUSE_PAYMENT = 1;
        public readonly byte PENALTY = 2;
        public readonly byte PUBLIC_SERVICE = 3;
        public readonly byte WAIVE_PAYMENT = 4;
        public readonly byte BOOKING_DEPOSIT = 5;
        public readonly byte OVER_PAYMENT = 6;
        public readonly byte PRINCIPLE = 7;
        public readonly byte INTEREST = 8;
        public readonly byte PENALTY_PRINCIPLE = 9;
        public readonly byte PENALTY_INTEREST = 10;
        public readonly byte WAIVE_PENALTY = 11;
        public readonly byte WAIVE_PUBLIC_SERVICE = 12;
        public readonly byte FINAL_PAYMENT = 13;
        public readonly byte PAID_OFF_DISCOUNT = 14;
        public readonly byte ELECTRICITY = 15;
        public readonly byte OTHERS = 16;
    }
}
