﻿namespace DataAccess.Models
{
    public class CustomObject
    {
        public string? object1 { get; set; }
    }
}
