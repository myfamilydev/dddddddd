﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Models
{
    public partial class AttachmentsModel
    {
        [Key]
        [Column("File_UUID")]
        public Guid FileUuid { get; set; }
        [Column("FILE_NAME")]
        [StringLength(255)]
        public string FileName { get; set; }
        [Column("FILE_EXT")]
        [StringLength(20)]
        public string FileExt { get; set; }
        [Column("FILE_SIZE")]
        public long? FileSize { get; set; }
        [Column("FILE_REF")]
        [StringLength(30)]
        public string FileRef { get; set; }
        [Column("FILE_REF_ID")]
        public int? FileRefId { get; set; }
        [Column("CREATED_AT", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("CREATED_BY")]
        [StringLength(100)]
        public string? CreatedBy { get; set; }
    }
}
