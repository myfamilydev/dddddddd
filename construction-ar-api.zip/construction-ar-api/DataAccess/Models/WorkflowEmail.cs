﻿namespace DataAccess.Models
{
    public partial class WorkflowEmail
    {
        public byte isTo;
        public byte isCC;
        public string email;
        public string email_subject;
        public string email_content;
        public string notif_to;
        public string notif_cc;
    }
}
