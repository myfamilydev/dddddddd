﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Models
{
    public class UserLogIn
    {
        public int? Id { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string? UserName { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string? FullName { get; set; }

        [Column(TypeName = "varchar(100)")]
        public string? Email { get; set; }

        [Column(TypeName = "varchar(20)")]
        public string? UserRole { get; set; }

        [Column("ad_user_id")]
        public Guid? AdUserId { get; set; }

        public string Token { get; set; }
    }
}
