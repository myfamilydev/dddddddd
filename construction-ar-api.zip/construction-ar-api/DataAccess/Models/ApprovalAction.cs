﻿using System;

namespace DataAccess.Models
{
    public class ApprovalAction
    {
        public Guid wf_detail_uuid { get; set; }
        public byte cur_status { get; set; }
        public string role_name { get; set; }
        public string btn_action { get; set; }
        public int? ordering { get; set; }
    }
}
