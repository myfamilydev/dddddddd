﻿using System.Collections.Generic;

namespace DataAccess.Models
{
    public class ApprovalWorkflowModel
    {
        public ApprovalWorkflowModel()
        {
            this.people = new List<ApprovalWorkflow>();
        }
        public string role_name { get; set; }
        public List<ApprovalWorkflow> people { get; set; }
    }
}
