﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("manual_loan_balance_detail_report", Schema = "report")]
    public partial class ManualLoanBalanceDetailReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("manual_loan_balance_report_id")]
        public int? ManualLoanBalanceReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("location")]
        [StringLength(100)]
        public string? Location { get; set; }
        [Column("loan_tittle_deed")]
        [StringLength(100)]
        public string? LoanTittleDeed { get; set; }
        [Column("project_type")]
        [StringLength(100)]
        [Unicode(false)]
        public string? ProjectType { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 10)")]
        public decimal? InterestRate { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 3)")]
        public decimal? LoanAmount { get; set; }
        [Column("repayment_amount", TypeName = "decimal(15, 3)")]
        public decimal? RepaymentAmount { get; set; }
        [Column("os_mount", TypeName = "decimal(15, 3)")]
        public decimal? OsMount { get; set; }
        [Column("starting_date", TypeName = "datetime")]
        public DateTime? StartingDate { get; set; }
        [Column("maturity_date", TypeName = "datetime")]
        public DateTime? MaturityDate { get; set; }
        [Column("duration", TypeName = "decimal(15, 2)")]
        public decimal? Duration { get; set; }
        [Column("duration_paid", TypeName = "decimal(15, 2)")]
        public decimal? DurationPaid { get; set; }
        [Column("remaining_year", TypeName = "decimal(15, 2)")]
        public decimal? RemainingYear { get; set; }
        [Column("lock_period")]
        public string? LockPeriod { get; set; }
        [Column("remark_en")]
        public string? RemarkEn { get; set; }
        [Column("remark_kh")]
        public string? RemarkKh { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("insert_type")]
        [StringLength(255)]
        [Unicode(false)]
        public string? InsertType { get; set; }
    }
}
