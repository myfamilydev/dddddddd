﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("bank_import_temp")]
    public partial class BankImportTemp
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("ref_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RefCode { get; set; }
        [Column("transaction_type_id")]
        public int? TransactionTypeId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("creted_by")]
        public int? CretedBy { get; set; }
    }
}
