﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_to_roles")]
    public partial class UsersToRole
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("role_id")]
        public short? RoleId { get; set; }
        [Column("disable_notif")]
        public bool? DisableNotif { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
