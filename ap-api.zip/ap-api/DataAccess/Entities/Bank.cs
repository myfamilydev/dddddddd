﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("banks")]
    public partial class Bank
    {
        public Bank()
        {
            BanksProjectsChildren = new HashSet<BanksProjectsChild>();
        }

        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        public string? BankName { get; set; }
        [Column("account_number")]
        [StringLength(200)]
        public string? AccountNumber { get; set; }
        [Column("bank_account")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankAccount { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("ref_code")]
        public short? RefCode { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }

        [InverseProperty("Parent")]
        public virtual ICollection<BanksProjectsChild> BanksProjectsChildren { get; set; }
    }
}
