﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("item_name")]
    public partial class ItemName
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("item_name")]
        [StringLength(50)]
        public string? ItemName1 { get; set; }
        [Column("category_item_code")]
        [StringLength(50)]
        public string? CategoryItemCode { get; set; }
    }
}
