﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_positions")]
    public partial class UsersPosition
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("position")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Position { get; set; }
        [Column("position_kh")]
        [StringLength(100)]
        public string? PositionKh { get; set; }
        [Column("dept_id")]
        public short? DeptId { get; set; }
        [Column("is_active")]
        public bool? IsActive { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
