﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualSpaReport
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        public string? BankName { get; set; }
        [Column("spa_amount", TypeName = "decimal(15, 2)")]
        public decimal? SpaAmount { get; set; }
        [Column("spa_loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? SpaLoanAmount { get; set; }
        [Column("total_buy_back_amount", TypeName = "decimal(15, 2)")]
        public decimal? TotalBuyBackAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
    }
}
