﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("file_links")]
    public partial class FileLink
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("url")]
        [Unicode(false)]
        public string? Url { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
