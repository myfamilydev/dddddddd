﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("dim_request_types", Schema = "arch")]
    public partial class DimRequestType
    {
        [Column("id")]
        public short Id { get; set; }
        [Column("type")]
        [StringLength(250)]
        [Unicode(false)]
        public string? Type { get; set; }
    }
}
