﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VCustomerRequestCancel
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("customer_request_id")]
        public int? CustomerRequestId { get; set; }
        [Column("request_code")]
        [StringLength(166)]
        public string? RequestCode { get; set; }
        [Column("cancel_date", TypeName = "datetime")]
        public DateTime? CancelDate { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("cancel_reason")]
        public string? CancelReason { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? StatusName { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string? Project { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? HouseNumber { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("cancel_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CancelCode { get; set; }
        [Column("customer_id_1")]
        public int? CustomerId1 { get; set; }
        [Column("customer_id_2")]
        public int? CustomerId2 { get; set; }
        [Column("customer1")]
        [StringLength(100)]
        public string? Customer1 { get; set; }
        [Column("customer2")]
        [StringLength(100)]
        public string? Customer2 { get; set; }
        [Column("nationalId1")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NationalId1 { get; set; }
        [Column("nationalId2")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NationalId2 { get; set; }
        [Column("phone1")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Phone1 { get; set; }
        [Column("phone2")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Phone2 { get; set; }
    }
}
