﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_infos")]
    [Index("SupplierCode", Name = "IX_suppliers")]
    public partial class SuppliersInfo
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("supplier_location")]
        [StringLength(20)]
        [Unicode(false)]
        public string? SupplierLocation { get; set; }
        [Column("supplier_code")]
        [StringLength(20)]
        [Unicode(false)]
        public string? SupplierCode { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string? NameKh { get; set; }
        [Column("NID")]
        [StringLength(20)]
        [Unicode(false)]
        public string? Nid { get; set; }
        [Column("address")]
        public string? Address { get; set; }
        [Column("contact_number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContactNumber { get; set; }
        [Column("contact_telegram")]
        [StringLength(20)]
        [Unicode(false)]
        public string? ContactTelegram { get; set; }
        [Column("email")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Email { get; set; }
        [Column("payment_collector")]
        [StringLength(1000)]
        [Unicode(false)]
        public string? PaymentCollector { get; set; }
        [Column("collector_number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CollectorNumber { get; set; }
        [Column("collector_telegram")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CollectorTelegram { get; set; }
        [Column("name_on_cheque")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameOnCheque { get; set; }
        [Column("behavior")]
        [StringLength(50)]
        public string? Behavior { get; set; }
        [Column("behavior_description")]
        [StringLength(100)]
        public string? BehaviorDescription { get; set; }
        [Column("supplier_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SupplierType { get; set; }
        [Column("normal")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Normal { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        [Unicode(false)]
        public string? Remark { get; set; }
        [Column("category")]
        [StringLength(10)]
        public string? Category { get; set; }
        [Column("type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Type { get; set; }
        [Column("job")]
        [StringLength(10)]
        public string? Job { get; set; }
        [Column("job_decription")]
        public string? JobDecription { get; set; }
        [Column("payment_term")]
        [StringLength(1000)]
        [Unicode(false)]
        public string? PaymentTerm { get; set; }
        [Column("settlement_method")]
        [StringLength(30)]
        [Unicode(false)]
        public string? SettlementMethod { get; set; }
        [Column("bank_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankName { get; set; }
        [Column("bank_acc_name_kh")]
        [StringLength(100)]
        public string? BankAccNameKh { get; set; }
        [Column("bank_acc_Name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankAccNameEn { get; set; }
        [Column("bank_acc_number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankAccNumber { get; set; }
        [Column("id_card_no")]
        [StringLength(30)]
        [Unicode(false)]
        public string? IdCardNo { get; set; }
        [Column("currency")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Currency { get; set; }
        [Column("is_active")]
        public bool? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
