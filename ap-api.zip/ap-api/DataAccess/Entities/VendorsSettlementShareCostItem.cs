﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_settlement_share_cost_items")]
    public partial class VendorsSettlementShareCostItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendors_settlement_sub_id")]
        public int? VendorsSettlementSubId { get; set; }
        [Column("cost_type_id")]
        public int? CostTypeId { get; set; }
        [Column("share_cost_category_id")]
        public int? ShareCostCategoryId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("chart_accounts_id")]
        public int? ChartAccountsId { get; set; }
        [Column("cost_rate", TypeName = "decimal(18, 0)")]
        public decimal? CostRate { get; set; }
        [Column("amount", TypeName = "decimal(18, 0)")]
        public decimal? Amount { get; set; }
        [Column("deleted_at", TypeName = "datetime")]
        public DateTime? DeletedAt { get; set; }
    }
}
