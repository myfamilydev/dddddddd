﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualSummaryDetailReport
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("manual_summary_report_id")]
        public int? ManualSummaryReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("contracted_house_land", TypeName = "decimal(18, 0)")]
        public decimal? ContractedHouseLand { get; set; }
        [Column("total_overdue_house", TypeName = "decimal(18, 0)")]
        public decimal? TotalOverdueHouse { get; set; }
        [Column("overdue_house_one", TypeName = "decimal(18, 0)")]
        public decimal? OverdueHouseOne { get; set; }
        [Column("overdue_house_two", TypeName = "decimal(18, 0)")]
        public decimal? OverdueHouseTwo { get; set; }
        [Column("overdue_house_three", TypeName = "decimal(18, 0)")]
        public decimal? OverdueHouseThree { get; set; }
        [Column("overdue_house_four", TypeName = "decimal(18, 0)")]
        public decimal? OverdueHouseFour { get; set; }
        [Column("total_overdue_amount", TypeName = "decimal(18, 0)")]
        public decimal? TotalOverdueAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
