﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VGroupPaymentHouseActive
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("alias_name")]
        [StringLength(100)]
        public string? AliasName { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("active")]
        public bool? Active { get; set; }
    }
}
