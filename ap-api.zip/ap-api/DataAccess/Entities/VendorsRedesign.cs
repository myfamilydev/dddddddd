﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns")]
    public partial class VendorsRedesign
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("vendors_labor_cover_id")]
        public int? VendorsLaborCoverId { get; set; }
        [Column("vendors_settlement_sub_id")]
        public int? VendorsSettlementSubId { get; set; }
        [Column("account_code")]
        [StringLength(200)]
        public string? AccountCode { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        [Unicode(false)]
        public string? VendorCategory { get; set; }
        [Column("settlement_id")]
        public int? SettlementId { get; set; }
        [Column("settlement_date", TypeName = "date")]
        public DateTime? SettlementDate { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
