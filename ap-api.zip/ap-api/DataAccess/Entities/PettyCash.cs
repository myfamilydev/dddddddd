﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("petty_cashes")]
    public partial class PettyCash
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("pv_ref")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PvRef { get; set; }
        [Column("voucher_date", TypeName = "date")]
        public DateTime? VoucherDate { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("supplier_name")]
        [StringLength(100)]
        public string? SupplierName { get; set; }
        [Column("settlement_id")]
        public int? SettlementId { get; set; }
        [Column("settlement_code")]
        public string? SettlementCode { get; set; }
        [Column("payee_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? PayeeName { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
    }
}
