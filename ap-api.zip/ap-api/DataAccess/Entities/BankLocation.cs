﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("bank_locations")]
    public partial class BankLocation
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("location")]
        [StringLength(100)]
        public string? Location { get; set; }
        [Column("description")]
        [StringLength(100)]
        public string? Description { get; set; }
    }
}
