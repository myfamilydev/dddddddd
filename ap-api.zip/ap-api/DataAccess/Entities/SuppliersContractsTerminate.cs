﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_contracts_terminates")]
    public partial class SuppliersContractsTerminate
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("terminate_code")]
        [StringLength(100)]
        [Unicode(false)]
        public string? TerminateCode { get; set; }
        [Column("supplier_item_id")]
        public int? SupplierItemId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_po")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContractPo { get; set; }
        [Column("cancel_date", TypeName = "datetime")]
        public DateTime? CancelDate { get; set; }
        [Column("terminate_reason")]
        [StringLength(255)]
        public string? TerminateReason { get; set; }
        [Column("received_date", TypeName = "datetime")]
        public DateTime? ReceivedDate { get; set; }
        [Column("signed_date", TypeName = "datetime")]
        public DateTime? SignedDate { get; set; }
        [Column("remark")]
        [StringLength(50)]
        public string? Remark { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("create_at", TypeName = "datetime")]
        public DateTime? CreateAt { get; set; }
        [Column("create_by")]
        public int? CreateBy { get; set; }
        [Column("update_at", TypeName = "datetime")]
        public DateTime? UpdateAt { get; set; }
        [Column("update_by")]
        public int? UpdateBy { get; set; }
    }
}
