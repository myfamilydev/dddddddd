﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VContractLoanStandard
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_type_id")]
        public int? LoanTypeId { get; set; }
        [Column("contract_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContractCode { get; set; }
        [Column("loan_bank_ref")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LoanBankRef { get; set; }
        [Column("loan_date", TypeName = "datetime")]
        public DateTime? LoanDate { get; set; }
        [Column("contract_loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? ContractLoanAmount { get; set; }
        [Column("admin_fee", TypeName = "decimal(15, 2)")]
        public decimal? AdminFee { get; set; }
        [Column("loan_duration")]
        public int? LoanDuration { get; set; }
        [Column("payment_remark")]
        public string? PaymentRemark { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("loan_type")]
        [StringLength(100)]
        public string? LoanType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
