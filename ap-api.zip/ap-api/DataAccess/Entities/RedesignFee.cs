﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("redesign_fees")]
    public partial class RedesignFee
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("fee", TypeName = "decimal(15, 2)")]
        public decimal? Fee { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
