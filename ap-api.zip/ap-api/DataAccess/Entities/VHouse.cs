﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VHouse
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? HouseNumber { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string? HouseType { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        [Unicode(false)]
        public string? HouseSize { get; set; }
    }
}
