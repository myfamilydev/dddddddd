﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendor_penalty")]
    public partial class VendorPenalty
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("penalty_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PenaltyCode { get; set; }
        [Column("payment_tracking_id")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaymentTrackingId { get; set; }
        [Column("settlement_date", TypeName = "date")]
        public DateTime? SettlementDate { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
