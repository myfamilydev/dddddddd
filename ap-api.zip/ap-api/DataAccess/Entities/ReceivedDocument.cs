﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("received_documents")]
    public partial class ReceivedDocument
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("document_code")]
        [StringLength(30)]
        [Unicode(false)]
        public string? DocumentCode { get; set; }
        [Column("received_date", TypeName = "date")]
        public DateTime? ReceivedDate { get; set; }
        [Column("document_type")]
        [StringLength(20)]
        [Unicode(false)]
        public string? DocumentType { get; set; }
        [Column("invoice_no")]
        [StringLength(200)]
        [Unicode(false)]
        public string? InvoiceNo { get; set; }
        [Column("invoice_amount", TypeName = "decimal(18, 2)")]
        public decimal? InvoiceAmount { get; set; }
        [Column("remark")]
        [StringLength(2000)]
        public string? Remark { get; set; }
        [Column("attach_ref")]
        [StringLength(100)]
        public string? AttachRef { get; set; }
        [Column("settlement_at", TypeName = "datetime")]
        public DateTime? SettlementAt { get; set; }
        [Column("cancel_at", TypeName = "datetime")]
        public DateTime? CancelAt { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
