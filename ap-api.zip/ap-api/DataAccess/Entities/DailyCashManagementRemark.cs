﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("daily_cash_management_remark", Schema = "report")]
    public partial class DailyCashManagementRemark
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("ownership")]
        [StringLength(2)]
        public string? Ownership { get; set; }
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
    }
}
