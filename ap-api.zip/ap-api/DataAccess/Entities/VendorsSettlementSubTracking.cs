﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_settlement_sub_tracking")]
    public partial class VendorsSettlementSubTracking
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("claim_perc")]
        public int? ClaimPerc { get; set; }
        [Column("is_final")]
        public bool? IsFinal { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
