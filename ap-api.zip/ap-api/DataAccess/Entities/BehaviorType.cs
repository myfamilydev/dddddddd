﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("behavior_types", Schema = "arch")]
    public partial class BehaviorType
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("behavior_type")]
        [StringLength(50)]
        public string? BehaviorType1 { get; set; }
        [Column("status")]
        public byte Status { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
    }
}
