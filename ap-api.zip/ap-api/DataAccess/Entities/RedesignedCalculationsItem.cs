﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("redesigned_calculations_items", Schema = "arch")]
    public partial class RedesignedCalculationsItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("redesigned_calculation_id")]
        public int? RedesignedCalculationId { get; set; }
        [Column("redesinged_floor")]
        [StringLength(10)]
        [Unicode(false)]
        public string? RedesingedFloor { get; set; }
        [Column("sub_job_id")]
        public int? SubJobId { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("unit_id")]
        public int? UnitId { get; set; }
        [Column("qty")]
        public int? Qty { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
    }
}
