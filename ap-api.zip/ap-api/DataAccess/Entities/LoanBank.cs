﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_banks")]
    public partial class LoanBank
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("bank_short")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankShort { get; set; }
        [Column("bank_name_kh")]
        [StringLength(200)]
        public string? BankNameKh { get; set; }
        [Column("bank_name_en")]
        [StringLength(200)]
        [Unicode(false)]
        public string? BankNameEn { get; set; }
        [Column("bank_location_id")]
        public int? BankLocationId { get; set; }
        [Column("bank_account_name")]
        [StringLength(200)]
        public string? BankAccountName { get; set; }
        [Column("bank_account_number")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankAccountNumber { get; set; }
    }
}
