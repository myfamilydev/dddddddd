﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("contract_individual_htd_items")]
    public partial class ContractIndividualHtdItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("type")]
        [StringLength(10)]
        public string? Type { get; set; }
        [Column("number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Number { get; set; }
        [Column("ownership_name")]
        [StringLength(50)]
        public string? OwnershipName { get; set; }
        [Column("location")]
        public string? Location { get; set; }
        [Column("address")]
        public string? Address { get; set; }
        [Column("total_size")]
        [StringLength(50)]
        [Unicode(false)]
        public string? TotalSize { get; set; }
        [Column("remarks")]
        public string? Remarks { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
