﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualInterestIncomeExpense
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("total_interest_inome", TypeName = "decimal(18, 0)")]
        public decimal? TotalInterestInome { get; set; }
        [Column("totaI_interest_hold_tax", TypeName = "decimal(18, 0)")]
        public decimal? TotaIInterestHoldTax { get; set; }
        [Column("remark")]
        [StringLength(155)]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
    }
}
