﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_contract_Individual_htd_disbursement_infos")]
    public partial class LoanContractIndividualHtdDisbursementInfo
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_contract_id")]
        public int? LoanContractId { get; set; }
        [Column("loan_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LoanNo { get; set; }
        [Column("project_htd")]
        [StringLength(100)]
        [Unicode(false)]
        public string? ProjectHtd { get; set; }
        [Column("house_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? HouseNo { get; set; }
        [Column("street_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? StreetNo { get; set; }
        [Column("customer_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? CustomerName { get; set; }
        [Column("house_category")]
        [StringLength(100)]
        [Unicode(false)]
        public string? HouseCategory { get; set; }
        [Column("contract_date", TypeName = "datetime")]
        public DateTime? ContractDate { get; set; }
        [Column("lek_lo")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LekLo { get; set; }
        [Column("lek_phor_por")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LekPhorPor { get; set; }
        [Column("card_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? CardNo { get; set; }
        [Column("ownership_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? OwnershipName { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("currency")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Currency { get; set; }
        [Column("exchange_rate", TypeName = "decimal(15, 2)")]
        public decimal? ExchangeRate { get; set; }
        [Column("contract_price", TypeName = "decimal(15, 2)")]
        public decimal? ContractPrice { get; set; }
        [Column("loan_from_bank", TypeName = "decimal(15, 2)")]
        public decimal? LoanFromBank { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("duration")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Duration { get; set; }
        [Column("maturity_date", TypeName = "datetime")]
        public DateTime? MaturityDate { get; set; }
        [Column("total_loan_amount_khr", TypeName = "decimal(15, 2)")]
        public decimal? TotalLoanAmountKhr { get; set; }
        [Column("total_loan_amount_usd", TypeName = "decimal(15, 2)")]
        public decimal? TotalLoanAmountUsd { get; set; }
        [Column("total_loan_amount_all", TypeName = "decimal(15, 2)")]
        public decimal? TotalLoanAmountAll { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
