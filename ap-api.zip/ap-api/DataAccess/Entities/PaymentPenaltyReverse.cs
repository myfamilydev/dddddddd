﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("payment_penalty_reverse")]
    public partial class PaymentPenaltyReverse
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("parent_voucher_id")]
        public int? ParentVoucherId { get; set; }
        [Column("parent_petty_cash_id")]
        public int? ParentPettyCashId { get; set; }
        [Column("voucher_ref_id")]
        public int? VoucherRefId { get; set; }
        [Column("petty_cash_ref_id")]
        public int? PettyCashRefId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
