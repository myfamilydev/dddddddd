﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_contract_bank_items")]
    public partial class LoanContractBankItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_contract_id")]
        public int? LoanContractId { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("bank_short")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankShort { get; set; }
        [Column("bank_name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankNameEn { get; set; }
        [Column("bank_name_kh")]
        [StringLength(100)]
        public string? BankNameKh { get; set; }
        [Column("bank_location_id")]
        public int? BankLocationId { get; set; }
        [Column("bank_location")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankLocation { get; set; }
        [Column("currency_id")]
        public int? CurrencyId { get; set; }
        [Column("currency")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Currency { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("effective_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? EffectiveInterestRate { get; set; }
        [Column("interest_nature")]
        [StringLength(100)]
        [Unicode(false)]
        public string? InterestNature { get; set; }
        [Column("change_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? ChangeInterestRate { get; set; }
        [Column("bank_account_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankAccountName { get; set; }
        [Column("bank_account_number")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankAccountNumber { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("remark_payment")]
        public string? RemarkPayment { get; set; }
        [Column("settlement_by")]
        [StringLength(100)]
        [Unicode(false)]
        public string? SettlementBy { get; set; }
        [Column("loan_phase_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LoanPhaseNo { get; set; }
        [Column("loan_purpose")]
        public string? LoanPurpose { get; set; }
        [Column("disbursment_date", TypeName = "datetime")]
        public DateTime? DisbursmentDate { get; set; }
        [Column("payment_date", TypeName = "datetime")]
        public DateTime? PaymentDate { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
