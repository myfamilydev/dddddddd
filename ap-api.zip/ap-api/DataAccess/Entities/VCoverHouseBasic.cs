﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VCoverHouseBasic
    {
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? Number { get; set; }
    }
}
