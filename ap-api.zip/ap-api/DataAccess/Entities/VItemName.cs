﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VItemName
    {
        public int Expr1 { get; set; }
        [StringLength(50)]
        public string? Expr2 { get; set; }
        [StringLength(50)]
        public string? Expr3 { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("item_name")]
        [StringLength(50)]
        public string? ItemName { get; set; }
        [Column("category_item_code")]
        [StringLength(50)]
        public string? CategoryItemCode { get; set; }
    }
}
