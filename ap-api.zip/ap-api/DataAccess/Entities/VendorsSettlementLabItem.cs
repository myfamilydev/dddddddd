﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_settlement_lab_items")]
    public partial class VendorsSettlementLabItem
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("cost_type_id")]
        public int? CostTypeId { get; set; }
        [Column("settlement_lab_id")]
        public int? SettlementLabId { get; set; }
        [Column("labor_cover_id")]
        public int? LaborCoverId { get; set; }
        [Column("claimed_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimedAmount { get; set; }
        [Column("request_amount", TypeName = "decimal(15, 2)")]
        public decimal? RequestAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("standard_chart_account_id")]
        public int? StandardChartAccountId { get; set; }
        [Column("type_id")]
        public short? TypeId { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
    }
}
