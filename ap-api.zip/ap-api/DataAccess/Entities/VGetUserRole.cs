﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VGetUserRole
    {
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("role_created_by")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RoleCreatedBy { get; set; }
        [Column("role_id")]
        public short? RoleId { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RoleName { get; set; }
        [Column("role_created_at")]
        [StringLength(30)]
        [Unicode(false)]
        public string? RoleCreatedAt { get; set; }
        [Column("username")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Username { get; set; }
        [Column("user_status")]
        public byte? UserStatus { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? FullName { get; set; }
        [Column("is_dynamic")]
        public bool? IsDynamic { get; set; }
        [Column("pos_id")]
        public int? PosId { get; set; }
        [Column("position")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Position { get; set; }
    }
}
