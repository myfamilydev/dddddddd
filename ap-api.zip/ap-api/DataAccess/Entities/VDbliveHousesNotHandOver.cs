﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDbliveHousesNotHandOver
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("house_type_id")]
        public int? HouseTypeId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? HouseNumber { get; set; }
    }
}
