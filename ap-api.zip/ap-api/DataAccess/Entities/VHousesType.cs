﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VHousesType
    {
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? Number { get; set; }
        [Column("name")]
        [StringLength(100)]
        public string? Name { get; set; }
        [Column("floor")]
        public byte? Floor { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
