﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("dim_account_threatment_types")]
    public partial class DimAccountThreatmentType
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("account_threatment_type")]
        [StringLength(100)]
        [Unicode(false)]
        public string? AccountThreatmentType { get; set; }
    }
}
