﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_contracts")]
    public partial class SuppliersContract
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_code")]
        [StringLength(20)]
        [Unicode(false)]
        public string? ContractCode { get; set; }
        [Column("contract_po")]
        [StringLength(20)]
        [Unicode(false)]
        public string? ContractPo { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("supplier_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? SupplierName { get; set; }
        [Column("term_pay")]
        [StringLength(100)]
        [Unicode(false)]
        public string? TermPay { get; set; }
        [Column("payment_method")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaymentMethod { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
