﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VPaymentSettlementsBasic
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("settlement_code")]
        [StringLength(150)]
        public string? SettlementCode { get; set; }
        [Column("contractor_name")]
        [StringLength(100)]
        public string? ContractorName { get; set; }
        [Column("amount", TypeName = "decimal(18, 2)")]
        public decimal? Amount { get; set; }
        [Column("is_bank_voucher")]
        public bool IsBankVoucher { get; set; }
    }
}
