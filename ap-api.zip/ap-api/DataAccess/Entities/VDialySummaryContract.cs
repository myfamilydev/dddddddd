﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
	[Table("v_daily_summary_sub_contracts", Schema = "report")]
	[Keyless]
	public partial class VDialySummaryContract
	{
		[Column("id")]
		public Int64 Id { get; set; }
		[Column("company_id")]
		public int? CompanyId { get; set; }
		[Column("pro_id")]
		public Int16 ProId { get; set; }
	   [Column("project")]
	   public string? Project { get; set; }
		[Column("standart_house")]
		public string? StandartHouse { get; set; }
		[Column("redesign_house")]
		public string? RedesignHouse { get; set; }
		[Column("vendor_id")]
	   public int? VendorId { get; set; }
	   [Column("vendor_item")]
	   public int? ItemId { get; set; }
	   [Column("vendor_name")]
	   public string? VendorName { get; set; }
		[Column("item_name")]
		public string? ItemName { get; set; }
		[Column("contract_id")]
		public int? ContractId { get; set; }
		[Column("document_code")]
		public string? DocumentCode { get; set; }
		[Column("cost_type")]
		public string? CostType { get; set; } 
		[Column("deadline")]
		public DateTime? DeadLine { get; set; }
        [Column("received_date")]
        public DateTime? RceiveDate { get; set; }
        [Column("contract_code")]
        public string? ContractCode { get; set; }
        [Column("settlement_code")]
        public string? SettlementCode { get; set; }
        [Column("settlement_date", TypeName = "datetime")]
        public DateTime? SettlementDate { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("phase")]
        public decimal? Phase { get; set; }
        [Column("reason")]
		public string? Reason { get; set; }
        [Column("claim_amount_standard")]
        public decimal? ClaimAmountStandard { get; set; }
        [Column("cliam_amount_redesign")]
        public decimal? CliamAmountRedesign { get; set; }
        [Column("total_amount")]
        public decimal? TotalAmount { get; set; }
        [Column("claim_perc")]
        public decimal ClaimPerc { get; set; }
        [Column("claim_amount_total")]
        public decimal? ClaimAmountTotal { get; set; }
        [Column("outstanding")]
        public decimal? Outstanding { get; set; }
        [Column("rec_status")]
        public Int16? RecStatus { get; set; }

    }
}


