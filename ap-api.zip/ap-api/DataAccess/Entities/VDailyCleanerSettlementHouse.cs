﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDailyCleanerSettlementHouse
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("cleaner_settle_id")]
        public int? CleanerSettleId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("comment")]
        [StringLength(1000)]
        public string? Comment { get; set; }
        [Column("number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? Number { get; set; }
    }
}
