﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_htd_items")]
    public partial class LoanHtdItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("type")]
        [StringLength(50)]
        public string? Type { get; set; }
        [Column("number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Number { get; set; }
        [Column("ownership")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Ownership { get; set; }
        [Column("location")]
        public string? Location { get; set; }
        [Column("address")]
        public string? Address { get; set; }
        [Column("total_size")]
        [StringLength(50)]
        [Unicode(false)]
        public string? TotalSize { get; set; }
        [Column("remarks")]
        public string? Remarks { get; set; }
    }
}
