﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_category")]
    public partial class VendorsCategory
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("category_text")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CategoryText { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("order_no")]
        public short? OrderNo { get; set; }
    }
}
