﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("redesigned_calculations_cancels", Schema = "arch")]
    public partial class RedesignedCalculationsCancel
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("redesigned_cancel_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RedesignedCancelCode { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("redesigned_calculation_id")]
        public int? RedesignedCalculationId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("date", TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [Column("customer_id_1")]
        public int? CustomerId1 { get; set; }
        [Column("customer_id_2")]
        public int? CustomerId2 { get; set; }
        [Column("customer_1")]
        [StringLength(100)]
        public string? Customer1 { get; set; }
        [Column("customer_2")]
        [StringLength(100)]
        public string? Customer2 { get; set; }
        [Column("nid_1")]
        [StringLength(50)]
        public string? Nid1 { get; set; }
        [Column("nid_2")]
        [StringLength(50)]
        public string? Nid2 { get; set; }
        [Column("tel_1")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Tel1 { get; set; }
        [Column("tel_2")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Tel2 { get; set; }
        [Column("redesigned_type_id")]
        public int? RedesignedTypeId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("reasons")]
        public string? Reasons { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
    }
}
