﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("settle_payment_materials")]
    public partial class SettlePaymentMaterial
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("settle_payment_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SettlePaymentCode { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("term_pay")]
        public int? TermPay { get; set; }
        [Column("item_stock_id")]
        public int? ItemStockId { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("settle_months")]
        [StringLength(100)]
        [Unicode(false)]
        public string? SettleMonths { get; set; }
        [Column("total", TypeName = "decimal(18, 0)")]
        public decimal? Total { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
