﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VContractIndividualScheduleDetail
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_individual_schedule_id")]
        public int? ContractIndividualScheduleId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string? Project { get; set; }
        [Column("principal_amount", TypeName = "decimal(15, 2)")]
        public decimal? PrincipalAmount { get; set; }
        [Column("balance_amount", TypeName = "decimal(15, 2)")]
        public decimal? BalanceAmount { get; set; }
        [Column("interest_amount", TypeName = "decimal(15, 2)")]
        public decimal? InterestAmount { get; set; }
        [Column("wht14", TypeName = "decimal(15, 2)")]
        public decimal? Wht14 { get; set; }
        [Column("total_payment", TypeName = "decimal(15, 2)")]
        public decimal? TotalPayment { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
