﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_contracts_terminations_types")]
    public partial class VendorsContractsTerminationsType
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("type")]
        [StringLength(100)]
        public string? Type { get; set; }
    }
}
