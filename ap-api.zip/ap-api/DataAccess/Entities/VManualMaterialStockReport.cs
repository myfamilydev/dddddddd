﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualMaterialStockReport
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("balance", TypeName = "decimal(15, 2)")]
        public decimal? Balance { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
    }
}
