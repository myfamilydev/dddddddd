﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("dim_account_types")]
    public partial class DimAccountType
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("account_type")]
        [StringLength(100)]
        [Unicode(false)]
        public string? AccountType { get; set; }
    }
}
