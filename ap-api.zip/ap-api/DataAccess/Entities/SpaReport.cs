﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("spa_report")]
    public partial class SpaReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("spa_amount", TypeName = "decimal(15, 2)")]
        public decimal? SpaAmount { get; set; }
        [Column("spa_loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? SpaLoanAmount { get; set; }
        [Column("total_buy_back_amount", TypeName = "decimal(15, 2)")]
        public decimal? TotalBuyBackAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
    }
}
