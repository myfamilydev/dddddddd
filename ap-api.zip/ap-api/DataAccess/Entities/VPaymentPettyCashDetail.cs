﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VPaymentPettyCashDetail
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("payment_pretty_cash_id")]
        public int? PaymentPrettyCashId { get; set; }
        [Column("account_code")]
        [StringLength(200)]
        public string? AccountCode { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("standard_chart_account_id")]
        public int? StandardChartAccountId { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("account_description")]
        public string? AccountDescription { get; set; }
        [Column("cost_center_id")]
        public short? CostCenterId { get; set; }
        [Column("payment_description")]
        public string? PaymentDescription { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("project_code")]
        public int? ProjectCode { get; set; }
        [Column("project_short")]
        [StringLength(200)]
        public string? ProjectShort { get; set; }
    }
}
