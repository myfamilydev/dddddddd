﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("payment_vouchers_details")]
    public partial class PaymentVouchersDetail
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("settlement_id")]
        public int? SettlementId { get; set; }
        [Column("payment_voucher_id")]
        public int? PaymentVoucherId { get; set; }
        [Column("account_code")]
        [StringLength(200)]
        public string? AccountCode { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("standard_chart_account_id")]
        public int? StandardChartAccountId { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("account_description")]
        public string? AccountDescription { get; set; }
        [Column("cost_center_id")]
        public short? CostCenterId { get; set; }
        [Column("payment_description")]
        public string? PaymentDescription { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("classify")]
        [StringLength(100)]
        public string? Classify { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
