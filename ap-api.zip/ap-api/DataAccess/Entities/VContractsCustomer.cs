﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VContractsCustomer
    {
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("customer1")]
        [StringLength(150)]
        public string Customer1 { get; set; } = null!;
        [Column("current_customer1_id")]
        public int? CurrentCustomer1Id { get; set; }
        [Column("customer2")]
        [StringLength(150)]
        public string? Customer2 { get; set; }
        [Column("current_customer2_id")]
        public int? CurrentCustomer2Id { get; set; }
        [Column("phone1")]
        [StringLength(161)]
        [Unicode(false)]
        public string Phone1 { get; set; } = null!;
        [Column("phone2")]
        [StringLength(161)]
        [Unicode(false)]
        public string Phone2 { get; set; } = null!;
        [Column("nationalId1")]
        [StringLength(100)]
        public string? NationalId1 { get; set; }
        [Column("nationalId2")]
        [StringLength(100)]
        public string? NationalId2 { get; set; }
    }
}
