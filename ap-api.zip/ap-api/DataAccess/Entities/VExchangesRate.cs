﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VExchangesRate
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        [Column("payment_term")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaymentTerm { get; set; }
        [Column("exchange_rate")]
        [StringLength(50)]
        public string? ExchangeRate { get; set; }
        [Column("currency_id")]
        public int? CurrencyId { get; set; }
        [Column("reference")]
        [StringLength(50)]
        public string? Reference { get; set; }
        [Column("attachement_id")]
        public int? AttachementId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("currency")]
        [StringLength(50)]
        public string? Currency { get; set; }
        [Column("file_upload")]
        public byte[]? FileUpload { get; set; }
    }
}
