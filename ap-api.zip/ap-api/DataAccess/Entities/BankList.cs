﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("bank_lists")]
    public partial class BankList
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("bank_name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankNameEn { get; set; }
        [Column("bank_name_kh")]
        [StringLength(100)]
        public string? BankNameKh { get; set; }
        [Column("account_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? AccountName { get; set; }
        [Column("account_number")]
        [StringLength(100)]
        [Unicode(false)]
        public string? AccountNumber { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("pv_ref")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PvRef { get; set; }
        [Column("bank_account_no")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankAccountNo { get; set; }
        [Column("pcv_no")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PcvNo { get; set; }
    }
}
