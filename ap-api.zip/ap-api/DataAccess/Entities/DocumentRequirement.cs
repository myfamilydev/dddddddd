﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("document_requirements")]
    public partial class DocumentRequirement
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_contract_id")]
        public int? LoanContractId { get; set; }
        [Column("description")]
        public string? Description { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("deadline", TypeName = "datetime")]
        public DateTime? Deadline { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
