﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("execute_delete_transactions")]
    public partial class ExecuteDeleteTransaction
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("execute_sp")]
        public string? ExecuteSp { get; set; }
        [Column("transaction_name")]
        [StringLength(50)]
        public string? TransactionName { get; set; }
    }
}
