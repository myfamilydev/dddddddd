﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_schedules_payments_details")]
    public partial class SuppliersSchedulesPaymentsDetail
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("schedule_payment_id")]
        public int? SchedulePaymentId { get; set; }
        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column("amount_kh", TypeName = "decimal(18, 2)")]
        public decimal? AmountKh { get; set; }
        [Column("amount_usd", TypeName = "decimal(18, 2)")]
        public decimal? AmountUsd { get; set; }
        [Column("type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Type { get; set; }
        [Column("pv_ref")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PvRef { get; set; }
        [Column("exchange_rate", TypeName = "decimal(18, 2)")]
        public decimal? ExchangeRate { get; set; }
        [Column("paid_at", TypeName = "date")]
        public DateTime? PaidAt { get; set; }
        [Column("paid_amount", TypeName = "decimal(18, 2)")]
        public decimal? PaidAmount { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
