﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("suppliers_items_masters")]
    public partial class SuppliersItemsMaster
    {
        [Column("id")]
        public int? Id { get; set; }
    }
}
