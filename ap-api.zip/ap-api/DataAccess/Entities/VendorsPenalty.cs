﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_penalties")]
    public partial class VendorsPenalty
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        [Unicode(false)]
        public string? VendorCategory { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("penalty_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PenaltyCode { get; set; }
        [Column("payment_tracking_id")]
        public int? PaymentTrackingId { get; set; }
        [Column("settlement_date", TypeName = "date")]
        public DateTime? SettlementDate { get; set; }
        [Column("penalty_amount", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmount { get; set; }
        [Column("payment_method")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaymentMethod { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("account_code")]
        [StringLength(100)]
        [Unicode(false)]
        public string? AccountCode { get; set; }
        [Column("penalty_reason")]
        public string? PenaltyReason { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
