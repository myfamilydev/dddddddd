﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_reschedules")]
    public partial class LoanReschedule
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("reschedule_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RescheduleCode { get; set; }
        [Column("load_type_id")]
        public int? LoadTypeId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("loan_bank_ref")]
        [StringLength(50)]
        [Unicode(false)]
        public string? LoanBankRef { get; set; }
        [Column("reschedule_date", TypeName = "datetime")]
        public DateTime? RescheduleDate { get; set; }
        [Column("extra_principal", TypeName = "decimal(15, 2)")]
        public decimal? ExtraPrincipal { get; set; }
        [Column("new_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? NewInterestRate { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
