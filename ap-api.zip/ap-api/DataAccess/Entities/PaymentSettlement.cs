﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("payment_settlements")]
    public partial class PaymentSettlement
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("table_name")]
        [StringLength(200)]
        public string? TableName { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("contractor_name")]
        [StringLength(100)]
        public string? ContractorName { get; set; }
        [Column("cheque_name")]
        [StringLength(100)]
        public string? ChequeName { get; set; }
        [Column("contractor_id")]
        public int? ContractorId { get; set; }
        [Column("settlement_code")]
        [StringLength(150)]
        public string? SettlementCode { get; set; }
        [Column("amount", TypeName = "decimal(18, 2)")]
        public decimal? Amount { get; set; }
        [Column("voucher_at", TypeName = "datetime")]
        public DateTime? VoucherAt { get; set; }
        [Column("pretty_cash_at", TypeName = "datetime")]
        public DateTime? PrettyCashAt { get; set; }
        [Column("is_bank_voucher")]
        public bool? IsBankVoucher { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
