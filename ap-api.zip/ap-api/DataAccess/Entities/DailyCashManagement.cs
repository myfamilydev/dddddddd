﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("daily_cash_management", Schema = "report")]
    public partial class DailyCashManagement
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("ownership")]
        [StringLength(2)]
        public string? Ownership { get; set; }
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        [Column("inter_fund_channel", TypeName = "decimal(15, 2)")]
        public decimal? InterFundChannel { get; set; }
        [Column("reserved_other_expense", TypeName = "decimal(15, 2)")]
        public decimal? ReservedOtherExpense { get; set; }
        [Column("non_inter_fund_channel", TypeName = "decimal(15, 2)")]
        public decimal? NonInterFundChannel { get; set; }
        [Column("notice")]
        public string? Notice { get; set; }
    }
}
