﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_physical_check_labs")]
    public partial class VendorsPhysicalCheckLab
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("settlement_id")]
        public int? SettlementId { get; set; }
        [Column("code")]
        [StringLength(30)]
        [Unicode(false)]
        public string? Code { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("check_date", TypeName = "date")]
        public DateTime? CheckDate { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
