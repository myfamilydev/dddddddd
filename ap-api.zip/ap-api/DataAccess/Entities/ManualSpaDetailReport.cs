﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("manual_spa_detail_report", Schema = "report")]
    public partial class ManualSpaDetailReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("manual_spa_report_id")]
        public int? ManualSpaReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("spa_amount", TypeName = "decimal(15, 2)")]
        public decimal? SpaAmount { get; set; }
        [Column("spa_loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? SpaLoanAmount { get; set; }
        [Column("total_buy_back_amount", TypeName = "decimal(15, 2)")]
        public decimal? TotalBuyBackAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("insert_type")]
        [StringLength(255)]
        [Unicode(false)]
        public string? InsertType { get; set; }
    }
}
