﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("model_has_category")]
    public partial class ModelHasCategory
    {
        [Key]
        public int Id { get; set; }
        [Column("model_id")]
        public int? ModelId { get; set; }
        [Column("model_type")]
        [StringLength(250)]
        [Unicode(false)]
        public string? ModelType { get; set; }
        [Column("model_item_name")]
        [StringLength(250)]
        [Unicode(false)]
        public string? ModelItemName { get; set; }
        [Column("model_description", TypeName = "text")]
        public string? ModelDescription { get; set; }
        [Column("deleted_at", TypeName = "datetime")]
        public DateTime? DeletedAt { get; set; }
    }
}
