﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("audit_log")]
    public partial class AuditLog
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("company_name")]
        [StringLength(200)]
        public string? CompanyName { get; set; }
        [Column("action")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Action { get; set; }
        [Column("module_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ModuleName { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_by_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CreatedByName { get; set; }
        [Column("description")]
        [StringLength(200)]
        public string? Description { get; set; }
    }
}
