﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_terminations")]
    public partial class VendorsContractsTermination
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("contract_terminate_code")]
        [StringLength(20)]
        [Unicode(false)]
        public string? ContractTerminateCode { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("cancellation_date", TypeName = "date")]
        public DateTime? CancellationDate { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("terminate_reason")]
        [StringLength(1000)]
        public string? TerminateReason { get; set; }
        [Column("received_document_date", TypeName = "date")]
        public DateTime? ReceivedDocumentDate { get; set; }
        [Column("signed_new_contract_date", TypeName = "date")]
        public DateTime? SignedNewContractDate { get; set; }
        [Column("remarks")]
        [StringLength(2000)]
        public string? Remarks { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
