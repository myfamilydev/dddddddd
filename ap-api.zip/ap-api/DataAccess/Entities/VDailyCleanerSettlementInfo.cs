﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDailyCleanerSettlementInfo
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("cleaner_settle_id")]
        public int? CleanerSettleId { get; set; }
        [Column("total_working_day", TypeName = "decimal(10, 2)")]
        public decimal? TotalWorkingDay { get; set; }
        [Column("cleaner_info_id")]
        public int? CleanerInfoId { get; set; }
        [Column("tatal_payment", TypeName = "decimal(10, 2)")]
        public decimal? TatalPayment { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string? NameKh { get; set; }
        [Column("position_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? PositionEn { get; set; }
        [Column("position_kh")]
        [StringLength(100)]
        public string? PositionKh { get; set; }
        [Column("daily_wage_fee", TypeName = "decimal(10, 2)")]
        public decimal? DailyWageFee { get; set; }
    }
}
