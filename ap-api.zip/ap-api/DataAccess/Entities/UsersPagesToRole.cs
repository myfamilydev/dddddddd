﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_pages_to_roles")]
    public partial class UsersPagesToRole
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("page_id")]
        public int? PageId { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
