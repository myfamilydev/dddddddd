﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_roles")]
    public partial class UsersRole
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RoleName { get; set; }
        [Column("role_description")]
        [StringLength(1000)]
        [Unicode(false)]
        public string? RoleDescription { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("auth")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Auth { get; set; }
        [Column("is_dynamic")]
        public bool? IsDynamic { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
