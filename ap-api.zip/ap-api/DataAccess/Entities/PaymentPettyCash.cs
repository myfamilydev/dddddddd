﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("payment_petty_cashes")]
    public partial class PaymentPettyCash
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("exchange_rate_id")]
        public int? ExchangeRateId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("pv_ref")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PvRef { get; set; }
        [Column("voucher_date", TypeName = "datetime")]
        public DateTime? VoucherDate { get; set; }
        [Column("settlement_id")]
        public string? SettlementId { get; set; }
        [Column("settlement_code")]
        public string? SettlementCode { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        public string? BankName { get; set; }
        [Column("description")]
        public string? Description { get; set; }
        [Column("payee_name")]
        [StringLength(200)]
        public string? PayeeName { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("company_name")]
        [StringLength(200)]
        public string? CompanyName { get; set; }
    }
}
