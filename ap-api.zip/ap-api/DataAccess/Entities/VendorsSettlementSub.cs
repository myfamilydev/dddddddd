﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_settlement_sub")]
    public partial class VendorsSettlementSub
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("settlement_date", TypeName = "datetime")]
        public DateTime? SettlementDate { get; set; }
        [Column("settlement_code")]
        [StringLength(30)]
        [Unicode(false)]
        public string? SettlementCode { get; set; }
        [Column("vendor_item")]
        public int? VendorItem { get; set; }
        [Column("is_no_contract")]
        public bool? IsNoContract { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("contract_purchase_id")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContractPurchaseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("is_match_payment_term")]
        public bool? IsMatchPaymentTerm { get; set; }
        [Column("payment_term_perc", TypeName = "decimal(15, 2)")]
        public decimal? PaymentTermPerc { get; set; }
        [Column("cost_type_id")]
        public int? CostTypeId { get; set; }
        [Column("document_id")]
        public int? DocumentId { get; set; }
        [Column("deadline", TypeName = "date")]
        public DateTime? Deadline { get; set; }
        [Column("reason")]
        public string? Reason { get; set; }
        [Column("claim_time")]
        public int? ClaimTime { get; set; }
        [Column("rec_status")]
        public short RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("payment_term_item_id")]
        public int? PaymentTermItemId { get; set; }
        [Column("physical_check_at", TypeName = "datetime")]
        public DateTime? PhysicalCheckAt { get; set; }
        [Column("payment_type_id")]
        public int? PaymentTypeId { get; set; }
        [Column("unfollow_contract")]
        public bool? UnfollowContract { get; set; }
        [Column("auto_lock")]
        public bool? AutoLock { get; set; }
        [Column("deposit")]
        public bool? Deposit { get; set; }
        [Column("deposit_chart_account_id")]
        public int? DepositChartAccountId { get; set; }
        [Column("reverse_deposit")]
        public bool? ReverseDeposit { get; set; }
    }
}
