﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDbliveHouseCategory
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("name")]
        [StringLength(250)]
        public string? Name { get; set; }
        [Column("desc")]
        [Unicode(false)]
        public string? Desc { get; set; }
        [Column("public_service")]
        public double? PublicService { get; set; }
        [Column("remarks")]
        public string? Remarks { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("house_qty")]
        public int? HouseQty { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
