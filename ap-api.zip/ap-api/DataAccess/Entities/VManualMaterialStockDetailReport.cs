﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualMaterialStockDetailReport
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("manual_material_stock_report_id")]
        public int? ManualMaterialStockReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("balance", TypeName = "decimal(15, 2)")]
        public decimal? Balance { get; set; }
        [Column("project_short")]
        public string? ProjectShort { get; set; }
        [Column("remark_en")]
        public string? RemarkEn { get; set; }
        [Column("remark_kh")]
        public string? RemarkKh { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("other_project")]
        public string? OtherProject { get; set; }
    }
}
