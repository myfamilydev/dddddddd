﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("chart_accounts_auto_types")]
    public partial class ChartAccountsAutoType
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("auto_type")]
        [StringLength(100)]
        public string? AutoType { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
