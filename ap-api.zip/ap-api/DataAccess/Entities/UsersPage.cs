﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_pages")]
    public partial class UsersPage
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("page_title")]
        [StringLength(100)]
        [Unicode(false)]
        public string? PageTitle { get; set; }
        [Column("page_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PageName { get; set; }
        [Column("page_url")]
        [StringLength(200)]
        [Unicode(false)]
        public string? PageUrl { get; set; }
        [Column("icon_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? IconName { get; set; }
        [Column("page_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PageType { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("ordering")]
        public int? Ordering { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
    }
}
