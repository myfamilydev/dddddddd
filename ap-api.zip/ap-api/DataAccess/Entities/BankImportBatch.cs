﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("bank_import_batch")]
    public partial class BankImportBatch
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("file_name")]
        [StringLength(150)]
        [Unicode(false)]
        public string? FileName { get; set; }
        [Column("file_size_kb", TypeName = "decimal(15, 2)")]
        public decimal? FileSizeKb { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
