﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_terminations_covers")]
    public partial class VendorsContractsTerminationsCover
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("terminate_id")]
        public int? TerminateId { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("terminate_type_id")]
        public int? TerminateTypeId { get; set; }
        [Column("allow")]
        public bool? Allow { get; set; }
        [Column("transfer")]
        public bool? Transfer { get; set; }
        [Column("transfer_amount", TypeName = "decimal(15, 2)")]
        public decimal? TransferAmount { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
