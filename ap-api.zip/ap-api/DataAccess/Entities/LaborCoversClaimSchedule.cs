﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("labor_covers_claim_schedules")]
    public partial class LaborCoversClaimSchedule
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("cover_item_id")]
        public long? CoverItemId { get; set; }
        [Column("claim_date", TypeName = "date")]
        public DateTime? ClaimDate { get; set; }
        [Column("claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("accumulated_claim", TypeName = "decimal(18, 2)")]
        public decimal? AccumulatedClaim { get; set; }
        [Column("remaining_claim", TypeName = "decimal(18, 2)")]
        public decimal? RemainingClaim { get; set; }
        [Column("claim_link")]
        [StringLength(200)]
        [Unicode(false)]
        public string? ClaimLink { get; set; }
        [Column("payment_voucher_id")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaymentVoucherId { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
