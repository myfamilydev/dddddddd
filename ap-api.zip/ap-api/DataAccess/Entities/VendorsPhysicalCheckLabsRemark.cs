﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_physical_check_labs_remarks")]
    public partial class VendorsPhysicalCheckLabsRemark
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("physical_check_lab_id")]
        public long? PhysicalCheckLabId { get; set; }
        [Column("remark_short")]
        [StringLength(30)]
        [Unicode(false)]
        public string? RemarkShort { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
