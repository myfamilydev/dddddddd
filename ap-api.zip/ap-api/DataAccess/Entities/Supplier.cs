﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers")]
    [Index("SupplierCode", Name = "IX_suppliers")]
    public partial class Supplier
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("supplier_location")]
        [StringLength(20)]
        [Unicode(false)]
        public string? SupplierLocation { get; set; }
        [Column("supplier_code")]
        [StringLength(20)]
        [Unicode(false)]
        public string? SupplierCode { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string? NameKh { get; set; }
        [Column("nid")]
        [StringLength(20)]
        [Unicode(false)]
        public string? Nid { get; set; }
        [Column("address")]
        public string? Address { get; set; }
        [Column("contact_number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContactNumber { get; set; }
        [Column("contact_telegram")]
        [StringLength(20)]
        [Unicode(false)]
        public string? ContactTelegram { get; set; }
        [Column("email")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Email { get; set; }
        [Column("payment_collector")]
        [StringLength(1000)]
        [Unicode(false)]
        public string? PaymentCollector { get; set; }
        [Column("collector_number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CollectorNumber { get; set; }
        [Column("collector_telegram")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CollectorTelegram { get; set; }
        [Column("name_on_cheque")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameOnCheque { get; set; }
        [Column("behavior")]
        [StringLength(50)]
        public string? Behavior { get; set; }
        [Column("behavior_description")]
        [StringLength(100)]
        public string? BehaviorDescription { get; set; }
        [Column("supplier_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SupplierType { get; set; }
        [Column("normal")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Normal { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        [Unicode(false)]
        public string? Remark { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
