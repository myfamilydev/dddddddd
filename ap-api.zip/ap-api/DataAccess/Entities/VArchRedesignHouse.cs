﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VArchRedesignHouse
    {
        [Column("redesigned_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RedesignedCode { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("sub_job_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SubJobCode { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("discount", TypeName = "decimal(15, 2)")]
        public decimal? Discount { get; set; }
        [Column("cancel_date", TypeName = "datetime")]
        public DateTime? CancelDate { get; set; }
        [Column("redesign_type")]
        [StringLength(250)]
        [Unicode(false)]
        public string? RedesignType { get; set; }
        [Column("sub_job_name")]
        [StringLength(250)]
        public string? SubJobName { get; set; }
    }
}
