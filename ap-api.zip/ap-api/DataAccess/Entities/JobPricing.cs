﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("job_pricing", Schema = "arch")]
    public partial class JobPricing
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("jop_pricing_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? JopPricingCode { get; set; }
        [Column("job_id")]
        public int? JobId { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
