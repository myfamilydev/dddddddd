﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("dim_share_cost_standard")]
    public partial class DimShareCostStandard
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("effective_id")]
        public int? EffectiveId { get; set; }
        [Column("cost_rate", TypeName = "decimal(18, 2)")]
        public decimal? CostRate { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
