﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VGetWorkflow
    {
        [Column("role_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? RoleName { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? FullName { get; set; }
        [Column("is_done")]
        public byte? IsDone { get; set; }
        [Column("action_at", TypeName = "datetime")]
        public DateTime ActionAt { get; set; }
    }
}
