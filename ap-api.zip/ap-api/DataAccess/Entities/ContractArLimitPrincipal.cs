﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("contract_ar_limit_principals")]
    public partial class ContractArLimitPrincipal
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("limit_principal_percentage", TypeName = "decimal(15, 2)")]
        public decimal? LimitPrincipalPercentage { get; set; }
        [Column("limit_principal_amount", TypeName = "decimal(15, 2)")]
        public decimal? LimitPrincipalAmount { get; set; }
        [Column("actual_accumulate_amount", TypeName = "decimal(15, 2)")]
        public decimal? ActualAccumulateAmount { get; set; }
        [Column("balance_amount", TypeName = "decimal(15, 2)")]
        public decimal? BalanceAmount { get; set; }
        [Column("allocate_house_amount", TypeName = "decimal(15, 2)")]
        public decimal? AllocateHouseAmount { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
