﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_items", Schema = "log")]
    public partial class VendorsContractsItem1
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("claim_time")]
        public int? ClaimTime { get; set; }
        [Column("is_final")]
        public bool? IsFinal { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("locked")]
        public bool? Locked { get; set; }
    }
}
