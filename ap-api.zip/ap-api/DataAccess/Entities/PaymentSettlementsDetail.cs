﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("payment_settlements_details")]
    public partial class PaymentSettlementsDetail
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("cost_center_id")]
        public int? CostCenterId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("payment_settlement_id")]
        public int? PaymentSettlementId { get; set; }
        [Column("standard_chart_account_id")]
        public int? StandardChartAccountId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("classify")]
        [StringLength(100)]
        public string? Classify { get; set; }
    }
}
