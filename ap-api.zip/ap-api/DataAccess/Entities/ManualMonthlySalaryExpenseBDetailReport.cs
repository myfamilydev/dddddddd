﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("manual_monthly_salary_expense_b_detail_report", Schema = "report")]
    public partial class ManualMonthlySalaryExpenseBDetailReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("manual_monthly_salary_expense_b_report_id")]
        public int? ManualMonthlySalaryExpenseBReportId { get; set; }
        [Column("description_en")]
        public string? DescriptionEn { get; set; }
        [Column("description_kh")]
        public string? DescriptionKh { get; set; }
        [Column("no_staff_ab", TypeName = "decimal(15, 2)")]
        public decimal? NoStaffAb { get; set; }
        [Column("expense_ab", TypeName = "decimal(15, 2)")]
        public decimal? ExpenseAb { get; set; }
        [Column("no_staff_share", TypeName = "decimal(15, 2)")]
        public decimal? NoStaffShare { get; set; }
        [Column("expense_share", TypeName = "decimal(15, 2)")]
        public decimal? ExpenseShare { get; set; }
        [Column("total_staff", TypeName = "decimal(15, 2)")]
        public decimal? TotalStaff { get; set; }
        [Column("total_expense", TypeName = "decimal(15, 2)")]
        public decimal? TotalExpense { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("insert_type")]
        [StringLength(255)]
        [Unicode(false)]
        public string? InsertType { get; set; }
    }
}
