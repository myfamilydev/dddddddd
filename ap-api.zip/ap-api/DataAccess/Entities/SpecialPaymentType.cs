﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("special_payment_types")]
    public partial class SpecialPaymentType
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("type")]
        [StringLength(100)]
        public string? Type { get; set; }
        [Column("description")]
        public string? Description { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
