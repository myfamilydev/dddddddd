﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_master", Schema = "log")]
    public partial class VendorsContractsMaster1
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("cost_name")]
        [StringLength(50)]
        public string? CostName { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("description")]
        public string? Description { get; set; }
        [Column("require_reason")]
        public bool? RequireReason { get; set; }
        [Column("house_redesign_id")]
        public int? HouseRedesignId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("locked")]
        public bool? Locked { get; set; }
    }
}
