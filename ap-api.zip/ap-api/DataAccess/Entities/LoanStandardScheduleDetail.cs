﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_standard_schedule_details")]
    public partial class LoanStandardScheduleDetail
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("loan_standard_schedule_id")]
        public int? LoanStandardScheduleId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("principal_amount", TypeName = "decimal(15, 2)")]
        public decimal? PrincipalAmount { get; set; }
        [Column("balance_amount", TypeName = "decimal(15, 2)")]
        public decimal? BalanceAmount { get; set; }
        [Column("interest_amount", TypeName = "decimal(15, 2)")]
        public decimal? InterestAmount { get; set; }
        [Column("wht14", TypeName = "decimal(15, 2)")]
        public decimal? Wht14 { get; set; }
        [Column("total_payment", TypeName = "decimal(15, 2)")]
        public decimal? TotalPayment { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
    }
}
