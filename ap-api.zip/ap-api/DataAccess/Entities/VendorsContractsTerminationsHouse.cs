﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_terminations_houses")]
    public partial class VendorsContractsTerminationsHouse
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_terminate_id")]
        public int? ContractTerminateId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("cover_houses")]
        public string? CoverHouses { get; set; }
        [Column("cover_house_ids")]
        public string? CoverHouseIds { get; set; }
        [Column("paid_status")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaidStatus { get; set; }
        [Column("transfer_vendor_id")]
        public int? TransferVendorId { get; set; }
        [Column("transfered_at", TypeName = "datetime")]
        public DateTime? TransferedAt { get; set; }
        [Column("can_terminate")]
        public bool? CanTerminate { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
