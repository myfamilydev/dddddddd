﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDailyCleanerInfoBasic
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string? NameKh { get; set; }
        [Column("position_id")]
        public int? PositionId { get; set; }
        [Column("position_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? PositionEn { get; set; }
        [Column("position_kh")]
        [StringLength(100)]
        public string? PositionKh { get; set; }
        [Column("daily_wage_fee", TypeName = "decimal(15, 2)")]
        public decimal? DailyWageFee { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
