﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("redesigned_calculations", Schema = "arch")]
    public partial class RedesignedCalculation
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("redesigned_short")]
        [StringLength(10)]
        [Unicode(false)]
        public string? RedesignedShort { get; set; }
        [Column("redesigned_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RedesignedCode { get; set; }
        [Column("redesigned_type_id")]
        public int? RedesignedTypeId { get; set; }
        [Column("condition_remark")]
        public string? ConditionRemark { get; set; }
        [Column("is_payment_installment")]
        public byte? IsPaymentInstallment { get; set; }
        [Column("discount", TypeName = "decimal(15, 2)")]
        public decimal? Discount { get; set; }
        [Column("discount_remark")]
        public string? DiscountRemark { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
