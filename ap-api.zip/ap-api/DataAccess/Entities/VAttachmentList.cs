﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VAttachmentList
    {
        [Column("file_uuid")]
        public Guid FileUuid { get; set; }
        [Column("file_name")]
        public string? FileName { get; set; }
        [Column("file_ext")]
        [StringLength(20)]
        [Unicode(false)]
        public string? FileExt { get; set; }
        [Column("file_size")]
        public long? FileSize { get; set; }
        [Column("file_ref")]
        [StringLength(30)]
        [Unicode(false)]
        public string? FileRef { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? FullName { get; set; }
        [Column("file_ref_id")]
        public long? FileRefId { get; set; }
        [Column("created_by")]
        public int CreatedBy { get; set; }
    }
}
