﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VChequeBooksDetail
    {
        [Column("cheque_book_id")]
        public int? ChequeBookId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        [Column("start_number", TypeName = "decimal(15, 2)")]
        public decimal? StartNumber { get; set; }
        [Column("end_number", TypeName = "decimal(15, 2)")]
        public decimal? EndNumber { get; set; }
        [Column("incharge_staff_id")]
        public int? InchargeStaffId { get; set; }
    }
}
