﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VHousesListsAll
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("house_type_id")]
        public int? HouseTypeId { get; set; }
        [Column("road_type")]
        [StringLength(30)]
        [Unicode(false)]
        public string? RoadType { get; set; }
        [Column("number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? Number { get; set; }
        [Column("price", TypeName = "decimal(15, 8)")]
        public decimal? Price { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("house_category")]
        [StringLength(250)]
        public string? HouseCategory { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; } = null!;
        [Column("land_width")]
        [StringLength(10)]
        [Unicode(false)]
        public string? LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        [Unicode(false)]
        public string? LandLength { get; set; }
    }
}
