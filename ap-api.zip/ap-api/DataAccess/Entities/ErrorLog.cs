﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("error_logs")]
    public partial class ErrorLog
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("log_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? LogType { get; set; }
        [Column("description")]
        [Unicode(false)]
        public string? Description { get; set; }
        [Column("ip")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Ip { get; set; }
        [Column("created_by")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CreatedBy { get; set; }
        [Column("created_at")]
        public byte[]? CreatedAt { get; set; }
    }
}
