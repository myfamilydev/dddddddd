﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VBankReconcile
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        public string? BankName { get; set; }
        [Column("generate_month")]
        [StringLength(50)]
        [Unicode(false)]
        public string? GenerateMonth { get; set; }
        [Column("opening_amount", TypeName = "decimal(18, 0)")]
        public decimal? OpeningAmount { get; set; }
        [Column("total_withdraw", TypeName = "decimal(18, 0)")]
        public decimal? TotalWithdraw { get; set; }
        [Column("total_deposit", TypeName = "decimal(18, 0)")]
        public decimal? TotalDeposit { get; set; }
        [Column("balance_qb", TypeName = "decimal(18, 0)")]
        public decimal? BalanceQb { get; set; }
        [Column("genrate")]
        public bool? Genrate { get; set; }
        [Column("confirm_final")]
        public bool? ConfirmFinal { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
