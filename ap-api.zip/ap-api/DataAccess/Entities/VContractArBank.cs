﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VContractArBank
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("loan_amount_khr", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmountKhr { get; set; }
        [Column("loan_amount_usd", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmountUsd { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("bank_short")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankShort { get; set; }
        [Column("bank_name_kh")]
        [StringLength(200)]
        public string? BankNameKh { get; set; }
        [Column("bank_name_en")]
        [StringLength(200)]
        [Unicode(false)]
        public string? BankNameEn { get; set; }
        [Column("bank_account_name")]
        [StringLength(200)]
        public string? BankAccountName { get; set; }
        [Column("location")]
        [StringLength(100)]
        public string? Location { get; set; }
        [Column("settlement_by")]
        [StringLength(100)]
        public string? SettlementBy { get; set; }
        [Column("loan_phase_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LoanPhaseNo { get; set; }
        [Column("loan_purpose")]
        public string? LoanPurpose { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("effective_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? EffectiveInterestRate { get; set; }
        [Column("interest_nature", TypeName = "decimal(15, 2)")]
        public decimal? InterestNature { get; set; }
        [Column("change_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? ChangeInterestRate { get; set; }
        [Column("bank_location_id")]
        public int? BankLocationId { get; set; }
    }
}
