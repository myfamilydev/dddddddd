﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_cost_centers")]
    public partial class LoanCostCenter
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("loan_disburement_id")]
        public int? LoanDisburementId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
    }
}
