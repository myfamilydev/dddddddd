﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VGroupPaymentHouseAvailable
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("group_payment_id")]
        public int? GroupPaymentId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("active")]
        public bool Active { get; set; }
        [Column("number")]
        [StringLength(22)]
        [Unicode(false)]
        public string? Number { get; set; }
    }
}
