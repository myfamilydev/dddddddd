﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("banks_projects_child")]
    public partial class BanksProjectsChild
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }

        [ForeignKey("ParentId")]
        [InverseProperty("BanksProjectsChildren")]
        public virtual Bank? Parent { get; set; }
    }
}
