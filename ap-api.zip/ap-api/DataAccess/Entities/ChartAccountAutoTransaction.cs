﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("chart_account_auto_transactions")]
    public partial class ChartAccountAutoTransaction
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("transaction_title")]
        [StringLength(100)]
        public string? TransactionTitle { get; set; }
        [Key]
        [Column("auto_type_id")]
        public int AutoTypeId { get; set; }
        [Column("standard_account_id")]
        public int? StandardAccountId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
