﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_terminates_types")]
    public partial class VendorsTerminatesType
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("type_name")]
        [StringLength(50)]
        public string? TypeName { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
