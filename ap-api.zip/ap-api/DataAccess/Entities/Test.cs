﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("test")]
    public partial class Test
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("test")]
        [StringLength(50)]
        public string? Test1 { get; set; }
    }
}
