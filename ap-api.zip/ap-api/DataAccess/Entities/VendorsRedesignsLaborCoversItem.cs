﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns_labor_covers_items")]
    public partial class VendorsRedesignsLaborCoversItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendors_labor_cover_id")]
        public int VendorsLaborCoverId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("price_item_id")]
        public long? PriceItemId { get; set; }
        [Column("quantity", TypeName = "decimal(18, 3)")]
        public decimal Quantity { get; set; }
        [Column("uom")]
        [StringLength(200)]
        public string? Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("redesign_type_id")]
        public int? RedesignTypeId { get; set; }
        [Column("redesign_category_id")]
        public int? RedesignCategoryId { get; set; }
        [Column("final_amount", TypeName = "decimal(15, 2)")]
        public decimal? FinalAmount { get; set; }
        [Column("reason")]
        public string? Reason { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
