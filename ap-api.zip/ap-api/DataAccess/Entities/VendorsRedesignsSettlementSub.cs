﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns_settlement_sub")]
    public partial class VendorsRedesignsSettlementSub
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendors_settlement_sub_id")]
        public int VendorsSettlementSubId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("account_code")]
        [StringLength(200)]
        public string? AccountCode { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
