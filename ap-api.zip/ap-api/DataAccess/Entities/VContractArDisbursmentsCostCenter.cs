﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VContractArDisbursmentsCostCenter
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_ar_disbursment_id")]
        public int? ContractArDisbursmentId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
