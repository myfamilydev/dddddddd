﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns_items")]
    public partial class VendorsRedesignsItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendors_redesign_id")]
        public int? VendorsRedesignId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("price_item_id")]
        public long? PriceItemId { get; set; }
        [Column("quantity", TypeName = "decimal(18, 3)")]
        public decimal Quantity { get; set; }
        [Column("uom")]
        [StringLength(200)]
        public string? Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("total_price", TypeName = "decimal(18, 2)")]
        public decimal? TotalPrice { get; set; }
        [Column("prev_claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? PrevClaimAmount { get; set; }
        [Column("prev_perc", TypeName = "decimal(18, 2)")]
        public decimal? PrevPerc { get; set; }
        [Column("pre_lock_tick")]
        public bool? PreLockTick { get; set; }
        [Column("lock_tick")]
        public bool? LockTick { get; set; }
        [Column("claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("pre_is_match")]
        public bool? PreIsMatch { get; set; }
        [Column("is_match")]
        public bool? IsMatch { get; set; }
        [Column("perc", TypeName = "decimal(18, 2)")]
        public decimal? Perc { get; set; }
        [Column("claim_time", TypeName = "decimal(15, 2)")]
        public decimal? ClaimTime { get; set; }
        [Column("adj_amount", TypeName = "decimal(15, 2)")]
        public decimal? AdjAmount { get; set; }
        [Column("redesign_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RedesignType { get; set; }
        [Column("redesign_amount", TypeName = "decimal(15, 2)")]
        public decimal? RedesignAmount { get; set; }
        [Column("redesigned_code")]
        [StringLength(100)]
        [Unicode(false)]
        public string? RedesignedCode { get; set; }
        [Column("claim_id")]
        [StringLength(100)]
        [Unicode(false)]
        public string? ClaimId { get; set; }
        [Column("reason")]
        public string? Reason { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
