﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_tracking_cost_names")]
    public partial class VendorsContractsTrackingCostName
    {
        [Column("id")]
        public long Id { get; set; }
        [Key]
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Key]
        [Column("vendor_id")]
        public int VendorId { get; set; }
        [Key]
        [Column("master_id")]
        public int MasterId { get; set; }
        [Column("cost_name")]
        public string CostName { get; set; } = null!;
        [Key]
        [Column("item_id")]
        public int ItemId { get; set; }
        [Key]
        [Column("status")]
        public bool Status { get; set; }
        [Column("claim_time")]
        public int? ClaimTime { get; set; }
        [Column("total_claim_perc", TypeName = "decimal(18, 2)")]
        public decimal? TotalClaimPerc { get; set; }
        [Column("is_match")]
        public bool? IsMatch { get; set; }
        [Column("is_final")]
        public bool? IsFinal { get; set; }
        [Column("is_terminated")]
        public bool? IsTerminated { get; set; }
    }
}
