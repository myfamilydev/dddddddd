﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("labor_covers")]
    public partial class LaborCover
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("vendor_item_id")]
        public int? VendorItemId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("cover_code")]
        [StringLength(20)]
        [Unicode(false)]
        public string? CoverCode { get; set; }
        [Column("site_area_engineer")]
        [StringLength(30)]
        [Unicode(false)]
        public string? SiteAreaEngineer { get; set; }
        [Column("site_engineer")]
        [StringLength(30)]
        [Unicode(false)]
        public string? SiteEngineer { get; set; }
        [Column("is_claim_same_contract")]
        public bool? IsClaimSameContract { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
