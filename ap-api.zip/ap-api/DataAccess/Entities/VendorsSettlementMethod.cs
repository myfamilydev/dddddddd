﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_settlement_methods")]
    public partial class VendorsSettlementMethod
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("settlement_type")]
        [StringLength(50)]
        public string? SettlementType { get; set; }
        [Column("is_default")]
        public bool? IsDefault { get; set; }
    }
}
