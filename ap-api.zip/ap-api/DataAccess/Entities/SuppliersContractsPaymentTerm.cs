﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_contracts_payment_terms")]
    public partial class SuppliersContractsPaymentTerm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("phase")]
        [StringLength(500)]
        public string? Phase { get; set; }
        [Column("percentage", TypeName = "decimal(10, 2)")]
        public decimal? Percentage { get; set; }
        [Column("condition")]
        [StringLength(1000)]
        public string? Condition { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
