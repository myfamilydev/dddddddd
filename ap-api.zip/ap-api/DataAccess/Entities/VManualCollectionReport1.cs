﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualCollectionReport1
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("total_house_land", TypeName = "decimal(18, 0)")]
        public decimal? TotalHouseLand { get; set; }
        [Column("total_house_land_sale", TypeName = "decimal(18, 0)")]
        public decimal? TotalHouseLandSale { get; set; }
        [Column("principle_collection", TypeName = "decimal(18, 0)")]
        public decimal? PrincipleCollection { get; set; }
        [Column("other_collection", TypeName = "decimal(18, 0)")]
        public decimal? OtherCollection { get; set; }
        [Column("total_collection", TypeName = "decimal(18, 0)")]
        public decimal? TotalCollection { get; set; }
        [Column("total_contract_value", TypeName = "decimal(18, 0)")]
        public decimal? TotalContractValue { get; set; }
        [Column("total_principle_collection", TypeName = "decimal(18, 0)")]
        public decimal? TotalPrincipleCollection { get; set; }
        [Column("total_principle_dis", TypeName = "decimal(18, 0)")]
        public decimal? TotalPrincipleDis { get; set; }
        [Column("os_collection", TypeName = "decimal(18, 0)")]
        public decimal? OsCollection { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
    }
}
