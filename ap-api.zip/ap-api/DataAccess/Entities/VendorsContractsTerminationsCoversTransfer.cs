﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_terminations_covers_transfers")]
    public partial class VendorsContractsTerminationsCoversTransfer
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("terminate_cover_id")]
        public int? TerminateCoverId { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("contract_po")]
        [StringLength(200)]
        public string? ContractPo { get; set; }
        [Column("new_contract_id")]
        public int? NewContractId { get; set; }
        [Column("allow_edit_contract")]
        public bool? AllowEditContract { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
