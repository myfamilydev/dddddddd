﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_contracts_items_list")]
    public partial class SuppliersContractsItemsList
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("contract_item_id")]
        public int? ContractItemId { get; set; }
        [Column("supplier_item_id")]
        public int? SupplierItemId { get; set; }
        [Column("unit", TypeName = "decimal(18, 2)")]
        public decimal? Unit { get; set; }
        [Column("uom")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("remarks")]
        [StringLength(1000)]
        public string? Remarks { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
