﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_physical_check_labs_covers")]
    public partial class VendorsPhysicalCheckLabsCover
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("physical_check_lab_id")]
        public long PhysicalCheckLabId { get; set; }
        [Column("settlement_lab_item_id")]
        public int SettlementLabItemId { get; set; }
        [Column("cover_id")]
        public int CoverId { get; set; }
        [Column("reduction_amount", TypeName = "decimal(18, 2)")]
        public decimal? ReductionAmount { get; set; }
        [Column("remark_id")]
        public long? RemarkId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
