﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns_settlement_sub_items_adj_amount")]
    public partial class VendorsRedesignsSettlementSubItemsAdjAmount
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendors_settlements_sub_id")]
        public int? VendorsSettlementsSubId { get; set; }
        [Column("adj_total_amount", TypeName = "decimal(15, 2)")]
        public decimal? AdjTotalAmount { get; set; }
        [Column("adj_total_request_amount", TypeName = "decimal(15, 2)")]
        public decimal? AdjTotalRequestAmount { get; set; }
        [Column("adj_total_preopen_amount", TypeName = "decimal(15, 2)")]
        public decimal? AdjTotalPreopenAmount { get; set; }
        [Column("adj_total_remain_amount", TypeName = "decimal(15, 2)")]
        public decimal? AdjTotalRemainAmount { get; set; }
    }
}
