﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_group_workflow_roles")]
    public partial class UsersGroupWorkflowRole
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("user_role_id")]
        public int? UserRoleId { get; set; }
        [Column("user_group_id")]
        public int? UserGroupId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
