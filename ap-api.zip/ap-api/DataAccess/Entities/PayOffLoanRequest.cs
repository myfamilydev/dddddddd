﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("pay_off_loan_requests")]
    public partial class PayOffLoanRequest
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_type_id")]
        public int? LoanTypeId { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("loan_phase_id")]
        public int? LoanPhaseId { get; set; }
        [Column("project_htd_id")]
        public int? ProjectHtdId { get; set; }
        [Column("final_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? FinalType { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
