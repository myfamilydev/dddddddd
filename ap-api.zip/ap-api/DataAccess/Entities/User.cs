﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users")]
    public partial class User
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("uuid")]
        public Guid? Uuid { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? FullName { get; set; }
        [Column("username")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Username { get; set; }
        [Column("password")]
        [StringLength(150)]
        [Unicode(false)]
        public string? Password { get; set; }
        [Column("password_change_at", TypeName = "datetime")]
        public DateTime? PasswordChangeAt { get; set; }
        [Column("email")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Email { get; set; }
        [Column("designation")]
        [StringLength(200)]
        [Unicode(false)]
        public string? Designation { get; set; }
        [Column("department_id")]
        public short? DepartmentId { get; set; }
        [Column("phone_number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PhoneNumber { get; set; }
        [Column("telegram_id")]
        public int? TelegramId { get; set; }
        [Column("is_hod")]
        public bool? IsHod { get; set; }
        [Column("is_line_manager")]
        public bool? IsLineManager { get; set; }
        [Column("emp_id")]
        [StringLength(50)]
        [Unicode(false)]
        public string? EmpId { get; set; }
        [Column("company_session_id")]
        public int? CompanySessionId { get; set; }
        [Column("user_group_id")]
        public int? UserGroupId { get; set; }
        [Column("pos_id")]
        public int? PosId { get; set; }
        [Column("position")]
        [StringLength(100)]
        public string? Position { get; set; }
        [Column("sso_sync_at", TypeName = "datetime")]
        public DateTime? SsoSyncAt { get; set; }
        [Column("sso_id")]
        public int? SsoId { get; set; }
        [Column("sso_token")]
        [StringLength(200)]
        public string? SsoToken { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("is_admin")]
        public bool? IsAdmin { get; set; }
        [Column("line_manager_id")]
        public int? LineManagerId { get; set; }
        [Column("attachment_ref_profile")]
        public long? AttachmentRefProfile { get; set; }
        [Column("chat_session_id")]
        [StringLength(100)]
        [Unicode(false)]
        public string? ChatSessionId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
