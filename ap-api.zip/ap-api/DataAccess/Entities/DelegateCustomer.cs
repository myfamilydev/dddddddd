﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("delegate_customers", Schema = "arch")]
    public partial class DelegateCustomer
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("name")]
        [StringLength(50)]
        public string? Name { get; set; }
        [Column("gender")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Gender { get; set; }
        [Column("dob", TypeName = "date")]
        public DateTime? Dob { get; set; }
        [Column("identity_card")]
        [StringLength(100)]
        [Unicode(false)]
        public string? IdentityCard { get; set; }
        [Column("nationality")]
        [StringLength(50)]
        public string? Nationality { get; set; }
        [Column("phone")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Phone { get; set; }
        [Column("address")]
        public string? Address { get; set; }
        [Column("relationship")]
        [StringLength(50)]
        public string? Relationship { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
