﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns_type")]
    public partial class VendorsRedesignsType
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("type_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? TypeName { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
