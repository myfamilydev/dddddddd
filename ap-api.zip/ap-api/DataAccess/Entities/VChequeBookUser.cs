﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VChequeBookUser
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("user_id")]
        [StringLength(10)]
        public string? UserId { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? FullName { get; set; }
        [Column("username")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Username { get; set; }
    }
}
