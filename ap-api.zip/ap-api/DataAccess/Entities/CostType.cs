﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("cost_types")]
    public partial class CostType
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Key]
        [Column("type")]
        [StringLength(50)]
        public string Type { get; set; } = null!;
        [Key]
        [Column("shortcut")]
        [StringLength(50)]
        [Unicode(false)]
        public string Shortcut { get; set; } = null!;
    }
}
