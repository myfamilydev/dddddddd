﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("material_stock_report")]
    public partial class MaterialStockReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("proId")]
        public int? ProId { get; set; }
        [Column("balance", TypeName = "decimal(15, 2)")]
        public decimal? Balance { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
    }
}
