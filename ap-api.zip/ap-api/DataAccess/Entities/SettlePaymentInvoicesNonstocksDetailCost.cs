﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("settle_payment_invoices_nonstocks_detail_costs")]
    public partial class SettlePaymentInvoicesNonstocksDetailCost
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("effective_id")]
        public int? EffectiveId { get; set; }
        [Column("settle_payment_id")]
        public int? SettlePaymentId { get; set; }
        [Column("non_stock_detail_id")]
        public int? NonStockDetailId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("amount", TypeName = "decimal(18, 0)")]
        public decimal? Amount { get; set; }
        [Column("percentage", TypeName = "decimal(18, 0)")]
        public decimal? Percentage { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("locked")]
        public bool? Locked { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
