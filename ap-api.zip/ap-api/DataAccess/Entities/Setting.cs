﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("settings")]
    public partial class Setting
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_payment_voucher", TypeName = "decimal(18, 0)")]
        public decimal? BankPaymentVoucher { get; set; }
        [Column("pretty_cash_voucher", TypeName = "decimal(18, 0)")]
        public decimal? PrettyCashVoucher { get; set; }
        [Column("telegram_chat_id")]
        [StringLength(50)]
        public string? TelegramChatId { get; set; }
        [Column("telegram_bot_token")]
        [StringLength(200)]
        public string? TelegramBotToken { get; set; }
    }
}
