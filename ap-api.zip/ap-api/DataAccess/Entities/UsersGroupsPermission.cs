﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_groups_permissions")]
    public partial class UsersGroupsPermission
    {
        [Column("id")]
        public int Id { get; set; }
        [Key]
        [Column("user_group_id")]
        public int UserGroupId { get; set; }
        [Key]
        [Column("user_permission_id")]
        public int UserPermissionId { get; set; }
        [Column("name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Name { get; set; }
    }
}
