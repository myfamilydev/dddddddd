﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("job_pricing_projects", Schema = "arch")]
    public partial class JobPricingProject
    {
        [Column("id")]
        public int Id { get; set; }
        [Key]
        [Column("job_pricing_id")]
        public int JobPricingId { get; set; }
        [Key]
        [Column("project_id")]
        public int ProjectId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
    }
}
