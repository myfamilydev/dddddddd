﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_permissions")]
    public partial class UsersPermission
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("main")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Main { get; set; }
        [Column("sub")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Sub { get; set; }
        [Column("name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Name { get; set; }
        [Column("workflow_id")]
        public int? WorkflowId { get; set; }
        [Column("ordering")]
        public int? Ordering { get; set; }
    }
}
