﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("contract_ar_loans")]
    public partial class ContractArLoan
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_type_id")]
        public int? LoanTypeId { get; set; }
        [Column("contract_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContractCode { get; set; }
        [Column("loan_bank_ref")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LoanBankRef { get; set; }
        [Column("loan_date", TypeName = "date")]
        public DateTime? LoanDate { get; set; }
        [Column("total_loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? TotalLoanAmount { get; set; }
        [Column("total_loan_amount_khr", TypeName = "decimal(15, 2)")]
        public decimal? TotalLoanAmountKhr { get; set; }
        [Column("total_loan_amount_usd", TypeName = "decimal(15, 2)")]
        public decimal? TotalLoanAmountUsd { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("loan_amount_khr", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmountKhr { get; set; }
        [Column("loan_amount_usd", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmountUsd { get; set; }
        [Column("settlement_by")]
        [StringLength(100)]
        public string? SettlementBy { get; set; }
        [Column("loan_phase_no")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LoanPhaseNo { get; set; }
        [Column("loan_purpose")]
        public string? LoanPurpose { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("effective_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? EffectiveInterestRate { get; set; }
        [Column("interest_nature", TypeName = "decimal(15, 2)")]
        public decimal? InterestNature { get; set; }
        [Column("change_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? ChangeInterestRate { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
