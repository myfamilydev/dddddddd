﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("redesigned_calculations_subterms", Schema = "arch")]
    public partial class RedesignedCalculationsSubterm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("redesigned_calculation_id")]
        public int? RedesignedCalculationId { get; set; }
        [Column("payment_installment")]
        [StringLength(20)]
        [Unicode(false)]
        public string? PaymentInstallment { get; set; }
        [Column("payment_type")]
        [StringLength(10)]
        [Unicode(false)]
        public string? PaymentType { get; set; }
        [Column("payment_value", TypeName = "decimal(15, 2)")]
        public decimal? PaymentValue { get; set; }
        [Column("pay_amount", TypeName = "decimal(15, 2)")]
        public decimal? PayAmount { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
    }
}
