﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("test_user2")]
    public partial class TestUser2
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("info")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Info { get; set; }
    }
}
