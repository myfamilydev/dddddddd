﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("sub_jobs", Schema = "arch")]
    public partial class SubJob
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("job_pricing_id")]
        public int? JobPricingId { get; set; }
        [Column("job_pricing_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? JobPricingCode { get; set; }
        [Column("job_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? JobCode { get; set; }
        [Column("sub_job_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SubJobCode { get; set; }
        [Column("sub_job_name")]
        [StringLength(250)]
        public string? SubJobName { get; set; }
        [Column("unit_id")]
        public int? UnitId { get; set; }
        [Column("qty")]
        public int? Qty { get; set; }
        [Column("cost", TypeName = "decimal(15, 2)")]
        public decimal? Cost { get; set; }
        [Column("customer_cost", TypeName = "decimal(15, 2)")]
        public decimal? CustomerCost { get; set; }
        [Column("margin_cost")]
        public int? MarginCost { get; set; }
        [Column("is_active")]
        public short? IsActive { get; set; }
    }
}
