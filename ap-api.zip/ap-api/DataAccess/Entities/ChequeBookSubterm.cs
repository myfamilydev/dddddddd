﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("cheque_book_subterms")]
    public partial class ChequeBookSubterm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("cheque_book_id")]
        public int? ChequeBookId { get; set; }
        [Column("sheet_per_book", TypeName = "decimal(15, 2)")]
        public decimal? SheetPerBook { get; set; }
        [Column("start_number", TypeName = "decimal(15, 2)")]
        public decimal? StartNumber { get; set; }
        [Column("end_number", TypeName = "decimal(15, 2)")]
        public decimal? EndNumber { get; set; }
        [Column("incharge_staff_id")]
        public int? InchargeStaffId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
