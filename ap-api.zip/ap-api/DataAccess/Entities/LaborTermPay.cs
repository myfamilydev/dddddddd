﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("labor_term_pays")]
    public partial class LaborTermPay
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("term_pay")]
        [StringLength(50)]
        public string? TermPay { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
