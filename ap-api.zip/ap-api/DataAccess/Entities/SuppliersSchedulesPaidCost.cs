﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("suppliers_schedules_paid_costs")]
    public partial class SuppliersSchedulesPaidCost
    {
        [Column("id")]
        public int? Id { get; set; }
        [Column("supplier_schedule_paid_id")]
        public int? SupplierSchedulePaidId { get; set; }
        [Column("cost", TypeName = "decimal(18, 2)")]
        public decimal? Cost { get; set; }
        [Column("amount", TypeName = "decimal(18, 2)")]
        public decimal? Amount { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("status")]
        [StringLength(10)]
        public string? Status { get; set; }
        [Column("created_at")]
        public int? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
