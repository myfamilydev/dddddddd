﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_notify_sessions")]
    public partial class UsersNotifySession
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("signalR_session")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SignalRSession { get; set; }
        [Column("last_active_at", TypeName = "datetime")]
        public DateTime? LastActiveAt { get; set; }
    }
}
