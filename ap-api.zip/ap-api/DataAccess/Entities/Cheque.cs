﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("cheques")]
    public partial class Cheque
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("cheque_name")]
        [StringLength(100)]
        public string? ChequeName { get; set; }
        [Column("description")]
        public string? Description { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("cheque_at", TypeName = "datetime")]
        public DateTime? ChequeAt { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("voucher_ref_ids")]
        public string? VoucherRefIds { get; set; }
        [Column("cheque_ref")]
        [StringLength(300)]
        public string? ChequeRef { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
    }
}
