﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VCompanyCostCenter
    {
        [Column("company_id")]
        public short CompanyId { get; set; }
        [Column("company_uuid")]
        public Guid? CompanyUuid { get; set; }
        [Column("company_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? CompanyName { get; set; }
        [Column("business_type")]
        [StringLength(200)]
        [Unicode(false)]
        public string? BusinessType { get; set; }
        [Column("account_threatment_type")]
        [StringLength(200)]
        [Unicode(false)]
        public string? AccountThreatmentType { get; set; }
        [Column("cost_center_id")]
        public short? CostCenterId { get; set; }
        [Column("cost_center")]
        [StringLength(10)]
        [Unicode(false)]
        public string? CostCenter { get; set; }
        [Column("share_type")]
        public int? ShareType { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        [Unicode(false)]
        public string? FullName { get; set; }
        [Column("cost_center_status")]
        public byte? CostCenterStatus { get; set; }
    }
}
