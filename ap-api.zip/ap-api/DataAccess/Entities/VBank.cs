﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VBank
    {
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        public string? BankName { get; set; }
        [Column("account_number")]
        [StringLength(200)]
        public string? AccountNumber { get; set; }
        [Column("bank_account")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BankAccount { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("ref_code")]
        public short? RefCode { get; set; }
        [Column("children")]
        public string? Children { get; set; }
        [Column("children_ids")]
        public string? ChildrenIds { get; set; }
    }
}
