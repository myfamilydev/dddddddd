﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("manual_interest_income_expense_detail_report", Schema = "report")]
    public partial class ManualInterestIncomeExpenseDetailReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("manual_iie_report_id")]
        public int? ManualIieReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("total_interest_inome", TypeName = "decimal(15, 2)")]
        public decimal? TotalInterestInome { get; set; }
        [Column("totaI_interest_hold_tax", TypeName = "decimal(15, 2)")]
        public decimal? TotaIInterestHoldTax { get; set; }
        [Column("remark_en")]
        public string? RemarkEn { get; set; }
        [Column("remark_kh")]
        public string? RemarkKh { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("insert_type")]
        [StringLength(255)]
        [Unicode(false)]
        public string? InsertType { get; set; }
    }
}
