﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("contract_ar_admin_fees")]
    public partial class ContractArAdminFee
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("fee_type")]
        [StringLength(100)]
        public string? FeeType { get; set; }
        [Column("multiple_with")]
        [StringLength(100)]
        [Unicode(false)]
        public string? MultipleWith { get; set; }
        [Column("is_one_timeoff")]
        public bool? IsOneTimeoff { get; set; }
        [Column("deadline", TypeName = "date")]
        public DateTime? Deadline { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
