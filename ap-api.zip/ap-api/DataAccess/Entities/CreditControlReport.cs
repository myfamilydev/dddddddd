﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("credit_control_report")]
    public partial class CreditControlReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("contracted_house_land", TypeName = "decimal(15, 2)")]
        public decimal? ContractedHouseLand { get; set; }
        [Column("total_overdue", TypeName = "decimal(15, 2)")]
        public decimal? TotalOverdue { get; set; }
        [Column("total_penalty", TypeName = "decimal(15, 2)")]
        public decimal? TotalPenalty { get; set; }
        [Column("overdue_payment", TypeName = "decimal(15, 2)")]
        public decimal? OverduePayment { get; set; }
        [Column("penalty_amount_paid", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmountPaid { get; set; }
        [Column("overdue_house", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouse { get; set; }
        [Column("overdue_house_equal", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseEqual { get; set; }
        [Column("overdue_house_getter", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseGetter { get; set; }
        [Column("overdue_house_less", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseLess { get; set; }
        [Column("penalty_amount", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
