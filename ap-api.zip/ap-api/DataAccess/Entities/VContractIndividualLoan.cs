﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VContractIndividualLoan
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ContractCode { get; set; }
        [Column("loan_type_id")]
        public int? LoanTypeId { get; set; }
        [Column("lender_name_en_1")]
        [StringLength(100)]
        public string? LenderNameEn1 { get; set; }
        [Column("lender_name_kh_1")]
        [StringLength(100)]
        public string? LenderNameKh1 { get; set; }
        [Column("nid_name_1")]
        [StringLength(100)]
        public string? NidName1 { get; set; }
        [Column("lender_name_en_2")]
        [StringLength(100)]
        public string? LenderNameEn2 { get; set; }
        [Column("lender_name_kh_2")]
        [StringLength(100)]
        public string? LenderNameKh2 { get; set; }
        [Column("nid_name_2")]
        [StringLength(100)]
        public string? NidName2 { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("admin_fee", TypeName = "decimal(15, 2)")]
        public decimal? AdminFee { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("effective_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? EffectiveInterestRate { get; set; }
        [Column("interest_nature", TypeName = "decimal(15, 2)")]
        public decimal? InterestNature { get; set; }
        [Column("change_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? ChangeInterestRate { get; set; }
        [Column("disbursment_date", TypeName = "date")]
        public DateTime? DisbursmentDate { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("duration")]
        public int? Duration { get; set; }
        [Column("maturity_date", TypeName = "date")]
        public DateTime? MaturityDate { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("type")]
        [StringLength(100)]
        public string? Type { get; set; }
        [Column("loan_description")]
        public string? LoanDescription { get; set; }
        [Column("loan_date", TypeName = "date")]
        public DateTime? LoanDate { get; set; }
        [Column("phase_no")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PhaseNo { get; set; }
        [Column("is_no_contract")]
        public bool IsNoContract { get; set; }
    }
}
