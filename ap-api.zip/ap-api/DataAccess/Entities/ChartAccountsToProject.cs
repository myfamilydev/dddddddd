﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("chart_accounts_to_projects")]
    public partial class ChartAccountsToProject
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("account_standard_id")]
        public int? AccountStandardId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("is_default")]
        public bool? IsDefault { get; set; }
        [Column("account_code")]
        [StringLength(50)]
        public string? AccountCode { get; set; }
        [Column("account_name")]
        [StringLength(100)]
        public string? AccountName { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
