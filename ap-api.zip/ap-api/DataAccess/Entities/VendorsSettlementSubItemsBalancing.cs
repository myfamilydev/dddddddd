﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_settlement_sub_items_balancing")]
    public partial class VendorsSettlementSubItemsBalancing
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("claim_amount", TypeName = "decimal(15, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("prev_claim_amount", TypeName = "decimal(15, 2)")]
        public decimal? PrevClaimAmount { get; set; }
        [Column("total_amount", TypeName = "decimal(15, 2)")]
        public decimal? TotalAmount { get; set; }
    }
}
