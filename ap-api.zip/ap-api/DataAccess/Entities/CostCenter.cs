﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("cost_centers")]
    public partial class CostCenter
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_ids")]
        [StringLength(200)]
        public string? ProjectIds { get; set; }
        [Column("cost_center")]
        [StringLength(200)]
        public string? CostCenter1 { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
