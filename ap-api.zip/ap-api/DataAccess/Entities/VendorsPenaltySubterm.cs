﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_penalty_subterms")]
    public partial class VendorsPenaltySubterm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("penalty_amount", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmount { get; set; }
        [Column("payment_method")]
        [StringLength(50)]
        [Unicode(false)]
        public string? PaymentMethod { get; set; }
        [Column("account_code_id")]
        public int? AccountCodeId { get; set; }
        [Column("penalty_reason")]
        [StringLength(100)]
        public string? PenaltyReason { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
