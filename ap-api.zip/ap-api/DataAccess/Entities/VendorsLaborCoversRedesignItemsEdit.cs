﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_labor_covers_redesign_items_edit", Schema = "log")]
    public partial class VendorsLaborCoversRedesignItemsEdit
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("cover_edit_id")]
        public int? CoverEditId { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("qty", TypeName = "decimal(18, 2)")]
        public decimal? Qty { get; set; }
        [Column("unit")]
        [StringLength(200)]
        public string? Unit { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("total_price", TypeName = "decimal(18, 2)")]
        public decimal? TotalPrice { get; set; }
        [Column("redesign_amount", TypeName = "decimal(18, 2)")]
        public decimal? RedesignAmount { get; set; }
        [Column("redesign_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RedesignType { get; set; }
        [Column("adj_amount", TypeName = "decimal(18, 2)")]
        public decimal? AdjAmount { get; set; }
        [Column("reason")]
        public string? Reason { get; set; }
        [Column("description")]
        [StringLength(100)]
        public string? Description { get; set; }
        [Column("cost_description")]
        public string? CostDescription { get; set; }
        [Column("cost_name")]
        [StringLength(200)]
        public string? CostName { get; set; }
        [Column("is_redesign")]
        public bool? IsRedesign { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
