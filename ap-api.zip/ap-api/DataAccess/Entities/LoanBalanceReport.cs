﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_balance_report")]
    public partial class LoanBalanceReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("bank_lender")]
        [StringLength(100)]
        public string? BankLender { get; set; }
        [Column("location")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Location { get; set; }
        [Column("loan_tittle_deed")]
        [StringLength(100)]
        public string? LoanTittleDeed { get; set; }
        [Column("project_type")]
        [StringLength(100)]
        [Unicode(false)]
        public string? ProjectType { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("repayment_amount", TypeName = "decimal(15, 2)")]
        public decimal? RepaymentAmount { get; set; }
        [Column("os_mount", TypeName = "decimal(15, 2)")]
        public decimal? OsMount { get; set; }
        [Column("starting_date", TypeName = "datetime")]
        public DateTime? StartingDate { get; set; }
        [Column("maturity_date", TypeName = "datetime")]
        public DateTime? MaturityDate { get; set; }
        [Column("duration", TypeName = "decimal(15, 2)")]
        public decimal? Duration { get; set; }
        [Column("duration_paid", TypeName = "decimal(15, 2)")]
        public decimal? DurationPaid { get; set; }
        [Column("remaining_year", TypeName = "decimal(15, 2)")]
        public decimal? RemainingYear { get; set; }
        [Column("lock_period")]
        [StringLength(100)]
        [Unicode(false)]
        public string? LockPeriod { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
    }
}
