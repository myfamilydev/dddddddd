﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("customer_requests", Schema = "arch")]
    public partial class CustomerRequest
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("request_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RequestCode { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("customer_id_1")]
        public int? CustomerId1 { get; set; }
        [Column("customer_id_2")]
        public int? CustomerId2 { get; set; }
        [Column("customer1")]
        [StringLength(100)]
        public string? Customer1 { get; set; }
        [Column("customer2")]
        [StringLength(100)]
        public string? Customer2 { get; set; }
        [Column("nationalId1")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NationalId1 { get; set; }
        [Column("nationalId2")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NationalId2 { get; set; }
        [Column("phone1")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Phone1 { get; set; }
        [Column("phone2")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Phone2 { get; set; }
        [Column("floor")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Floor { get; set; }
        [Column("redesign_fee_id")]
        public int? RedesignFeeId { get; set; }
        [Column("is_not_owner_vip")]
        public byte? IsNotOwnerVip { get; set; }
        [Column("delegate_customer_id")]
        public int? DelegateCustomerId { get; set; }
        [Column("not_owner_vip_remark")]
        public string? NotOwnerVipRemark { get; set; }
        [Column("behavior_type_id")]
        public int? BehaviorTypeId { get; set; }
        [Column("behavior_remark")]
        public string? BehaviorRemark { get; set; }
        [Column("is_vip")]
        public byte? IsVip { get; set; }
        [Column("vip_remark")]
        public string? VipRemark { get; set; }
        [Column("deadline_head_site", TypeName = "datetime")]
        public DateTime? DeadlineHeadSite { get; set; }
        [Column("deadline_head_me", TypeName = "datetime")]
        public DateTime? DeadlineHeadMe { get; set; }
        [Column("deadline_head_planning", TypeName = "datetime")]
        public DateTime? DeadlineHeadPlanning { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
