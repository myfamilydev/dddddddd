﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_payment_terms", Schema = "log")]
    public partial class VendorsContractsPaymentTerm1
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_item_id")]
        public int? ContractItemId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("allow_request_num_house")]
        public bool? AllowRequestNumHouse { get; set; }
        [Column("min_settle_house")]
        public int? MinSettleHouse { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
