﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_price_items")]
    public partial class VendorsContractsPriceItem
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("vendor_contract_id")]
        public int? VendorContractId { get; set; }
        [Column("contract_price_id")]
        public int? ContractPriceId { get; set; }
        [Column("sub_item_name")]
        public string? SubItemName { get; set; }
        [Column("unit")]
        [StringLength(50)]
        public string? Unit { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("remarks")]
        [StringLength(1000)]
        public string? Remarks { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
