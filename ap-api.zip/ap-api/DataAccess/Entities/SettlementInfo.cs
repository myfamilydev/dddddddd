﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("settlement_infos")]
    public partial class SettlementInfo
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_contract_id")]
        public int? LoanContractId { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankName { get; set; }
        [Column("bank_account_name")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankAccountName { get; set; }
        [Column("bank_account_number")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankAccountNumber { get; set; }
        [Column("currency")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Currency { get; set; }
        [Column("pay_cheque_to")]
        public string? PayChequeTo { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
