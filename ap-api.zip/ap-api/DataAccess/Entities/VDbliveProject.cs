﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDbliveProject
    {
        [Column("id")]
        public short Id { get; set; }
        [Column("company_id")]
        public short? CompanyId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("project_code")]
        [StringLength(13)]
        [Unicode(false)]
        public string? ProjectCode { get; set; }
        [Column("project_name")]
        [StringLength(150)]
        public string? ProjectName { get; set; }
        [Column("ownership")]
        [StringLength(255)]
        public string? Ownership { get; set; }
    }
}
