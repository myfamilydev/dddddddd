﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VJobPricing
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("name")]
        [StringLength(250)]
        public string? Name { get; set; }
        [Column("code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Code { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? StatusName { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("jop_pricing_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? JopPricingCode { get; set; }
        [Column("job_id")]
        public int? JobId { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
    }
}
