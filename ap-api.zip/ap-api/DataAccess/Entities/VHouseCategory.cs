﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VHouseCategory
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        [Unicode(false)]
        public string? HouseNumber { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
    }
}
