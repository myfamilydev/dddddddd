﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_settlement_sub_cost_center_redesigns")]
    public partial class VendorsSettlementSubCostCenterRedesign
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("cost_center_id")]
        public int? CostCenterId { get; set; }
        [Column("summary_sub_item_id")]
        public int? SummarySubItemId { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("locked")]
        public bool? Locked { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
