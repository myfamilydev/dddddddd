﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_physical_cheque_subs")]
    public partial class VendorsPhysicalChequeSub
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("payment_tracking_id")]
        public int? PaymentTrackingId { get; set; }
        [Column("physical_cheque_id")]
        public int? PhysicalChequeId { get; set; }
        [Column("code")]
        [StringLength(30)]
        [Unicode(false)]
        public string? Code { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("claim_time")]
        public short? ClaimTime { get; set; }
        [Column("claim_percentage", TypeName = "decimal(5, 2)")]
        public decimal? ClaimPercentage { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
