﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDblhdBudgetsLine
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("budget_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BudgetCode { get; set; }
        [Column("budget_name")]
        [StringLength(100)]
        public string? BudgetName { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
