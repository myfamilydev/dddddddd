﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("telegram_log")]
    public partial class TelegramLog
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("workflow_id")]
        public int? WorkflowId { get; set; }
        [Column("telegram_content")]
        [StringLength(3000)]
        [Unicode(false)]
        public string? TelegramContent { get; set; }
        [Column("telegram_group_id")]
        public int? TelegramGroupId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("comment")]
        [StringLength(300)]
        [Unicode(false)]
        public string? Comment { get; set; }
        [Column("user_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? UserName { get; set; }
        [Column("action_label")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ActionLabel { get; set; }
        [Column("workflow_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? WorkflowName { get; set; }
        [Column("house_type")]
        [StringLength(80)]
        [Unicode(false)]
        public string? HouseType { get; set; }
        [Column("house_no")]
        [StringLength(10)]
        [Unicode(false)]
        public string? HouseNo { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Project { get; set; }
        [Column("content1")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Content1 { get; set; }
        [Column("url")]
        [StringLength(200)]
        [Unicode(false)]
        public string? Url { get; set; }
    }
}
