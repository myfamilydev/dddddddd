﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_settlement_sub_items_edit", Schema = "log")]
    public partial class VendorsSettlementSubItemsEdit
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("settlement_sub_edit_id")]
        public int? SettlementSubEditId { get; set; }
        [Column("settlement_sub_id")]
        public int? SettlementSubId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("cost_name")]
        [StringLength(200)]
        public string? CostName { get; set; }
        [Column("price_item_id")]
        public long? PriceItemId { get; set; }
        [Column("quantity", TypeName = "decimal(18, 2)")]
        public decimal? Quantity { get; set; }
        [Column("uom")]
        [StringLength(200)]
        public string? Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("total_price", TypeName = "decimal(18, 2)")]
        public decimal? TotalPrice { get; set; }
        [Column("prev_claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? PrevClaimAmount { get; set; }
        [Column("prev_perc", TypeName = "decimal(18, 2)")]
        public decimal? PrevPerc { get; set; }
        [Column("claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("is_match")]
        public bool? IsMatch { get; set; }
        [Column("lock_tick")]
        public bool? LockTick { get; set; }
        [Column("perc", TypeName = "decimal(18, 2)")]
        public decimal? Perc { get; set; }
        [Column("claim_id")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ClaimId { get; set; }
        [Column("claim_time", TypeName = "decimal(15, 2)")]
        public decimal? ClaimTime { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
