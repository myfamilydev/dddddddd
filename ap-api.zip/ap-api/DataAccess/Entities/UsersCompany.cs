﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_companies")]
    public partial class UsersCompany
    {
        [Column("id")]
        public int Id { get; set; }
        [Key]
        [Column("user_id")]
        public int UserId { get; set; }
        [Key]
        [Column("company_id")]
        public int CompanyId { get; set; }
        [Key]
        [Column("status")]
        public bool Status { get; set; }
    }
}
