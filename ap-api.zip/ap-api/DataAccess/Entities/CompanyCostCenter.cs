﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("company_cost_centers")]
    public partial class CompanyCostCenter
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("company_id")]
        public short? CompanyId { get; set; }
        [Column("cost_center")]
        [StringLength(200)]
        [Unicode(false)]
        public string? CostCenter { get; set; }
        [Column("share_type")]
        [StringLength(10)]
        [Unicode(false)]
        public string? ShareType { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
