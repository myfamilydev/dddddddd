﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_banks_items")]
    public partial class LoanBanksItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("loan_amount", TypeName = "decimal(15, 2)")]
        public decimal? LoanAmount { get; set; }
        [Column("currency_id")]
        public int? CurrencyId { get; set; }
        [Column("interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? InterestRate { get; set; }
        [Column("effective_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? EffectiveInterestRate { get; set; }
        [Column("interest_nature", TypeName = "decimal(15, 2)")]
        public decimal? InterestNature { get; set; }
        [Column("change_interest_rate", TypeName = "decimal(15, 2)")]
        public decimal? ChangeInterestRate { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
    }
}
