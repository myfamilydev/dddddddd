﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors")]
    public partial class Vendor
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("history_id")]
        public int? HistoryId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("vendor_code")]
        [StringLength(20)]
        [Unicode(false)]
        public string? VendorCode { get; set; }
        [Column("vendor_category")]
        [StringLength(50)]
        [Unicode(false)]
        public string? VendorCategory { get; set; }
        [Column("NID_no")]
        [StringLength(30)]
        [Unicode(false)]
        public string? NidNo { get; set; }
        [Column("name_en")]
        [StringLength(200)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(300)]
        public string? NameKh { get; set; }
        [Column("dob", TypeName = "date")]
        public DateTime? Dob { get; set; }
        [Column("address")]
        [StringLength(2000)]
        public string? Address { get; set; }
        [Column("phone_contract")]
        [StringLength(200)]
        public string? PhoneContract { get; set; }
        [Column("phone_number_update")]
        [StringLength(200)]
        public string? PhoneNumberUpdate { get; set; }
        [Column("email")]
        [StringLength(200)]
        [Unicode(false)]
        public string? Email { get; set; }
        [Column("characteristic_notice")]
        public string? CharacteristicNotice { get; set; }
        [Column("is_editable")]
        public bool? IsEditable { get; set; }
        [Column("settlement_method_id_1")]
        public int? SettlementMethodId1 { get; set; }
        [Column("cheque_name_1")]
        [StringLength(50)]
        public string? ChequeName1 { get; set; }
        [Column("payment_collector_1")]
        [StringLength(200)]
        public string? PaymentCollector1 { get; set; }
        [Column("settlement_phone_1")]
        [StringLength(100)]
        public string? SettlementPhone1 { get; set; }
        [Column("settlement_method_id_2")]
        public int? SettlementMethodId2 { get; set; }
        [Column("bank_name_2")]
        [StringLength(50)]
        public string? BankName2 { get; set; }
        [Column("account_name_en_2")]
        [StringLength(50)]
        [Unicode(false)]
        public string? AccountNameEn2 { get; set; }
        [Column("account_name_kh_2")]
        [StringLength(50)]
        public string? AccountNameKh2 { get; set; }
        [Column("account_number_2")]
        [StringLength(50)]
        public string? AccountNumber2 { get; set; }
        [Column("card_no_2")]
        [StringLength(50)]
        [Unicode(false)]
        public string? CardNo2 { get; set; }
        [Column("currency_2")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Currency2 { get; set; }
        [Column("settlement_phone_2")]
        [StringLength(50)]
        public string? SettlementPhone2 { get; set; }
        [Column("payment_collector_photo")]
        public string? PaymentCollectorPhoto { get; set; }
        [Column("isAuthorize")]
        public bool? IsAuthorize { get; set; }
        [Column("attachment_ref_temp")]
        public long? AttachmentRefTemp { get; set; }
        [Column("approve_time")]
        public int? ApproveTime { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
