﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualCreditControlDetailReport
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("manual_credit_control_id")]
        public int? ManualCreditControlId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("contracted_house_land", TypeName = "decimal(15, 2)")]
        public decimal? ContractedHouseLand { get; set; }
        [Column("total_overdue", TypeName = "decimal(15, 2)")]
        public decimal? TotalOverdue { get; set; }
        [Column("total_penalty", TypeName = "decimal(15, 2)")]
        public decimal? TotalPenalty { get; set; }
        [Column("overdue_payment", TypeName = "decimal(15, 2)")]
        public decimal? OverduePayment { get; set; }
        [Column("penalty_amount_paid", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmountPaid { get; set; }
        [Column("overdue_house", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouse { get; set; }
        [Column("overdue_house_one", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseOne { get; set; }
        [Column("overdue_house_two", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseTwo { get; set; }
        [Column("overdue_house_three", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseThree { get; set; }
        [Column("overdue_house_four", TypeName = "decimal(15, 2)")]
        public decimal? OverdueHouseFour { get; set; }
        [Column("penalty_amount", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmount { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
