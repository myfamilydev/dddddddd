﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("contract_individual_schedules")]
    public partial class ContractIndividualSchedule
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_individual_schedule_info_id")]
        public int? ContractIndividualScheduleInfoId { get; set; }
        [Column("repay_date", TypeName = "date")]
        public DateTime? RepayDate { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("from_date", TypeName = "date")]
        public DateTime? FromDate { get; set; }
        [Column("days")]
        public int? Days { get; set; }
        [Column("rate", TypeName = "decimal(15, 2)")]
        public decimal? Rate { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
