﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDblhdCompany
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("business_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? BusinessType { get; set; }
        [Column("name_kh")]
        [StringLength(50)]
        public string? NameKh { get; set; }
        [Column("name_en")]
        [StringLength(50)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("address")]
        public string? Address { get; set; }
        [Column("contract_no")]
        [StringLength(20)]
        [Unicode(false)]
        public string? ContractNo { get; set; }
        [Column("vat_no")]
        [StringLength(20)]
        [Unicode(false)]
        public string? VatNo { get; set; }
        [Column("register_no")]
        [StringLength(20)]
        [Unicode(false)]
        public string? RegisterNo { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
