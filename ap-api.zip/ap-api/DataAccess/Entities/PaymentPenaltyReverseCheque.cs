﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("payment_penalty_reverse_cheque")]
    public partial class PaymentPenaltyReverseCheque
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("cheque_id")]
        public int? ChequeId { get; set; }
        [Column("parent_voucher_id")]
        public int? ParentVoucherId { get; set; }
        [Column("voucher_ref_id")]
        public int? VoucherRefId { get; set; }
        [Column("cheque_ref")]
        [StringLength(100)]
        public string? ChequeRef { get; set; }
        [Column("penalty_amount", TypeName = "decimal(15, 2)")]
        public decimal? PenaltyAmount { get; set; }
        [Column("delete_at", TypeName = "datetime")]
        public DateTime? DeleteAt { get; set; }
    }
}
