﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_redesigns_settlement_sub_items")]
    public partial class VendorsRedesignsSettlementSubItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendors_settlement_sub_id")]
        public int VendorsSettlementSubId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("price_item_id")]
        public long? PriceItemId { get; set; }
        [Column("quantity", TypeName = "decimal(18, 3)")]
        public decimal Quantity { get; set; }
        [Column("uom")]
        [StringLength(200)]
        public string? Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("is_match")]
        public bool? IsMatch { get; set; }
        [Column("perc", TypeName = "decimal(18, 2)")]
        public decimal? Perc { get; set; }
        [Column("prev_perc", TypeName = "decimal(18, 2)")]
        public decimal? PrevPerc { get; set; }
        [Column("redesign_type_id")]
        public int? RedesignTypeId { get; set; }
        [Column("redesign_category_id")]
        public int? RedesignCategoryId { get; set; }
        [Column("final_amount", TypeName = "decimal(15, 2)")]
        public decimal? FinalAmount { get; set; }
        [Column("reason")]
        public string? Reason { get; set; }
        [Column("cost_center_id")]
        public int? CostCenterId { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("balancing_cheque", TypeName = "decimal(5, 2)")]
        public decimal? BalancingCheque { get; set; }
        [Column("parent_id")]
        public int? ParentId { get; set; }
    }
}
