﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_schedules_payments")]
    public partial class SuppliersSchedulesPayment
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("schedule_payment_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SchedulePaymentCode { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("supplier_id")]
        public int? SupplierId { get; set; }
        [Column("item_type_id")]
        public int? ItemTypeId { get; set; }
        [Column("term_pay")]
        [StringLength(50)]
        [Unicode(false)]
        public string? TermPay { get; set; }
        [Column("share_cost_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ShareCostType { get; set; }
        [Column("description")]
        [StringLength(300)]
        public string? Description { get; set; }
        [Column("chart_account_id")]
        public int? ChartAccountId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
