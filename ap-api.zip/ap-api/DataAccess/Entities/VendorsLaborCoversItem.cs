﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_labor_covers_items")]
    public partial class VendorsLaborCoversItem
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("is_transfered")]
        public bool? IsTransfered { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("transfer_houses_ids")]
        public string? TransferHousesIds { get; set; }
        [Column("transfer_houses")]
        public string? TransferHouses { get; set; }
        [Column("transfer_items")]
        [StringLength(200)]
        public string? TransferItems { get; set; }
        [Column("qty", TypeName = "decimal(18, 3)")]
        public decimal Qty { get; set; }
        [Column("unit")]
        [StringLength(200)]
        public string? Unit { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 4)")]
        public decimal? UnitPrice { get; set; }
        [Column("total_price", TypeName = "decimal(18, 2)")]
        public decimal? TotalPrice { get; set; }
        [Column("description")]
        [StringLength(100)]
        public string? Description { get; set; }
        [Column("cost_description")]
        public string? CostDescription { get; set; }
        [Column("cost_name")]
        [StringLength(200)]
        public string? CostName { get; set; }
        [Column("is_redesign")]
        public bool? IsRedesign { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
