﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_labor_covers_houses_edit", Schema = "log")]
    public partial class VendorsLaborCoversHousesEdit
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("cover_code")]
        [StringLength(100)]
        [Unicode(false)]
        public string? CoverCode { get; set; }
        [Column("contract_code")]
        [StringLength(100)]
        [Unicode(false)]
        public string? ContractCode { get; set; }
        [Column("cover_id")]
        public int? CoverId { get; set; }
        [Column("claimed_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimedAmount { get; set; }
        [Column("cost_descriptions")]
        public string? CostDescriptions { get; set; }
        [Column("cost_type_id")]
        public int? CostTypeId { get; set; }
        [Column("cost_names")]
        public string? CostNames { get; set; }
        [Column("house_types")]
        public string? HouseTypes { get; set; }
        [Column("claim_houses")]
        public string? ClaimHouses { get; set; }
        [Column("item_name")]
        public string? ItemName { get; set; }
        [Column("total_amount", TypeName = "decimal(18, 2)")]
        public decimal? TotalAmount { get; set; }
        [Column("account_code")]
        [StringLength(10)]
        [Unicode(false)]
        public string? AccountCode { get; set; }
        [Column("is_touch")]
        public bool? IsTouch { get; set; }
        [Column("is_final")]
        public bool? IsFinal { get; set; }
        [Column("claim_time")]
        public int? ClaimTime { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("cover_house_id")]
        public int CoverHouseId { get; set; }
    }
}
