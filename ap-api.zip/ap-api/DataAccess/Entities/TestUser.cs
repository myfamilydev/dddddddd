﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("test_users")]
    public partial class TestUser
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("test_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? TestName { get; set; }
        [Column("info_id")]
        public int? InfoId { get; set; }
        [Column("address")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Address { get; set; }
    }
}
