﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("users_departments")]
    public partial class UsersDepartment
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("department")]
        [StringLength(100)]
        [Unicode(false)]
        public string? Department { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
    }
}
