﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_desburement_items")]
    public partial class LoanDesburementItem
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("loan_bank_id")]
        public int? LoanBankId { get; set; }
        [Column("disbursement_amount", TypeName = "decimal(15, 2)")]
        public decimal? DisbursementAmount { get; set; }
        [Column("disbursment_date", TypeName = "datetime")]
        public DateTime? DisbursmentDate { get; set; }
        [Column("payment_date", TypeName = "datetime")]
        public DateTime? PaymentDate { get; set; }
        [Column("maturity_date", TypeName = "datetime")]
        public DateTime? MaturityDate { get; set; }
        [Column("loan_purpose")]
        public string? LoanPurpose { get; set; }
        [Column("loan_phase _number")]
        [StringLength(50)]
        [Unicode(false)]
        public string? LoanPhaseNumber { get; set; }
        [Column("project_cost_center_id")]
        public int? ProjectCostCenterId { get; set; }
        [Column("settlement_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? SettlementType { get; set; }
        [Column("currency_id")]
        public int? CurrencyId { get; set; }
    }
}
