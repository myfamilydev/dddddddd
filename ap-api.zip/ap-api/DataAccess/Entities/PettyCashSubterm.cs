﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("petty_cash_subterms")]
    public partial class PettyCashSubterm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("account_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? AccountCode { get; set; }
        [Column("ac_description")]
        [StringLength(100)]
        public string? AcDescription { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("payment_description")]
        [StringLength(100)]
        public string? PaymentDescription { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
