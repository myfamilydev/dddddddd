﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VCentralCashBook
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("bank_id")]
        public int? BankId { get; set; }
        [Column("bank_name")]
        [StringLength(100)]
        public string? BankName { get; set; }
        [Column("supplier_name")]
        [StringLength(50)]
        public string? SupplierName { get; set; }
        [Column("cheque_ref")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ChequeRef { get; set; }
        [Column("ref_code")]
        [StringLength(50)]
        [Unicode(false)]
        public string? RefCode { get; set; }
        [Column("date", TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [Column("transaction_type_id")]
        public byte? TransactionTypeId { get; set; }
        [Column("type")]
        [StringLength(100)]
        public string? Type { get; set; }
        [Column("amount", TypeName = "decimal(15, 2)")]
        public decimal? Amount { get; set; }
        [Column("statement_date", TypeName = "datetime")]
        public DateTime? StatementDate { get; set; }
        [Column("send_date", TypeName = "datetime")]
        public DateTime? SendDate { get; set; }
        [Column("receive_date", TypeName = "datetime")]
        public DateTime? ReceiveDate { get; set; }
        [Column("release_date", TypeName = "datetime")]
        public DateTime? ReleaseDate { get; set; }
        [Column("statement_date_1", TypeName = "datetime")]
        public DateTime? StatementDate1 { get; set; }
        [Column("bank_withdraw", TypeName = "decimal(15, 2)")]
        public decimal? BankWithdraw { get; set; }
        [Column("bank_deposit", TypeName = "decimal(15, 2)")]
        public decimal? BankDeposit { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        [Unicode(false)]
        public string? StatusName { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("is_inter_project_transaction")]
        public bool? IsInterProjectTransaction { get; set; }
        [Column("inter_project_id")]
        public int? InterProjectId { get; set; }
        [Column("inter_project")]
        [StringLength(100)]
        public string? InterProject { get; set; }
        [Column("is_opening")]
        public bool IsOpening { get; set; }
        [Column("decription")]
        public string? Decription { get; set; }
        [Column("cash_flow_type_id")]
        public int? CashFlowTypeId { get; set; }
        [Column("name")]
        public string? Name { get; set; }
        [Column("bank_transaction_ref")]
        [StringLength(100)]
        [Unicode(false)]
        public string? BankTransactionRef { get; set; }
    }
}
