﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("daily_cleaner_info")]
    public partial class DailyCleanerInfo
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("code")]
        [StringLength(30)]
        [Unicode(false)]
        public string? Code { get; set; }
        [Column("name_en")]
        [StringLength(100)]
        [Unicode(false)]
        public string? NameEn { get; set; }
        [Column("name_kh")]
        [StringLength(100)]
        public string? NameKh { get; set; }
        [Column("nid")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Nid { get; set; }
        [Column("address")]
        [StringLength(1000)]
        public string? Address { get; set; }
        [Column("contact")]
        [StringLength(50)]
        [Unicode(false)]
        public string? Contact { get; set; }
        [Column("position_id")]
        public int? PositionId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
