﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_contracts_terminations_covers_transfers_houses")]
    public partial class VendorsContractsTerminationsCoversTransfersHouse
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("termination_cover_transfer_id")]
        public int? TerminationCoverTransferId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("master_id")]
        public int? MasterId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
