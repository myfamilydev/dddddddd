﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VDblhdHoliday
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("holiday_date", TypeName = "date")]
        public DateTime HolidayDate { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("holiday_name")]
        [StringLength(200)]
        public string? HolidayName { get; set; }
    }
}
