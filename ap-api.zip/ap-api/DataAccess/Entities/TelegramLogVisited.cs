﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("telegram_log_visited")]
    public partial class TelegramLogVisited
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("telegram_log_id")]
        public long? TelegramLogId { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
        [Column("visited_at", TypeName = "datetime")]
        public DateTime? VisitedAt { get; set; }
    }
}
