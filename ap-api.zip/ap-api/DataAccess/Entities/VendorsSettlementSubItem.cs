﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_settlement_sub_items")]
    public partial class VendorsSettlementSubItem
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("settlement_sub_id")]
        public int? SettlementSubId { get; set; }
        [Column("item_id")]
        public int? ItemId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("item_description")]
        public string? ItemDescription { get; set; }
        [Column("cost_name")]
        [StringLength(200)]
        public string? CostName { get; set; }
        [Column("price_item_id")]
        public long? PriceItemId { get; set; }
        [Column("quantity", TypeName = "decimal(18, 3)")]
        public decimal Quantity { get; set; }
        [Column("uom")]
        [StringLength(200)]
        public string? Uom { get; set; }
        [Column("unit_price", TypeName = "decimal(18, 2)")]
        public decimal? UnitPrice { get; set; }
        [Column("total_price", TypeName = "decimal(18, 2)")]
        public decimal? TotalPrice { get; set; }
        [Column("prev_claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? PrevClaimAmount { get; set; }
        [Column("prev_perc", TypeName = "decimal(18, 2)")]
        public decimal? PrevPerc { get; set; }
        [Column("claim_amount", TypeName = "decimal(18, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("cost_center")]
        public string? CostCenter { get; set; }
        [Column("pre_is_match")]
        public bool? PreIsMatch { get; set; }
        [Column("is_match")]
        public bool? IsMatch { get; set; }
        [Column("pre_lock_tick")]
        public bool? PreLockTick { get; set; }
        [Column("lock_tick")]
        public bool? LockTick { get; set; }
        [Column("perc", TypeName = "decimal(18, 2)")]
        public decimal? Perc { get; set; }
        [Column("claim_id")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ClaimId { get; set; }
        [Column("claim_time", TypeName = "decimal(15, 2)")]
        public decimal? ClaimTime { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("diff_claim_amount", TypeName = "decimal(15, 2)")]
        public decimal? DiffClaimAmount { get; set; }
        [Column("diff_prev_claim_amount", TypeName = "decimal(15, 2)")]
        public decimal? DiffPrevClaimAmount { get; set; }
        [Column("diff_total_amount", TypeName = "decimal(15, 2)")]
        public decimal? DiffTotalAmount { get; set; }
        [Column("balancing_cheque", TypeName = "decimal(5, 2)")]
        public decimal? BalancingCheque { get; set; }
    }
}
