﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("customer_behavior_types")]
    public partial class CustomerBehaviorType
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("type")]
        [StringLength(50)]
        public string? Type { get; set; }
        [Column("status")]
        public byte Status { get; set; }
        [Column("ordering")]
        public byte? Ordering { get; set; }
    }
}
