﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("loan_documents_requirement")]
    public partial class LoanDocumentsRequirement
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("description")]
        public string? Description { get; set; }
        [Column("remark")]
        public string? Remark { get; set; }
        [Column("deadline", TypeName = "datetime")]
        public DateTime? Deadline { get; set; }
    }
}
