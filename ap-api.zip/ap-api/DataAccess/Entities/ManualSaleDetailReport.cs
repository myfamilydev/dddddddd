﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("manual_sale_detail_report", Schema = "report")]
    public partial class ManualSaleDetailReport
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("manual_sale_report_id")]
        public int? ManualSaleReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("total_house_land", TypeName = "decimal(15, 2)")]
        public decimal? TotalHouseLand { get; set; }
        [Column("total_house_land_sal", TypeName = "decimal(15, 2)")]
        public decimal? TotalHouseLandSal { get; set; }
        [Column("total_house_land_sold", TypeName = "decimal(15, 2)")]
        public decimal? TotalHouseLandSold { get; set; }
        [Column("booking_no_contracted", TypeName = "decimal(15, 2)")]
        public decimal? BookingNoContracted { get; set; }
        [Column("contracted_house_land", TypeName = "decimal(15, 2)")]
        public decimal? ContractedHouseLand { get; set; }
        [Column("total_contracted_house_land", TypeName = "decimal(15, 2)")]
        public decimal? TotalContractedHouseLand { get; set; }
        [Column("total_sold", TypeName = "decimal(15, 4)")]
        public decimal? TotalSold { get; set; }
        [Column("remaining_house", TypeName = "decimal(15, 2)")]
        public decimal? RemainingHouse { get; set; }
        [Column("remaining_land", TypeName = "decimal(15, 2)")]
        public decimal? RemainingLand { get; set; }
        [Column("remark_en")]
        public string? RemarkEn { get; set; }
        [Column("remark_kh")]
        public string? RemarkKh { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("insert_type")]
        [StringLength(255)]
        [Unicode(false)]
        public string? InsertType { get; set; }
    }
}
