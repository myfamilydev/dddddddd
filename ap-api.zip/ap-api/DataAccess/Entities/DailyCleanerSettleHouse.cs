﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("daily_cleaner_settle_houses")]
    public partial class DailyCleanerSettleHouse
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("cleaner_settle_id")]
        public int? CleanerSettleId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("comment")]
        [StringLength(1000)]
        public string? Comment { get; set; }
    }
}
