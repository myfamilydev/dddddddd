﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_contracts_payterms")]
    public partial class SuppliersContractsPayterm
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("supplier_contract_id")]
        public int? SupplierContractId { get; set; }
        [Column("phase")]
        [StringLength(500)]
        public string? Phase { get; set; }
        [Column("percentage", TypeName = "decimal(10, 2)")]
        public decimal? Percentage { get; set; }
        [Column("condition")]
        [StringLength(1000)]
        public string? Condition { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
