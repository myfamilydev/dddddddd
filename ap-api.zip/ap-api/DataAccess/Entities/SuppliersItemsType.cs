﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("suppliers_items_types")]
    public partial class SuppliersItemsType
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("item_type")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ItemType { get; set; }
        [Column("item_desc")]
        [StringLength(500)]
        [Unicode(false)]
        public string? ItemDesc { get; set; }
        [Column("is_stock")]
        public bool? IsStock { get; set; }
        [Column("is_active")]
        public bool? IsActive { get; set; }
    }
}
