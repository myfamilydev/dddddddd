﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    public partial class VManualInterestIncomeExpenseDetailReport
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("manual_iie_report_id")]
        public int? ManualIieReportId { get; set; }
        [Column("pro_id")]
        public int? ProId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string? ProjectShort { get; set; }
        [Column("remark_en")]
        public string? RemarkEn { get; set; }
        [Column("remark_kh")]
        public string? RemarkKh { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("total_interest_inome", TypeName = "decimal(15, 2)")]
        public decimal? TotalInterestInome { get; set; }
        [Column("totaI_interest_hold_tax", TypeName = "decimal(15, 2)")]
        public decimal? TotaIInterestHoldTax { get; set; }
    }
}
