﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Table("vendors_physical_check_subs_details")]
    public partial class VendorsPhysicalCheckSubsDetail
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("vendor_physical_check_sub_id")]
        public int? VendorPhysicalCheckSubId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("claim_time")]
        [StringLength(50)]
        [Unicode(false)]
        public string? ClaimTime { get; set; }
        [Column("claim_percentage", TypeName = "decimal(15, 2)")]
        public decimal? ClaimPercentage { get; set; }
        [Column("claim_amount", TypeName = "decimal(15, 2)")]
        public decimal? ClaimAmount { get; set; }
        [Column("is_done")]
        public bool? IsDone { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
