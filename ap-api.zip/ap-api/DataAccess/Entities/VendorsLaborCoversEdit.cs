﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Entities
{
    [Keyless]
    [Table("vendors_labor_covers_edit", Schema = "log")]
    public partial class VendorsLaborCoversEdit
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("labor_cover_id")]
        public int? LaborCoverId { get; set; }
        [Column("company_id")]
        public int? CompanyId { get; set; }
        [Column("pro_id")]
        public short? ProId { get; set; }
        [Column("vendor_id")]
        public int? VendorId { get; set; }
        [Column("vendorItemId")]
        public int? VendorItemId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("claim_houses")]
        [StringLength(200)]
        [Unicode(false)]
        public string? ClaimHouses { get; set; }
        [Column("cover_code")]
        [StringLength(50)]
        public string? CoverCode { get; set; }
        [Column("site_area_engineer")]
        [StringLength(30)]
        [Unicode(false)]
        public string? SiteAreaEngineer { get; set; }
        [Column("site_engineer")]
        [StringLength(30)]
        [Unicode(false)]
        public string? SiteEngineer { get; set; }
        [Column("is_claim_same_contract")]
        public bool? IsClaimSameContract { get; set; }
        [Column("payment_term_perc", TypeName = "decimal(15, 2)")]
        public decimal? PaymentTermPerc { get; set; }
        [Column("reason")]
        public string? Reason { get; set; }
        [Column("remark")]
        [StringLength(1000)]
        public string? Remark { get; set; }
        [Column("rec_status")]
        public short? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
