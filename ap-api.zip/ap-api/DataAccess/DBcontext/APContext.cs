﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities;

namespace DataAccess.DBcontext
{
    public partial class APContext : DbContext
    {
        public APContext()
        {
        }

        public APContext(DbContextOptions<APContext> options)
            : base(options)
        {
        }
        
        public virtual DbSet<VDialySummaryContract> VDialySummaryContracts { get; set; } = null!;
        public virtual DbSet<Attachment> Attachments { get; set; } = null!;
        public virtual DbSet<AuditLog> AuditLogs { get; set; } = null!;
        public virtual DbSet<Bank> Banks { get; set; } = null!;
        public virtual DbSet<BankImportBatch> BankImportBatches { get; set; } = null!;
        public virtual DbSet<BankImportBatchDetail> BankImportBatchDetails { get; set; } = null!;
        public virtual DbSet<BankItem> BankItems { get; set; } = null!;
        public virtual DbSet<BankList> BankLists { get; set; } = null!;
        public virtual DbSet<BankLocation> BankLocations { get; set; } = null!;
        public virtual DbSet<BankReconcile> BankReconciles { get; set; } = null!;
        public virtual DbSet<BanksProjectsChild> BanksProjectsChildren { get; set; } = null!;
        public virtual DbSet<BehaviorType> BehaviorTypes { get; set; } = null!;
        public virtual DbSet<CashFlowType> CashFlowTypes { get; set; } = null!;
        public virtual DbSet<CentralCashBook> CentralCashBooks { get; set; } = null!;
        public virtual DbSet<ChartAccount> ChartAccounts { get; set; } = null!;
        public virtual DbSet<ChartAccountAutoTransaction> ChartAccountAutoTransactions { get; set; } = null!;
        public virtual DbSet<ChartAccountsAutoType> ChartAccountsAutoTypes { get; set; } = null!;
        public virtual DbSet<ChartAccountsToProject> ChartAccountsToProjects { get; set; } = null!;
        public virtual DbSet<Cheque> Cheques { get; set; } = null!;
        public virtual DbSet<ChequeBook> ChequeBooks { get; set; } = null!;
        public virtual DbSet<ChequeBookCancel> ChequeBookCancels { get; set; } = null!;
        public virtual DbSet<ChequeBookSubterm> ChequeBookSubterms { get; set; } = null!;
        public virtual DbSet<Company> Companies { get; set; } = null!;
        public virtual DbSet<CompanyCostCenter> CompanyCostCenters { get; set; } = null!;
        public virtual DbSet<ContractArAdminFee> ContractArAdminFees { get; set; } = null!;
        public virtual DbSet<ContractArDisbursment> ContractArDisbursments { get; set; } = null!;
        public virtual DbSet<ContractArDisbursmentsCostCenter> ContractArDisbursmentsCostCenters { get; set; } = null!;
        public virtual DbSet<ContractArDisbursmentsHtd> ContractArDisbursmentsHtds { get; set; } = null!;
        public virtual DbSet<ContractArDisbursmentsUseFund> ContractArDisbursmentsUseFunds { get; set; } = null!;
        public virtual DbSet<ContractArDocumentsRequirement> ContractArDocumentsRequirements { get; set; } = null!;
        public virtual DbSet<ContractArFee> ContractArFees { get; set; } = null!;
        public virtual DbSet<ContractArLimitPrincipal> ContractArLimitPrincipals { get; set; } = null!;
        public virtual DbSet<ContractArLoan> ContractArLoans { get; set; } = null!;
        public virtual DbSet<ContractArPaymentTerm> ContractArPaymentTerms { get; set; } = null!;
        public virtual DbSet<ContractArSettlement> ContractArSettlements { get; set; } = null!;
        public virtual DbSet<ContractIndividualCostCenter> ContractIndividualCostCenters { get; set; } = null!;
        public virtual DbSet<ContractIndividualHtdItem> ContractIndividualHtdItems { get; set; } = null!;
        public virtual DbSet<ContractIndividualLoan> ContractIndividualLoans { get; set; } = null!;
        public virtual DbSet<ContractIndividualSchedule> ContractIndividualSchedules { get; set; } = null!;
        public virtual DbSet<ContractIndividualScheduleDetail> ContractIndividualScheduleDetails { get; set; } = null!;
        public virtual DbSet<ContractIndividualSchedulesInfo> ContractIndividualSchedulesInfos { get; set; } = null!;
        public virtual DbSet<ContractIndividualSettlement> ContractIndividualSettlements { get; set; } = null!;
        public virtual DbSet<ContractIndividualUseFund> ContractIndividualUseFunds { get; set; } = null!;
        public virtual DbSet<ContractStandardLoan> ContractStandardLoans { get; set; } = null!;
        public virtual DbSet<CostCenter> CostCenters { get; set; } = null!;
        public virtual DbSet<CostType> CostTypes { get; set; } = null!;
        public virtual DbSet<Currency> Currencies { get; set; } = null!;
        public virtual DbSet<CustomerBehaviorType> CustomerBehaviorTypes { get; set; } = null!;
        public virtual DbSet<CustomerRequest> CustomerRequests { get; set; } = null!;
        public virtual DbSet<CustomerRequestCancel> CustomerRequestCancels { get; set; } = null!;
        public virtual DbSet<CustomerRequestDetail> CustomerRequestDetails { get; set; } = null!;
        public virtual DbSet<DailyCashManagement> DailyCashManagements { get; set; } = null!;
        public virtual DbSet<DailyCashManagementRemark> DailyCashManagementRemarks { get; set; } = null!;
        public virtual DbSet<DailyCleanerInfo> DailyCleanerInfos { get; set; } = null!;
        public virtual DbSet<DailyCleanerSettle> DailyCleanerSettles { get; set; } = null!;
        public virtual DbSet<DailyCleanerSettleHouse> DailyCleanerSettleHouses { get; set; } = null!;
        public virtual DbSet<DailyCleanerSettleInfo> DailyCleanerSettleInfos { get; set; } = null!;
        public virtual DbSet<DailyCleanerWage> DailyCleanerWages { get; set; } = null!;
        public virtual DbSet<DelegateCustomer> DelegateCustomers { get; set; } = null!;
        public virtual DbSet<DimAccountThreatmentType> DimAccountThreatmentTypes { get; set; } = null!;
        public virtual DbSet<DimAccountType> DimAccountTypes { get; set; } = null!;
        public virtual DbSet<DimRequestType> DimRequestTypes { get; set; } = null!;
        public virtual DbSet<DimShareCostEffective> DimShareCostEffectives { get; set; } = null!;
        public virtual DbSet<DimShareCostStandard> DimShareCostStandards { get; set; } = null!;
        public virtual DbSet<DisbursementInfo> DisbursementInfos { get; set; } = null!;
        public virtual DbSet<DocumentRequirement> DocumentRequirements { get; set; } = null!;
        public virtual DbSet<ErrorLog> ErrorLogs { get; set; } = null!;
        public virtual DbSet<ExchangeRate> ExchangeRates { get; set; } = null!;
        public virtual DbSet<ExchangeRatesType> ExchangeRatesTypes { get; set; } = null!;
        public virtual DbSet<ExecuteDeleteTransaction> ExecuteDeleteTransactions { get; set; } = null!;
        public virtual DbSet<GroupPayment> GroupPayments { get; set; } = null!;
        public virtual DbSet<GroupPaymentHouse> GroupPaymentHouses { get; set; } = null!;
        public virtual DbSet<HtdInfo> HtdInfos { get; set; } = null!;
        public virtual DbSet<ItemName> ItemNames { get; set; } = null!;
        public virtual DbSet<ItemType> ItemTypes { get; set; } = null!;
        public virtual DbSet<JobPricing> JobPricings { get; set; } = null!;
        public virtual DbSet<LaborTermPay> LaborTermPays { get; set; } = null!;
        public virtual DbSet<LoanBank> LoanBanks { get; set; } = null!;
        public virtual DbSet<LoanBanksItem> LoanBanksItems { get; set; } = null!;
        public virtual DbSet<LoanContract> LoanContracts { get; set; } = null!;
        public virtual DbSet<LoanContractBankItem> LoanContractBankItems { get; set; } = null!;
        public virtual DbSet<LoanContractDisbursementInfo> LoanContractDisbursementInfos { get; set; } = null!;
        public virtual DbSet<LoanContractDocumentRequirement> LoanContractDocumentRequirements { get; set; } = null!;
        public virtual DbSet<LoanContractFee> LoanContractFees { get; set; } = null!;
        public virtual DbSet<LoanContractHtdInfo> LoanContractHtdInfos { get; set; } = null!;
        public virtual DbSet<LoanContractIndividualHtdDisbursementInfo> LoanContractIndividualHtdDisbursementInfos { get; set; } = null!;
        public virtual DbSet<LoanContractSettlementInfo> LoanContractSettlementInfos { get; set; } = null!;
        public virtual DbSet<LoanCostCenter> LoanCostCenters { get; set; } = null!;
        public virtual DbSet<LoanDisburementItem> LoanDisburementItems { get; set; } = null!;
        public virtual DbSet<LoanDocumentsRequirement> LoanDocumentsRequirements { get; set; } = null!;
        public virtual DbSet<LoanHtdItem> LoanHtdItems { get; set; } = null!;
        public virtual DbSet<LoanReschedule> LoanReschedules { get; set; } = null!;
        public virtual DbSet<LoanSchedulesInfo> LoanSchedulesInfos { get; set; } = null!;
        public virtual DbSet<LoanStandardSchedule> LoanStandardSchedules { get; set; } = null!;
        public virtual DbSet<LoanStandardScheduleDetail> LoanStandardScheduleDetails { get; set; } = null!;
        public virtual DbSet<LoanType> LoanTypes { get; set; } = null!;
        public virtual DbSet<LoanUseFund> LoanUseFunds { get; set; } = null!;
        public virtual DbSet<ManualAttachmentFile> ManualAttachmentFiles { get; set; } = null!;
        public virtual DbSet<ManualCollectionDetailReport> ManualCollectionDetailReports { get; set; } = null!;
        public virtual DbSet<ManualCollectionReport> ManualCollectionReports { get; set; } = null!;
        public virtual DbSet<ManualCreditControlDetailReport> ManualCreditControlDetailReports { get; set; } = null!;
        public virtual DbSet<ManualCreditControlReport> ManualCreditControlReports { get; set; } = null!;
        public virtual DbSet<ManualInterestIncomeExpenseDetailReport> ManualInterestIncomeExpenseDetailReports { get; set; } = null!;
        public virtual DbSet<ManualInterestIncomeExpenseReport> ManualInterestIncomeExpenseReports { get; set; } = null!;
        public virtual DbSet<ManualLoanBalanceDetailReport> ManualLoanBalanceDetailReports { get; set; } = null!;
        public virtual DbSet<ManualLoanBalanceReport> ManualLoanBalanceReports { get; set; } = null!;
        public virtual DbSet<ManualMaterialStockDetailReport> ManualMaterialStockDetailReports { get; set; } = null!;
        public virtual DbSet<ManualMaterialStockReport> ManualMaterialStockReports { get; set; } = null!;
        public virtual DbSet<ManualMonthlySalaryExpenseADetailReport> ManualMonthlySalaryExpenseADetailReports { get; set; } = null!;
        public virtual DbSet<ManualMonthlySalaryExpenseAReport> ManualMonthlySalaryExpenseAReports { get; set; } = null!;
        public virtual DbSet<ManualMonthlySalaryExpenseAbDetailReport> ManualMonthlySalaryExpenseAbDetailReports { get; set; } = null!;
        public virtual DbSet<ManualMonthlySalaryExpenseAbReport> ManualMonthlySalaryExpenseAbReports { get; set; } = null!;
        public virtual DbSet<ManualMonthlySalaryExpenseBDetailReport> ManualMonthlySalaryExpenseBDetailReports { get; set; } = null!;
        public virtual DbSet<ManualMonthlySalaryExpenseBReport> ManualMonthlySalaryExpenseBReports { get; set; } = null!;
        public virtual DbSet<ManualSaleDetailReport> ManualSaleDetailReports { get; set; } = null!;
        public virtual DbSet<ManualSaleReport> ManualSaleReports { get; set; } = null!;
        public virtual DbSet<ManualSpaDetailReport> ManualSpaDetailReports { get; set; } = null!;
        public virtual DbSet<ManualSpaReport> ManualSpaReports { get; set; } = null!;
        public virtual DbSet<ManualSummaryDetailReport> ManualSummaryDetailReports { get; set; } = null!;
        public virtual DbSet<ManualSummaryReport> ManualSummaryReports { get; set; } = null!;
        public virtual DbSet<ModelHasCategory> ModelHasCategories { get; set; } = null!;
        public virtual DbSet<PayOffLoanRequest> PayOffLoanRequests { get; set; } = null!;
        public virtual DbSet<PaymentPenaltyReverse> PaymentPenaltyReverses { get; set; } = null!;
        public virtual DbSet<PaymentPenaltyReverseCheque> PaymentPenaltyReverseCheques { get; set; } = null!;
        public virtual DbSet<PaymentPettyCash> PaymentPettyCashes { get; set; } = null!;
        public virtual DbSet<PaymentPettyCashesDetail> PaymentPettyCashesDetails { get; set; } = null!;
        public virtual DbSet<PaymentSettlement> PaymentSettlements { get; set; } = null!;
        public virtual DbSet<PaymentSettlementsDetail> PaymentSettlementsDetails { get; set; } = null!;
        public virtual DbSet<PaymentVoucher> PaymentVouchers { get; set; } = null!;
        public virtual DbSet<PaymentVouchersDetail> PaymentVouchersDetails { get; set; } = null!;
        public virtual DbSet<PhoneTracking> PhoneTrackings { get; set; } = null!;
        public virtual DbSet<Purpose> Purposes { get; set; } = null!;
        public virtual DbSet<ReceivedDocument> ReceivedDocuments { get; set; } = null!;
        public virtual DbSet<ReceivedDocumentsCancel> ReceivedDocumentsCancels { get; set; } = null!;
        public virtual DbSet<RedesignFee> RedesignFees { get; set; } = null!;
        public virtual DbSet<RedesignFloor> RedesignFloors { get; set; } = null!;
        public virtual DbSet<RedesignJob> RedesignJobs { get; set; } = null!;
        public virtual DbSet<RedesignedCalculation> RedesignedCalculations { get; set; } = null!;
        public virtual DbSet<RedesignedCalculationsCancel> RedesignedCalculationsCancels { get; set; } = null!;
        public virtual DbSet<RedesignedCalculationsItem> RedesignedCalculationsItems { get; set; } = null!;
        public virtual DbSet<RedesignedCalculationsSubterm> RedesignedCalculationsSubterms { get; set; } = null!;
        public virtual DbSet<Setting> Settings { get; set; } = null!;
        public virtual DbSet<SettlePaymentInvoice> SettlePaymentInvoices { get; set; } = null!;
        public virtual DbSet<SettlePaymentInvoicesDetail> SettlePaymentInvoicesDetails { get; set; } = null!;
        public virtual DbSet<SettlePaymentInvoicesNonstock> SettlePaymentInvoicesNonstocks { get; set; } = null!;
        public virtual DbSet<SettlePaymentInvoicesNonstocksDetail> SettlePaymentInvoicesNonstocksDetails { get; set; } = null!;
        public virtual DbSet<SettlePaymentInvoicesNonstocksDetailCost> SettlePaymentInvoicesNonstocksDetailCosts { get; set; } = null!;
        public virtual DbSet<SettlePaymentMaterial> SettlePaymentMaterials { get; set; } = null!;
        public virtual DbSet<SettlementInfo> SettlementInfos { get; set; } = null!;
        public virtual DbSet<SpecialPaymentType> SpecialPaymentTypes { get; set; } = null!;
        public virtual DbSet<SubJob> SubJobs { get; set; } = null!;
        public virtual DbSet<SubJobHouseCategory> SubJobHouseCategories { get; set; } = null!;
        public virtual DbSet<SubJobProject> SubJobProjects { get; set; } = null!;
        public virtual DbSet<Supplier> Suppliers { get; set; } = null!;
        public virtual DbSet<SuppliersContract> SuppliersContracts { get; set; } = null!;
        public virtual DbSet<SuppliersContractsItem> SuppliersContractsItems { get; set; } = null!;
        public virtual DbSet<SuppliersContractsItemsSub> SuppliersContractsItemsSubs { get; set; } = null!;
        public virtual DbSet<SuppliersContractsPaymentTerm> SuppliersContractsPaymentTerms { get; set; } = null!;
        public virtual DbSet<SuppliersContractsTerminate> SuppliersContractsTerminates { get; set; } = null!;
        public virtual DbSet<SuppliersItem> SuppliersItems { get; set; } = null!;
        public virtual DbSet<SuppliersItemsType> SuppliersItemsTypes { get; set; } = null!;
        public virtual DbSet<SuppliersLocation> SuppliersLocations { get; set; } = null!;
        public virtual DbSet<SuppliersSchedulesPaid> SuppliersSchedulesPaids { get; set; } = null!;
        public virtual DbSet<SuppliersSchedulesPaidCost> SuppliersSchedulesPaidCosts { get; set; } = null!;
        public virtual DbSet<SuppliersSchedulesPayment> SuppliersSchedulesPayments { get; set; } = null!;
        public virtual DbSet<SuppliersSchedulesPaymentsDetail> SuppliersSchedulesPaymentsDetails { get; set; } = null!;
        public virtual DbSet<TelegramLog> TelegramLogs { get; set; } = null!;
        public virtual DbSet<TelegramLogVisited> TelegramLogVisiteds { get; set; } = null!;
        public virtual DbSet<Test> Tests { get; set; } = null!;
        public virtual DbSet<TransactionType> TransactionTypes { get; set; } = null!;
        public virtual DbSet<Unit> Units { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;
        public virtual DbSet<UsersCompany> UsersCompanies { get; set; } = null!;
        public virtual DbSet<UsersDepartment> UsersDepartments { get; set; } = null!;
        public virtual DbSet<UsersGroup> UsersGroups { get; set; } = null!;
        public virtual DbSet<UsersGroupWorkflowRole> UsersGroupWorkflowRoles { get; set; } = null!;
        public virtual DbSet<UsersGroupsPermission> UsersGroupsPermissions { get; set; } = null!;
        public virtual DbSet<UsersNotifySession> UsersNotifySessions { get; set; } = null!;
        public virtual DbSet<UsersPage> UsersPages { get; set; } = null!;
        public virtual DbSet<UsersPagesToRole> UsersPagesToRoles { get; set; } = null!;
        public virtual DbSet<UsersPermission> UsersPermissions { get; set; } = null!;
        public virtual DbSet<UsersPosition> UsersPositions { get; set; } = null!;
        public virtual DbSet<UsersRole> UsersRoles { get; set; } = null!;
        public virtual DbSet<UsersToProject> UsersToProjects { get; set; } = null!;
        public virtual DbSet<UsersToRole> UsersToRoles { get; set; } = null!;
        public virtual DbSet<VAffectedRow> VAffectedRows { get; set; } = null!;
        public virtual DbSet<VArchRedesignHouse> VArchRedesignHouses { get; set; } = null!;
        public virtual DbSet<VAttachmentList> VAttachmentLists { get; set; } = null!;
        public virtual DbSet<VBank> VBanks { get; set; } = null!;
        public virtual DbSet<VBankReconcile> VBankReconciles { get; set; } = null!;
        public virtual DbSet<VBankVoucherBasic> VBankVoucherBasics { get; set; } = null!;
        public virtual DbSet<VCentralCashBook> VCentralCashBooks { get; set; } = null!;
        public virtual DbSet<VChartAccount> VChartAccounts { get; set; } = null!;
        public virtual DbSet<VChartAccountToProject> VChartAccountToProjects { get; set; } = null!;
        public virtual DbSet<VChequeBook> VChequeBooks { get; set; } = null!;
        public virtual DbSet<VChequeBookCancel> VChequeBookCancels { get; set; } = null!;
        public virtual DbSet<VChequeBookSubterm> VChequeBookSubterms { get; set; } = null!;
        public virtual DbSet<VChequeBookUser> VChequeBookUsers { get; set; } = null!;
        public virtual DbSet<VChequeBooksDetail> VChequeBooksDetails { get; set; } = null!;
        public virtual DbSet<VCompanyCostCenter> VCompanyCostCenters { get; set; } = null!;
        public virtual DbSet<VContractAdminFee> VContractAdminFees { get; set; } = null!;
        public virtual DbSet<VContractArDisbursment> VContractArDisbursments { get; set; } = null!;
        public virtual DbSet<VContractArDisbursmentsCostCenter> VContractArDisbursmentsCostCenters { get; set; } = null!;
        public virtual DbSet<VContractArDisbursmentsHtd> VContractArDisbursmentsHtds { get; set; } = null!;
        public virtual DbSet<VContractArDisbursmentsUseFund> VContractArDisbursmentsUseFunds { get; set; } = null!;
        public virtual DbSet<VContractArDocumentRequirement> VContractArDocumentRequirements { get; set; } = null!;
        public virtual DbSet<VContractArLoan> VContractArLoans { get; set; } = null!;
        public virtual DbSet<VContractArSettlement> VContractArSettlements { get; set; } = null!;
        public virtual DbSet<VContractIndividualCostCenter> VContractIndividualCostCenters { get; set; } = null!;
        public virtual DbSet<VContractIndividualHtdItem> VContractIndividualHtdItems { get; set; } = null!;
        public virtual DbSet<VContractIndividualLoan> VContractIndividualLoans { get; set; } = null!;
        public virtual DbSet<VContractIndividualScheduleDetail> VContractIndividualScheduleDetails { get; set; } = null!;
        public virtual DbSet<VContractIndividualSettlement> VContractIndividualSettlements { get; set; } = null!;
        public virtual DbSet<VContractIndividualUseFund> VContractIndividualUseFunds { get; set; } = null!;
        public virtual DbSet<VContractLoanStandard> VContractLoanStandards { get; set; } = null!;
        public virtual DbSet<VContractsCustomer> VContractsCustomers { get; set; } = null!;
        public virtual DbSet<VCoverHouseBasic> VCoverHouseBasics { get; set; } = null!;
        public virtual DbSet<VCustomerRequest> VCustomerRequests { get; set; } = null!;
        public virtual DbSet<VCustomerRequestBasic> VCustomerRequestBasics { get; set; } = null!;
        public virtual DbSet<VCustomerRequestCancel> VCustomerRequestCancels { get; set; } = null!;
        public virtual DbSet<VCustomerRequestDetail> VCustomerRequestDetails { get; set; } = null!;
        public virtual DbSet<VDailyCleanerInfo> VDailyCleanerInfos { get; set; } = null!;
        public virtual DbSet<VDailyCleanerInfoBasic> VDailyCleanerInfoBasics { get; set; } = null!;
        public virtual DbSet<VDailyCleanerSettlement> VDailyCleanerSettlements { get; set; } = null!;
        public virtual DbSet<VDailyCleanerSettlementHouse> VDailyCleanerSettlementHouses { get; set; } = null!;
        public virtual DbSet<VDailyCleanerSettlementInfo> VDailyCleanerSettlementInfos { get; set; } = null!;
        public virtual DbSet<VDailyCleanerWage> VDailyCleanerWages { get; set; } = null!;
        public virtual DbSet<VDblhdBudgetsLine> VDblhdBudgetsLines { get; set; } = null!;
        public virtual DbSet<VDblhdCompany> VDblhdCompanies { get; set; } = null!;
        public virtual DbSet<VDblhdHoliday> VDblhdHolidays { get; set; } = null!;
        public virtual DbSet<VDbliveContract> VDbliveContracts { get; set; } = null!;
        public virtual DbSet<VDbliveCustomer> VDbliveCustomers { get; set; } = null!;
        public virtual DbSet<VDbliveHouseCategory> VDbliveHouseCategories { get; set; } = null!;
        public virtual DbSet<VDbliveHouseType> VDbliveHouseTypes { get; set; } = null!;
        public virtual DbSet<VDbliveHousesNotHandOver> VDbliveHousesNotHandOvers { get; set; } = null!;
        public virtual DbSet<VDbliveProject> VDbliveProjects { get; set; } = null!;
        public virtual DbSet<VDbliveStreet> VDbliveStreets { get; set; } = null!;
        public virtual DbSet<VGetUserRole> VGetUserRoles { get; set; } = null!;
        public virtual DbSet<VGetWorkflow> VGetWorkflows { get; set; } = null!;
        public virtual DbSet<VGroupHousesPayment> VGroupHousesPayments { get; set; } = null!;
        public virtual DbSet<VGroupPayment> VGroupPayments { get; set; } = null!;
        public virtual DbSet<VGroupPaymentHouseActive> VGroupPaymentHouseActives { get; set; } = null!;
        public virtual DbSet<VGroupPaymentHouseAvailable> VGroupPaymentHouseAvailables { get; set; } = null!;
        public virtual DbSet<VHouse> VHouses { get; set; } = null!;
        public virtual DbSet<VHouseAvailable> VHouseAvailables { get; set; } = null!;
        public virtual DbSet<VHouseCategory> VHouseCategories { get; set; } = null!;
        public virtual DbSet<VHousesList> VHousesLists { get; set; } = null!;
        public virtual DbSet<VHousesListsAll> VHousesListsAlls { get; set; } = null!;
        public virtual DbSet<VHousesType> VHousesTypes { get; set; } = null!;
        public virtual DbSet<VJobPricing> VJobPricings { get; set; } = null!;
        public virtual DbSet<VLaborTermPay> VLaborTermPays { get; set; } = null!;
        public virtual DbSet<VLoanBanksItem> VLoanBanksItems { get; set; } = null!;
        public virtual DbSet<VLoanCostCenter> VLoanCostCenters { get; set; } = null!;
        public virtual DbSet<VLoanDisburementItem> VLoanDisburementItems { get; set; } = null!;
        public virtual DbSet<VLoanSchedulesInfo> VLoanSchedulesInfos { get; set; } = null!;
        public virtual DbSet<VLoanUseFund> VLoanUseFunds { get; set; } = null!;
        public virtual DbSet<VManualCollectionDetailReport> VManualCollectionDetailReports { get; set; } = null!;
        public virtual DbSet<VManualCreditControlDetailReport> VManualCreditControlDetailReports { get; set; } = null!;
        public virtual DbSet<VManualInterestIncomeExpenseDetailReport> VManualInterestIncomeExpenseDetailReports { get; set; } = null!;
        public virtual DbSet<VManualLoanBalanceDetailReport> VManualLoanBalanceDetailReports { get; set; } = null!;
        public virtual DbSet<VManualLoanBalanceReport> VManualLoanBalanceReports { get; set; } = null!;
        public virtual DbSet<VManualMaterialStockDetailReport> VManualMaterialStockDetailReports { get; set; } = null!;
        public virtual DbSet<VManualSaleDetailReport> VManualSaleDetailReports { get; set; } = null!;
        public virtual DbSet<VManualSpaDetailReport> VManualSpaDetailReports { get; set; } = null!;
        public virtual DbSet<VManualSummaryDetailReport> VManualSummaryDetailReports { get; set; } = null!;
        public virtual DbSet<VPaymentPettyCash> VPaymentPettyCashes { get; set; } = null!;
        public virtual DbSet<VPaymentPettyCashDetail> VPaymentPettyCashDetails { get; set; } = null!;
        public virtual DbSet<VPaymentSettlementsBasic> VPaymentSettlementsBasics { get; set; } = null!;
        public virtual DbSet<VPaymentSettlementsPrettyCashBasic> VPaymentSettlementsPrettyCashBasics { get; set; } = null!;
        public virtual DbSet<VPaymentVouchersDetail> VPaymentVouchersDetails { get; set; } = null!;
        public virtual DbSet<VPaymentVourcher> VPaymentVourchers { get; set; } = null!;
        public virtual DbSet<VPhoneTracking> VPhoneTrackings { get; set; } = null!;
        public virtual DbSet<VPhysicalCheckLab> VPhysicalCheckLabs { get; set; } = null!;
        public virtual DbSet<VPhysicalCheckLabCover> VPhysicalCheckLabCovers { get; set; } = null!;
        public virtual DbSet<VPhysicalCheckSub> VPhysicalCheckSubs { get; set; } = null!;
        public virtual DbSet<VProject> VProjects { get; set; } = null!;
        public virtual DbSet<VProjectHouseCategory> VProjectHouseCategories { get; set; } = null!;
        public virtual DbSet<VReceivedDocument> VReceivedDocuments { get; set; } = null!;
        public virtual DbSet<VReceivedDocumentBasic> VReceivedDocumentBasics { get; set; } = null!;
        public virtual DbSet<VReceivedDocumentsCancel> VReceivedDocumentsCancels { get; set; } = null!;
        public virtual DbSet<VRedesignFee> VRedesignFees { get; set; } = null!;
        public virtual DbSet<VRedesignFloor> VRedesignFloors { get; set; } = null!;
        public virtual DbSet<VRedesignedCalculation> VRedesignedCalculations { get; set; } = null!;
        public virtual DbSet<VRedesignedCalculationCancel> VRedesignedCalculationCancels { get; set; } = null!;
        public virtual DbSet<VRedesignedCalculationItem> VRedesignedCalculationItems { get; set; } = null!;
        public virtual DbSet<VRedesignedCalculationSubterm> VRedesignedCalculationSubterms { get; set; } = null!;
        public virtual DbSet<VSchedulesDetail> VSchedulesDetails { get; set; } = null!;
        public virtual DbSet<VSchedulesStandardLoan> VSchedulesStandardLoans { get; set; } = null!;
        public virtual DbSet<VSettlePaymentInvoicesNonstocksDetailCost> VSettlePaymentInvoicesNonstocksDetailCosts { get; set; } = null!;
        public virtual DbSet<VSettlePaymentMaterial> VSettlePaymentMaterials { get; set; } = null!;
        public virtual DbSet<VShareCostStandard> VShareCostStandards { get; set; } = null!;
        public virtual DbSet<VSubJobEffectiveDate> VSubJobEffectiveDates { get; set; } = null!;
        public virtual DbSet<VSubJobEffectiveProject> VSubJobEffectiveProjects { get; set; } = null!;
        public virtual DbSet<VSubJobHouseCategory> VSubJobHouseCategories { get; set; } = null!;
        public virtual DbSet<VSubJobProject> VSubJobProjects { get; set; } = null!;
        public virtual DbSet<VSubJobUnlink> VSubJobUnlinks { get; set; } = null!;
        public virtual DbSet<VSubJop> VSubJops { get; set; } = null!;
        public virtual DbSet<VSuppliersBasic> VSuppliersBasics { get; set; } = null!;
        public virtual DbSet<VSuppliersContract> VSuppliersContracts { get; set; } = null!;
        public virtual DbSet<VSuppliersContractsBasic> VSuppliersContractsBasics { get; set; } = null!;
        public virtual DbSet<VSuppliersItem> VSuppliersItems { get; set; } = null!;
        public virtual DbSet<VSuppliersItemsBasic> VSuppliersItemsBasics { get; set; } = null!;
        public virtual DbSet<VSuppliersSchedulesPayment> VSuppliersSchedulesPayments { get; set; } = null!;
        public virtual DbSet<VSuppliersTerminate> VSuppliersTerminates { get; set; } = null!;
        public virtual DbSet<VTestUser> VTestUsers { get; set; } = null!;
        public virtual DbSet<VUser> VUsers { get; set; } = null!;
        public virtual DbSet<VUserLoggedIn> VUserLoggedIns { get; set; } = null!;
        public virtual DbSet<VUserRoleBasic> VUserRoleBasics { get; set; } = null!;
        public virtual DbSet<VUsersCompany> VUsersCompanies { get; set; } = null!;
        public virtual DbSet<VUsersGroupsPermisssion> VUsersGroupsPermisssions { get; set; } = null!;
        public virtual DbSet<VUsersPage> VUsersPages { get; set; } = null!;
        public virtual DbSet<VUsersPermission> VUsersPermissions { get; set; } = null!;
        public virtual DbSet<VUsersRolesBasic> VUsersRolesBasics { get; set; } = null!;
        public virtual DbSet<VVendor> VVendors { get; set; } = null!;
        public virtual DbSet<VVendorContract> VVendorContracts { get; set; } = null!;
        public virtual DbSet<VVendorContractBasic> VVendorContractBasics { get; set; } = null!;
        public virtual DbSet<VVendorSettlementSubItem> VVendorSettlementSubItems { get; set; } = null!;
        public virtual DbSet<VVendorsContractItem> VVendorsContractItems { get; set; } = null!;
        public virtual DbSet<VVendorsContractsMaster> VVendorsContractsMasters { get; set; } = null!;
        public virtual DbSet<VVendorsContractsPaymentTerm> VVendorsContractsPaymentTerms { get; set; } = null!;
        public virtual DbSet<VVendorsContractsPriceItem> VVendorsContractsPriceItems { get; set; } = null!;
        public virtual DbSet<VVendorsContractsPricing> VVendorsContractsPricings { get; set; } = null!;
        public virtual DbSet<VVendorsContractsTermination> VVendorsContractsTerminations { get; set; } = null!;
        public virtual DbSet<VVendorsContractsTerminationsHouse> VVendorsContractsTerminationsHouses { get; set; } = null!;
        public virtual DbSet<VVendorsInfo> VVendorsInfos { get; set; } = null!;
        public virtual DbSet<VVendorsItem> VVendorsItems { get; set; } = null!;
        public virtual DbSet<VVendorsLaborCover> VVendorsLaborCovers { get; set; } = null!;
        public virtual DbSet<VVendorsLaborCoversBasic> VVendorsLaborCoversBasics { get; set; } = null!;
        public virtual DbSet<VVendorsLaborCoversBasicFinal> VVendorsLaborCoversBasicFinals { get; set; } = null!;
        public virtual DbSet<VVendorsLaborCoversHousesBasic> VVendorsLaborCoversHousesBasics { get; set; } = null!;
        public virtual DbSet<VVendorsPenaltiesCover> VVendorsPenaltiesCovers { get; set; } = null!;
        public virtual DbSet<VVendorsPenalty> VVendorsPenalties { get; set; } = null!;
        public virtual DbSet<VVendorsPhysicalCheckSubsDetail> VVendorsPhysicalCheckSubsDetails { get; set; } = null!;
        public virtual DbSet<VVendorsRedesignsLaborCoversItem> VVendorsRedesignsLaborCoversItems { get; set; } = null!;
        public virtual DbSet<VVendorsRedesignsSettlementSubItem> VVendorsRedesignsSettlementSubItems { get; set; } = null!;
        public virtual DbSet<VVendorsSettlementLab> VVendorsSettlementLabs { get; set; } = null!;
        public virtual DbSet<VVendorsSettlementLabBasic> VVendorsSettlementLabBasics { get; set; } = null!;
        public virtual DbSet<VVendorsSettlementShareCostItem> VVendorsSettlementShareCostItems { get; set; } = null!;
        public virtual DbSet<VVendorsSettlementSubBasic> VVendorsSettlementSubBasics { get; set; } = null!;
        public virtual DbSet<VVendorsSettlementsSub> VVendorsSettlementsSubs { get; set; } = null!;
        public virtual DbSet<VVendorsSettlementsSubSpecial> VVendorsSettlementsSubSpecials { get; set; } = null!;
        public virtual DbSet<VWorkflowAction> VWorkflowActions { get; set; } = null!;
        public virtual DbSet<VWorkflowNotification> VWorkflowNotifications { get; set; } = null!;
        public virtual DbSet<VWorkflowStatus> VWorkflowStatuses { get; set; } = null!;
        public virtual DbSet<Vendor> Vendors { get; set; } = null!;
        public virtual DbSet<VendorsCategory> VendorsCategories { get; set; } = null!;
        public virtual DbSet<VendorsContract> VendorsContracts { get; set; } = null!;
        public virtual DbSet<VendorsContract1> VendorsContracts1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsItem> VendorsContractsItems { get; set; } = null!;
        public virtual DbSet<VendorsContractsItem1> VendorsContractsItems1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsMaster> VendorsContractsMasters { get; set; } = null!;
        public virtual DbSet<VendorsContractsMaster1> VendorsContractsMasters1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsPaymentTerm> VendorsContractsPaymentTerms { get; set; } = null!;
        public virtual DbSet<VendorsContractsPaymentTerm1> VendorsContractsPaymentTerms1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsPaymentTermsItem> VendorsContractsPaymentTermsItems { get; set; } = null!;
        public virtual DbSet<VendorsContractsPaymentTermsItem1> VendorsContractsPaymentTermsItems1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsPrice> VendorsContractsPrices { get; set; } = null!;
        public virtual DbSet<VendorsContractsPrice1> VendorsContractsPrices1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsPriceItem> VendorsContractsPriceItems { get; set; } = null!;
        public virtual DbSet<VendorsContractsPriceItem1> VendorsContractsPriceItems1 { get; set; } = null!;
        public virtual DbSet<VendorsContractsSettlementInfo> VendorsContractsSettlementInfos { get; set; } = null!;
        public virtual DbSet<VendorsContractsTermination> VendorsContractsTerminations { get; set; } = null!;
        public virtual DbSet<VendorsContractsTerminationsCover> VendorsContractsTerminationsCovers { get; set; } = null!;
        public virtual DbSet<VendorsContractsTerminationsCoversTransfer> VendorsContractsTerminationsCoversTransfers { get; set; } = null!;
        public virtual DbSet<VendorsContractsTerminationsCoversTransfersHouse> VendorsContractsTerminationsCoversTransfersHouses { get; set; } = null!;
        public virtual DbSet<VendorsContractsTerminationsType> VendorsContractsTerminationsTypes { get; set; } = null!;
        public virtual DbSet<VendorsContractsTrackingCostName> VendorsContractsTrackingCostNames { get; set; } = null!;
        public virtual DbSet<VendorsContractsTrackingHouse> VendorsContractsTrackingHouses { get; set; } = null!;
        public virtual DbSet<VendorsContractsTrackingRedesignHouse> VendorsContractsTrackingRedesignHouses { get; set; } = null!;
        public virtual DbSet<VendorsHistory> VendorsHistories { get; set; } = null!;
        public virtual DbSet<VendorsItem> VendorsItems { get; set; } = null!;
        public virtual DbSet<VendorsLaborCover> VendorsLaborCovers { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversEdit> VendorsLaborCoversEdits { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversHouse> VendorsLaborCoversHouses { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversHousesEdit> VendorsLaborCoversHousesEdits { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversItem> VendorsLaborCoversItems { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversItemsEdit> VendorsLaborCoversItemsEdits { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversRedesignItem> VendorsLaborCoversRedesignItems { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversRedesignItemsEdit> VendorsLaborCoversRedesignItemsEdits { get; set; } = null!;
        public virtual DbSet<VendorsLaborCoversSchedule> VendorsLaborCoversSchedules { get; set; } = null!;
        public virtual DbSet<VendorsPenaltiesCostCenter> VendorsPenaltiesCostCenters { get; set; } = null!;
        public virtual DbSet<VendorsPenaltiesCover> VendorsPenaltiesCovers { get; set; } = null!;
        public virtual DbSet<VendorsPenaltiesCoversCostCenter> VendorsPenaltiesCoversCostCenters { get; set; } = null!;
        public virtual DbSet<VendorsPenalty> VendorsPenalties { get; set; } = null!;
        public virtual DbSet<VendorsPhysicalCheckLab> VendorsPhysicalCheckLabs { get; set; } = null!;
        public virtual DbSet<VendorsPhysicalCheckLabsCover> VendorsPhysicalCheckLabsCovers { get; set; } = null!;
        public virtual DbSet<VendorsPhysicalCheckLabsRemark> VendorsPhysicalCheckLabsRemarks { get; set; } = null!;
        public virtual DbSet<VendorsPhysicalCheckSub> VendorsPhysicalCheckSubs { get; set; } = null!;
        public virtual DbSet<VendorsPhysicalCheckSubsDetail> VendorsPhysicalCheckSubsDetails { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsCategory> VendorsRedesignsCategories { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsLaborCover> VendorsRedesignsLaborCovers { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsLaborCoversItem> VendorsRedesignsLaborCoversItems { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsSettlementSub> VendorsRedesignsSettlementSubs { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsSettlementSubItem> VendorsRedesignsSettlementSubItems { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsSettlementSubItemsAdjAmount> VendorsRedesignsSettlementSubItemsAdjAmounts { get; set; } = null!;
        public virtual DbSet<VendorsRedesignsType> VendorsRedesignsTypes { get; set; } = null!;
        public virtual DbSet<VendorsSettlementLab> VendorsSettlementLabs { get; set; } = null!;
        public virtual DbSet<VendorsSettlementLabCostCenter> VendorsSettlementLabCostCenters { get; set; } = null!;
        public virtual DbSet<VendorsSettlementLabItem> VendorsSettlementLabItems { get; set; } = null!;
        public virtual DbSet<VendorsSettlementMethod> VendorsSettlementMethods { get; set; } = null!;
        public virtual DbSet<VendorsSettlementShareCostItem> VendorsSettlementShareCostItems { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSub> VendorsSettlementSubs { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSubCostCenter> VendorsSettlementSubCostCenters { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSubCostCenterRedesign> VendorsSettlementSubCostCenterRedesigns { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSubEdit> VendorsSettlementSubEdits { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSubItem> VendorsSettlementSubItems { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSubItemsEdit> VendorsSettlementSubItemsEdits { get; set; } = null!;
        public virtual DbSet<VendorsSettlementSubRedesign> VendorsSettlementSubRedesigns { get; set; } = null!;
        public virtual DbSet<VendorsTerminatesType> VendorsTerminatesTypes { get; set; } = null!;
        public virtual DbSet<Workflow> Workflows { get; set; } = null!;
        public virtual DbSet<WorkflowApi> WorkflowApis { get; set; } = null!;
        public virtual DbSet<WorkflowDetail> WorkflowDetails { get; set; } = null!;
        public virtual DbSet<WorkflowHistory> WorkflowHistories { get; set; } = null!;
        public virtual DbSet<WorkflowNotifContent> WorkflowNotifContents { get; set; } = null!;
        public virtual DbSet<WorkflowNotifContentUrl> WorkflowNotifContentUrls { get; set; } = null!;
        public virtual DbSet<WorkflowNotification> WorkflowNotifications { get; set; } = null!;
        public virtual DbSet<WorkflowPerson> WorkflowPeople { get; set; } = null!;
        public virtual DbSet<WorkflowRoleLabel> WorkflowRoleLabels { get; set; } = null!;
        public virtual DbSet<WorkflowStatus> WorkflowStatuses { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Name=ConnectionStrings:APConnection");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("SQL_Latin1_General_CP850_BIN");

            modelBuilder.Entity<Attachment>(entity =>
            {
                entity.Property(e => e.FileExt).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FileName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FileRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<Bank>(entity =>
            {
                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<BankImportBatch>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<BankList>(entity =>
            {
                entity.Property(e => e.AccountName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankAccountNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankNameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PcvNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PvRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<BanksProjectsChild>(entity =>
            {
                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.BanksProjectsChildren)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK_banks_projects_child_banks");
            });

            modelBuilder.Entity<BehaviorType>(entity =>
            {
                entity.Property(e => e.BehaviorType1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Ordering).HasDefaultValueSql("((0))");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<CashFlowType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<ChartAccount>(entity =>
            {
                entity.Property(e => e.IsChildAccount).HasDefaultValueSql("((0))");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<ChartAccountAutoTransaction>(entity =>
            {
                entity.HasKey(e => new { e.Id, e.AutoTypeId });

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<ChequeBookCancel>(entity =>
            {
                entity.Property(e => e.CancelNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.AccountThreatmentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BusinessType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CompanyName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<CompanyCostCenter>(entity =>
            {
                entity.Property(e => e.CostCenter).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ShareType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ContractArAdminFee>(entity =>
            {
                entity.Property(e => e.MultipleWith).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ContractArDisbursment>(entity =>
            {
                entity.Property(e => e.CardNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LekPhorPor).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ContractArSettlement>(entity =>
            {
                entity.Property(e => e.BankAccountNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ContractIndividualHtdItem>(entity =>
            {
                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TotalSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Type)
                    .IsFixedLength()
                    .UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ContractIndividualSettlement>(entity =>
            {
                entity.Property(e => e.BankAccountName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankAccountNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PayChequeTo)
                    .IsFixedLength()
                    .UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ContractIndividualUseFund>(entity =>
            {
                entity.Property(e => e.Other).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<CostType>(entity =>
            {
                entity.HasKey(e => new { e.Id, e.Type, e.Shortcut });
            });

            modelBuilder.Entity<CustomerBehaviorType>(entity =>
            {
                entity.Property(e => e.Ordering).HasDefaultValueSql("((0))");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<CustomerRequest>(entity =>
            {
                entity.Property(e => e.BehaviorRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Floor).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IsNotOwnerVip).HasDefaultValueSql("((0))");

                entity.Property(e => e.NationalId1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotOwnerVipRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RequestCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");

                entity.Property(e => e.VipRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<CustomerRequestCancel>(entity =>
            {
                entity.Property(e => e.CancelCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CancelReason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RecStatus).HasDefaultValueSql("((0))");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<CustomerRequestDetail>(entity =>
            {
                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<DailyCleanerInfo>(entity =>
            {
                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Contact).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<DailyCleanerSettle>(entity =>
            {
                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<DailyCleanerWage>(entity =>
            {
                entity.Property(e => e.PaymentMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PositionEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<DelegateCustomer>(entity =>
            {
                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Gender).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IdentityCard).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nationality).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Relationship).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<DimAccountThreatmentType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.AccountThreatmentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<DimAccountType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<DimRequestType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Type).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ErrorLog>(entity =>
            {
                entity.Property(e => e.CreatedAt)
                    .IsRowVersion()
                    .IsConcurrencyToken();

                entity.Property(e => e.CreatedBy).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Ip).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LogType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ExchangeRatesType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<ExecuteDeleteTransaction>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<ItemType>(entity =>
            {
                entity.Property(e => e.ItemTypeEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<JobPricing>(entity =>
            {
                entity.Property(e => e.JopPricingCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<LoanBank>(entity =>
            {
                entity.Property(e => e.BankShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanDisburementItem>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LoanPhaseNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanPurpose).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanDocumentsRequirement>(entity =>
            {
                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanHtdItem>(entity =>
            {
                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Location).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Ownership).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TotalSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Type).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanReschedule>(entity =>
            {
                entity.Property(e => e.LoanBankRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RescheduleCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanSchedulesInfo>(entity =>
            {
                entity.Property(e => e.LoanPhaseNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ScheduleNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanType>(entity =>
            {
                entity.Property(e => e.Category).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HtdRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanDescription).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Type).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<LoanUseFund>(entity =>
            {
                entity.Property(e => e.Other).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ManualLoanBalanceReport>(entity =>
            {
                entity.Property(e => e.Title).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ManualMaterialStockDetailReport>(entity =>
            {
                entity.Property(e => e.OtherProject).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<PayOffLoanRequest>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.FinalType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<PaymentPettyCash>(entity =>
            {
                entity.Property(e => e.PvRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<PaymentSettlementsDetail>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<PaymentVoucher>(entity =>
            {
                entity.Property(e => e.NoCheque).HasDefaultValueSql("(CONVERT([bit],(0)))");
            });

            modelBuilder.Entity<PhoneTracking>(entity =>
            {
                entity.Property(e => e.Phone).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Purpose>(entity =>
            {
                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Ordering).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<ReceivedDocument>(entity =>
            {
                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<ReceivedDocumentsCancel>(entity =>
            {
                entity.Property(e => e.CancelReason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<RedesignFloor>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Status).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<RedesignJob>(entity =>
            {
                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<RedesignedCalculation>(entity =>
            {
                entity.Property(e => e.ConditionRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DiscountRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IsPaymentInstallment).HasDefaultValueSql("((0))");

                entity.Property(e => e.RedesignedCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<RedesignedCalculationsCancel>(entity =>
            {
                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Reasons).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedCancelCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Tel1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Tel2).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<RedesignedCalculationsItem>(entity =>
            {
                entity.Property(e => e.RedesingedFloor).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<RedesignedCalculationsSubterm>(entity =>
            {
                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.PaymentInstallment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SettlePaymentInvoicesNonstocksDetailCost>(entity =>
            {
                entity.Property(e => e.Locked).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<SpecialPaymentType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<SubJob>(entity =>
            {
                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Supplier>(entity =>
            {
                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Behavior).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BehaviorDescription).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CollectorNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CollectorTelegram).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContactTelegram).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Normal).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SupplierLocation).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersContract>(entity =>
            {
                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TermPay).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersContractsItem>(entity =>
            {
                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersContractsItemsSub>(entity =>
            {
                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Uom).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersContractsPaymentTerm>(entity =>
            {
                entity.Property(e => e.Condition).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phase).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersContractsTerminate>(entity =>
            {
                entity.Property(e => e.ContractPo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TerminateCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TerminateReason).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersItem>(entity =>
            {
                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UomEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UomKh).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersItemsType>(entity =>
            {
                entity.Property(e => e.ItemDesc).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ItemType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SuppliersSchedulesPaidCost>(entity =>
            {
                entity.Property(e => e.Status).IsFixedLength();
            });

            modelBuilder.Entity<TelegramLog>(entity =>
            {
                entity.Property(e => e.ActionLabel).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Comment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Content1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TelegramContent).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Url).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UserName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.WorkflowName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<TransactionType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<Unit>(entity =>
            {
                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.Designation).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.EmpId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Password).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<UsersCompany>(entity =>
            {
                entity.HasKey(e => new { e.UserId, e.CompanyId, e.Status });

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UsersDepartment>(entity =>
            {
                entity.Property(e => e.Department).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<UsersGroupsPermission>(entity =>
            {
                entity.HasKey(e => new { e.UserGroupId, e.UserPermissionId });

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UsersNotifySession>(entity =>
            {
                entity.Property(e => e.SignalRSession).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<UsersPage>(entity =>
            {
                entity.Property(e => e.IconName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PageName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PageTitle).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PageType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PageUrl).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<UsersPermission>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<UsersPosition>(entity =>
            {
                entity.Property(e => e.Position).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PositionKh).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<UsersRole>(entity =>
            {
                entity.Property(e => e.Auth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IsDynamic).HasDefaultValueSql("((0))");

                entity.Property(e => e.RoleDescription).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<UsersToProject>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VAffectedRow>(entity =>
            {
                entity.ToView("v_affected_row");
            });

            modelBuilder.Entity<VArchRedesignHouse>(entity =>
            {
                entity.ToView("v_arch_redesign_houses");

                entity.Property(e => e.RedesignType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VAttachmentList>(entity =>
            {
                entity.ToView("v_attachment_list");

                entity.Property(e => e.FileExt).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FileName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FileRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VBank>(entity =>
            {
                entity.ToView("v_banks");
            });

            modelBuilder.Entity<VBankReconcile>(entity =>
            {
                entity.ToView("v_bank_reconcile");
            });

            modelBuilder.Entity<VBankVoucherBasic>(entity =>
            {
                entity.ToView("v_bank_voucher_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VCentralCashBook>(entity =>
            {
                entity.ToView("v_central_cash_books");

                entity.Property(e => e.InterProject).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChartAccount>(entity =>
            {
                entity.ToView("v_chart_accounts");

                entity.Property(e => e.CreatedByName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UpdatedByName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChartAccountToProject>(entity =>
            {
                entity.ToView("v_chart_account_to_projects");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChequeBook>(entity =>
            {
                entity.ToView("v_cheque_book");

                entity.Property(e => e.BankShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChequeBookCancel>(entity =>
            {
                entity.ToView("v_cheque_book_cancel");

                entity.Property(e => e.BankShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CancelNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChequeBookSubterm>(entity =>
            {
                entity.ToView("v_cheque_book_subterms");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChequeBookUser>(entity =>
            {
                entity.ToView("v_cheque_book_users");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UserId)
                    .IsFixedLength()
                    .UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VChequeBooksDetail>(entity =>
            {
                entity.ToView("v_cheque_books_detail");
            });

            modelBuilder.Entity<VCompanyCostCenter>(entity =>
            {
                entity.ToView("v_company_cost_center");

                entity.Property(e => e.AccountThreatmentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BusinessType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CompanyName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CostCenter).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractAdminFee>(entity =>
            {
                entity.ToView("v_contract_admin_fees");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.MultipleWith).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractArDisbursment>(entity =>
            {
                entity.ToView("v_contract_ar_disbursments");

                entity.Property(e => e.CardNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LekPhorPor).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractArDisbursmentsCostCenter>(entity =>
            {
                entity.ToView("v_contract_ar_disbursments_cost_centers");
            });

            modelBuilder.Entity<VContractArDisbursmentsHtd>(entity =>
            {
                entity.ToView("v_contract_ar_disbursments_htds");
            });

            modelBuilder.Entity<VContractArDisbursmentsUseFund>(entity =>
            {
                entity.ToView("v_contract_ar_disbursments_use_funds");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractArDocumentRequirement>(entity =>
            {
                entity.ToView("v_contract_ar_document_requirements");

                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractArLoan>(entity =>
            {
                entity.ToView("v_contract_ar_loans");

                entity.Property(e => e.BankShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractArSettlement>(entity =>
            {
                entity.ToView("v_contract_ar_settlements");

                entity.Property(e => e.BankAccountNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractIndividualCostCenter>(entity =>
            {
                entity.ToView("v_contract_individual_cost_centers");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractIndividualHtdItem>(entity =>
            {
                entity.ToView("v_contract_individual_htd_items");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TotalSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Type)
                    .IsFixedLength()
                    .UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractIndividualLoan>(entity =>
            {
                entity.ToView("v_contract_individual_loans");

                entity.Property(e => e.Type).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractIndividualScheduleDetail>(entity =>
            {
                entity.ToView("v_contract_individual_schedule_details");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractIndividualSettlement>(entity =>
            {
                entity.ToView("v_contract_individual_settlements");

                entity.Property(e => e.BankAccountName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankAccountNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PayChequeTo)
                    .IsFixedLength()
                    .UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractIndividualUseFund>(entity =>
            {
                entity.ToView("v_contract_individual_use_funds");

                entity.Property(e => e.Other).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractLoanStandard>(entity =>
            {
                entity.ToView("v_contract_loan_standard");

                entity.Property(e => e.LoanType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VContractsCustomer>(entity =>
            {
                entity.ToView("v_contracts_customers", "arch");

                entity.Property(e => e.NationalId1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone2).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VCoverHouseBasic>(entity =>
            {
                entity.ToView("v_cover_house_basic");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VCustomerRequest>(entity =>
            {
                entity.ToView("v_customer_requests", "arch");

                entity.Property(e => e.BehaviorRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Floor).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotOwnerVipRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RequestCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VipRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VCustomerRequestBasic>(entity =>
            {
                entity.ToView("v_customer_request_basic");

                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RequestCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VCustomerRequestCancel>(entity =>
            {
                entity.ToView("v_customer_request_cancel", "arch");

                entity.Property(e => e.CancelCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CancelReason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NationalId2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RequestCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VCustomerRequestDetail>(entity =>
            {
                entity.ToView("v_customer_request_details");

                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Type).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDailyCleanerInfo>(entity =>
            {
                entity.ToView("v_daily_cleaner_info");

                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Contact).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PositionEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDailyCleanerInfoBasic>(entity =>
            {
                entity.ToView("v_daily_cleaner_info_basic");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PositionEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDailyCleanerSettlement>(entity =>
            {
                entity.ToView("v_daily_cleaner_settlements");

                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDailyCleanerSettlementHouse>(entity =>
            {
                entity.ToView("v_daily_cleaner_settlement_houses");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDailyCleanerSettlementInfo>(entity =>
            {
                entity.ToView("v_daily_cleaner_settlement_info");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PositionEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDailyCleanerWage>(entity =>
            {
                entity.ToView("v_daily_cleaner_wages");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.PaymentMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PositionEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDblhdBudgetsLine>(entity =>
            {
                entity.ToView("v_dblhd_budgets_lines");
            });

            modelBuilder.Entity<VDblhdCompany>(entity =>
            {
                entity.ToView("v_dblhd_companies");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.NameKh).UseCollation("SQL_Latin1_General_CP437_BIN");
            });

            modelBuilder.Entity<VDblhdHoliday>(entity =>
            {
                entity.ToView("v_dblhd_holidays");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VDbliveContract>(entity =>
            {
                entity.ToView("v_dblive_contracts");

                entity.Property(e => e.Condition).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CustomerRelationship).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.MergedHouses).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.OwnerCustomerRelationship).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentTermData).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDbliveCustomer>(entity =>
            {
                entity.ToView("v_dblive_customers");

                entity.Property(e => e.Commune).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContactType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CustomerType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.District).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Facebook).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Gender).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.IdNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IdType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nationality).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Occupation).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Other).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneCall).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneContract).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Province).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Street).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TelegramNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Village).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDbliveHouseCategory>(entity =>
            {
                entity.ToView("v_dblive_house_categories");

                entity.Property(e => e.Desc).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDbliveHouseType>(entity =>
            {
                entity.ToView("v_dblive_house_types");

                entity.Property(e => e.CategoryName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDbliveHousesNotHandOver>(entity =>
            {
                entity.ToView("v_dblive_houses_not_hand_over");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDbliveProject>(entity =>
            {
                entity.ToView("v_dblive_projects");

                entity.Property(e => e.Ownership).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VDbliveStreet>(entity =>
            {
                entity.ToView("v_dblive_streets");

                entity.Property(e => e.Commune).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.District).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Province).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.StNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Village).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VGetUserRole>(entity =>
            {
                entity.ToView("v_get_user_roles");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Position).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoleCreatedBy).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VGetWorkflow>(entity =>
            {
                entity.ToView("v_getWorkflow");
            });

            modelBuilder.Entity<VGroupHousesPayment>(entity =>
            {
                entity.ToView("v_group_houses_payments");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VGroupPayment>(entity =>
            {
                entity.ToView("v_group_payments");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VGroupPaymentHouseActive>(entity =>
            {
                entity.ToView("v_group_payment_house_active");
            });

            modelBuilder.Entity<VGroupPaymentHouseAvailable>(entity =>
            {
                entity.ToView("v_group_payment_house_availables");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouse>(entity =>
            {
                entity.ToView("v_houses");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseAvailable>(entity =>
            {
                entity.ToView("v_house_availables");

                entity.Property(e => e.Billercode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Block).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproaccid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproref).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phase).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoadType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseCategory>(entity =>
            {
                entity.ToView("v_house_category");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHousesList>(entity =>
            {
                entity.ToView("v_houses_list");

                entity.Property(e => e.Billercode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Block).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproaccid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproref).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phase).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoadType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHousesListsAll>(entity =>
            {
                entity.ToView("v_houses_lists_all");

                entity.Property(e => e.HouseCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoadType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHousesType>(entity =>
            {
                entity.ToView("v_houses_types");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VJobPricing>(entity =>
            {
                entity.ToView("v_job_pricing");

                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.JopPricingCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VLaborTermPay>(entity =>
            {
                entity.ToView("v_labor_term_pays");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VLoanBanksItem>(entity =>
            {
                entity.ToView("v_loan_banks_items");
            });

            modelBuilder.Entity<VLoanCostCenter>(entity =>
            {
                entity.ToView("v_loan_cost_centers");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VLoanDisburementItem>(entity =>
            {
                entity.ToView("v_loan_disburement_items");

                entity.Property(e => e.BankShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Currency).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanPhaseNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LoanPurpose).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VLoanSchedulesInfo>(entity =>
            {
                entity.ToView("v_loan_schedules_info");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.LoanPhaseNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ScheduleNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VLoanUseFund>(entity =>
            {
                entity.ToView("v_loan_use_funds");

                entity.Property(e => e.Other).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualCollectionDetailReport>(entity =>
            {
                entity.ToView("v_manual_collection_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualCreditControlDetailReport>(entity =>
            {
                entity.ToView("v_manual_credit_control_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualInterestIncomeExpenseDetailReport>(entity =>
            {
                entity.ToView("v_manual_interest_income_expense_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualLoanBalanceDetailReport>(entity =>
            {
                entity.ToView("v_manual_loan_balance_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualLoanBalanceReport>(entity =>
            {
                entity.ToView("v_manual_loan_balance_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualMaterialStockDetailReport>(entity =>
            {
                entity.ToView("v_manual_material_stock_detail_report", "report");

                entity.Property(e => e.OtherProject).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualSaleDetailReport>(entity =>
            {
                entity.ToView("v_manual_sale_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualSpaDetailReport>(entity =>
            {
                entity.ToView("v_manual_spa_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VManualSummaryDetailReport>(entity =>
            {
                entity.ToView("v_manual_summary_detail_report", "report");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VPaymentPettyCash>(entity =>
            {
                entity.ToView("v_payment_petty_cashes");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PvRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VPaymentPettyCashDetail>(entity =>
            {
                entity.ToView("v_payment_petty_cash_detail");
            });

            modelBuilder.Entity<VPaymentSettlementsBasic>(entity =>
            {
                entity.ToView("v_payment_settlements_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VPaymentSettlementsPrettyCashBasic>(entity =>
            {
                entity.ToView("v_payment_settlements_pretty_cash_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VPaymentVouchersDetail>(entity =>
            {
                entity.ToView("v_payment_vouchers_details");
            });

            modelBuilder.Entity<VPaymentVourcher>(entity =>
            {
                entity.ToView("v_payment_vourchers");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VPhoneTracking>(entity =>
            {
                entity.ToView("v_phone_trackings", "arch");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phone).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VPhysicalCheckLab>(entity =>
            {
                entity.ToView("v_physical_check_lab");

                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VPhysicalCheckLabCover>(entity =>
            {
                entity.ToView("v_physical_check_lab_covers");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RemarkShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VPhysicalCheckSub>(entity =>
            {
                entity.ToView("v_physical_check_sub");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VProject>(entity =>
            {
                entity.ToView("v_projects");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.ProjectAbbr).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VProjectHouseCategory>(entity =>
            {
                entity.ToView("v_project_house_categories");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VReceivedDocument>(entity =>
            {
                entity.ToView("v_received_documents");

                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VReceivedDocumentBasic>(entity =>
            {
                entity.ToView("v_received_document_basic");

                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.InvoiceNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VReceivedDocumentsCancel>(entity =>
            {
                entity.ToView("v_received_documents_cancel");

                entity.Property(e => e.CancelReason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.InvoiceNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VRedesignFee>(entity =>
            {
                entity.ToView("v_redesign_fees");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VRedesignFloor>(entity =>
            {
                entity.ToView("v_redesign_floors");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VRedesignedCalculation>(entity =>
            {
                entity.ToView("v_redesigned_calculations", "arch");

                entity.Property(e => e.ConditionRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DiscountRemark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VRedesignedCalculationCancel>(entity =>
            {
                entity.ToView("v_redesigned_calculation_cancel");

                entity.Property(e => e.Customer1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Customer2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Reasons).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedCancelCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesingedType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Tel1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Tel2).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VRedesignedCalculationItem>(entity =>
            {
                entity.ToView("v_redesigned_calculation_items");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesingedFloor).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VRedesignedCalculationSubterm>(entity =>
            {
                entity.ToView("v_redesigned_calculation_subterm", "arch");

                entity.Property(e => e.PaymentInstallment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PreprintedNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSchedulesDetail>(entity =>
            {
                entity.ToView("v_schedules_details");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSchedulesStandardLoan>(entity =>
            {
                entity.ToView("v_schedules_standard_loans");

                entity.Property(e => e.BankShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSettlePaymentInvoicesNonstocksDetailCost>(entity =>
            {
                entity.ToView("v_settle_payment_invoices_nonstocks_detail_costs");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSettlePaymentMaterial>(entity =>
            {
                entity.ToView("v_settle_payment_materials");

                entity.Property(e => e.ItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ItemType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VShareCostStandard>(entity =>
            {
                entity.ToView("v_share_cost_standard");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSubJobEffectiveDate>(entity =>
            {
                entity.ToView("v_sub_job_effective_date", "arch");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSubJobEffectiveProject>(entity =>
            {
                entity.ToView("v_sub_job_effective_project", "arch");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSubJobHouseCategory>(entity =>
            {
                entity.ToView("v_sub_job_house_category", "arch");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSubJobProject>(entity =>
            {
                entity.ToView("v_sub_job_project", "arch");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSubJobUnlink>(entity =>
            {
                entity.ToView("v_sub_job_unlinks");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSubJop>(entity =>
            {
                entity.ToView("v_sub_jop", "arch");

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSuppliersBasic>(entity =>
            {
                entity.ToView("v_suppliers_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VSuppliersContract>(entity =>
            {
                entity.ToView("v_suppliers_contracts");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ItemType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SupplierNid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TermPay).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSuppliersContractsBasic>(entity =>
            {
                entity.ToView("v_suppliers_contracts_basic");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VSuppliersItem>(entity =>
            {
                entity.ToView("v_suppliers_items");

                entity.Property(e => e.ItemType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UomEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UomKh).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSuppliersItemsBasic>(entity =>
            {
                entity.ToView("v_suppliers_items_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSuppliersSchedulesPayment>(entity =>
            {
                entity.ToView("v_suppliers_schedules_payments");

                entity.Property(e => e.ItemType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VSuppliersTerminate>(entity =>
            {
                entity.ToView("v_suppliers_terminates");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Nid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TermPay).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TerminateCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TerminateReason).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VTestUser>(entity =>
            {
                entity.ToView("v_test_users");

                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.TestName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VUser>(entity =>
            {
                entity.ToView("v_users");

                entity.Property(e => e.Designation).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VUserLoggedIn>(entity =>
            {
                entity.ToView("v_user_logged_in");

                entity.Property(e => e.Auth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.UserRole).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VUserRoleBasic>(entity =>
            {
                entity.ToView("v_user_role_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VUsersCompany>(entity =>
            {
                entity.ToView("v_users_companies");
            });

            modelBuilder.Entity<VUsersGroupsPermisssion>(entity =>
            {
                entity.ToView("v_users_groups_permisssions");
            });

            modelBuilder.Entity<VUsersPage>(entity =>
            {
                entity.ToView("v_users_pages");

                entity.Property(e => e.Icon).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PageName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Title).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Type).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Url).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VUsersPermission>(entity =>
            {
                entity.ToView("v_users_permissions");

                entity.Property(e => e.WorkflowTitle).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VUsersRolesBasic>(entity =>
            {
                entity.ToView("v_users_roles_basics");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendor>(entity =>
            {
                entity.ToView("v_vendors");

                entity.Property(e => e.AccountNameEn2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNameKh2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNumber2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CardNo2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CharacteristicNotice).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ChequeName1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Currency2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementType1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementType2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorContract>(entity =>
            {
                entity.ToView("v_vendor_contracts");

                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TermPayment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorContractBasic>(entity =>
            {
                entity.ToView("v_vendor_contract_basic");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.TermPayment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorSettlementSubItem>(entity =>
            {
                entity.ToView("v_vendor_settlement_sub_items");

                entity.Property(e => e.ClaimId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SubItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Uom).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsContractItem>(entity =>
            {
                entity.ToView("v_vendors_contract_items");
            });

            modelBuilder.Entity<VVendorsContractsMaster>(entity =>
            {
                entity.ToView("v_vendors_contracts_master");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseRedo).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsContractsPaymentTerm>(entity =>
            {
                entity.ToView("v_vendors_contracts_payment_terms");
            });

            modelBuilder.Entity<VVendorsContractsPriceItem>(entity =>
            {
                entity.ToView("v_vendors_contracts_price_items");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SubItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsContractsPricing>(entity =>
            {
                entity.ToView("v_vendors_contracts_pricing");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsContractsTermination>(entity =>
            {
                entity.ToView("v_vendors_contracts_terminations");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractTerminateCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsContractsTerminationsHouse>(entity =>
            {
                entity.ToView("v_vendors_contracts_terminations_houses");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaidStatus).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsInfo>(entity =>
            {
                entity.ToView("v_vendors_info");

                entity.Property(e => e.AccountNameEn2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNameKh2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNumber2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CardNo2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CharacteristicNotice).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ChequeName1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Currency2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementType1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementType2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsItem>(entity =>
            {
                entity.ToView("v_vendors_items");
            });

            modelBuilder.Entity<VVendorsLaborCover>(entity =>
            {
                entity.ToView("v_vendors_labor_covers");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SiteAreaEngineer).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SiteEngineer).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsLaborCoversBasic>(entity =>
            {
                entity.ToView("v_vendors_labor_covers_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VVendorsLaborCoversBasicFinal>(entity =>
            {
                entity.ToView("v_vendors_labor_covers_basic_final");
            });

            modelBuilder.Entity<VVendorsLaborCoversHousesBasic>(entity =>
            {
                entity.ToView("v_vendors_labor_covers_houses_basic");
            });

            modelBuilder.Entity<VVendorsPenaltiesCover>(entity =>
            {
                entity.ToView("v_vendors_penalties_covers");

                entity.Property(e => e.VendorName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsPenalty>(entity =>
            {
                entity.ToView("v_vendors_penalties");

                entity.Property(e => e.AccountCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PenaltyCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsPhysicalCheckSubsDetail>(entity =>
            {
                entity.ToView("v_vendors_physical_check_subs_details");

                entity.Property(e => e.ClaimTime).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsRedesignsLaborCoversItem>(entity =>
            {
                entity.ToView("v_vendors_redesigns_labor_covers_items");

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SubItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsRedesignsSettlementSubItem>(entity =>
            {
                entity.ToView("v_vendors_redesigns_settlement_sub_items");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SubItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsSettlementLab>(entity =>
            {
                entity.ToView("v_vendors_settlement_lab");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsSettlementLabBasic>(entity =>
            {
                entity.ToView("v_vendors_settlement_lab_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VVendorsSettlementShareCostItem>(entity =>
            {
                entity.ToView("v_vendors_settlement_share_cost_items");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsSettlementSubBasic>(entity =>
            {
                entity.ToView("v_vendors_settlement_sub_basic");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsSettlementsSub>(entity =>
            {
                entity.ToView("v_vendors_settlements_sub");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorNameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VVendorsSettlementsSubSpecial>(entity =>
            {
                entity.ToView("v_vendors_settlements_sub_special");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DocumentCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorNameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VWorkflowAction>(entity =>
            {
                entity.ToView("v_workflow_action");

                entity.Property(e => e.BtnAction).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.WorkflowName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VWorkflowNotification>(entity =>
            {
                entity.ToView("v_workflow_notifications");

                entity.Property(e => e.NotifTitle).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VWorkflowStatus>(entity =>
            {
                entity.ToView("v_workflow_status");

                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<Vendor>(entity =>
            {
                entity.Property(e => e.AccountNameEn2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNameKh2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNumber2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CardNo2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CharacteristicNotice).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ChequeName1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Currency2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IsEditable).HasDefaultValueSql("((1))");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContract>(entity =>
            {
                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IsCovered).HasDefaultValueSql("((0))");

                entity.Property(e => e.ItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TermPayment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContract1>(entity =>
            {
                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.TermPayment).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsPaymentTermsItem>(entity =>
            {
                entity.Property(e => e.Condition).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsPaymentTermsItem1>(entity =>
            {
                entity.Property(e => e.Condition).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsPrice>(entity =>
            {
                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsPrice1>(entity =>
            {
                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsPriceItem>(entity =>
            {
                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SubItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsPriceItem1>(entity =>
            {
                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SubItemName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsSettlementInfo>(entity =>
            {
                entity.Property(e => e.AttachmentRef).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankAccountNameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankAccountNameKh).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankAccountNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CardNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ChequeName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Currency).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentCollector).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementOption).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsTermination>(entity =>
            {
                entity.Property(e => e.ContractTerminateCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsContractsTrackingCostName>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.VendorId, e.MasterId, e.ItemId, e.Status })
                    .HasName("PK_vendors_contracts_tracking_cost_names_1");

                entity.Property(e => e.ClaimTime).HasDefaultValueSql("((0))");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.IsMatch).HasDefaultValueSql("((1))");

                entity.Property(e => e.TotalClaimPerc).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<VendorsContractsTrackingHouse>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.VendorId, e.MasterId, e.HouseId, e.ItemId, e.Status });

                entity.Property(e => e.ClaimTime).HasDefaultValueSql("((0))");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.TotalClaimPerc).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<VendorsContractsTrackingRedesignHouse>(entity =>
            {
                entity.HasKey(e => new { e.ContractId, e.VendorId, e.HouseId, e.ItemId, e.Status })
                    .HasName("PK_vendors_contracts_tracking_redesign_houses_1");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VendorsHistory>(entity =>
            {
                entity.Property(e => e.AccountNameEn2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNameKh2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.AccountNumber2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Address).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BankName2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CardNo2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CharacteristicNotice).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ChequeName1).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Currency2).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.NameEn).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NidNo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.VendorCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCover>(entity =>
            {
                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SiteAreaEngineer).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SiteEngineer).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCoversEdit>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SiteAreaEngineer).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SiteEngineer).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCoversHouse>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VendorsLaborCoversHousesEdit>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VendorsLaborCoversItem>(entity =>
            {
                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCoversItemsEdit>(entity =>
            {
                entity.Property(e => e.Description).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCoversRedesignItem>(entity =>
            {
                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCoversRedesignItemsEdit>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Unit).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsLaborCoversSchedule>(entity =>
            {
                entity.Property(e => e.ClaimLink).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentVoucherId).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsPenalty>(entity =>
            {
                entity.Property(e => e.AccountCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PaymentMethod).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PenaltyCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsPhysicalCheckLab>(entity =>
            {
                entity.Property(e => e.Code).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsPhysicalCheckLabsRemark>(entity =>
            {
                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RemarkShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsPhysicalCheckSub>(entity =>
            {
                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsPhysicalCheckSubsDetail>(entity =>
            {
                entity.Property(e => e.ClaimTime).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsRedesignsLaborCoversItem>(entity =>
            {
                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsRedesignsSettlementSubItem>(entity =>
            {
                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsSettlementMethod>(entity =>
            {
                entity.Property(e => e.SettlementType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsSettlementSub>(entity =>
            {
                entity.Property(e => e.ClaimTime).HasDefaultValueSql("((1))");

                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsSettlementSubCostCenter>(entity =>
            {
                entity.Property(e => e.BalanceAmount).HasComment("For formula round");
            });

            modelBuilder.Entity<VendorsSettlementSubCostCenterRedesign>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VendorsSettlementSubEdit>(entity =>
            {
                entity.Property(e => e.ContractPurchaseId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.SettlementCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsSettlementSubItem>(entity =>
            {
                entity.Property(e => e.ClaimId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LockTick).HasDefaultValueSql("((0))");

                entity.Property(e => e.Uom).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsSettlementSubItemsEdit>(entity =>
            {
                entity.Property(e => e.ClaimId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.Uom).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsSettlementSubRedesign>(entity =>
            {
                entity.Property(e => e.Reason).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RedesignedCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VendorsTerminatesType>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<Workflow>(entity =>
            {
                entity.Property(e => e.AllowEdit).HasDefaultValueSql("((0))");

                entity.Property(e => e.FormUrl)
                    .HasComment("front-end link URI")
                    .UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Indexing)
                    .HasDefaultValueSql("((0))")
                    .HasComment("related the same table have different threshold");

                entity.Property(e => e.WorkflowName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.WorkflowTitle).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.WorkflowUuid).HasDefaultValueSql("(newid())");
            });

            modelBuilder.Entity<WorkflowApi>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.ApiName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Url).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<WorkflowDetail>(entity =>
            {
                entity.Property(e => e.ActionLabel).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.BtnAction).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.CurLabel).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.DisabledNotify).HasDefaultValueSql("((0))");

                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.WfDetailUuid).HasDefaultValueSql("(newid())");

                entity.Property(e => e.WorkflowLabel).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.WorkflowName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<WorkflowHistory>(entity =>
            {
                entity.Property(e => e.Comment).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<WorkflowNotifContent>(entity =>
            {
                entity.Property(e => e.EmailContent).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotifCc).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotifFunction).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotifSubject).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotifTo).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotifType).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ParamJson).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<WorkflowNotifContentUrl>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();
            });

            modelBuilder.Entity<WorkflowNotification>(entity =>
            {
                entity.Property(e => e.NotifTitle).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NotifType).HasComment("1=To do, 2=Inform");
            });

            modelBuilder.Entity<WorkflowRoleLabel>(entity =>
            {
                entity.Property(e => e.RoleName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<WorkflowStatus>(entity =>
            {
                entity.Property(e => e.StatusName).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
