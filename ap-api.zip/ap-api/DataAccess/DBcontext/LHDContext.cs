﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.LHDEntities;

namespace DataAccess.DBcontext
{
    public partial class LHDContext : DbContext
    {
        public LHDContext()
        {
        }

        public LHDContext(DbContextOptions<LHDContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BudgetsLine> BudgetsLines { get; set; } = null!;
        public virtual DbSet<Company> Companies { get; set; } = null!;
        public virtual DbSet<ExcluseProcedure> ExcluseProcedures { get; set; } = null!;
        public virtual DbSet<Holiday> Holidays { get; set; } = null!;
        public virtual DbSet<House> Houses { get; set; } = null!;
        public virtual DbSet<HouseCategory> HouseCategories { get; set; } = null!;
        public virtual DbSet<HouseType> HouseTypes { get; set; } = null!;
        public virtual DbSet<Project> Projects { get; set; } = null!;
        public virtual DbSet<SsoApp> SsoApps { get; set; } = null!;
        public virtual DbSet<SsoUsersApp> SsoUsersApps { get; set; } = null!;
        public virtual DbSet<StoreVersion> StoreVersions { get; set; } = null!;
        public virtual DbSet<SyncLog> SyncLogs { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;
        public virtual DbSet<VCompaniesBasic> VCompaniesBasics { get; set; } = null!;
        public virtual DbSet<VCompany> VCompanies { get; set; } = null!;
        public virtual DbSet<VHouse> VHouses { get; set; } = null!;
        public virtual DbSet<VHouseCategoriesList> VHouseCategoriesLists { get; set; } = null!;
        public virtual DbSet<VHouseCategory> VHouseCategories { get; set; } = null!;
        public virtual DbSet<VHouseList> VHouseLists { get; set; } = null!;
        public virtual DbSet<VHouseType> VHouseTypes { get; set; } = null!;
        public virtual DbSet<VHouseTypeList> VHouseTypeLists { get; set; } = null!;
        public virtual DbSet<VLhdHouseType> VLhdHouseTypes { get; set; } = null!;
        public virtual DbSet<VProject> VProjects { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Name=ConnectionStrings:LHDConnection");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("SQL_Latin1_General_CP850_BIN");

            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.NameKh).UseCollation("SQL_Latin1_General_CP437_BIN");
            });

            modelBuilder.Entity<House>(entity =>
            {
                entity.Property(e => e.Billercode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Block).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproaccid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproref).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phase).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoadType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<HouseCategory>(entity =>
            {
                entity.Property(e => e.Desc).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<HouseType>(entity =>
            {
                entity.Property(e => e.HouseLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<Project>(entity =>
            {
                entity.Property(e => e.Communue).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Detail).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.District).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Landsize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameKh).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Ownership).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectAbbr).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectLocation).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Province).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Village).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<SsoApp>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<SsoUsersApp>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.Designation).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Email).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.EmpId).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.FullName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.IsAdmin).HasDefaultValueSql("((0))");

                entity.Property(e => e.Password).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.PhoneNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Username).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VCompaniesBasic>(entity =>
            {
                entity.ToView("v_companies_basic");

                entity.Property(e => e.CompanyNameKh).UseCollation("SQL_Latin1_General_CP437_BIN");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VCompany>(entity =>
            {
                entity.ToView("v_companies");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.NameKh).UseCollation("SQL_Latin1_General_CP437_BIN");
            });

            modelBuilder.Entity<VHouse>(entity =>
            {
                entity.ToView("v_houses");

                entity.Property(e => e.Billercode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Block).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Number).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproaccid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproref).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Phase).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoadType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseCategoriesList>(entity =>
            {
                entity.ToView("v_house_categories_list");

                entity.Property(e => e.CategoryName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseCategory>(entity =>
            {
                entity.ToView("v_house_categories");

                entity.Property(e => e.Desc).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseList>(entity =>
            {
                entity.ToView("v_house_list");

                entity.Property(e => e.CategoryName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseNumber).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Payproaccid).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Project).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.RoadType).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseType>(entity =>
            {
                entity.ToView("v_house_types");

                entity.Property(e => e.CategoryName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VHouseTypeList>(entity =>
            {
                entity.ToView("v_house_type_list");

                entity.Property(e => e.HouseCategory).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandSize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Projects).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VLhdHouseType>(entity =>
            {
                entity.ToView("v_lhd_house_types");

                entity.Property(e => e.CategoryName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.HouseWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandLength).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.LandWidth).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remarks).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            modelBuilder.Entity<VProject>(entity =>
            {
                entity.ToView("v_projects");

                entity.Property(e => e.Communue).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Detail).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.District).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Landsize).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Name).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.NameKh).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Ownership).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectAbbr).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectCode).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectLocation).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectName).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.ProjectShort).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Province).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Remark).UseCollation("SQL_Latin1_General_CP1_CI_AS");

                entity.Property(e => e.Village).UseCollation("SQL_Latin1_General_CP1_CI_AS");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
