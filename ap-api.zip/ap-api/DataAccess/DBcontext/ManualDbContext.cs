﻿using DataAccess.Entities;
using DataAccess.Models;
//using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MPrintCoversSettlementItem = DataAccess.Models.MPrintCoversSettlementItem;
using MPrintPhysicalCheckLab = DataAccess.Models.MPrintPhysicalCheckLab;
using MPrintPhysicalCheckLabInfo = DataAccess.Models.MPrintPhysicalCheckLabInfo;
using VDbliveProject = DataAccess.Models.VDbliveProject;

namespace DataAccess.dbcontext
{
#pragma warning disable CS8618 // #warning directive
    public partial class ManualDbContext : DbContext
    {
        public ManualDbContext()
        {
        }

        public ManualDbContext(DbContextOptions<ManualDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<UserLogIn> UserLogIn { get; set; }
        public virtual DbSet<WorkflowSubmit> WorkflowSubmit { get; set; }
        public virtual DbSet<WorkflowEmail> WorkflowEmail { get; set; }
        public virtual DbSet<ApprovalAction> ApprovalAction { get; set; }
        public virtual DbSet<ApprovalWorkflow> ApprovalWorkflow { get; set; }
        public virtual DbSet<WorkflowHistoryModel> WorkflowHistoryModel { get; set; }
        public virtual DbSet<ExecuteAffectedRow> ExecuteAffectedRow { get; set; }
        public virtual DbSet<VWorkflowAction> VWorkflowActions { get; set; }
        public virtual DbSet<Workflow> Workflows { get; set; }
        public virtual DbSet<AttachmentsModel> AttachmentsModel { get; set; }

        public virtual DbSet<NotifModel> NotifModel { get; set; }
        public virtual DbSet<WorkflowPerson> WorkflowPeople { get; set; } = null!;

        public virtual DbSet<PhysicalCheckHouse> PhysicalCheckHouses { get; set; } = null!;
        public virtual DbSet<VendorContractHouse> VendorContractHouses { get; set; } = null!;
        public virtual DbSet<VendorContractPriceItem> VendorContractPriceItems { get; set; } = null!;
        public virtual DbSet<VendorSettlementSubItem> VendorSettlementSubItems { get; set; } = null!;
        public virtual DbSet<VendorSettlementLabItem> VendorSettlementLabItems { get; set; } = null!;
        public virtual DbSet<VendorSettlementLabCoverBasic> VendorSettlementLabCoverBasics { get; set; } = null!;
        public virtual DbSet<VendorSettlementSubItemRedesign> VendorSettlementSubItemRedesigns { get; set; } = null!;
        public virtual DbSet<VendorSettlementSubRedesignConfirm> VendorSettlementSubRedesignConfirms { get; set; } = null!;
        public virtual DbSet<VendorContractLab> VendorContractLabs { get; set; } = null!;
        public virtual DbSet<VendorContractHouseLab> VendorContractHouseLabs { get; set; } = null!;
        public virtual DbSet<VendorLabCover> VendorLabCovers { get; set; } = null!;

        public virtual DbSet<MVendorLaborCoverItem> MVendorLaborCoverItems { get; set; } = null!;
        public virtual DbSet<MVendorLaborCoverRedesignItem> MVendorLaborCoverRedesignItems { get; set; } = null!;
        public virtual DbSet<MVendorLaborCoverRedesignItemConfirm> MVendorLaborCoverRedesignItemConfirms { get; set; } = null!;
        public virtual DbSet<MVendorSettlementSub> MVendorSettlementSubs { get; set; } = null!;
        public virtual DbSet<MPrintSettlementSubInfo> MPrintSettlementSubInfos { get; set; } = null!;
        public virtual DbSet<MPrintSettlementSubItem> MPrintSettlementSubItems { get; set; } = null!;
        public virtual DbSet<MPrintSummaryAccount> MPrintSummaryAccounts { get; set; } = null!;
        public virtual DbSet<MPrintLaborCoverInfo> MPrintLaborCoverInfos { get; set; } = null!;
        public virtual DbSet<MPrintLaborCoverItem> MPrintLaborCoverItems { get; set; } = null!;
        public virtual DbSet<MPrintSettlementLabInfo> MPrintSettlementLabInfos { get; set; } = null!;
        public virtual DbSet<MPrintSettlementLabCover> MPrintSettlementLabCovers { get; set; } = null!;
        public virtual DbSet<MPrintSettlementLabPenaltyList> MPrintSettlementLabPenaltyLists { get; set; } = null!;
        public virtual DbSet<MPrintSettlementLabAccount> MPrintSettlementLabAccounts { get; set; } = null!;
        public virtual DbSet<MPrintSettlementCleanerInfo> MPrintSettlementCleanerInfos { get; set; } = null!;
        public virtual DbSet<MPrintSettlementCleanerWork> MPrintSettlementCleanerWorks { get; set; } = null!;
        public virtual DbSet<MVendorSettlementSubHistory> MVendorSettlementSubHistories { get; set; } = null!;
        public virtual DbSet<MLaborCoverClaimSchedule> MLaborCoverClaimSchedules { get; set; } = null!;

        public virtual DbSet<MShareCostStandEffective> MShareCostStandEffectives { get; set; } = null!;

        public virtual DbSet<VTelegramLog> VTelegramLogs { get; set; } = null!;

        public virtual DbSet<MPrintCoversSettlementItem> MPrintCoversSettlementItems { get; set; } = null!;

        public virtual DbSet<MPrintPhysicalCheckLab> MPrintPhysicalCheckLabs { get; set; } = null!;

        public virtual DbSet<MPrintPhysicalCheckLabInfo> MPrintPhysicalCheckLabInfos { get; set; } = null!;

        public virtual DbSet<MPrintPhysicalCheckSubInfo> MPrintPhysicalCheckSubInfos { get; set; } = null!;

        public virtual DbSet<MPrintPhysicalCheckSub> MPrintPhysicalCheckSubs { get; set; } = null!;

        public virtual DbSet<MworkflowApproveBy> MworkflowApproveBies { get; set; } = null!;

        public virtual DbSet<CoverByContractBasic> CoverByContractBasics { get; set; } = null!;
        public virtual DbSet<MVendorHouseByContract> MVendorHouseByContracts { get; set; } = null!;
        public virtual DbSet<VendorSettlementSubClaimHistory> MVendorSettlementSubClaimHistories { get; set; } = null!;

        public virtual DbSet<MVendorSettlementSubReClaimHistory> MVendorSettlementSubReClaimHistories { get; set; } = null!;
        public virtual DbSet<SettlementSubDeadline> SettlementSubDeadlines { get; set; } = null!;

        public virtual DbSet<VDbliveProject> VDbliveProjects { get; set; } = null!;

        public virtual DbSet<dynamic> dbObject { get; set; } = null!;

        public virtual DbSet<StoredProcedure> StoredProcedures { get; set; } = null!;

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json")
               .Build();
                var connectionString = configuration.GetConnectionString("APConnection");
                optionsBuilder.UseSqlServer(connectionString);

                //optionsBuilder.UseSqlServer("Name=ConnectionStrings:APConnection");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:DefaultSchema", "dbo");
            modelBuilder.Entity<WorkflowEmail>().HasNoKey();
            modelBuilder.Entity<WorkflowSubmit>().HasNoKey();
            modelBuilder.Entity<ApprovalAction>().HasNoKey();
            modelBuilder.Entity<ExecuteAffectedRow>().HasNoKey();
            modelBuilder.Entity<ApprovalWorkflow>().HasNoKey();
            modelBuilder.Entity<WorkflowHistoryModel>().HasNoKey();
            modelBuilder.Entity<NotifModel>().HasNoKey();
            modelBuilder.Entity<PhysicalCheckHouse>().HasNoKey();
            modelBuilder.Entity<VendorContractHouse>().HasNoKey();
            modelBuilder.Entity<VendorContractPriceItem>().HasNoKey();
            modelBuilder.Entity<VendorSettlementSubItem>().HasNoKey();
            modelBuilder.Entity<VendorSettlementSubItemRedesign>().HasNoKey();
            modelBuilder.Entity<VendorSettlementSubRedesignConfirm>().HasNoKey();
            modelBuilder.Entity<VendorContractLab>().HasNoKey();
            modelBuilder.Entity<VendorContractHouseLab>().HasNoKey();
            modelBuilder.Entity<VendorLabCover>().HasNoKey();
            modelBuilder.Entity<VendorSettlementLabItem>().HasNoKey();
            modelBuilder.Entity<VendorSettlementLabCoverBasic>().HasNoKey();
            modelBuilder.Entity<MVendorLaborCoverItem>().HasNoKey();
            modelBuilder.Entity<MVendorLaborCoverRedesignItem>().HasNoKey();
            modelBuilder.Entity<MVendorLaborCoverRedesignItemConfirm>().HasNoKey();
            modelBuilder.Entity<MVendorSettlementSub>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementSubInfo>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementSubItem>().HasNoKey();
            modelBuilder.Entity<MPrintSummaryAccount>().HasNoKey();
            modelBuilder.Entity<MPrintLaborCoverInfo>().HasNoKey();
            modelBuilder.Entity<MPrintLaborCoverItem>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementLabInfo>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementLabCover>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementLabPenaltyList>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementLabAccount>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementCleanerInfo>().HasNoKey();
            modelBuilder.Entity<MPrintSettlementCleanerWork>().HasNoKey();
            modelBuilder.Entity<MVendorSettlementSubHistory>().HasNoKey();
            modelBuilder.Entity<MLaborCoverClaimSchedule>().HasNoKey();
            modelBuilder.Entity<MShareCostStandEffective>().HasNoKey();
            modelBuilder.Entity<MPrintCoversSettlementItem>().HasNoKey();
            modelBuilder.Entity<MPrintPhysicalCheckLab>().HasNoKey();
            modelBuilder.Entity<MPrintPhysicalCheckLabInfo>().HasNoKey();
            modelBuilder.Entity<MPrintPhysicalCheckSubInfo>().HasNoKey();
            modelBuilder.Entity<MPrintPhysicalCheckSub>().HasNoKey();
            modelBuilder.Entity<MworkflowApproveBy>().HasNoKey();
            modelBuilder.Entity<VTelegramLog>().HasNoKey();
            modelBuilder.Entity<CoverByContractBasic>().HasNoKey();
            modelBuilder.Entity<MVendorHouseByContract>().HasNoKey();
            modelBuilder.Entity<dynamic>().HasNoKey();
			modelBuilder.Entity<StoredProcedure>().HasNoKey();


			modelBuilder.Entity<VendorSettlementSubClaimHistory>().HasNoKey();
            modelBuilder.Entity<MVendorSettlementSubReClaimHistory>().HasNoKey();
            modelBuilder.Entity<SettlementSubDeadline>().HasNoKey();
            modelBuilder.Entity<VDbliveProject>().HasNoKey();
            modelBuilder.Entity<VWorkflowAction>(entity =>
            {
                entity.ToView("v_workflow_action");

                entity.Property(e => e.BtnAction).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);

                entity.Property(e => e.WorkflowName).IsUnicode(false);
            });

            modelBuilder.Entity<Workflow>(entity =>
            {
                entity.Property(e => e.WorkflowName).IsUnicode(false);

                entity.Property(e => e.WorkflowTitle).IsUnicode(false);
            });
        }

        //public Task<ActionResult<IEnumerable<object>>> ExecuteQuery(string v)
        //{
        //    throw new NotImplementedException();
        //}
    }
}