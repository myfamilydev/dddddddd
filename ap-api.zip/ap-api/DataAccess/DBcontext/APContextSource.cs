﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities;
using DataAccess.Models;

namespace DataAccess.DBcontext
{
    public partial class APContextSource : DbContext
    {
        public APContextSource()
        {

        }

        public APContextSource(DbContextOptions<APContextSource> options)
            : base(options)
        {

        }

		public virtual DbSet<StoredProcedure> StoredProcedures { get; set; } = null!;

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Name=ConnectionStrings:APSource");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseCollation("SQL_Latin1_General_CP850_BIN");

			modelBuilder.Entity<StoredProcedure>().HasNoKey();

			OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
