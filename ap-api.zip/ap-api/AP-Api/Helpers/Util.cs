﻿namespace AP_Api.Helpers
{
    public static class Util
    {
        public static bool isUnicode(string input)
        {
            const int MaxAnsiCode = 255;

            return input.Any(c => c > MaxAnsiCode);

        }
    }
}
