﻿using System.Text.RegularExpressions;

namespace AP_Api.Helpers
{
	public static class StringExtensions
	{
		public static string ReplaceIgnoreCase(this string str, string oldValue, string newValue)
		{
			return Regex.Replace(str, oldValue.Replace("[", "\\[").Replace("]", "\\]"), newValue.Replace("$", "$$"), RegexOptions.IgnoreCase);
		}
	}
}
