using AP_Api.Services;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
using WatchDog;
using Microsoft.Extensions.DependencyInjection;
using WatchDog.src.Enums;
using Polly;

var builder = WebApplication.CreateBuilder(args);


//builder.Services.AddWatchDogServices(opt =>
//{
//    opt.IsAutoClear = false;
//    opt.SetExternalDbConnString = builder.Configuration.GetConnectionString("LogConnection");
//    opt.DbDriverOption = WatchDog.src.Enums.WatchDogDbDriverEnum.MSSQL;
//});

builder.Services.AddControllers();
/*builder.Services.AddControllers().AddNewtonsoftJson(options =>
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
);*/

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(option =>
{
    option.SwaggerDoc("v1", new OpenApiInfo { Title = "Demo API", Version = "v1" });
    option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter a valid token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JWT",
        Scheme = "Bearer"
    });
    option.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id="Bearer"
                }
            },
            new string[]{}
        }
     });
});

builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

builder.Services.AddDbContext<APContext>(options =>
                options.UseSqlServer(builder.Configuration["ConnectionStrings:APConnection"]));

builder.Services.AddDbContext<ManualDbContext>(options =>
   options.UseSqlServer(builder.Configuration["ConnectionStrings:APConnection"]));

builder.Services.AddDbContext<LHDContext>(options =>
               options.UseSqlServer(builder.Configuration["ConnectionStrings:LHDConnection"]));
builder.Services.AddDbContext<APContextSource>(options =>
			   options.UseSqlServer(builder.Configuration["ConnectionStrings:APSource"]));




var key = Encoding.ASCII.GetBytes(builder.Configuration["Jwt:Secret"]);

builder.Services.AddAuthentication(x =>
{
    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
    .AddJwtBearer(x =>
    {
        x.RequireHttpsMetadata = false;
        x.SaveToken = true;
        x.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ValidateIssuer = false,
            ValidateAudience = false
        };
    });


builder.Services.AddHostedService<LongRunningService>();

builder.Services.AddSingleton<BackgroundWorkerQueue>();
builder.Services.AddSingleton<ITimeZoneService>(new TimeZoneService("Asia/Phnom_Penh"));

try
{
    builder.Services.AddWatchDogServices(opt =>
    {
        opt.IsAutoClear = true;
        opt.ClearTimeSchedule = WatchDogAutoClearScheduleEnum.Monthly;

        opt.SetExternalDbConnString = builder.Configuration["ConnectionStrings:LogConnection"];
        opt.DbDriverOption = WatchDog.src.Enums.WatchDogDbDriverEnum.MSSQL;
    });
}
catch { }

var app = builder.Build();



app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.UseCors(x => x
    .AllowAnyOrigin()
    .AllowAnyMethod()
    .AllowAnyHeader());

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.UseWatchDogExceptionLogger();

app.UseWatchDog(opt =>
{
    opt.WatchPageUsername = "admin";
    opt.WatchPagePassword = "apiAdmin@2023#";
    opt.Blacklist = "/api/v1/auth/authenticate"; //Prevent logging for specified endpoints
    //opt.Serializer = WatchDogSerializerEnum.Newtonsoft; //If your project use a global json converter
});

//using (var scope = app.Services.CreateScope())
//{
//	var services = scope.ServiceProvider;

//	var context = services.GetRequiredService<APContext>();

//	context.Database.Migrate();
//}


app.Run();
