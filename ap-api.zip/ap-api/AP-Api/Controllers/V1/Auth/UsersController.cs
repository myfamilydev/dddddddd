﻿using BVMPP.ClientOauth.Models;
using BVMPP.ClientOauth;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.LHDEntities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Transactions;
using Telegram.Bot.Types;
using Web.Models;
using User = DataAccess.Entities.User;

namespace AP_Api.Controllers
{

    [Route("api/v1/users")]
    [ApiController]
    //[Authorize(Roles = "Executive")]
    [Authorize]
    public class UsersController : Controller
    {
        private readonly APContext _context;
        private readonly IConfiguration _config;
        //private readonly IHttpContextAccessor _httpContextAccessor;
        private CustomUserIdentity _auth;
		private ClientApi _clientApi;
		private SDKConfiguration _SDKConfiguration;

		public UsersController(APContext context, IConfiguration config, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _config = config;

			var clientId = _config.GetSection("SSO:ClientId").Value;
			var clientSecret = _config.GetSection("SSO:ClientSecret").Value;
			var redirectUri = _config.GetSection("SSO:RedirectUri").Value;
			_SDKConfiguration = new SDKConfiguration
			{
				ClienId = clientId,
				ClientSecret = clientSecret,
				RedirectUri = redirectUri,
				ProvideURL = _config.GetSection("SSO:Url").Value
			};

			_clientApi = new ClientApi(_SDKConfiguration);
		}

        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> Getusers()
        {
            return await _context.Users.ToListAsync();
        }

        [HttpGet("basicinfo")]
        public async Task<ActionResult<IEnumerable<object>>> GetusersBasicInfo([FromQuery] PaginationFilter filter)
        {

            var pagedData = await _context.VUsers
                                .Where(x =>
                                    (String.IsNullOrEmpty(filter.Search) || 
                                    (x.Username.Contains(filter.Search) || x.Email.Contains(filter.Search) ||
                                     x.PhoneNumber.Contains(filter.Search)
                                    )))
                                .OrderBy(x => x.Username)
                                .Skip((filter.PageNumber - 1) * filter.PageSize)
                                .Take(filter.PageSize)
                                .ToListAsync();

            filter.TotalRecords = await _context.VUsers
                                .Where(x =>
                                    (String.IsNullOrEmpty(filter.Search) ||
                                    (x.Username.Contains(filter.Search) || x.Email.Contains(filter.Search) ||
                                     x.PhoneNumber.Contains(filter.Search)
                                    )))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, filter));

        }
        
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == id);

            user.Password = "";

            if (user == null)
            {
                return BadRequest(new ApiResponse("Not Found","User ID not found", "400"));
            }

            return user;
        }

        [HttpPost("add-session/{sessionId}")]
        public async Task<ActionResult> AddUser(string sessionId)
        {
            _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == _auth.Id);

            if (user == null)
            {
                return BadRequest(new ApiResponse("Not Found", "User ID not found", "400"));
            }

            user.ChatSessionId = sessionId;

            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpPut("change-password")]
        public async Task<ActionResult> ChangePasswordAsync(UserPassword data)
        {
            if (ModelState.IsValid)
            {
				var _auth = new CustomUserIdentity(User);

				var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == data.Id);

                if (user == null)
                {
                    return BadRequest(new ApiResponse("Not Found", "User ID not found", "400"));
                }

                Encryption enc = new Encryption();
                string encrypt_pwd = enc.ComputeSha512Hash(user.Username.ToLower().Trim() + data.NewPassword);
                user.Password = encrypt_pwd;

                _auth = new CustomUserIdentity(this.User);

                user.UpdatedAt = DateTime.Now;
                user.UpdatedBy = _auth.Id;



				try
				{
					var _user = new OauthUser { Username = user.Username, Password = data.NewPassword };

					await _clientApi.ResetPassword(_auth.SSOToken, _user);
				}
				finally
				{
					await _context.SaveChangesAsync();
				}

				return Ok();
            }

            var problemDetails = new ValidationProblemDetails(ModelState)
            {
                Status = StatusCodes.Status400BadRequest,
            };

            return BadRequest(problemDetails);

        }

        [HttpGet("me")]
        public async Task<ActionResult<User>> GetMe()

        {
            _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == _auth.Id);

            user.Password = "";

            if (user == null)
            {
                return BadRequest(new ApiResponse("Not Found", "User ID not found", "400"));
            }

            return user;
        }

        [HttpGet("permissions")]
        public async Task<ActionResult<List<string?>>> GetPermissionAsync()

        {
            _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == _auth.Id && x.Status == 1);

            return await _context.VUsersGroupsPermisssions
                            .Where(x => x.UserGroupId == user.UserGroupId)
                            .Select(x => x.Name)
                            .ToListAsync(); 
        }
        

        [HttpPost("add")]
        public async Task<ActionResult<User>> AddUser(User user)
        {
            user.Username = user.Username.ToLower().Trim();

            var user_exists = await _context.Users.FirstOrDefaultAsync(x => x.Username == user.Username && x.Status == 1);

            if (user_exists != null)
            {
                return BadRequest(new ApiResponse("failed","User name is already exists.","400"));
            }
            string password = user.Password;
            

            Encryption enc = new Encryption();
            string encrypt_pwd = enc.ComputeSha512Hash(user.Username + user.Password);
            user.Password = encrypt_pwd;

            _auth = new CustomUserIdentity(this.User);

            user.UpdatedAt = DateTime.Now;

            user.UpdatedBy = _auth.Id;

            user.Uuid = Guid.NewGuid();

            user.Status = 1;

            _context.Users.Add(user);

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
					try
					{
						var _user = new OauthUser { Email = user.Email, Username = user.Username, Password = password };

						ResJson data = await _clientApi.SyncUser(_auth.SSOToken, _user);

						if (data != null)
						{
                            if (data.is_exist)
                            {
                                var dataUser = new OauthUser { Username = user.Username, Password = password };

                                //await _clientApi.ResetPassword(_auth.SSOToken, dataUser);
                                //var _user = new OauthUser { Username = clsLogin.Username, Password = default_pwd };

                                await _clientApi.ResetPassword(_auth.SSOToken, dataUser, true);
                            } else
                            {
                                user.SsoId = data.data.id;
                            }
							
						}
					}
					finally
					{
						
					}

					await _context.SaveChangesAsync();

                    user.Password = "";

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_workflow_roles_from_group] {0}, {1}", user.UserGroupId, user.Id);

					ts.Complete();
                }

                return Ok(user);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpGet("projects")]
        public async Task<ActionResult<IEnumerable<object>>> GetAllProject()
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            return _context.VDbliveProjects
                .Where(x => x.CompanyId == u.CompanySessionId)
                .AsEnumerable()
                .Select(x => new { projectId = x.Id, projectCode = x.ProjectShort })
                            .OrderBy(x => x.projectCode)
                           .ToList();
        }

        [HttpPut("update")]
        public async Task<ActionResult<User>> UpdateUser(User data)
        {
            _auth = new CustomUserIdentity(this.User);

            var valid = await _context.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if(valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Update failed", "400"));
            }

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Uuid).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.Password).IsModified = false;
			_context.Entry(data).Property(x => x.Username).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    if (data.UserGroupId != valid.UserGroupId)
                    {
                        _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_workflow_roles_from_group] {0}, {1}", data.UserGroupId, data.Id);
                    }

                    await _context.SaveChangesAsync();

                    data.Password = "";

                    ts.Complete();
                }

                return Ok(data);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
;
        }

        [HttpPut("update/status")]
        public async Task<ActionResult<User>> updateUserStatus(User data)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Uuid == data.Uuid);

            if (user == null)
            {
                return BadRequest(new ApiResponse("failed", "User UUID is not exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);

            user.UpdatedAt = DateTime.Now;
            user.UpdatedBy = _auth.Id;
            user.Status = data.Status;

            await _context.SaveChangesAsync();

            return Ok(user);
        }

        [HttpPost("to-roles/add")]
        public async Task<ActionResult<UsersToRole>> AddRole(UsersToRole json)
        {
            var data = _context.UsersToRoles.FirstOrDefaultAsync(x => x.UserId == json.UserId && x.RoleId == json.RoleId);

            if (data != null)
            {
                return BadRequest(new ApiResponse("failed", "Role is already exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);
            json.CreatedBy = _auth.Id;
            json.CreatedAt = DateTime.Now;

            _context.UsersToRoles.Add(json);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Inserted", new { id = json.Id }, json);
        }

        [HttpPost("to-roles/delete")]
        public async Task<IActionResult> DeletePages(UsersToRole json)
        {
            var data = await _context.UsersToRoles.FindAsync(json.Id);
            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "User is not exists.", "400"));
            }

            _context.UsersToRoles.Remove(json);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("roles")]
        public async Task<ActionResult<IEnumerable<UsersRole>>> GetUsersRoles()
        {
            return await _context.UsersRoles.ToListAsync();
        }

        [HttpGet("roles/{id}")]
        public async Task<ActionResult<UsersRole>> GetUsersRoles(short id)
        {
            var data = await _context.UsersRoles.FindAsync(id);

            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is not exists.", "400"));
            }

            return data;
        }

        [HttpPost("roles/add")]
        public async Task<ActionResult<UsersRole>> AddUsersRoles(UsersRole json)
        {
            var role = await _context.UsersRoles.FirstOrDefaultAsync(x => x.RoleName == json.RoleName);

            if (role != null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is already exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);

            json.CreatedAt = DateTime.Now;
            json.CreatedBy = _auth.Id;

            _context.UsersRoles.Add(json);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUsersRoles", new { id = json.Id }, json);
        }

        [HttpPut("roles/update")]
        public async Task<ActionResult<UsersRole>> UpdateUsersRoles(UsersRole json)
        {
            var userRoles = await _context.UsersRoles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == json.Id);

            if (userRoles == null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is not exists.", "400"));
            }

            userRoles = await _context.UsersRoles.AsNoTracking().FirstOrDefaultAsync(x => x.RoleName == json.RoleName && x.Id != json.Id);

            if (userRoles != null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is already exists.", "400"));
            }

            _context.Entry(json).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return Ok(json);
        }


        [HttpGet("pages")]
        public async Task<ActionResult<IEnumerable<UsersPage>>> GetUsersPages([FromQuery] PaginationFilter filter)
        {
            var pagedData = await _context.UsersPages
                                .Where(x =>
                                    (String.IsNullOrEmpty(filter.Search) ||
                                    (x.PageName.Contains(filter.Search) || x.PageTitle.Contains(filter.Search) ||
                                     x.PageUrl.Contains(filter.Search)
                                    )))
                                .OrderBy(x => x.PageName)
                                .Skip((filter.PageNumber - 1) * filter.PageSize)
                                .Take(filter.PageSize)
                                .ToListAsync();

            filter.TotalRecords = await _context.UsersPages
                                .Where(x =>
                                    (String.IsNullOrEmpty(filter.Search) ||
                                    (x.PageName.Contains(filter.Search) || x.PageTitle.Contains(filter.Search) ||
                                     x.PageUrl.Contains(filter.Search)
                                    )))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, filter));
        }

        [HttpGet("pages/{id}")]
        public async Task<ActionResult<UsersPage>> GetUsersPages(int id)
        {
            var data = await _context.UsersPages.FindAsync(id);

            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "Page is not exists.", "400"));
            }

            return data;
        }

        [HttpPost("pages/add")]
        public async Task<ActionResult<UsersPage>> AddPages(UsersPage json)
        {
            _auth = new CustomUserIdentity(this.User);

            json.CreatedAt = DateTime.Now;
            json.CreatedBy = _auth.Id;

            _context.UsersPages.Add(json);

            await _context.SaveChangesAsync();

            return Ok(json);
        }

        [HttpPut("pages/update")]
        public async Task<IActionResult> UpdatePages(UsersPage json)
        {
            var data = await _context.UsersPages.AsNoTracking().FirstOrDefaultAsync(x => x.Id == json.Id);
            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "Page is not exists.", "400"));
            }

            data = await _context.UsersPages.AsNoTracking().FirstOrDefaultAsync(x => x.PageName == json.PageName && x.Id != json.Id);

            if (data != null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is already exists.", "400"));
            }

            _context.Entry(json).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("pages/delete")]
        public async Task<IActionResult> DeletePages(UsersPage json)
        {
            var data = await _context.UsersPages.FindAsync(json.Id);
            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is not exists.", "400"));
            }

            var roles = await _context.UsersPagesToRoles.FirstOrDefaultAsync(x => x.PageId == json.Id);

            if (roles != null)
            {
                return BadRequest(new ApiResponse("failed", "Page already assigned to role.", "400"));
            }

            _context.UsersPages.Remove(data);

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("pages/to-roles/add")]
        public async Task<ActionResult<UsersPagesToRole>> AddPages(UsersPagesToRole json)
        {
            var data = _context.UsersPagesToRoles.FirstOrDefaultAsync(x => x.PageId == json.PageId && x.RoleId == json.RoleId);

            if (data != null)
            {
                return BadRequest(new ApiResponse("failed", "Page is already exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);
            json.CreatedBy = _auth.Id;
            json.CreatedAt = DateTime.Now;

            _context.UsersPagesToRoles.Add(json);
            await _context.SaveChangesAsync();

            return Ok(json);
        }

        [HttpDelete("pages/to-roles/delete")]
        public async Task<IActionResult> DeletePages(UsersPagesToRole json)
        {
            var data = await _context.UsersPagesToRoles.FindAsync(json.Id);
            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "Page is not exists.", "400"));
            }

            _context.UsersPagesToRoles.Remove(data);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("notify/session")]
        public async Task<ActionResult<UsersNotifySession>> AddUserNotifySession(UsersNotifySession json)
        {
            var data = _context.UsersNotifySessions.FirstOrDefaultAsync(x => x.UserId == json.UserId && x.SignalRSession == json.SignalRSession);

            if (data != null)
            {
                _context.Entry(json).State = EntityState.Modified;
                json.LastActiveAt = DateTime.Now;

                await _context.SaveChangesAsync();

                return BadRequest(new ApiResponse("failed", "Session is already exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);

            json.LastActiveAt = DateTime.Now;

            _context.UsersNotifySessions.Add(json);

            await _context.SaveChangesAsync();

            return Ok(json);
        }

        [HttpGet("positions")]
        public async Task<ActionResult<IEnumerable<object>>> GetUserPositions([FromQuery] PaginationFilter filter)
        {
            var pagedData = await _context.UsersPositions
                                .Where(x =>
                                    string.IsNullOrEmpty(filter.Search) ||
                                    x.Position.Contains(filter.Search))
                                .OrderByDescending(x => x.Position)
                                .Skip((filter.PageNumber - 1) * filter.PageSize)
                                .Take(filter.PageSize)
                                .ToListAsync();

            filter.TotalRecords = await _context.UsersPositions
                                .Where(x =>
                                    string.IsNullOrEmpty(filter.Search) ||
                                    x.Position.Contains(filter.Search))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, filter));

        }

        [HttpGet("positions/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetUserPositionsBasic([FromQuery] PaginationFilter? filter)
        {
            var pagedData = await _context.UsersPositions
                                .Where(x =>
                                    string.IsNullOrEmpty(filter.Search) ||
                                    x.Position.Contains(filter.Search) &&
                                    x.IsActive == true
                                    )
                                .OrderByDescending(x => x.Position)
                                .Skip((filter.PageNumber - 1) * filter.PageSize)
                                .Select(x => new
                                {
                                    Id = x.Id,
                                    Position = x.Position
                                })
                                .Take(filter.PageSize)
                                .ToListAsync();

            filter.TotalRecords = await _context.UsersPositions
                                .Where(x =>
                                    string.IsNullOrEmpty(filter.Search) ||
                                    x.Position.Contains(filter.Search) &&
                                    x.IsActive == true
                                    )
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, filter));

        }


        [HttpGet("positions/{id}")]
        public async Task<ActionResult<UsersPosition>> GetUsersPositions(int id)
        {
            var data = await _context.UsersPositions.FindAsync(id);

            if (data == null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is not exists.", "400"));
            }

            return data;
        }

        [HttpPost("positions/add")]
        public async Task<ActionResult<UsersPosition>> AddUsersPosition(UsersPosition json)
        {
            var role = await _context.UsersPositions.FirstOrDefaultAsync(x => x.Position.Trim().ToLower() == json.Position.Trim().ToLower());

            if (role != null)
            {
                return BadRequest(new ApiResponse("failed", "User Role is already exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);

            json.UpdatedAt = DateTime.Now;
            json.UpdatedBy = _auth.Id;

            _context.UsersPositions.Add(json);
            await _context.SaveChangesAsync();

            return Ok(json);
        }

        [HttpPut("positions/update")]
        public async Task<ActionResult<UsersPosition>> UpdateUsersPositions(UsersPosition json)
        {
            json.Position = json.Position.Trim();

            var userRoles = await _context.UsersPositions.FirstOrDefaultAsync(x =>
                    x.Position.Trim().ToLower() == json.Position.Trim().ToLower() &&
                    x.Id != json.Id);

            if (userRoles != null)
            {
                return BadRequest(new ApiResponse("failed", "Position is not exists.", "400"));
            }

            _auth = new CustomUserIdentity(this.User);

            json.UpdatedAt = DateTime.Now;
            json.UpdatedBy = _auth.Id;

            _context.Entry(json).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return Ok(json);
        }

        [HttpGet("departments")]
        public async Task<ActionResult<List<UsersDepartment>>> GetUserDepartment()
        {
            var data = await _context.UsersDepartments.Where(x => x.Status == 1).OrderBy(x => x.Department).ToListAsync();

            return data;
        }
        [HttpPut("resetUserPassword")]
        public async Task<IActionResult> ResetAllUserPassword(ClsLogin clsLogin)
        {
            Encryption enc = new Encryption();
            string default_pwd = "User@2021$";
            //string default_pwd = clsLogin.Password;

            try
            {
                var users = _context.Users.Where(x => x.Username.ToLower() == clsLogin.Username.ToLower()).Take(1).ToList();
                //var users = _context.Users.ToList();

                foreach (var user in users)
                {
                    string encrypt_pwd = enc.ComputeSha512Hash(user.Username + default_pwd);
                    user.Password = encrypt_pwd;
                    user.PasswordChangeAt = DateTime.Now;
                    user.UpdatedAt = DateTime.Now;
                    user.UpdatedBy = null;
                }

                try
                {
					var _user = new OauthUser { Username = clsLogin.Username, Password = default_pwd };

					await _clientApi.ResetPassword(_auth.SSOToken, _user);
				}
                finally
                {
					await _context.SaveChangesAsync();
				}

                

                return Ok("Successful");
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        [HttpPost("changePassword")]
        public async Task<IActionResult> ChangePassword(UserChangePassword user)
        {
			var _auth = new CustomUserIdentity(User);

			Encryption enc = new Encryption();

            var getUser = _context.Users.FirstOrDefault(x => x.Id == _auth.Id);

            if (getUser == null)
            {
                return BadRequest("User not found");
            }

            string encrypt_pwd = enc.ComputeSha512Hash(getUser.Username + user.OldPassword);

            if (encrypt_pwd != getUser.Password)
            {
                return BadRequest("Incorrect old password");
            }

            encrypt_pwd = enc.ComputeSha512Hash(getUser.Username + user.NewPassword);

            getUser.Password = encrypt_pwd;

            getUser.PasswordChangeAt = DateTime.Now;

            getUser.UpdatedBy = _auth.Id;

            getUser.UpdatedAt = DateTime.Now;

            try
            {
				try
				{
					var _user = new OauthUserPassword { CurrentPassword = user.OldPassword, Password = user.NewPassword };

					await _clientApi.ChangePassword(_auth.SSOToken, _user);

					//var _user = new OauthUser { Username = getUser.Username, Password = user.NewPassword };

					//await _clientApi.ResetPassword(_auth.SSOToken, _user);
				}
				finally
				{
					await _context.SaveChangesAsync();
				}

				return Ok("Successful");
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }


            return Ok();
        }

        [HttpGet("{id}/projects")]
        public async Task<ActionResult<IEnumerable<short?>>> GetAllProjectsByUser(int id)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.UsersToProjects
                .Where(x => x.UserId == id && x.CompanyId == user.CompanySessionId)
                .Select(x => x.ProjectId)
                .ToListAsync();
        }

        [HttpPut("{id}/projects/update")]
        public async Task<IActionResult> UpdateAssignUsersToProject(int id, List<int> proList)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            try
            {
                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_assign_user_to_project] {0},{1},{2}", user.CompanySessionId, id, string.Join(",", proList));

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("{id}/roles")]
        public async Task<ActionResult<IEnumerable<short?>>> GetAllProjectsByRole(int id)
        {
            return await _context.UsersToRoles
                .Where(x => x.UserId == id)
                .Select(x => x.RoleId)
                .ToListAsync();
        }

        [HttpPut("{id}/roles/update")]
        public async Task<IActionResult> UpdateAssignUsersToRole(int id, List<int> roleList)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            try
            {
                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_assign_user_to_role] {0},{1},{2}", user.CompanySessionId, id, string.Join(",", roleList));

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("roles/basic")]
        public async Task<ActionResult<IEnumerable<VUsersRolesBasic>>> GetAllProjectsByRoleBasic()
        {
            _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            return await _context.VUsersRolesBasics
                .AsNoTracking()
                .Where(s => (s.CompanyId == u.CompanySessionId))
                .ToListAsync();
        }
    }

    
}
