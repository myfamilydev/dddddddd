﻿using AP_Api.Models;
using Bogus.DataSets;
using BVMPP.ClientOauth;
using BVMPP.ClientOauth.Models;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Librabies;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NuGet.Common;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Ubiety.Dns.Core;
using static PO_Revamp.Controllers.AuthController;

namespace PO_Revamp.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly APContext _context;
        private readonly IConfiguration _config;
        private readonly HttpClient client = new HttpClient();

        private ClientApi _clientApi;
        private SDKConfiguration _SDKConfiguration;

        public AuthController(APContext context, IConfiguration config)
        {
            _context = context;
            _config = config;

            var clientId = _config.GetSection("SSO:ClientId").Value;
            var clientSecret = _config.GetSection("SSO:ClientSecret").Value;
            var redirectUri = _config.GetSection("SSO:RedirectUri").Value;
            _SDKConfiguration = new SDKConfiguration
            {
                ClienId = clientId,
                ClientSecret = clientSecret,
                RedirectUri = redirectUri,
                ProvideURL = _config.GetSection("SSO:Url").Value
            };

            _clientApi = new ClientApi(_SDKConfiguration);
        }

        [HttpPost("authenticate/onbehalf")]
        [Authorize(Roles = "master")]
        public async Task<ActionResult<AuthorizationModel>> AuthenticateAdmin(User users)
        {
            return await Authenticate(users);
        }

        [HttpPost("company/{id}/switch")]
        public async Task<ActionResult> SwitchCompany(int id)
        {
            var _auth = new CustomUserIdentity(this.User);

            var valid = await _context.Users.FindAsync(_auth.Id);

            valid.CompanySessionId = id;


            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpPost("authenticate")]
        public async Task<ActionResult<AuthorizationModel>> Authenticate(User users)
        {
            Encryption enc = new Encryption();

            string encrypt_pwd = enc.ComputeSha512Hash(users.Username + users.Password);



            var userLogin = _context.Users.FirstOrDefault(x => x.Username == users.Username.ToLower() && x.Password == encrypt_pwd && x.Status == 1);

            if (userLogin == null)
            {
                return BadRequest("You are not authorized!");
            }

            var user = _context.VUserLoggedIns.AsNoTracking().Where(x => x.Username == users.Username && x.Uuid == userLogin.Uuid).ToList();
            if (user.Count() == 0)
            {
                return BadRequest(new ApiResponse("failed", "User is not exists.", "400"));
            }

            int i = 0;

            AuthorizationModel am = new AuthorizationModel();
            am.users = await _context.Users.FindAsync(user.First().Id);

            List<Claim> claims = new List<Claim>();
            string pre_role = "";
            List<object> auth_role = new List<object>();

            foreach (var item in user)
            {
                if (i == 0)
                {
                    claims.Add(new Claim(ClaimTypes.Name, item.FullName));
                    claims.Add(new Claim(ClaimTypes.Email, item.Email));
                    claims.Add(new Claim(ClaimTypes.NameIdentifier, Convert.ToString(item.Id)));
                    i++;
                }

                if (!String.IsNullOrEmpty(item.Auth) && !pre_role.Equals(item.Auth))
                {
                    pre_role = item.Auth;

                    var auths = item.Auth.Split(","); // multiple auth role
                    foreach (var auth in auths)
                    {
                        if (auth != "")
                        {
                            claims.Add(new Claim(ClaimTypes.Role, auth));
                            auth_role.Add(new { auth_role = auth });
                        }
                    }
                }
            }

            am.activate = true;

            //var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.GetSection("AppSettings:Token").Value));
            var key = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_config["Jwt:Secret"]));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

            var tokenDecriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims.ToArray()),
                Expires = DateTime.Now.AddDays(10),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDecriptor);

            am.token = tokenHandler.WriteToken(token);
            am.authorizedPageActions = auth_role;

            am.companies = await _context.VUsersCompanies
                            .AsNoTracking()
                            .Where(x => x.UserId == userLogin.Id)
                            .ToListAsync();

            am.authorizedPages =
                   await _context.VUsersPages.Where(x => x.UserId == am.users.Id || x.UserId == null)
                        .Select(s => new VUsersPage
                        {
                            Id = s.Id,
                            Title = s.Title,
                            PageName = s.PageName,
                            Url = s.Url,
                            Icon = s.Icon,
                            Type = s.Type,
                            ParentId = s.ParentId,
                            RecStatus = s.RecStatus,
                            Ordering = s.Ordering,
                            CreatedBy = s.CreatedBy,
                            CreatedAt = s.CreatedAt,
                            UserId = 0
                        }).Distinct().ToListAsync();

            am.permissions = await _context.VUsersGroupsPermisssions
                            .Where(x => x.UserGroupId == am.users.UserGroupId)
                            .Select(x => x.Name)
                            .ToListAsync();

            return am;

        }


        private async Task<ActionResult<AuthorizationModel>> AuthenticateSSO(User users, string ssoToken)
        {
            Encryption enc = new Encryption();

            string encrypt_pwd = users.Password;

            var userLogin = _context.Users.FirstOrDefault(x => x.Username == users.Username && x.Status == 1);

            if (userLogin == null)
            {
                return BadRequest("You are not authorized!");
            }

            userLogin.SsoToken = ssoToken;

            _context.Entry(userLogin).State = EntityState.Modified;

            await _context.SaveChangesAsync();


            var user = _context.VUserLoggedIns.AsNoTracking().Where(x => x.Username == users.Username && x.Uuid == userLogin.Uuid).ToList();
            if (user.Count() == 0)
            {
                return BadRequest(new ApiResponse("failed", "User is not exists.", "400"));
            }

            int i = 0;

            AuthorizationModel am = new AuthorizationModel();
            am.users = await _context.Users.FindAsync(user.First().Id);

            List<Claim> claims = new List<Claim>();
            string pre_role = "";
            List<object> auth_role = new List<object>();

            claims.Add(new Claim("sso_token", ssoToken));
            am.activate = true;

            foreach (var item in user)
            {
                if (i == 0)
                {
                    claims.Add(new Claim(ClaimTypes.Name, item.FullName));
                    claims.Add(new Claim(ClaimTypes.Email, item.Email));
                    claims.Add(new Claim(ClaimTypes.NameIdentifier, Convert.ToString(item.Id)));
                    i++;
                }

                if (!String.IsNullOrEmpty(item.Auth) && !pre_role.Equals(item.Auth))
                {
                    pre_role = item.Auth;

                    var auths = item.Auth.Split(","); // multiple auth role
                    foreach (var auth in auths)
                    {
                        if (auth != "")
                        {
                            claims.Add(new Claim(ClaimTypes.Role, auth));
                            auth_role.Add(new { auth_role = auth });
                        }
                    }
                }
            }

            var key = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_config["Jwt:Secret"]));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);

            var tokenDecriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims.ToArray()),
                Expires = DateTime.Now.AddDays(10),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDecriptor);

            am.token = tokenHandler.WriteToken(token);
            am.authorizedPageActions = auth_role;

            am.companies = await _context.VUsersCompanies
                            .AsNoTracking()
                            .Where(x => x.UserId == userLogin.Id)
                            .ToListAsync();

            am.authorizedPages =
                   await _context.VUsersPages.Where(x => x.UserId == am.users.Id || x.UserId == null)
                        .Select(s => new VUsersPage
                        {
                            Id = s.Id,
                            Title = s.Title,
                            PageName = s.PageName,
                            Url = s.Url,
                            Icon = s.Icon,
                            Type = s.Type,
                            ParentId = s.ParentId,
                            RecStatus = s.RecStatus,
                            Ordering = s.Ordering,
                            CreatedBy = s.CreatedBy,
                            CreatedAt = s.CreatedAt,
                            UserId = 0
                        }).Distinct().ToListAsync();

            am.permissions = await _context.VUsersGroupsPermisssions
                            .Where(x => x.UserGroupId == am.users.UserGroupId)
                            .Select(x => x.Name)
                            .ToListAsync();
            am.ssoToken = ssoToken;

            return am;

        }

        [HttpPost("sso")]
        public async Task<ActionResult<AuthorizationModel>> GetSSO(VeriedCode veriedCode)
        {
            try
            {
                _SDKConfiguration.RedirectUri = veriedCode.RedirectUri;

                _clientApi = new ClientApi(_SDKConfiguration);

                SSOAccessOwner oauthToken = await _clientApi.GetSSOAccessOwner(veriedCode.Code);

                var user = await _context.Users.FirstOrDefaultAsync(x => x.Username == oauthToken.Username && x.Status == 1);

                if (user == null)
                {

                    AuthorizationModel am = new AuthorizationModel();
                    var users = new User();
                    users.Username = oauthToken.Username;
                    users.Email = oauthToken.Email;
  

                    am.activate = false;
                    am.ssoToken = oauthToken.AccessToken;
                    am.users = users;



                    return am;
                }

                return await AuthenticateSSO(user, oauthToken.AccessToken);

            } catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpPost("sso/activate")]
        public async Task<ActionResult<AuthorizationModel>> Activate(ClsSSOLogin sSOLogin)
        {
            try
            {

                sSOLogin.Username = sSOLogin.Username.ToLower().Trim();

                var user_exists = await _context.Users.FirstOrDefaultAsync(x => x.Username == sSOLogin.Username && x.Status == 1);

                if (user_exists != null)
                {
                    return await AuthenticateSSO(user_exists, sSOLogin.Token);
                }

                var user = new User();

                user.Username = sSOLogin.Username;

                user.FullName = sSOLogin.Username;

                user.Email = sSOLogin.Email;

                user.Uuid = Guid.NewGuid();

                user.UserGroupId = 2;

                user.CompanySessionId = 1;

                user.PhoneNumber = null;

                user.Password = null;

                user.Status = 1;

                _context.Users.Add(user);

                await _context.SaveChangesAsync();

                var users = await _context.Users.FirstOrDefaultAsync(x => x.Username == sSOLogin.Username && x.Status == 1);

                return await AuthenticateSSO(users, sSOLogin.Token);

            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpGet("sso/sync/{id}")]
        public async Task<ActionResult> GetSSOSync(int id)
        {
            
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (user == null)
            {
                return BadRequest(new ApiResponse("failed", "Invalid Id"));
            }
            _context.Entry(user).State = EntityState.Modified;

            user.SsoSyncAt = DateTime.Now;

            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _auth.SSOToken);

            try
            {
                var _user = new OauthUser { Email = user.Email, Username = user.Username, Password = "1234567" };

                ResJson data = await _clientApi.SyncUser(_auth.SSOToken, _user);

                if (data != null)
                {
                    user.SsoId = data.data.id;
                }
            }
            finally
            {
                await _context.SaveChangesAsync();
            }

            return Ok();
        }

        public class VeriedCode
        {
            public string Code { get; set; }

            public string? RedirectUri { get; set; }
        }
    }
}

    