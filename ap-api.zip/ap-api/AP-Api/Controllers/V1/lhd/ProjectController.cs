﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.LHDEntities;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DataAccess.Models;
using System.IO;

namespace Web.Controllers.LHD
{
    [Route("api/v1/lhd/project")]
    [ApiController]
    [Authorize]
    public class ProjectController : ControllerBase
    {
        private readonly LHDContext _context;
        private readonly APContext _apcontext;

        public ProjectController(LHDContext context, APContext aPContext)
        {
            _context = context;
            _apcontext = aPContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllProjectAsync([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;

            var _auth = new CustomUserIdentity(User);

            var user = await _apcontext.Users.FindAsync(_auth.Id);

            var pagedData = _context.VProjects
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (String.IsNullOrEmpty(filter.Search)
                           || s.NameKh.Contains(filter.Search)
                           || s.Name.Contains(filter.Search)
                           || s.Company.Contains(filter.Search)
                           || s.ProjectAbbr.Contains(filter.Search)
                           || s.ProjectCode.Contains(filter.Search)
                           || s.ProjectShort.Contains(filter.Search)
                           || s.Remark.Contains(filter.Search)) && s.Status == 1)
                           .OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VProjects
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (String.IsNullOrEmpty(filter.Search)
                           || s.NameKh.Contains(filter.Search)
                           || s.Name.Contains(filter.Search)
                           || s.Company.Contains(filter.Search)
                           || s.ProjectAbbr.Contains(filter.Search)
                           || s.ProjectCode.Contains(filter.Search)
                           || s.ProjectShort.Contains(filter.Search)
                           || s.Remark.Contains(filter.Search)) && s.Status == 1 )
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VProject>> GetProjectAsync(int id)
        {
            var data = await _context.VProjects.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Project>> AddProjectAsync(Project data)
        {
            var _auth = new CustomUserIdentity(User);


            bool valid = await _context.VProjects.AnyAsync(x => (x.Name.ToLower().Trim() == data.Name.ToLower().Trim()
            || x.ProjectCode.ToLower().Trim() == data.ProjectCode.ToLower().Trim()
            || x.ProjectShort.ToLower().Trim() == data.ProjectShort.ToLower().Trim()
            || x.ProjectAbbr.ToLower().Trim() == data.ProjectAbbr.ToLower().Trim()) && x.CompanyId == data.CompanyId);

            if(valid)
            {
                return BadRequest(new ApiResponse("failed", "Project is already exists!", "400"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = 1;

            _context.Projects.Add(data);

            await _context.SaveChangesAsync();

            return data;

        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateProjectAsync(Project data)
        {
            var validData = await _context.Projects.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (validData == null)
            {
                return BadRequest();
            }

            bool valid = await _context.VProjects.AnyAsync(x => (x.Name.ToLower().Trim() == data.Name.ToLower().Trim()
            || x.ProjectCode.ToLower().Trim() == data.ProjectCode.ToLower().Trim()
            || x.ProjectShort.ToLower().Trim() == data.ProjectShort.ToLower().Trim()
            || x.ProjectAbbr.ToLower().Trim() == data.ProjectAbbr.ToLower().Trim()) && x.Id != data.Id && x.CompanyId == data.CompanyId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Project is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.Id = validData.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteProjectAsync(int id)
        {

            var valid = await _context.Projects.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            var validAR = await _context.VProjects.AsNoTracking().AnyAsync(x => x.Id == id && x.Status == 1 && x.Editable == 0);

            if(validAR)
            {
                return BadRequest(new ApiResponse("failed", "Project is locked!", "400"));
            }

            if (valid == null)
            {
                return BadRequest();
            }

            valid.Status = 0;


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }
    }
}
