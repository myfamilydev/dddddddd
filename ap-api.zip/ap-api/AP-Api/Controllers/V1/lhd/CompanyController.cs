﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.LHDEntities;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DataAccess.Models;
using System.IO;

namespace Web.Controllers.LHD
{
    [Route("api/v1/lhd/company")]
    [ApiController]
    [Authorize]
    public class CompanyController : ControllerBase
    {
        private readonly LHDContext _context;
        private readonly APContext _apcontext;

        public CompanyController(LHDContext context, APContext apcontext)
        {
            _context = context;
            _apcontext = apcontext; 
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllCompanyAsync([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;

            var pagedData = _context.Companies
                           .Where(s => String.IsNullOrEmpty(filter.Search)
                           || s.NameKh.Contains(filter.Search)
                           || s.NameEn.Contains(filter.Search)
                           || s.Address.Contains(filter.Search)
                           || s.ContractNo.Contains(filter.Search)
                           || s.VatNo.Contains(filter.Search)
                           || s.RegisterNo.Contains(filter.Search)
                           || s.Remark.Contains(filter.Search))
                           .OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.Companies
                           .Where(s => String.IsNullOrEmpty(filter.Search)
                           || s.NameKh.Contains(filter.Search)
                           || s.NameEn.Contains(filter.Search)
                           || s.Address.Contains(filter.Search)
                           || s.ContractNo.Contains(filter.Search)
                           || s.VatNo.Contains(filter.Search)
                           || s.RegisterNo.Contains(filter.Search)
                           || s.Remark.Contains(filter.Search))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetCompanyBasicAsync()
        {
            return await _context.VCompaniesBasics.ToListAsync();

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Company>> GetCompanyAsync(int id)
        {
            var data = await _context.Companies.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Company>> AddCompanyAsync(Company data)
        {
            

            bool valid = await _context.Companies.AnyAsync(x => x.NameEn.ToLower().Trim() == data.NameEn.ToLower().Trim());

            if(valid)
            {
                return BadRequest(new ApiResponse("failed", "Company is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.Companies.Add(data);

            await _context.SaveChangesAsync();

            return data;

        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateCompanyAsync(Company data)
        {
            var validData = await _context.Companies.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (validData == null)
            {
                return BadRequest();
            }

            bool valid = await _context.Companies.AnyAsync(x => x.NameEn.ToLower().Trim() == data.NameEn.ToLower().Trim() && data.Id != x.Id);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Company is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.Id = validData.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteCompanyAsync(int id)
        {
            var valid = await _context.Companies.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Companies.Remove(valid);


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }
    }
}
