﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.LHDEntities;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DataAccess.Models;
using System.IO;

namespace Web.Controllers.LHD
{
    [Route("api/v1/lhd/holiday")]
    [ApiController]
    [Authorize]
    public class HolidayController : ControllerBase
    {
        private readonly LHDContext _context;

        private readonly APContext _apContext;

        public HolidayController(LHDContext context, APContext apContext)
        {
            _context = context;
            _apContext = apContext;
            var db = _context.Database.GetConnectionString();
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllHolidayAsync([FromQuery] PaginationFilter filter)
        {

            var _auth = new CustomUserIdentity(User);

            var u = await _apContext.Users.FindAsync(_auth.Id);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.Holidays
                           .Where(s => (s.CompanyId == u.CompanySessionId && s.Status == true && (String.IsNullOrEmpty(filter.Search) || s.HolidayName.Contains(filter.Search))))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.Holidays
                           .Where(s => (s.CompanyId == u.CompanySessionId && s.Status == true && (String.IsNullOrEmpty(filter.Search) || s.HolidayName.Contains(filter.Search))))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Holiday>> GetHolidayAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apContext.Users.FindAsync(_auth.Id);

            var data = await _context.Holidays.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == u.CompanySessionId && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Holiday>> AddHolidayAsync(Holiday data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apContext.Users.FindAsync(_auth.Id);


            bool valid = await _context.Holidays.AnyAsync(x => (x.HolidayName == data.HolidayName || x.HolidayDate.Date == data.HolidayDate.Date) && x.CompanyId == u.CompanySessionId && x.Status == true);

            if(valid)
            {
                return BadRequest(new ApiResponse("failed", "Holiday date is already exists!", "400"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            data.CompanyId = u.CompanySessionId;

            _context.Holidays.Add(data);

            await _context.SaveChangesAsync();

            return data;

        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateHolidayAsync(Holiday data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apContext.Users.FindAsync(_auth.Id);

            var validData = await _context.Holidays.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == u.CompanySessionId &&  x.Status == true);

            if (validData == null)
            {
                return BadRequest();
            }

            bool valid = await _context.Holidays.AnyAsync(x => (x.HolidayName == data.HolidayName || x.HolidayDate.Date == data.HolidayDate.Date) && data.Id != x.Id && x.CompanyId == u.CompanySessionId && x.Status == true);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Holiday date is already exists!", "400"));
            }


            data.Id = validData.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteHolidayAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apContext.Users.FindAsync(_auth.Id);
            

            var valid = await _context.Holidays.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == u.CompanySessionId &&  x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;


            try
            {
                await _context.SaveChangesAsync();

                await _apContext.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }
    }
}
