﻿using DataAccess.DBcontext;
using DataAccess.Models.Filter;
using DataAccess.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataAccess.LHDEntities;
using DataAccess.dbcontext;

namespace AP_Api.Controllers.V1.lhd
{
    [Route("api/v1/lhd/houseList")]
    [ApiController]
    public class HouseListController : ControllerBase
    {
        private readonly LHDContext _context;
        private readonly APContext _apcontext;

        public HouseListController(LHDContext context, APContext apcontext)
        {
            _context = context;
            _apcontext = apcontext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllHouseListAsync([FromQuery] PaginationFilter filter)
        {

            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

			var list = new List<short>();

			if (filter.ProId == 0)
            {
				list = _apcontext.VDbliveProjects
				.FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
				.AsEnumerable()
				.Select(x => x.Id)
				 .ToList();
			}


			var pagedData = _context.VHouseLists
                           .Where(s => (s.CompanyId == u.CompanySessionId && s.Status == 1 && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                           || s.HouseType.Contains(filter.Search)
                           || s.HouseNumber.Contains(filter.Search))))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VHouseLists
                           .Where(s => (s.CompanyId == u.CompanySessionId && s.Status == 1 && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                           || s.HouseType.Contains(filter.Search)
                           || s.HouseNumber.Contains(filter.Search))))
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<House>> GetHouseListAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);

            var data = await _context.Houses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == u.CompanySessionId && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetHouseListBasicAsync()
        {
            return await _context.VHouseLists.ToListAsync();

        }

        [HttpPost("add")]
        public async Task<ActionResult<House>> AddHouseListAsync(House data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);


            bool valid = await _context.Houses.AnyAsync(x => (x.Number == data.Number) && x.CompanyId == u.CompanySessionId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "House list is already exists!", "400"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = u.CompanySessionId;

            _context.Houses.Add(data);

            data.Status = 1;

            data.RecStatus = 0;

            await _context.SaveChangesAsync();

            return data;

        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateHouseListAsync(House data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);

            var validData = await _context.Houses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == u.CompanySessionId);

            if (validData == null)
            {
                return BadRequest();
            }

            bool valid = await _context.VHouses.AnyAsync(x => (x.Number == data.Number) && x.CompanyId == u.CompanySessionId && x.Id != data.Id);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "House list is already exists!", "400"));
            }


            data.Id = validData.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteHouseListAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);


            var valid = await _context.Houses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == u.CompanySessionId && x.Status == 1);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = 0;


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }


    }
}
