﻿using DataAccess.DBcontext;
using DataAccess.Models.Filter;
using DataAccess.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataAccess.LHDEntities;
using DataAccess.dbcontext;

namespace AP_Api.Controllers.V1.lhd
{
    [Route("api/v1/lhd/houseCategories")]
    [ApiController]
    public class HouseCategoriesController : ControllerBase
    {
        private readonly LHDContext _context;
        private readonly APContext _apcontext;

        public HouseCategoriesController(LHDContext context, APContext apcontext)
        {
            _context = context;
            _apcontext = apcontext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllHouseCategoriesAsync([FromQuery] PaginationFilter filter)
        {

            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

			var list = new List<short>();

			if (filter.ProId == 0)
            {
				list = _apcontext.VDbliveProjects
				.FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
				.AsEnumerable()
				.Select(x => x.Id)
				 .ToList();
			}


			var pagedData = _context.VHouseCategoriesLists
                           .Where(s => (s.CompanyId == u.CompanySessionId && s.Status == 1 && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                           || s.CategoryName.Contains(filter.Search))))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VHouseCategoriesLists
                           .Where(s => (s.CompanyId == u.CompanySessionId && s.Status == 1 && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                           || s.CategoryName.Contains(filter.Search)))).CountAsync();
                                

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<HouseCategory>> GetHouseCategoriesAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);

            var data = await _context.HouseCategories.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == u.CompanySessionId && x.Status == 1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetHouseCategoriesBasicAsync()
        {
            return await _context.VHouseCategoriesLists.ToListAsync();

        }

        [HttpPost("add")]
        public async Task<ActionResult<HouseCategory>> AddHouseCategoriesAsync(HouseCategory data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);


            bool valid = await _context.VHouseCategories.AnyAsync(x => (x.Name == data.Name) && x.CompanyId == u.CompanySessionId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "House category is already exists!", "400"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = u.CompanySessionId;

            _context.HouseCategories.Add(data);

            data.Status = 1;

            await _context.SaveChangesAsync();

            return data;

        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateHouseCategoriesAsync(HouseCategory data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);

            var validData = await _context.HouseCategories.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == u.CompanySessionId);

            if (validData == null)
            {
                return BadRequest();
            }

            bool valid = await _context.VHouseCategories.AnyAsync(x => (x.Name == data.Name) && x.CompanyId == u.CompanySessionId && x.Id != data.Id);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "House category is already exists!", "400"));
            }


            data.Id = validData.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteHouseCategoriesAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _apcontext.Users.FindAsync(_auth.Id);


            var valid = await _context.HouseCategories.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == u.CompanySessionId && x.Status == 1);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = 0;


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

    }

}
