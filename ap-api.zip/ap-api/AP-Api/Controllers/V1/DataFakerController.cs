﻿using AP_Api.Services;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.FakeData;
using DataAccess.Models;
using LiteDB.Engine;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using OneSignalApi.Client;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Utilities.Zlib;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace AP_Api.Controllers.V1
{
    [Route("api/v1/data-faker")]
    [ApiController]
    public class DataFakerController : ControllerBase
    {
        private readonly HttpClient client = new HttpClient();

        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private readonly BackgroundWorkerQueue _backgroundWorkerQueue;
        private readonly IServiceScopeFactory serviceScopeFactory;
        public DataFakerController(APContext context, ManualDbContext manualDbContext, IServiceScopeFactory serviceScopeFactory)
        {
            _context = context;
            _manualDbContext = manualDbContext;
            this.serviceScopeFactory = serviceScopeFactory;
        }

        [HttpGet("generatedatafake")]
        public async Task<IActionResult> getAllTest()
        {
            Task.Run(() => BgTask(serviceScopeFactory));

            return Ok();
        }

        private async Task BgTask(IServiceScopeFactory serviceScopeFactory)
        {
            using (var scope = serviceScopeFactory.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetService<APContext>();

                try
                {
                    dbContext.Database.ExecuteSqlRaw(@"exec dbo.sp_truck_data");
                }
                catch (Exception ex) { }

                dbContext.ChartAccounts.AddRange(FakeDataTest.GenerateChartOfAccount(30));

                await dbContext.SaveChangesAsync();

                var list = await dbContext.ChartAccounts.Select(x => x.Id).ToListAsync();

                dbContext.VendorsItems.AddRange(FakeDataTest.GenerateVendorItem(30, list));

                await dbContext.SaveChangesAsync();

                dbContext.Vendors.AddRange(FakeDataTest.GenerateVendor(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContracts.AddRange(FakeDataTest.GenerateVendorContract(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContractsItems.AddRange(FakeDataTest.GenerateVendorContractItems(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContractsMasters.AddRange(FakeDataTest.GenerateVendorContractMasters(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContractsPrices.AddRange(FakeDataTest.GenerateVendorContractPrices(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContractsPriceItems.AddRange(FakeDataTest.GenerateVendorContractPriceItems(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContractsPaymentTerms.AddRange(FakeDataTest.GenerateVendorContractPaymentTerm(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsContractsPaymentTermsItems.AddRange(FakeDataTest.GenerateVendorContractPaymentTermItems(30));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsLaborCovers.AddRange(FakeDataTest.GenerateVendorsLaborCover(20));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsLaborCoversItems.AddRange(FakeDataTest.GenerateVendorsLaborCoverItem(20));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsSettlementSubs.AddRange(FakeDataTest.GenerateVendorsSettlementSub(20));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsSettlementSubItems.AddRange(FakeDataTest.GenerateVendorsSettlementSubItem(20));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsSettlementLabs.AddRange(FakeDataTest.GenerateVendorsSettlementLab(20));

                await dbContext.SaveChangesAsync();

                dbContext.VendorsSettlementLabItems.AddRange(FakeDataTest.GenerateVendorsSettlementLabItem(20));

                await dbContext.SaveChangesAsync();

                dbContext.ReceivedDocuments.AddRange(FakeDataTest.GenerateReceivedDocument(20));

                await dbContext.SaveChangesAsync();
            }
        }

    }


    
}
