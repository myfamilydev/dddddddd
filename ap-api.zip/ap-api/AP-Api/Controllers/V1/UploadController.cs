﻿using DataAccess.Models;
using LiteDB.Engine;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Utilities.Zlib;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;

namespace AP_Api.Controllers.V1
{
    [Route("api/v1/file-upload")]
    [ApiController]
    public class UploadController : ControllerBase
    {
        private readonly HttpClient client = new HttpClient();

        [HttpPost("{folder}")]
        public async Task<ActionResult<UplodResponse>> UploadFile(IFormFile file, string folder)
        {
            var stream = new StreamContent(file.OpenReadStream());

            stream.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);

            using var content = new MultipartFormDataContent
            {
                { stream, "file", file.FileName }
            };



            var response = await client.PostAsync("http://apps.vmpp.com/file-server/api/v1/file-upload/" + folder, content);

            UplodResponse res = await response.Content.ReadAsAsync<UplodResponse>();

            return res;

        }
    }


    public class UplodResponse
    {
        public string Message { get; set; } = "";

        public string Url { get; set; } = "";

        public string Original { get; set; } = string.Empty;
    }
}
