﻿using AP_Api.Helpers;
using AP_Api.Models;
using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual_report/print")]
    [ApiController]
    [Authorize]
    public class PrintReportManualController : ControllerBase
    {
        private readonly APContext _context;

        private readonly ManualDbContext _manualDbContext;

        public PrintReportManualController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }
        [HttpGet("manual_sale_report/{id}")]
        public async Task<ActionResult<object>> GetManualSaleRportAsync(int id)
        {
            var manualSaleReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_sale_report]  {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualSaleDetailReport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_sale_detail_report] {id}")
                .ToList();

            return Ok(
                new
                {
                    manualSaleReport = manualSaleReport,
                    manualSaleDetailReport = manualSaleDetailReport

                }); ;
        }

        [HttpGet("manual_material_stock_report/{id}")]
        public async Task<ActionResult<object>> GetManualMaterialStockRportAsync(int id)
        {
            var manualMaterialStockRport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_material_stock_report]  {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualMaterialStockDetailRport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_material_stock_detail_report] {id}")
                .ToList();

            return Ok(
                new
                {
                    manualMaterialStockRport = manualMaterialStockRport,
                    manualMaterialStockDetailRport = manualMaterialStockDetailRport

                }); ;
        }

        [HttpGet("manual_loan_balance_report/{id}")]
        public async Task<ActionResult<object>> GetManualLoanBalanceReportAsync(int id)
        {
            var manualLoanBalanceReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_loan_balance_report]   {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualLoanBalanceDetailRport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_loan_balance_detail_report]  {id}")
                .ToList();

            return Ok(
                new
                {
                    manualLoanBalanceReport = manualLoanBalanceReport,
                    manualLoanBalanceDetailRport = manualLoanBalanceDetailRport

                }); ;
        }

        [HttpGet("manual_spa_report/{id}")]
        public async Task<ActionResult<object>> GetManualSpaReportAsync(int id)
        {
            var manualSpaReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_spa_report]   {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualSpaDetailRport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_spa_detail_report]  {id}")
                .ToList();

            return Ok(
                new
                {
                    manualSpaReport = manualSpaReport,
                    manualSpaDetailRport = manualSpaDetailRport

                }); ;
        }

        [HttpGet("manual_credit_control_report/{id}")]
        public async Task<ActionResult<object>> GetManualCreditControllReportAsync(int id)
        {
            var manualCreditControlReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_credit_control_report]   {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualCreditControlDetailRport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_credit_control_detail_report]  {id}");

            return Ok(
                new
                {
                    manualCreditControlReport = manualCreditControlReport,
                    manualCreditControlDetailRport = manualCreditControlDetailRport,

                }); ;
        }

        [HttpGet("manual-interest-income-expense-report/{id}")]
        public async Task<ActionResult<object>> GetManualInterestIncomeExpenseReportAsync(int id)
        {
            var manualInterestIncomeExpenseReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_interest_income_expense_report]   {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualInterestIncomeExpenseDetailRport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_interest_income_expense_detail_report]  {id}")
                .ToList();

            return Ok(
                new
                {
                    manualInterestIncomeExpenseReport = manualInterestIncomeExpenseReport,
                    manualInterestIncomeExpenseDetailRport = manualInterestIncomeExpenseDetailRport

                }); ;
        }


        [HttpGet("manual_collection_report/{id}")]
        public async Task<ActionResult<object>> GetManualCollectionReportAsync(int id)
        {
            var manualCollectionReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_collection_report]   {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualCollectionDetailRport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_collection_detail_report]  {id}")
                .ToList();

            return Ok(
                new
                {
                    manualCollectionReport = manualCollectionReport,
                    manualCollectionDetailRport = manualCollectionDetailRport

                });
        }

        [HttpGet("manual-summary-report/{id}")]
        public async Task<ActionResult<object>> GetManualSummaryReportAsync(int id)
        {
            var manualSummaryReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_summary_report]   {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualSummaryDetailReport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_summary_detail_report]  {id}")
                .ToList();

            return Ok(
                new
                {
                    manualSummaryReport = manualSummaryReport,
                    manualSummaryDetailReport = manualSummaryDetailReport

                });
        }

        [HttpGet("manual_monthly_salary_expense_ab_report/{id}")]
        public async Task<ActionResult<object>> GetManualSalaryExpenseABRportAsync(int id)
        {
            var manualMonthlySalaryExpenseABReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_monthly_salary_expense_ab_report]  {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualMonthlySalaryExpenseABDetailReport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_monthly_salary_expense_ab_detail_report] {id}")
                .ToList();

            return Ok(
                new
                {
                    manualMonthlySalaryExpenseABReport = manualMonthlySalaryExpenseABReport,
                    manualMonthlySalaryExpenseABDetailReport = manualMonthlySalaryExpenseABDetailReport

                }); ;
        }

        [HttpGet("manual_monthly_salary_expense_a_report/{id}")]
        public async Task<ActionResult<object>> GetManualSalaryExpenseARportAsync(int id)
        {
            var manualMonthlySalaryExpenseAReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_monthly_salary_expense_a_report]  {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualMonthlySalaryExpenseADetailReport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_monthly_salary_expense_a_detail_report] {id}")
                .ToList();

            return Ok(
                new
                {
                    manualMonthlySalaryExpenseAReport = manualMonthlySalaryExpenseAReport,
                    manualMonthlySalaryExpenseADetailReport = manualMonthlySalaryExpenseADetailReport

                }); ;
        }

        [HttpGet("manual_monthly_salary_expense_b_report/{id}")]
        public async Task<ActionResult<object>> GetManualSalaryExpenseBRportAsync(int id)
        {
            var manualMonthlySalaryExpenseBReport = _manualDbContext.ExecuteQuery($"exec [report].[sp_get_print_manual_monthly_salary_expense_b_report]  {id}")
                .AsEnumerable()
                .FirstOrDefault();

            var manualMonthlySalaryExpenseBDetailReport = _manualDbContext
                .ExecuteQuery($"exec [report].[sp_get_print_manual_monthly_salary_expense_b_detail_report] {id}")
                .ToList();

            return Ok(
                new
                {
                    manualMonthlySalaryExpenseBReport = manualMonthlySalaryExpenseBReport,
                    manualMonthlySalaryExpenseBDetailReport = manualMonthlySalaryExpenseBDetailReport

                }); ;
        }

        [HttpPost("manual-report-all")]
        public async Task<ActionResult<object>> GetManualReportAllAsync(ClsManualReportAll clsManualReportAll)
        {

            var manualSaleReport = _context.ExecuteQuery($"exec [report].[manual_sale_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualMaterialReport = _context.ExecuteQuery($"exec [report].[manual_material_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualLoanBalanceReport = _context.ExecuteQuery($"exec [report].[manual_loan_balance_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualSPAReport = _context.ExecuteQuery($"exec [report].[manual_spa_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualInterestIncomeReport = _context.ExecuteQuery($"exec [report].[manual_interest_income_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualCredditControlReport = _context.ExecuteQuery($"exec [report].[manual_credit_control_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualSummaryReport = _context.ExecuteQuery($"exec [report].[manual_summary_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualCollectionReport = _context.ExecuteQuery($"exec [report].[manual_collection_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var netContractTermination = _context.ExecuteQuery($"exec  [report].[sp_net_contracts_termination] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualMonthlySalaryExpenseABReport = _context.ExecuteQuery($"exec  [report].[manual_monthly_salary_expense_ab_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualMonthlySalaryExpenseAReport = _context.ExecuteQuery($"exec  [report].[manual_monthly_salary_expense_a_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");
            var manualMonthlySalaryExpenseBReport = _context.ExecuteQuery($"exec  [report].[manual_monthly_salary_expense_b_report_by_owner] '{clsManualReportAll.Date.ToString("yyyy-MM-dd")}', {clsManualReportAll.Ownership}");

            return Ok(new
            {
                manualSaleReport = manualSaleReport,
                manualMaterialReport = manualMaterialReport,
                manualLoanBalanceReport = manualLoanBalanceReport,
                manualSPAReport = manualSPAReport,
                manualInterestIncomeReport = manualInterestIncomeReport,
                manualCredditControlReport = manualCredditControlReport,
                manualSummaryReport = manualSummaryReport,
                manualCollectionReport = manualCollectionReport,
                netContractTermination = netContractTermination,
                reportDate = clsManualReportAll.Date.ToString("yyyy-MM-dd"),
                ownerShip = clsManualReportAll.Ownership,
                manualMonthlySalaryExpenseABReport = manualMonthlySalaryExpenseABReport,
                manualMonthlySalaryExpenseAReport = manualMonthlySalaryExpenseAReport,
                manualMonthlySalaryExpenseBReport = manualMonthlySalaryExpenseBReport,
            });
        }

        [HttpPost("manual-report-all/export-pdf")]
        public async Task<ActionResult<object>> GetManualReportAllPdfExport(ClsManualReportAll clsManualReportAll)
        {
            //try
            //{
            //    var app = new Microsoft.Office.Interop.Word.Application();
            //    var doc = app.Documents.Add();
            //    var rng = doc.Range(0, 0);
            //    rng.Text="hello world";
            //    doc.SaveAs2("d:\\test.pdf", Microsoft.Office.Interop.Word.WdSaveFormat.wdFormatPDF);
            //    doc.Close();
            //}
            //catch(Exception ex)
            //{
            //    return BadRequest(ex.Message);
            //}
            return null;



        }
    }
}
