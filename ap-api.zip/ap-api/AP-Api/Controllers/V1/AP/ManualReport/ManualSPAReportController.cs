﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualSPAReportController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualSPAReportController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-spa-report")]
        public async Task<ActionResult<IEnumerable<ManualSpaReport>>> GetAllManualSpaReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualSpaReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualSpaReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-spa-report/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetSpaReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.ManualSpaReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("report.manual_spa_report", ((int)data.Id), _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }




        [HttpPost("manual-spa-report/add")]
        public async Task<ActionResult<ManualSpaReport>> AddManualSpaReport(ManualSpaReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;
            data.RecStatus = 0;


            _context.ManualSpaReports.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("report.manual_spa_report", ((int)data.Id), _auth.Id);
            return data;
        }


        [HttpPut("manual-spa-report/update")]
        public async Task<IActionResult> UpdateManualSpaReport(ManualSpaReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualSpaReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpDelete("manual-spa-report/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteManualSpaReport(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "report.manual_spa_report", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("manual-spa-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<VManualSpaDetailReport>>> GetManualSpaReportDetail(int id)
        {
            return await _context.VManualSpaDetailReports
                           .Where(s => s.ManualSpaReportId == id)
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
        }

        [HttpGet("manual-spa-detail-report/{id}")]
        public async Task<ActionResult<VManualSpaDetailReport>> GetManualSpaReportDetailById(int id)
        {
            var data = await _context.VManualSpaDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("manual-spa-detail-report/add")]
        public async Task<ActionResult<ManualSpaDetailReport>> AddManualSpaDetailReport(ManualSpaDetailReport data, int? Id = null)
        {
            _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            //var exist = await _context.ManualSpaDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualSpaReportId == data.ManualSpaReportId);

            //if (exist != null)
            //{
            //    return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            //}

            _context.ManualSpaDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-spa-detail-report/update")]
        public async Task<IActionResult> UpdateManualSpaDetailReport(ManualSpaDetailReport data)
        {
            var valid = await _context.ManualSpaDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)

            {
                return BadRequest();
            }
            //var exist = await _context.ManualSpaDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualSpaReportId == data.ManualSpaReportId && x.Id != data.Id);

            //if (exist != null)
            //{
            //    return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            //}
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.UpdatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            //data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NoContent();
            }
            return Ok();
        }

        [HttpDelete("manual-spa-detail-report/{id}/delete")]
        public async Task<IActionResult> DeleteManualSpaDetailReport(int id)
        {
            var data_delete = await _context.ManualSpaDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualSpaDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                return NoContent();
            }
            return Ok();
        }

        [HttpPost("manual-spa-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportSPAReport(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            var bankList = await _context.Banks.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    var projectAll = await _context.VDbliveProjects.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();

                    while (reader.Read()) //Each ROW
                    {


                        var project = reader.GetValue(0)?.ToString();
                        var bank = reader.GetValue(1)?.ToString();
                        var spaAmount = decimal.Parse(reader.GetValue(2)?.ToString());
                        var spaLoanAmount = decimal.Parse(reader.GetValue(3)?.ToString());
                        var totalBuyBackAmount = decimal.Parse(reader.GetValue(4)?.ToString());
                        
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualSpaDetailReport spa = new ManualSpaDetailReport();
                        var pro = projectAll.FirstOrDefault(x => x.ProjectShort == project);
                        if (pro == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Project is not found!", "400"));
                        }
                        //var exist = await _context.ManualSpaDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == pro.Id && x.ManualSpaReportId == id);
                        //if (exist != null)
                        //{
                        //    return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
                        //}

                        var bankInfo = bankList.FirstOrDefault(x => x.BankName == bank);

                        if (bankInfo == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Bank is not found!", "400"));
                        }
                        //ccr.CompanyId = u.CompanySessionId;
                        spa.ProId = pro.Id;
                        spa.ManualSpaReportId = id;
                        spa.BankId = bankInfo.Id;
                        spa.SpaAmount = spaAmount;
                        spa.SpaLoanAmount = spaLoanAmount;
                        spa.TotalBuyBackAmount = totalBuyBackAmount;                      
                        spa.InsertType = "import";
                        spa.CreatedBy = _auth.Id;
                        _context.ManualSpaDetailReports.Add(spa);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }


    }
}
