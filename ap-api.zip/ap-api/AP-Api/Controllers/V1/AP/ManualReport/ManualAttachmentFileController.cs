﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualAttachmentController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualAttachmentController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-attach-file")]
        public async Task<ActionResult<IEnumerable<ManualAttachmentFile>>> GetManualAttachFile([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualAttachmentFiles
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.AttachFileName.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualAttachmentFiles
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.AttachFileName.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-attach-file/{id}")]
        public async Task<ActionResult<ManualAttachmentFile>> GetManualAttachFileById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualAttachmentFiles.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("manual-attach-file/add")]
        public async Task<ActionResult<ManualAttachmentFile>> AddManualAttachFile(ManualAttachmentFile data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;

            _context.ManualAttachmentFiles.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("manual-attach-file/update")]
        public async Task<IActionResult> UpdateManualAttachFile(ManualAttachmentFile data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualAttachmentFiles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-attach-file/{id}/delete")]
        public async Task<IActionResult> DeleteManualAttachFile(int id)
        {
            var data_delete = await _context.ManualAttachmentFiles.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualAttachmentFiles.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

    }
}
