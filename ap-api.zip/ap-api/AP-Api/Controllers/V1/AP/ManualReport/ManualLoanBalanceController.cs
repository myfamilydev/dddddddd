﻿using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualLoanBalanceController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualLoanBalanceController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-loan-balance-report")]
        public async Task<ActionResult<IEnumerable<ManualLoanBalanceReport>>> GetManualLoanBalanceReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualLoanBalanceReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualLoanBalanceReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-loan-balance-report/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetLoanBalnceReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.ManualLoanBalanceReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("report.manual_loan_balance_report", ((int)data.Id), _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }

        [HttpPost("manual-loan-balance-report/add")]
        public async Task<ActionResult<ManualLoanBalanceReport>> AddManualLoanBalanceReport(ManualLoanBalanceReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;
            data.RecStatus = 0;


            _context.ManualLoanBalanceReports.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("report.manual_loan_balance_report", ((int)data.Id), _auth.Id);
            return data;
        }

        [HttpPut("manual-loan-balance-report/update")]
        public async Task<IActionResult> UpdateManualLoanBalanceReport(ManualLoanBalanceReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualLoanBalanceReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-loan-balance-report/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteManualLoanBalanceReport(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "report.manual_loan_balance_report", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("manual-loan-balance-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<VManualLoanBalanceDetailReport>>> GetManualLoanBalanceReportDetail(int id)
        {
            return await _context.VManualLoanBalanceDetailReports
                           .Where(s => s.ManualLoanBalanceReportId == id)
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
        }

        [HttpGet("manual-loan-balance-report/detail/{id}")]
        public async Task<ActionResult<VManualLoanBalanceDetailReport>> GetManualLoanBalanceReportDetailById(int id)
        {
            var data = await _context.VManualLoanBalanceDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }



        [HttpPost("manual-loan-balance-report/detail/add")]
        public async Task<ActionResult<ManualLoanBalanceDetailReport>> AddManualLoanBalanceDetailReport(ManualLoanBalanceDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            //var exist = await _context.ManualLoanBalanceDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualLoanBalanceReportId == data.ManualLoanBalanceReportId);

            //if (exist != null)
            //{
            //    return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            //}

            _context.ManualLoanBalanceDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-loan-balance-report/detail/update")]
        public async Task<IActionResult> UpdateManualLoanBalanceDetailReport(ManualLoanBalanceDetailReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualLoanBalanceDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            //var exist = await _context.ManualLoanBalanceDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualLoanBalanceReportId == data.ManualLoanBalanceReportId && x.Id != data.Id);

            //if (exist != null)
            //{
            //    return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            //}

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualLoanBalanceReportId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-loan-balance-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteManualLoanBalanceDetailReport(int id)
        {
            var data_delete = await _context.ManualLoanBalanceDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualLoanBalanceDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-loan-balance-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportLoanBalanceReport(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            var bankList = await _context.Banks.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    var projectAll = await _context.VDbliveProjects.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
                   
                    while (reader.Read()) //Each ROW
                    {
                        

                        var project = reader.GetValue(0)?.ToString();                      
                        var bank = reader.GetValue(1)?.ToString();
                        var location = (reader.GetValue(2)?.ToString());
                        var loanTittleDeed = (reader.GetValue(3)?.ToString());
                        var projectType = (reader.GetValue(4)?.ToString());
                        var interestRate = decimal.Parse(reader.GetValue(5)?.ToString());
                        var loanAmount = decimal.Parse(reader.GetValue(6)?.ToString());
                        var repaymentAmount = decimal.Parse(reader.GetValue(7)?.ToString());
                        var osMount = decimal.Parse(reader.GetValue(8)?.ToString());
                        var startingDate = DateTime.Parse(reader.GetValue(9)?.ToString());
                        var maturityDate = DateTime.Parse(reader.GetValue(10)?.ToString());
                        var duration = decimal.Parse(reader.GetValue(11)?.ToString());
                        var durationPaid = decimal.Parse(reader.GetValue(12)?.ToString());
                        var remainingYear = decimal.Parse(reader.GetValue(13)?.ToString());
                        var lockPeriod = (reader.GetValue(14)?.ToString());
                        var remarkEn = (reader.GetValue(15)?.ToString());
                        var remarkKh = (reader.GetValue(16)?.ToString());
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualLoanBalanceDetailReport lb = new ManualLoanBalanceDetailReport();
                        var pro = projectAll.FirstOrDefault(x => x.ProjectShort == project);
                        if (pro == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Project is not found!", "400"));
                        }
                        //var exist = await _context.ManualLoanBalanceDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == pro.Id && x.ManualLoanBalanceReportId == id);
                        //if (exist != null)
                        //{
                        //    return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
                        //}

                        var bankInfo = bankList.FirstOrDefault(x => x.BankName == bank);

                        if (bankInfo == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Bank is not found!", "400"));
                        }
                        lb.CompanyId = u.CompanySessionId;
                        lb.ProId = pro.Id;
                        lb.ManualLoanBalanceReportId = id;
                        lb.BankId = bankInfo.Id;
                        lb.Location = location;
                        lb.LoanTittleDeed = loanTittleDeed;
                        lb.ProjectType = projectType;
                        lb.InterestRate = interestRate;
                        lb.LoanAmount = loanAmount;
                        lb.RepaymentAmount = repaymentAmount;
                        lb.OsMount = osMount;
                        lb.StartingDate = startingDate;
                        lb.MaturityDate = maturityDate;
                        lb.Duration = duration;
                        lb.DurationPaid = durationPaid;
                        lb.RemainingYear = remainingYear;
                        lb.LockPeriod = lockPeriod;
                        lb.RemarkEn = remarkEn;
                        lb.RemarkKh= remarkKh;
                        lb.InsertType = "import";
                        lb.CreatedBy = _auth.Id;
                        _context.ManualLoanBalanceDetailReports.Add(lb);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }
    }
}
