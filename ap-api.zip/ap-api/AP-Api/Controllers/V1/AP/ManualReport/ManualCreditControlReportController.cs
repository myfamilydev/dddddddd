﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.LHDEntities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualCreditControlReportController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualCreditControlReportController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-credit-control-report")]
        public async Task<ActionResult<IEnumerable<ManualCreditControlReport>>> GetManualCreditControlReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualCreditControlReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualCreditControlReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-credit-control-report/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetCreditControlReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.ManualCreditControlReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("report.manual_credit_control_report", ((int)data.Id), _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }

        [HttpPost("manual-credit-control-report/add")]
        public async Task<ActionResult<ManualCreditControlReport>> AddManualCreditControlReport(ManualCreditControlReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;
            data.RecStatus = 0;


            _context.ManualCreditControlReports.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("report.manual_credit_control_report", ((int)data.Id), _auth.Id);
            return data;
        }

        [HttpPut("manual-credit-control-report/update")]
        public async Task<IActionResult> UpdateManualCreditControlReport(ManualCreditControlReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualCreditControlReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-credit-control-report/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteManualCreditControlReport(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "report.manual_credit_control_report", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("manual-credit-control-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<VManualCreditControlDetailReport>>> GetManualCreditControlReportDetail(int id)
        {
            return await _context.VManualCreditControlDetailReports
                           .Where(s => s.ManualCreditControlId == id)
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
        }

        [HttpGet("manual-credit-control-report/detail/{id}")]
        public async Task<ActionResult<VManualCreditControlDetailReport>> GetManualCreditControlReportDetailById(int id)
        {
            var data = await _context.VManualCreditControlDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("manual-credit-control-report/detail/add")]
        public async Task<ActionResult<ManualCreditControlDetailReport>> AddManualCreditControlDetailReport(ManualCreditControlDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.InsertType = "form";

            var exist = await _context.ManualCreditControlDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualCreditControlId == data.ManualCreditControlId);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            _context.ManualCreditControlDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-credit-control-report/detail/update")]
        public async Task<IActionResult> UpdateManualCreditControlDetailReport(ManualCreditControlDetailReport data)
        {
            var _auth = new CustomUserIdentity(User);

            var valid = await _context.ManualCreditControlDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            var exist = await _context.ManualCreditControlDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualCreditControlId == data.ManualCreditControlId && x.Id != data.Id);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualCreditControlId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-credit-control-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteManualCreditControlDetailReport(int id)
        {
            var data_delete = await _context.ManualCreditControlDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualCreditControlDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-credit-control-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportCreditControlReport(int id,IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    var projectAll = await _context.VDbliveProjects.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
                    while (reader.Read()) //Each ROW
                    {
                        var project = reader.GetValue(0)?.ToString();
                        var contractedHouseLand = decimal.Parse(reader.GetValue(1)?.ToString());
                        var totalOverdue = decimal.Parse(reader.GetValue(2)?.ToString());
                        var totalPenalty = decimal.Parse(reader.GetValue(3)?.ToString());
                        var overduePayment = decimal.Parse(reader.GetValue(4)?.ToString());
                        var penaltyAmountPaid = decimal.Parse(reader.GetValue(5)?.ToString());
                        var overdueHouse = decimal.Parse(reader.GetValue(6)?.ToString());
                        var overdueHouseOne = decimal.Parse(reader.GetValue(7)?.ToString());
                        var overdueHouseTwo = decimal.Parse(reader.GetValue(8)?.ToString());
                        var overdueHouseThree = decimal.Parse(reader.GetValue(9)?.ToString());
                        var overdueHouseFour = decimal.Parse(reader.GetValue(10)?.ToString());
                        var penaltyAmount = decimal.Parse(reader.GetValue(11)?.ToString());
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualCreditControlDetailReport ccr = new ManualCreditControlDetailReport();
                        var pro = projectAll.FirstOrDefault(x => x.ProjectShort == project);
                        if(pro == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Project is not found!", "400"));
                        }
                        var exist = await _context.ManualCreditControlDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == pro.Id && x.ManualCreditControlId == id);
                        if (exist != null)
                        {
                            return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
                        }
                        ccr.CompanyId = u.CompanySessionId;
                        ccr.ProId = pro.Id;
                        ccr.ManualCreditControlId = id;
                        ccr.ContractedHouseLand = contractedHouseLand;
                        ccr.TotalOverdue = totalOverdue;
                        ccr.TotalPenalty = totalPenalty;
                        ccr.OverduePayment = overduePayment;
                        ccr.PenaltyAmountPaid = penaltyAmountPaid;
                        ccr.OverdueHouse = overdueHouse;
                        ccr.OverdueHouseOne = overdueHouseOne;
                        ccr.OverdueHouseTwo = overdueHouseTwo;
                        ccr.OverdueHouseThree = overdueHouseThree;
                        ccr.OverdueHouseFour = overdueHouseThree;
                        ccr.PenaltyAmount = penaltyAmount;
                        ccr.InsertType = "import";
                        ccr.CreatedBy = _auth.Id;
                        _context.ManualCreditControlDetailReports.Add(ccr);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }
    }
}
