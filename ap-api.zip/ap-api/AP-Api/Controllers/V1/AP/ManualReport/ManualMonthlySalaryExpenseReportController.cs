﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualMonthlySalaryExpenseReportController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualMonthlySalaryExpenseReportController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        //Monthly salary expense A+B report

        [HttpGet("manual-monthly-salary-expense-ab-report")]
        public async Task<ActionResult<IEnumerable<ManualMonthlySalaryExpenseAbReport>>> GetManualMonthlySalaryExpenseAbReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMonthlySalaryExpenseAbReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualMonthlySalaryExpenseAbReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-monthly-salary-expense-ab-report/{id}")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseAbReport>> GetMonthlySalaryExpenseAbReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMonthlySalaryExpenseAbReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }
            return data;
        }

        [HttpPost("manual-monthly-salary-expense-ab-report/add")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseAbReport>> AddMonthlySalaryExpenseAbReport(ManualMonthlySalaryExpenseAbReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;


            _context.ManualMonthlySalaryExpenseAbReports.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("manual-monthly-salary-expense-ab-report/update")]
        public async Task<IActionResult> UpdateMonthlySalaryExpenseAbReport(ManualMonthlySalaryExpenseAbReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualMonthlySalaryExpenseAbReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-monthly-salary-expense-ab-report/{id}/delete")]
        public async Task<IActionResult> DeleteMonthlySalaryExpenseAbReport(int id)
        {
            var data_delete = await _context.ManualMonthlySalaryExpenseAbReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMonthlySalaryExpenseAbReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpGet("manual-monthly-salary-expense-ab-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<ManualMonthlySalaryExpenseAbDetailReport>>> GetMonthlySalaryExpenseAbReportDetail(int id)
        {
            return await _context.ManualMonthlySalaryExpenseAbDetailReports
                           .Where(s => s.ManualMonthlySalaryExpenseAbReportId == id)
                           .OrderBy(x => x.CreatedAt)
                           .ToListAsync();
        }

        [HttpGet("manual-monthly-salary-expense-ab-report/detail/{id}")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseAbDetailReport>> GetMonthlySalaryExpenseAbReportDetailById(int id)
        {
            var data = await _context.ManualMonthlySalaryExpenseAbDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }



        [HttpPost("manual-monthly-salary-expense-ab-report/detail/add")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseAbDetailReport>> AddMonthlySalaryExpenseAbReportDetail(ManualMonthlySalaryExpenseAbDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.ManualMonthlySalaryExpenseAbDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-monthly-salary-expense-ab-report/detail/update")]
        public async Task<IActionResult> UpdateMonthlySalaryExpenseAbReportDetail(ManualMonthlySalaryExpenseAbDetailReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualMonthlySalaryExpenseAbDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualMonthlySalaryExpenseAbReportId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-monthly-salary-expense-ab-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteMonthlySalaryExpenseAbReportDetail(int id)
        {
            var data_delete = await _context.ManualMonthlySalaryExpenseAbDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMonthlySalaryExpenseAbDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-monthly-salary-expense-ab-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportMonthlySalaryExpenseAbReportDetail(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    while (reader.Read()) //Each ROW
                    {
                        var descriptionEn = reader.GetValue(0)?.ToString();
                        var descriptionKh = reader.GetValue(1)?.ToString();
                        var noStaffAb = decimal.Parse(reader.GetValue(2)?.ToString());
                        var expenseAb = decimal.Parse(reader.GetValue(3)?.ToString());
                        var noStaffShare = decimal.Parse(reader.GetValue(4)?.ToString());
                        var expenseShare = decimal.Parse(reader.GetValue(5)?.ToString());
                        var totalStaff = decimal.Parse(reader.GetValue(6)?.ToString());
                        var totalExpense = decimal.Parse(reader.GetValue(7)?.ToString());
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualMonthlySalaryExpenseAbDetailReport mseab = new ManualMonthlySalaryExpenseAbDetailReport();

                        mseab.CompanyId = u.CompanySessionId;
                        mseab.ManualMonthlySalaryExpenseAbReportId = id;
                        mseab.DescriptionEn = descriptionEn;
                        mseab.DescriptionKh = descriptionKh;
                        mseab.NoStaffAb = noStaffAb;
                        mseab.ExpenseAb = expenseAb;
                        mseab.NoStaffShare = noStaffShare;
                        mseab.ExpenseShare = expenseShare;
                        mseab.TotalStaff = totalStaff;
                        mseab.TotalExpense = totalExpense;
                        mseab.InsertType = "import";
                        mseab.CreatedBy = _auth.Id;
                        _context.ManualMonthlySalaryExpenseAbDetailReports.Add(mseab);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

        //Monthly salary expense A report

        [HttpGet("manual-monthly-salary-expense-a-report")]
        public async Task<ActionResult<IEnumerable<ManualMonthlySalaryExpenseAReport>>> GetManualMonthlySalaryExpenseAReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMonthlySalaryExpenseAReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualMonthlySalaryExpenseAReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-monthly-salary-expense-a-report/{id}")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseAReport>> GetMonthlySalaryExpenseAReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMonthlySalaryExpenseAReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }
            return data;
        }

        [HttpPost("manual-monthly-salary-expense-a-report/add")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseAReport>> AddMonthlySalaryExpenseAReport(ManualMonthlySalaryExpenseAReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;


            _context.ManualMonthlySalaryExpenseAReports.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("manual-monthly-salary-expense-a-report/update")]
        public async Task<IActionResult> UpdateMonthlySalaryExpenseAReport(ManualMonthlySalaryExpenseAReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualMonthlySalaryExpenseAReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-monthly-salary-expense-a-report/{id}/delete")]
        public async Task<IActionResult> DeleteMonthlySalaryExpenseAReport(int id)
        {
            var data_delete = await _context.ManualMonthlySalaryExpenseAbReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMonthlySalaryExpenseAbReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpGet("manual-monthly-salary-expense-a-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<ManualMonthlySalaryExpenseADetailReport>>> GetMonthlySalaryExpenseAReportDetail(int id)
        {
            return await _context.ManualMonthlySalaryExpenseADetailReports
                           .Where(s => s.ManualMonthlySalaryExpenseAReportId == id)
                           .OrderBy(x => x.CreatedAt)
                           .ToListAsync();
        }

        [HttpGet("manual-monthly-salary-expense-a-report/detail/{id}")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseADetailReport>> GetMonthlySalaryExpenseAReportDetailById(int id)
        {
            var data = await _context.ManualMonthlySalaryExpenseADetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }



        [HttpPost("manual-monthly-salary-expense-a-report/detail/add")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseADetailReport>> AddMonthlySalaryExpenseAReportDetail(ManualMonthlySalaryExpenseADetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.ManualMonthlySalaryExpenseADetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-monthly-salary-expense-a-report/detail/update")]
        public async Task<IActionResult> UpdateMonthlySalaryExpenseAReportDetail(ManualMonthlySalaryExpenseADetailReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualMonthlySalaryExpenseADetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualMonthlySalaryExpenseAReportId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-monthly-salary-expense-a-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteMonthlySalaryExpenseAReportDetail(int id)
        {
            var data_delete = await _context.ManualMonthlySalaryExpenseADetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMonthlySalaryExpenseADetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-monthly-salary-expense-a-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportMonthlySalaryExpenseAReportDetail(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    while (reader.Read()) //Each ROW
                    {
                        var descriptionEn = reader.GetValue(0)?.ToString();
                        var descriptionKh = reader.GetValue(1)?.ToString();
                        var noStaffAb = decimal.Parse(reader.GetValue(2)?.ToString());
                        var expenseAb = decimal.Parse(reader.GetValue(3)?.ToString());
                        var noStaffShare = decimal.Parse(reader.GetValue(4)?.ToString());
                        var expenseShare = decimal.Parse(reader.GetValue(5)?.ToString());
                        var totalStaff = decimal.Parse(reader.GetValue(6)?.ToString());
                        var totalExpense = decimal.Parse(reader.GetValue(7)?.ToString());
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualMonthlySalaryExpenseADetailReport msea = new ManualMonthlySalaryExpenseADetailReport();

                        msea.CompanyId = u.CompanySessionId;
                        msea.ManualMonthlySalaryExpenseAReportId = id;
                        msea.DescriptionEn = descriptionEn;
                        msea.DescriptionKh = descriptionKh;
                        msea.NoStaffAb = noStaffAb;
                        msea.ExpenseAb = expenseAb;
                        msea.NoStaffShare = noStaffShare;
                        msea.ExpenseShare = expenseShare;
                        msea.TotalStaff = totalStaff;
                        msea.TotalExpense = totalExpense;
                        msea.InsertType = "import";
                        msea.CreatedBy = _auth.Id;
                        _context.ManualMonthlySalaryExpenseADetailReports.Add(msea);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

        //Monthly salary expense B report

        [HttpGet("manual-monthly-salary-expense-b-report")]
        public async Task<ActionResult<IEnumerable<ManualMonthlySalaryExpenseBReport>>> GetManualMonthlySalaryExpenseBReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMonthlySalaryExpenseBReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualMonthlySalaryExpenseBReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-monthly-salary-expense-b-report/{id}")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseBReport>> GetMonthlySalaryExpenseBReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMonthlySalaryExpenseBReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }
            return data;
        }

        [HttpPost("manual-monthly-salary-expense-b-report/add")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseBReport>> AddMonthlySalaryExpenseBReport(ManualMonthlySalaryExpenseBReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;


            _context.ManualMonthlySalaryExpenseBReports.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("manual-monthly-salary-expense-b-report/update")]
        public async Task<IActionResult> UpdateMonthlySalaryExpenseBReport(ManualMonthlySalaryExpenseBReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualMonthlySalaryExpenseBReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-monthly-salary-expense-b-report/{id}/delete")]
        public async Task<IActionResult> DeleteMonthlySalaryExpenseBReport(int id)
        {
            var data_delete = await _context.ManualMonthlySalaryExpenseBReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMonthlySalaryExpenseBReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpGet("manual-monthly-salary-expense-b-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<ManualMonthlySalaryExpenseBDetailReport>>> GetMonthlySalaryExpenseBReportDetail(int id)
        {
            return await _context.ManualMonthlySalaryExpenseBDetailReports
                           .Where(s => s.ManualMonthlySalaryExpenseBReportId == id)
                           .OrderBy(x => x.CreatedAt)
                           .ToListAsync();
        }

        [HttpGet("manual-monthly-salary-expense-b-report/detail/{id}")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseBDetailReport>> GetMonthlySalaryExpenseBReportDetailById(int id)
        {
            var data = await _context.ManualMonthlySalaryExpenseBDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }



        [HttpPost("manual-monthly-salary-expense-b-report/detail/add")]
        public async Task<ActionResult<ManualMonthlySalaryExpenseBDetailReport>> AddMonthlySalaryExpenseBReportDetail(ManualMonthlySalaryExpenseBDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.ManualMonthlySalaryExpenseBDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-monthly-salary-expense-b-report/detail/update")]
        public async Task<IActionResult> UpdateMonthlySalaryExpenseBReportDetail(ManualMonthlySalaryExpenseBDetailReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualMonthlySalaryExpenseBDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualMonthlySalaryExpenseBReportId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-monthly-salary-expense-b-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteMonthlySalaryExpenseBReportDetail(int id)
        {
            var data_delete = await _context.ManualMonthlySalaryExpenseBDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMonthlySalaryExpenseBDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-monthly-salary-expense-b-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportMonthlySalaryExpenseBReportDetail(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    while (reader.Read()) //Each ROW
                    {
                        var descriptionEn = reader.GetValue(0)?.ToString();
                        var descriptionKh = reader.GetValue(1)?.ToString();
                        var noStaffAb = decimal.Parse(reader.GetValue(2)?.ToString());
                        var expenseAb = decimal.Parse(reader.GetValue(3)?.ToString());
                        var noStaffShare = decimal.Parse(reader.GetValue(4)?.ToString());
                        var expenseShare = decimal.Parse(reader.GetValue(5)?.ToString());
                        var totalStaff = decimal.Parse(reader.GetValue(6)?.ToString());
                        var totalExpense = decimal.Parse(reader.GetValue(7)?.ToString());
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualMonthlySalaryExpenseBDetailReport mseb = new ManualMonthlySalaryExpenseBDetailReport();

                        mseb.CompanyId = u.CompanySessionId;
                        mseb.ManualMonthlySalaryExpenseBReportId = id;
                        mseb.DescriptionEn = descriptionEn;
                        mseb.DescriptionKh = descriptionKh;
                        mseb.NoStaffAb = noStaffAb;
                        mseb.ExpenseAb = expenseAb;
                        mseb.NoStaffShare = noStaffShare;
                        mseb.ExpenseShare = expenseShare;
                        mseb.TotalStaff = totalStaff;
                        mseb.TotalExpense = totalExpense;
                        mseb.InsertType = "import";
                        mseb.CreatedBy = _auth.Id;
                        _context.ManualMonthlySalaryExpenseBDetailReports.Add(mseb);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

    }
}
