﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualInterestIncomeExpenseReportController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualInterestIncomeExpenseReportController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-interest-income-expense-report")]
        public async Task<ActionResult<IEnumerable<ManualInterestIncomeExpenseReport>>> GetManualInterestIncomeExpenseReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualInterestIncomeExpenseReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualInterestIncomeExpenseReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-interest-income-expense-report/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetIIEReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.ManualInterestIncomeExpenseReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("report.manual_interest_income_expense_report", ((int)data.Id), _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }

        [HttpPost("manual-interest-income-expense-report/add")]
        public async Task<ActionResult<ManualInterestIncomeExpenseReport>> AddManualIIEReport(ManualInterestIncomeExpenseReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;
            data.RecStatus = 0;


            _context.ManualInterestIncomeExpenseReports.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("report.manual_interest_income_expense_report", ((int)data.Id), _auth.Id);
            return data;
        }

        [HttpPut("manual-interest-income-expense-report/update")]
        public async Task<IActionResult> UpdateManualIIEReport(ManualInterestIncomeExpenseReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualInterestIncomeExpenseReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-interest-income-expense-report/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteManualIIEReport(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "report.manual_interest_income_expense_report", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("manual-interest-income-expense-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<VManualInterestIncomeExpenseDetailReport>>> GetManualInterestIncomeReportDetail(int id)
        {
            return await _context.VManualInterestIncomeExpenseDetailReports
                           .Where(s => s.ManualIieReportId == id)
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
        }

        [HttpGet("manual-interest-income-expense-report/detail/{id}")]
        public async Task<ActionResult<VManualInterestIncomeExpenseDetailReport>> GetManualInterestIncomeReportDetailById(int id)
        {
            var data = await _context.VManualInterestIncomeExpenseDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }



        [HttpPost("manual-interest-income-expense-report/detail/add")]
        public async Task<ActionResult<ManualInterestIncomeExpenseDetailReport>> AddManualInterestInterestIncomeDetailReport(ManualInterestIncomeExpenseDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            var exist = await _context.ManualInterestIncomeExpenseDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualIieReportId == data.ManualIieReportId);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            _context.ManualInterestIncomeExpenseDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-interest-income-expense-report/detail/update")]
        public async Task<IActionResult> UpdateManualInterestIncomeExpenseDetailReport(ManualInterestIncomeExpenseDetailReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualInterestIncomeExpenseDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            var exist = await _context.ManualInterestIncomeExpenseDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualIieReportId == data.ManualIieReportId && x.Id != data.Id);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualIieReportId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-interest-income-expense-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteManualInterestIncomeDetailReport(int id)
        {
            var data_delete = await _context.ManualInterestIncomeExpenseDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualInterestIncomeExpenseDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-interest-income-expense-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportInterestIncomeExpenseReport(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            //var bankList = await _context.Banks.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    var projectAll = await _context.VDbliveProjects.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();

                    while (reader.Read()) //Each ROW
                    {


                        var project = reader.GetValue(0)?.ToString();

                        var totalInterestIncome = decimal.Parse(reader.GetValue(1)?.ToString());
                        var totalInterestAndWithhodingTaxExpense = decimal.Parse(reader.GetValue(2)?.ToString());
                        var remarkEn = reader.GetValue(3)?.ToString();
                        var remarkKh = reader.GetValue(4)?.ToString();

                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualInterestIncomeExpenseDetailReport iie = new ManualInterestIncomeExpenseDetailReport();
                        var pro = projectAll.FirstOrDefault(x => x.ProjectShort == project);
                        if (pro == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Project is not found!", "400"));
                        }
                        var exist = await _context.ManualInterestIncomeExpenseDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == pro.Id && x.ManualIieReportId == id);
                        if (exist != null)
                        {
                            return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
                        }

                        //var bankInfo = bankList.FirstOrDefault(x => x.BankName == bank);

                        //if (bankInfo == null)
                        //{
                        //    return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Bank is not found!", "400"));
                        //}
                        //ccr.CompanyId = u.CompanySessionId;
                        iie.ProId = pro.Id;
                        iie.ManualIieReportId = id;
                        iie.TotalInterestInome = totalInterestIncome;
                        iie.TotaIInterestHoldTax = totalInterestAndWithhodingTaxExpense;
                        iie.RemarkEn = remarkEn;
                        iie.RemarkKh = remarkKh;
                        iie.InsertType = "import";
                        iie.CreatedBy = _auth.Id;
                        _context.ManualInterestIncomeExpenseDetailReports.Add(iie);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

    }
}
