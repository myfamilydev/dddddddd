﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualSaleReportController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualSaleReportController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-sale-report")]
        public async Task<ActionResult<IEnumerable<ManualSaleReport>>> GetManualSaleReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualSaleReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualSaleReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-sale-report/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetSaleReportByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.ManualSaleReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("report.manual_sale_report", ((int)data.Id), _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }

        [HttpPost("manual-sale-report/add")]
        public async Task<ActionResult<ManualSaleReport>> AddManualSaleReport(ManualSaleReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;
            data.RecStatus = 0;


            _context.ManualSaleReports.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("report.manual_sale_report", ((int)data.Id), _auth.Id);
            return data;
        }

        [HttpPut("manual-sale-report/update")]
        public async Task<IActionResult> UpdateManualSaleReport(ManualSaleReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualSaleReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-sale-report/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteManualSaleReport(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "report.manual_sale_report", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("manual-sale-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<VManualSaleDetailReport>>> GetManualSaleReportDetail(int id)
        {
            return await _context.VManualSaleDetailReports
                           .Where(s => s.ManualSaleReportId == id)
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
        }

        [HttpGet("manual-sale-report/detail/{id}")]
        public async Task<ActionResult<VManualSaleDetailReport>> GetManualSaleReportDetailById(int id)
        {
            var data = await _context.VManualSaleDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }



        [HttpPost("manual-sale-report/detail/add")]
        public async Task<ActionResult<ManualSaleDetailReport>> AddManualSaleDetailReport(ManualSaleDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            var exist = await _context.ManualSaleDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualSaleReportId == data.ManualSaleReportId);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            _context.ManualSaleDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }

        [HttpPut("manual-sale-report/detail/update")]
        public async Task<IActionResult> UpdateManualSaleDetailReport(ManualSaleDetailReport data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ManualSaleDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            var exist = await _context.ManualSaleDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualSaleReportId == data.ManualSaleReportId && x.Id != data.Id);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ManualSaleReportId).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("manual-sale-report/detail/{id}/delete")]
        public async Task<IActionResult> DeleteManualSaleDetailReport(int id)
        {
            var data_delete = await _context.ManualSaleDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualSaleDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

        [HttpPost("manual-sale-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportSaleReport(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    var projectAll = await _context.VDbliveProjects.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
                    while (reader.Read()) //Each ROW
                    {
                        var project = reader.GetValue(0)?.ToString();
                        var totalHouseLand = decimal.Parse(reader.GetValue(1)?.ToString());
                        var totalHouseLandSal = decimal.Parse(reader.GetValue(2)?.ToString());
                        var totalHouseLandSold = decimal.Parse(reader.GetValue(3)?.ToString());
                        var bookingNoContracted = decimal.Parse(reader.GetValue(4)?.ToString());
                        var contractedHouseLand = decimal.Parse(reader.GetValue(5)?.ToString());
                        var totalContractedHouseLand = decimal.Parse(reader.GetValue(6)?.ToString());
                        var totalSold = decimal.Parse(reader.GetValue(7)?.ToString());
                        var remainingHouse = decimal.Parse(reader.GetValue(8)?.ToString());
                        var remainingLand = decimal.Parse(reader.GetValue(9)?.ToString());
                        var remarkEn = reader.GetValue(10)?.ToString();
                        var remarkKh = reader.GetValue(11)?.ToString();
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualSaleDetailReport sr = new ManualSaleDetailReport();
                        var pro = projectAll.FirstOrDefault(x => x.ProjectShort == project);
                        if (pro == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Project is not found!", "400"));
                        }
                        var exist = await _context.ManualSaleDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == pro.Id && x.ManualSaleReportId == id);
                        if (exist != null)
                        {
                            return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
                        }
                        sr.CompanyId = u.CompanySessionId;
                        sr.ProId = pro.Id;
                        sr.ManualSaleReportId = id;
                        sr.TotalHouseLand = totalHouseLand;
                        sr.TotalHouseLandSal = totalHouseLandSal;
                        sr.TotalHouseLandSold = totalHouseLandSold;
                        sr.BookingNoContracted = bookingNoContracted;
                        sr.ContractedHouseLand = contractedHouseLand;
                        sr.TotalContractedHouseLand = totalContractedHouseLand;
                        sr.TotalSold = totalSold;
                        sr.RemainingHouse = remainingHouse;
                        sr.RemainingLand = remainingLand;
                        sr.RemarkEn = remarkEn;
                        sr.RemarkKh = remarkKh;
                        sr.InsertType = "import";
                        sr.CreatedBy = _auth.Id;
                        _context.ManualSaleDetailReports.Add(sr);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

    }
}
