﻿using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/manual-report")]
    [ApiController]
    [Authorize]
    public class ManualMaterialStockReportController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public ManualMaterialStockReportController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("manual-material-stock-report")]
        public async Task<ActionResult<IEnumerable<ManualMaterialStockReport>>> GetManualMaterialStockReport([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ManualMaterialStockReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.ManualMaterialStockReports
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.Title.Contains(filter.Search))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("manual-material-stock-report/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetByID(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.ManualMaterialStockReports.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("report.manual_material_stock_report", ((int)data.Id), _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }



        [HttpPost("manual-material-stock-report/add")]
        public async Task<ActionResult<ManualMaterialStockReport>> AddManualMaterialStockReport(ManualMaterialStockReport data)
        {

            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.Status = true;
            data.RecStatus = 0;


            _context.ManualMaterialStockReports.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("report.manual_material_stock_report", ((int)data.Id), _auth.Id);
            return data;
        }

        [HttpPut("manual-material-stock-report/update")]
        public async Task<IActionResult> UpdateManualMaterialStockReport(ManualMaterialStockReport data)
        {
            var valid = await _context.ManualMaterialStockReports.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.UpdatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NoContent();
            }
            return Ok();
        }

        [HttpDelete("manual-material-stock-report/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteManualMaterialStockReport(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "report.manual_material_stock_report", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("manual-material-stock-report/{id}/detail")]
        public async Task<ActionResult<IEnumerable<VManualMaterialStockDetailReport>>> GetAllManualMaterialStockDetailReport(int id)
        {
            return await _context.VManualMaterialStockDetailReports
                           .Where(s => s.ManualMaterialStockReportId == id)
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
        }


        [HttpGet("manual-material-stock-report/detail/{id}")]
        public async Task<ActionResult<VManualMaterialStockDetailReport>> GetManualMaterialStockDetailById(int id)
        {
            var data = await _context.VManualMaterialStockDetailReports.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("manual-material-stock-report/detail/add")]
        public async Task<ActionResult<ManualMaterialStockDetailReport>> AddManualMaterialStockDetailReport(ManualMaterialStockDetailReport data)
        {
            _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            var exist = await _context.ManualMaterialStockDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualMaterialStockReportId == data.ManualMaterialStockReportId);

            if (exist != null && data.ProId != -20)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            _context.ManualMaterialStockDetailReports.Add(data);
            await _context.SaveChangesAsync();
            return data;
        }


        [HttpPut("manual-material-stock-detail-report/update")]
        public async Task<IActionResult> UpdateManualMaterialStockDetailReport(ManualMaterialStockDetailReport data)
        {
            var valid = await _context.ManualMaterialStockDetailReports​.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)

            {
                return BadRequest();
            }

            var exist = await _context.ManualMaterialStockDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == data.ProId && x.ManualMaterialStockReportId == data.ManualMaterialStockReportId && x.Id != data.Id);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            data.UpdatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NoContent();
            }
            return Ok();
        }

        [HttpDelete("manual-material-stock-detail-report/{id}/delete")]
        public async Task<IActionResult> DeleteManualMaterialStockDetailReport(int id)
        {
            var data_delete = await _context.ManualMaterialStockDetailReports.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.ManualMaterialStockDetailReports.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                return NoContent();
            }
            return Ok();
        }

        [HttpPost("manual-material-stock-report/{id}/detail/import")]
        public async Task<ActionResult<object>> ImportmaterialStockReport(int id, IFormFile file)
        {
            int total_records = 0;
            DateTime created_at = DateTime.Now;
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            _auth = new CustomUserIdentity(User);
            var u = await _context.Users.FindAsync(_auth.Id);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    reader.Read(); //ignore first row
                    var projectAll = await _context.VDbliveProjects.Where(x => x.CompanyId == u.CompanySessionId).ToListAsync();
                    while (reader.Read()) //Each ROW
                    {
                        var project = reader.GetValue(0)?.ToString();
                        var balance = decimal.Parse(reader.GetValue(1)?.ToString());
                        var remarkEn = reader.GetValue(2)?.ToString();
                        var remarkKh = reader.GetValue(3)?.ToString();
                        total_records++;

                        //return new { Results = total_records++ + "test" };
                        ManualMaterialStockDetailReport ms = new ManualMaterialStockDetailReport();
                        var pro = projectAll.FirstOrDefault(x => x.ProjectShort == project);
                        if (pro == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Project is not found!", "400"));
                        }
                        var exist = await _context.ManualMaterialStockDetailReports.AsNoTracking().FirstOrDefaultAsync(x => x.ProId == pro.Id && x.ManualMaterialStockReportId == id);
                        if (exist != null)
                        {
                            return BadRequest(new ApiResponse("failed", "This project already exist!", "400"));
                        }
                        ms.CompanyId = u.CompanySessionId;
                        ms.ProId = pro.Id;
                        ms.ManualMaterialStockReportId = id;
                        ms.Balance = balance;
                        ms.RemarkEn = remarkEn;
                        ms.RemarkKh = remarkKh;
                        ms.InsertType = "import";
                        ms.CreatedBy = _auth.Id;
                        _context.ManualMaterialStockDetailReports.Add(ms);
                        await _context.SaveChangesAsync();
                        total_records++;
                    }
                }
            }
            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

    }
}
