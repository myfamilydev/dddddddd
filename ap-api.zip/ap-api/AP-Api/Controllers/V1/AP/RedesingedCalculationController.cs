﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Transactions;
using AP_Api.Helpers;
using System.Text.RegularExpressions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class RedesignedCalcuationController : ControllerBase
    {
        private readonly APContext _context;

        public RedesignedCalcuationController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VRedesignedCalculation>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VRedesignedCalculations
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.RedesignedCode == validFilter.Search || s.HouseNumber == validFilter.Search || s.Project.Contains(validFilter.Search ?? "")))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VRedesignedCalculations
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.RedesignedCode == validFilter.Search || s.HouseNumber == validFilter.Search || s.Project.Contains(validFilter.Search ?? "")))
                               )
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetById(int id)
        {
            var data = await _context.VRedesignedCalculations.FirstOrDefaultAsync(x => x.Id == id && x.IsActive == 1);

            var _auth = new CustomUserIdentity(User);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("arch.redesigned_calculations", data.Id, _auth.Id, 0);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("add")]
        public async Task<ActionResult<RedesignedCalculation>> Add(RedesignedCalculation data)
        {
            var project = await _context.VProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);
            string psort = "";
            if (project != null)
            {
                psort = project.ProjectAbbr;
            }

            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.RedesignedCalculations.Where(x => x.RedesignedCode.EndsWith(year) && x.IsActive == 1).MaxAsync(x => x.RedesignedCode);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:\w+-", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.RedesignedCode = "RC:" + psort + "-" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.RedesignedCode = "RC:" + psort + "-" + "00001" + year;
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.IsActive = 1;
            data.RecStatus = 0;

            _context.RedesignedCalculations.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("arch.redesigned_calculations", data.Id, _auth.Id);

            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateRedesignedCalculation(RedesignedCalculation data)
        {

            var valid = await _context.RedesignedCalculations.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }
            var project = await _context.VProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);
            string psort = "";
            if (project != null)
            {
                psort = project.ProjectAbbr;
            }

            data.Id = valid.Id;
            data.RedesignedCode = valid.RedesignedCode.Replace(@"\w+:\w+-", "RC:" + psort + "-");
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> UpdateStatus(RedesignedCalculation data)
        {
            var valid = await _context.RedesignedCalculations.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null && valid?.RecStatus >= 3)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = data.IsActive;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("subterms/{id}")]
        public async Task<ActionResult<IEnumerable<VRedesignedCalculationSubterm>>> GetSubterms(int id)
        {
            return await _context.VRedesignedCalculationSubterms.Where(x => x.RedesignedCalculationId == id).OrderBy(x => x.PaymentInstallment).ToListAsync();
        }

        [HttpPost("subterm/add")]
        public async Task<ActionResult<RedesignedCalculationsSubterm>> AddSubtern(RedesignedCalculationsSubterm data)
        {

            //var getMax = await _context.RedesignedCalculationsSubterms.Where(x => x.IsActive == 1 && x.RedesignedCalculationId == data.RedesignedCalculationId).MaxAsync(x => x.PaymentInstallment);
            
            //if (getMax != null)
            //{
            //    var maxNumber = Regex.Match(getMax, @"\d+").Value;
            //    data.PaymentInstallment = NumberFormat.AddOrdinal(Convert.ToInt32(maxNumber) + 1);
            //}
            //else
            //{
            //    data.PaymentInstallment = NumberFormat.AddOrdinal(1);
            //}

            //var _auth = new CustomUserIdentity(User);

            data.IsActive = 1;
            data.RegularCollectionId = null;

            _context.RedesignedCalculationsSubterms.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpDelete("subterm/delete/{id}")]
        public async Task<ActionResult> DeleteSubTerm(int id)
        {

            var data = await _context.RedesignedCalculationsSubterms.FindAsync(id);

            if (data == null || data.RegularCollectionId != null)
            {
                return BadRequest();
            }

            _context.RedesignedCalculationsSubterms.Remove(data);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "success"
            });
        }

        [HttpGet("items/{id}")]
        public async Task<ActionResult<IEnumerable<VRedesignedCalculationItem>>> GetItems(int id)
        {
            return await _context.VRedesignedCalculationItems
                .Where(x => x.RedesignedCalculationId == id)
                .ToListAsync();
        }

        [HttpPost("item/add")]
        public async Task<ActionResult<RedesignedCalculationsItem>> AddItem(RedesignedCalculationsItem data)
        {

            data.IsActive = 1;

            _context.RedesignedCalculationsItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("item/update")]
        public async Task<IActionResult> UpdateItem(RedesignedCalculationsItem data)
        {

            var valid = await _context.RedesignedCalculationsItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("item/update/status")]
        public async Task<IActionResult> ItemUpdateStatus(RedesignedCalculationsItem data)
        {
            var valid = await _context.RedesignedCalculationsItems.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.IsActive = data.IsActive;


            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

    }
}
