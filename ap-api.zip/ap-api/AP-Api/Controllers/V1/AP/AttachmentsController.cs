﻿using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Web.Controllers
{
    [Route("api/v1/attachments")]
    [ApiController]
    [Authorize]
    public class AttachmentsController : ControllerBase
    {
        private readonly APContext _context;

        public AttachmentsController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AttachmentsModel>>> GetAttachments()
        {
            using (var _manualCtx = new ManualDbContext())
            {
                string sql = @" select file_uuid,file_name,file_ext,file_size,file_ref,file_ref_id,created_at,created_by
                            from dbo.attachments 
                            where status=1";

                return await _manualCtx.AttachmentsModel.FromSqlRaw(sql).AsNoTracking().ToListAsync();
            }
        }

        [HttpGet("download/{fileUuId}")]
        public async Task<FileContentResult> GetAttachments(Guid fileUuId)
        {
            ClsAttachment att = new ClsAttachment(_context);
            return await att.DownloadAttachFileAsync(fileUuId);
        }
        [HttpGet("image/{fileUuId}")]
        public async Task<string> GetImageData(Guid fileUuId)
        {
            ClsAttachment att = new ClsAttachment(_context);
            return await att.ReadAttachFileAsync(fileUuId);
        }
        [HttpGet("{file_ref}/{file_ref_id}")]
        public async Task<ActionResult<IEnumerable<VAttachmentList>>> GetAttachmentsByRefId(string file_ref, long file_ref_id)
        {
            var _auth = new CustomUserIdentity(User);
            var data = await _context.VAttachmentLists.AsNoTracking()
                   .Where(x=>x.FileRef == file_ref && x.FileRefId == file_ref_id)
                   .ToListAsync();

            return data;
        }

        [HttpPost("upload/{file_ref}/{file_ref_id}")]
        public async Task<IActionResult> UploadFile(IFormFile file, string file_ref, long file_ref_id)
{
            var _auth = new CustomUserIdentity(User);

            ClsAttachment att = new ClsAttachment(_context);
            await att.SaveBinaryFileAsync(file_ref, file_ref_id, file, _auth.Id);

            return Ok("Record have been saved");

        }

        [HttpPost("delete")]
        public async Task<IActionResult> DeleteAttachments(Attachment attachments)
        {
            var Attachments = await _context.Attachments.AsNoTracking().FirstOrDefaultAsync(x => x.FileUuid == attachments.FileUuid && x.Status == 1);
            if (Attachments == null)
            {
                return NotFound();
            }

            //_context.Entry(attachments).State = EntityState.Modified;
            //attachments.Status = 0;
            _context.Attachments.Remove(Attachments);
            await _context.SaveChangesAsync();

            return Ok("Record have been deleted");
        }

        private bool AttachmentsExists(Guid fileUuId)
        {
            return _context.Attachments.Any(e => e.FileUuid == fileUuId && e.Status == 1);
        }

    }
}
