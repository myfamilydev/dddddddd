﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using AP_Api.Models;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ChartOACController : ControllerBase
    {
        private CustomUserIdentity _auth;
        private readonly APContext _context;

        public ChartOACController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VChartAccount>>> GetChartOAC([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;


            var pagedData = _context.VChartAccounts
                           .Where(s =>  (s.CompanyId == u.CompanySessionId) && (filter.Status == -1 || s.RecStatus == (filter.Status)) && (String.IsNullOrEmpty(filter.Search) ||
                            s.AccountNameKh.Contains(filter.Search) ||
                            s.Note.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountNameEn.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountCode.ToLower().Contains(filter.Search.ToLower()) ||
                            s.BusinessType.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountType.ToLower().Contains(filter.Search.ToLower())))
                           .OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VChartAccounts
                                .Where(s => (filter.Status == -1 || s.RecStatus == (filter.Status)) && (String.IsNullOrEmpty(filter.Search) ||
                            s.AccountNameKh.Contains(filter.Search) ||
                            s.Note.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountNameEn.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountCode.ToLower().Contains(filter.Search.ToLower()) ||
                            s.BusinessType.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountType.ToLower().Contains(filter.Search.ToLower())))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetChartOAC(int id)
        {
            var data = await _context.VChartAccounts.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }
            var _auth = new CustomUserIdentity(User);

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.chart_accounts", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpDelete("{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteChartOACAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.chart_accounts", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpPost("add")]
        public async Task<ActionResult<ChartAccount>> AddChartOAC(ChartAccount data)
        {
            var exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == data.CompanyId && x.AccountCode == data.AccountCode);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Account Code is already exists!", "400"));
            }

            exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == data.CompanyId && x.AccountNameEn.ToLower().Trim() == data.AccountNameEn.ToLower().Trim());

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Account Name En is already exists!", "400"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.InsertType = "Form";

            data.RecStatus = 0;

            data.Inactivate = false;

            data.Status = true;

            data.IsChildAccount = false;

            if (data.IsSubAccount != true)
            {
                data.SubAccountOfId = null;
            }

            _context.ChartAccounts.Add(data);

            if (data.IsSubAccount == true)
            {
                
            }

            await _context.SaveChangesAsync();

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.chart_accounts", data.Id, _auth.Id);

            return data;
        }

        private bool isExistAccountCode(string accountCode, int? id, int? companyId)
        {
            return _context.ChartAccounts.Any(cas => cas.AccountCode == accountCode && cas.CompanyId == companyId && (id == null || cas.Id != id));
        }

        [HttpPost("account_code/available")]
        public async Task<ActionResult<object>> CheckAvailableAccountCode(ClsAvailableAccountCode data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            bool isExisted = isExistAccountCode(data.AccountCode, data.Id, user.CompanySessionId); 

            string Message = isExisted ? "Account Code isn't available" : "Account Code is Available";

            return Ok(new
            {
                Availble = !isExisted,
                Message = Message
            });
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateChartOAC(ChartAccount data)
        {
            var valid = _context.ChartAccounts.AsNoTracking().FirstOrDefault(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "ID is not found!", "400"));
            }

            //Prevent duplicate account code
            var exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == data.CompanyId
                            && x.AccountCode == data.AccountCode
                            && x.Id != data.Id);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Account Code is already exists!", "400"));
            }

             exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == data.CompanyId && x.AccountNameEn.ToLower().Trim() == data.AccountNameEn.ToLower().Trim() && x.Id != data.Id);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Account Name En is already exists!", "400"));
            }


            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.InsertType).IsModified = false;

            if (data.IsSubAccount != true)
            {
                data.SubAccountOfId = null;
            }

            _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("import")]
        public async Task<ActionResult<object>> ImportChartOAC(IFormFile file)
        {

            int total_records = 0;
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    reader.Read(); //ignore first row

                    var company = await _context.VDblhdCompanies.AsNoTracking().ToListAsync();
                    var accType = await _context.DimAccountTypes.AsNoTracking().ToListAsync();
                    var budgetLines = await _context.VDblhdBudgetsLines.AsNoTracking().ToListAsync();

                    while (reader.Read()) //Each ROW
                    {

                        //Get company Id by Business Type
                        var com = company.FirstOrDefault(x => x.NameEn.ToLower().Trim() == reader.GetValue(0).ToString().ToLower().Trim());
                        if (com == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Company is not found!", "400"));
                        }

                        //Prevent duplicate account code
                        var exists = _context.ChartAccounts.AsNoTracking()
                            .FirstOrDefault(x => x.CompanyId == com.Id
                            && x.AccountCode == reader.GetValue(2).ToString());

                        if (exists != null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Account Code is already exists!", "400"));
                        }
                        string budgetCode = reader.GetValue(3).ToString().ToLower();

                        var budgetLine = budgetLines.FirstOrDefault(x => x.BudgetCode.ToLower() == budgetCode);
                        if (budgetLine == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Budget Line is not found!", "400"));
                        }

                        //Get Account Type Id
                        var account_type = accType.FirstOrDefault(x => x.AccountType.ToLower() == reader.GetValue(4).ToString().ToLower());
                        if (account_type == null)
                        {
                            return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Account Type is not found!", "400"));
                        }

                        int? sub_acc_id = null;

                        //Check if Sub Account Of
                        if (reader.GetValue(7) != null)
                        {
                            //Get Account Type Id
                            var sub_acc = _context.ChartAccounts.AsNoTracking()
                                        .FirstOrDefault(x => x.CompanyId == com.Id
                                        && x.AccountCode == reader.GetValue(7).ToString());

                            if (sub_acc == null)
                            {
                                return BadRequest(new ApiResponse("failed", "Row # " + (total_records + 2).ToString() + " Sub Account is not found!", "400"));
                            }
                            sub_acc_id = sub_acc.Id;
                        }

                        _auth = new CustomUserIdentity(User);

                        ChartAccount acc = new ChartAccount();
                        acc.CompanyId = (short)com.Id;

                        acc.AccountCode = reader.GetValue(2).ToString();
                        acc.AccountTypeId = account_type.Id;
                        acc.AccountNameEn = reader.GetValue(5).ToString();
                        acc.AccountNameKh = reader.GetValue(6).ToString();
                        acc.SubAccountOfId = sub_acc_id;
                        acc.Description = reader.GetValue(8)?.ToString();
                        acc.Note = reader.GetValue(9)?.ToString();
                        acc.RecStatus = 3; //Approved
                        acc.InsertType = "Import";
                        acc.CreatedAt = created_at;
                        acc.CreatedBy = _auth.Id;
                        acc.BudgetLineId = budgetLine.Id;

                        _context.ChartAccounts.Add(acc);
                        await _context.SaveChangesAsync();
                        total_records++;

                    }
                }
            }

            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

    }
}
