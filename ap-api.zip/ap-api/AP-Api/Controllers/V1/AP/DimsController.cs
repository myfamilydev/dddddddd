﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class DimsController : ControllerBase
    {
        private readonly APContext _context;

        public DimsController(APContext context)
        {
            _context = context;
        }

        [HttpGet("accountTypes")]
        public async Task<ActionResult<IEnumerable<DimAccountType>>> GetAllAccountType()
        {
            return await _context.DimAccountTypes.ToListAsync();
        }

        [HttpGet("accountThreatmentTypes")]
        public async Task<ActionResult<IEnumerable<DimAccountThreatmentType>>> GetAccountThreatmentType()
        {
            return await _context.DimAccountThreatmentTypes.ToListAsync();
        }

        [HttpGet("customer-request-types")]
        public async Task<ActionResult<IEnumerable<DimRequestType>>> GetAllRequestTyp()
        {
            return await _context.DimRequestTypes.ToListAsync();
        }

        [HttpGet("delegate-customers")]
        public async Task<ActionResult<IEnumerable<Object>>> GetAllDelegateCustomer()
        {
            return await _context.DelegateCustomers.Where(x => x.Status == 1).Select(
                x => new { id = x.Id, name = x.Name + " | " +x.IdentityCard} 
                ).ToListAsync();
        }

        [HttpGet("purposes")]
        public async Task<ActionResult<IEnumerable<Purpose>>> GetAllPurposes()
        {
            return await _context.Purposes.ToListAsync();
        }

        [HttpGet("units")]
        public async Task<ActionResult<IEnumerable<Unit>>> GetAllUnit()
        {
            return await _context.Units.ToListAsync();
        }
    }
}
