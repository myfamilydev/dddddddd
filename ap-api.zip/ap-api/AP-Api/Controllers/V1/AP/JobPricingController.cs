﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class JobPricingController : ControllerBase
    {
        private readonly APContext _context;

        public JobPricingController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VJobPricing>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VJobPricings
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.JopPricingCode == validFilter.Search || s.Name == validFilter.Search ))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VJobPricings
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.JopPricingCode == validFilter.Search || s.Name == validFilter.Search))
                               )
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
            
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetById(int id)
        {
            var data = await _context.VJobPricings.FirstOrDefaultAsync(x => x.Id == id);
            var _auth = new CustomUserIdentity(User);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("arch.job_pricing", data.Id, _auth.Id, 0);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("add")]
        public async Task<ActionResult> Add(JobPricing data)
        {
            try
            {
                string year = "/" + DateTime.Now.ToString("yy");
                var getMax = await _context.JobPricings.Where(x => x.JopPricingCode.StartsWith("JP:") && x.JopPricingCode.EndsWith(year) && x.Status ==1)
                                            .MaxAsync(x => x.JopPricingCode);
                var _auth = new CustomUserIdentity(User);
                if (getMax != null)
                {
                    getMax = getMax.Replace("JP:", "").Replace(year, "");
                    var maxNumber = Regex.Match(getMax, @"\d+").Value;
                    data.JopPricingCode = "JP:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
                }
                else
                {
                    data.JopPricingCode =  "JP:00001" + year;
                }

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    
                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _auth.Id;
                    data.Status = 1;
                    data.RecStatus = 0;

                    _context.JobPricings.Add(data);

                    await _context.SaveChangesAsync();
                    
   
                    
                    ts.Complete();
                   
                }
                new WorkflowDetailModel().WorkflowHistoryDraft("arch.job_pricing", data.Id, _auth.Id);
                return Ok(data);
            }
            catch(Exception)
            {
                return BadRequest();
            }

            
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(JobPricing data)
        {
            var valid = await _context.JobPricings.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.JopPricingCode).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> UpdateStatus(JobPricing data)
        {
            var valid = await _context.JobPricings.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("item/add")]
        public async Task<ActionResult<SubJob>> ItemAdd(SubJob data)
        {
            

            var getMax = await _context.VSubJobEffectiveDates.Where(x => x.SubJobCode.StartsWith(data.JobCode))
                                            .MaxAsync(x => x.SubJobCode);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(data.JobCode + ".", "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.SubJobCode = data.JobCode + "." + (Convert.ToInt32(maxNumber) + 1).ToString("D2");
            }
            else
            {
                data.SubJobCode = data.JobCode + ".01";
            }
            try
            {
                data.IsActive = 1;

                _context.SubJobs.Add(data);

                await _context.SaveChangesAsync();

                var _auth = new CustomUserIdentity(User);

                return Ok(data);
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut("item/update")]
        public async Task<IActionResult> ItemUpdate(SubJobInput req)
        {
            var data = req.data;
            List<int> projects = req.Projects;
            List<int> categories = req.Categories;

            var valid = await _context.SubJobs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            _context.Entry(data).Property(x => x.JobCode).IsModified = false;
            _context.Entry(data).Property(x => x.JobPricingCode).IsModified = false;
            _context.Entry(data).Property(x => x.SubJobCode).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            try
            {
                bool isUpdate = false;
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var subJobProjects = await _context.SubJobProjects.AsNoTracking().Where(x => x.SubJobId == data.Id).ToListAsync();
                    var subJobHouseCategories = await _context.SubJobHouseCategories.AsNoTracking().Where(x => x.SubJobId == data.Id).ToListAsync();

                 

                    projects.ForEach(s =>
                    {
                        isUpdate = !(subJobProjects.Where(x => x.ProjectId == s).Count() > 0);
                    });

                    categories.ForEach(s =>
                    {
                        isUpdate = !(subJobHouseCategories.Where(x => x.HouseCategoryId == s).Count() > 0);
                    });

                    if (projects.Count() != subJobProjects.Count() || categories.Count() != subJobHouseCategories.Count())
                    {
                        isUpdate = true;
                    }

                    if (isUpdate)
                    {
                        _context.SubJobProjects.RemoveRange(subJobProjects);
                        _context.SubJobHouseCategories.RemoveRange(subJobHouseCategories);
                        categories.ForEach(c => _context.SubJobHouseCategories.Add(new SubJobHouseCategory() { SubJobId = data.Id, HouseCategoryId = c, CreatedAt = DateTime.Now, CreatedBy = _auth.Id }));
                        projects.ForEach(s => _context.SubJobProjects.Add(new SubJobProject() { SubJobId = data.Id, ProjectId = s, CreatedAt = DateTime.Now, CreatedBy = _auth.Id }));
                    }
                    await _context.SaveChangesAsync();
                    req.data = valid;
                    ts.Complete();
                    return Ok(req);
                }
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("item/update/status")]
        public async Task<IActionResult> ItemUpdateStatus(SubJob data)
        {
            var valid = await _context.SubJobs.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);


            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var projects = _context.SubJobProjects.Where(x => x.SubJobId == data.Id).ToList();
                    var subJobHouseCategory = _context.SubJobHouseCategories.Where(x => x.SubJobId == data.Id).ToList();
                    _context.RemoveRange(projects);
                    _context.RemoveRange(subJobHouseCategory);
                    _context.Remove(valid);
                    await _context.SaveChangesAsync();
                    ts.Complete();
                    return Ok(valid);
                }
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("item/{id}")]
        public async Task<ActionResult<IEnumerable<object>>> GetItem(int id)
        {
            var subList = await _context.VSubJops.Where(x => x.JobPricingId == id).ToListAsync();
            var newSubList = subList.Select(async x => new { 
                data = x,
                categories = await _context.VSubJobHouseCategories.Where(y => y.SubJobId == x.Id).ToListAsync(),
                projects = await _context.VSubJobProjects.Where(y => y.SubJobId == x.Id).ToListAsync()
            });
            return Ok(newSubList.Select(x => x.Result));
        }

        [HttpGet("items/project/{id}")]
        public async Task<ActionResult<IEnumerable<VSubJobEffectiveProject>>> GetAllItem(int id)
        {
            return await _context.VSubJobEffectiveProjects.Where(x => x.ProjectId == id).ToListAsync();
        }

        [HttpGet("item/{id}/by/{itemId}")]
        public async Task<ActionResult<IEnumerable<object>>> GetItemById(int id, int itemId)
        {
            var subList = await _context.VSubJops.Where(x => x.JobPricingId == id && x.Id == itemId).ToListAsync();
            var newSubList = subList.Select(async x => new {
                data = x,
                categories = await _context.VSubJobHouseCategories.Where(y => y.SubJobId == x.Id).ToListAsync(),
                projects = await _context.VSubJobProjects.Where(y => y.SubJobId == x.Id).ToListAsync()
            });
            return Ok(newSubList.Select(x => x.Result));
        }
    }
}
