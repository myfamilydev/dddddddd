﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ContractIndividualLoanController : ControllerBase
    {
        private readonly APContext _context;

        public ContractIndividualLoanController(IHttpContextAccessor httpContextAccessor, APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VContractIndividualLoan>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VContractIndividualLoans
                        .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ContractCode == filter.Search || s.LoanDescription == filter.Search))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VContractIndividualLoans
                            .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ContractCode == filter.Search || s.LoanDescription == filter.Search) && s.Status == true)
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VContractIndividualLoan>> GetById(int id)
        {
            var data = await _context.VContractIndividualLoans.FirstOrDefaultAsync(x => x.Id==id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<ContractIndividualLoan>> Create(ContractIndividualLoan data)
        {
            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.ContractIndividualLoans.Where(x => x.ContractCode.EndsWith(year) && x.Status == true).MaxAsync(x => x.ContractCode);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.ContractCode = "IDV:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.ContractCode = "IDV:" + "00001" + year;
            }

            try
            {
                var _auth = new CustomUserIdentity(User);

                data.CreatedAt = DateTime.Now;
                data.CreatedBy = _auth.Id;
                data.Status = true;

                _context.ContractIndividualLoans.Add(data);

                await _context.SaveChangesAsync();

                return data;
            } catch
            {
                return BadRequest();
            }
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(ContractIndividualLoan data)
        {
            var valid = await _context.ContractIndividualLoans.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            
            _context.Entry(data).Property(x => x.ContractCode).IsModified = false;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var valid = await _context.ContractIndividualLoans.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("CostCenters")]
        public async Task<ActionResult<IEnumerable<VContractIndividualCostCenter>>> GetAllCostCenter()
        {
            return await _context.VContractIndividualCostCenters
                            .AsNoTracking()
                           .ToListAsync();
        }

        [HttpGet("{id}/CostCenters")]
        public async Task<ActionResult<IEnumerable<VContractIndividualCostCenter>>> GetAllCostCenters(int id)
        {

            return await _context.VContractIndividualCostCenters
                                    .AsNoTracking()
                                    .Where(x => x.ContractId == id)
                                    .ToListAsync();
        }

        [HttpGet("CostCenters/{id}")]
        public async Task<ActionResult<VContractIndividualCostCenter>> GetCostCentersById(int id)
        {
            var data = await _context.VContractIndividualCostCenters.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("CostCenters/add")]
        public async Task<ActionResult<ContractIndividualCostCenter>> AddBank(ContractIndividualCostCenter data)
        {
            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractIndividualCostCenters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("CostCenters/update")]
        public async Task<IActionResult> UpdateBank(ContractIndividualCostCenter data)
        {
            var valid = await _context.ContractIndividualCostCenters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }   

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;


            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("CostCenters/{id}/delete")]
        public async Task<IActionResult> CostCentersDelete(int id)
        {
            var valid = await _context.ContractIndividualCostCenters.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();

        }

        [HttpGet("UseFunds")]
        public async Task<ActionResult<IEnumerable<VContractIndividualUseFund>>> GetAllUseFunds()
        {
            return await _context.VContractIndividualUseFunds
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("{id}/UseFunds")]
        public async Task<ActionResult<IEnumerable<VContractIndividualUseFund>>> GetAllUseFunds(int id)
        {
            return await _context.VContractIndividualUseFunds
                .AsNoTracking()
                .Where(x => x.ContractId == id)
                .ToListAsync();
        }

        [HttpGet("UseFunds/{id}")]
        public async Task<ActionResult<VContractIndividualUseFund>> GetUseFundsById(int id)
        {
            var data = await _context.VContractIndividualUseFunds.FirstOrDefaultAsync(x=>x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("UseFunds/add")]
        public async Task<ActionResult<ContractIndividualUseFund>> AddUseFunds(ContractIndividualUseFund data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractIndividualUseFunds.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("UseFunds/update")]
        public async Task<IActionResult> UpdateUseFunds(ContractIndividualUseFund data)
        {
            var valid = await _context.ContractIndividualUseFunds.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("UseFunds/{id}/delete")]
        public async Task<IActionResult> UseFundsDelete(int id)
        {
            var valid = await _context.ContractIndividualUseFunds.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("Htds")]
        public async Task<ActionResult<IEnumerable<VContractIndividualHtdItem>>> GetAllAHtdItems()
        {
            return await _context.VContractIndividualHtdItems
                    .AsNoTracking()
                    .ToListAsync();
        }

        [HttpGet("{id}/Htds")]
        public async Task<ActionResult<IEnumerable<VContractIndividualHtdItem>>> GetAllHtdItems(int id)
        {
            return await _context.VContractIndividualHtdItems
                    .Where(x => x.ContractId == id)
                    .AsNoTracking()
                    .ToListAsync();
        }

        [HttpGet("Htds/{id}")]
        public async Task<ActionResult<VContractIndividualHtdItem>> GetHtdItemsById(int id)
        {
            var data = await _context.VContractIndividualHtdItems
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Htds/add")]
        public async Task<ActionResult<ContractIndividualHtdItem>> AddAdminFee(ContractIndividualHtdItem data)
        {
            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.IsActive = 1;

            _context.ContractIndividualHtdItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Htds/update")]
        public async Task<IActionResult> UpdateHtdItems(ContractIndividualHtdItem data)
        {
            var valid = await _context.ContractIndividualHtdItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Htds/{id}/delete")]
        public async Task<ActionResult> HtdItemsAdd(int id)
        {
            var valid = await _context.ContractIndividualHtdItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = 0;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("Settlements")]
        public async Task<ActionResult<IEnumerable<ContractIndividualSettlement>>> GetAllSettlements()
        {
            return await _context.ContractIndividualSettlements
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("{id}/Settlements")]
        public async Task<ActionResult<IEnumerable<VContractIndividualSettlement>>> GetAllSettlements(int id)
        {
            return await _context.VContractIndividualSettlements.AsNoTracking()
                .Where(x => x.ContractId == id)
                .ToListAsync();
        }

        [HttpGet("Settlements/{id}")]
        public async Task<ActionResult<VContractIndividualSettlement>> GetSettlementsById(int id)
        {
            var data = await _context.VContractIndividualSettlements.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Settlements/add")]
        public async Task<ActionResult<ContractIndividualSettlement>> AddSettlements(ContractIndividualSettlement data)
        {
            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            _context.ContractIndividualSettlements.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Settlements/update")]
        public async Task<IActionResult> UpdateSettlements(ContractIndividualSettlement data)
        {
            var valid = await _context.ContractIndividualSettlements
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x => x.Id == data.Id);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Settlements/{id}/delete")]
        public async Task<IActionResult> SettlementsDelete(int id)
        {
            var valid = await _context.ContractIndividualSettlements.FindAsync(id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("ScheduleInfos/add")]
        public async Task<ActionResult<ContractIndividualSchedulesInfo>> AddSchedules(ContractIndividualSchedulesInfo data)
        {
            var getMax = await _context.ContractIndividualSchedulesInfos.Where(x => x.ContractId== data.ContractId && x.Status == true).MaxAsync(x => x.ScheduleNumber);

            if (getMax != null)
            {
                data.ScheduleNumber = getMax + 1;
            }
            else
            {
                data.ScheduleNumber = 1;
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            _context.ContractIndividualSchedulesInfos.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPost("Schedules/add")]
        public async Task<ActionResult<ContractIndividualSchedule>> AddSchedules(ContractIndividualSchedule data)
        {
            var exists = _context.ContractIndividualSchedules.AsNoTracking()
                            .FirstOrDefault(x => x.ContractId == data.ContractId && x.RepayDate == data.RepayDate && data.Status == true);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Repay date is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            _context.ContractIndividualSchedules.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Schedules/update")]
        public async Task<ActionResult> UpdateSchedules(ContractIndividualSchedule data)
        {

            var valid = await _context.ContractIndividualSchedules.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.ContractId).IsModified = false;
            _context.Entry(data).Property(x => x.ContractIndividualScheduleInfoId).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Schedules/{id}/delete")]
        public async Task<ActionResult> DeleteSchedules(int id)
        {

            var valid = await _context.ContractIndividualSchedules.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            var data = await _context.ContractIndividualScheduleDetails.Where(x => x.ContractIndividualScheduleId == valid.Id).ToListAsync();

            try
            {
                data.ForEach(x => x.Status = false);

                valid.Status = false;

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpGet("{id}/Schedules")]
        public async Task<ActionResult<object>> GetAllSchedules(int id)
        {
            var scheduleDetails = await _context.VContractIndividualScheduleDetails.Where(x => x.ContractId == id && x.Status == true).ToListAsync();

            var schdules = await _context.ContractIndividualSchedules.Where(x => x.ContractId == id && x.Status == true).ToListAsync();

            return Ok(new
            {
                scheduleDetails = scheduleDetails,
                schdules = schdules
            });
        }

        [HttpGet("Schedules/{id}")]
        public async Task<ActionResult<ContractIndividualSchedule>> GetSchedulesById(int id)
        {
            var data = await _context.ContractIndividualSchedules.FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("SchedulesDetails/add")]
        public async Task<ActionResult<ContractIndividualScheduleDetail>> AddSchedulesDetails(ContractIndividualScheduleDetail data)
        {
            var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.ContractIndividualScheduleDetails.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("SchedulesDetails/update")]
        public async Task<ActionResult> UpdateSchedulesDetails(ContractIndividualScheduleDetail data)
        {

            var valid = await _context.ContractIndividualScheduleDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);
            
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.ContractId).IsModified = false;

            _context.Entry(data).Property(x => x.ContractIndividualScheduleId).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("SchedulesDetails/{id}/delete")]
        public async Task<ActionResult> DeleteSchedulesDetails(int id)
        {

            var valid = await _context.ContractIndividualScheduleDetails.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpPost("Schedules/import/{id}")]
        public async Task<ActionResult<object>> ImportSchedules(IFormFile file, int id)
        {

            int total_records = 0;
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())

            {

                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    reader.Read();

                    int countField = 0;
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        var cell = reader[i]?.ToString();
                        if (i > 500)
                        {
                            break;
                        }

                        if (cell != null)
                        {
                            countField++;
                        }
                    }

                    var schedules = await _context.ContractIndividualSchedules.AsNoTracking().ToListAsync();
                    var projects = await _context.VDbliveProjects.AsNoTracking().ToListAsync();
                    var scheduleInfo = await _context.ContractIndividualSchedulesInfos.FirstOrDefaultAsync(x => x.Id == id);

                    if (scheduleInfo == null)
                    {
                        return BadRequest(new ApiResponse("failed", "Schedule Info Id doesn't exists!", "400"));
                    }

                    using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                    {
                        while (reader.Read()) //Each ROW
                        {
                            string repayDate = reader.GetDateTime(1).ToString("yyyy-MM-dd");
                            var scheduleList = schedules.FirstOrDefault(x => x.ContractIndividualScheduleInfoId == id && x.RepayDate?.ToString("yyyy-MM-dd") == repayDate && x.Status == true);

                            if (scheduleList != null)
                            {
                                return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Repay Date is already exists!", "400"));
                            }

                            var _auth = new CustomUserIdentity(User);

                            ContractIndividualSchedule sl = new ContractIndividualSchedule();

                            sl.ContractId = scheduleInfo.ContractId;
                            sl.ContractIndividualScheduleInfoId = id;
                            sl.RepayDate = reader.GetDateTime(1);
                            sl.StartDate = reader.GetDateTime(2);
                            sl.FromDate = reader.GetDateTime(3);
                            sl.Days = Convert.ToInt32(reader.GetValue(4));
                            sl.Rate = Convert.ToDecimal(reader.GetValue(5));
                            sl.CreatedAt = created_at;
                            sl.CreatedBy = _auth.Id;
                            sl.Status = true;

                            _context.ContractIndividualSchedules.Add(sl);
                            await _context.SaveChangesAsync();
                            int resetCount = 1;

                            for (int i = 6; i < countField; i++)
                            {

                                if (resetCount == 6)
                                {

                                    ContractIndividualScheduleDetail lsd = new ContractIndividualScheduleDetail();
                                    lsd.ContractIndividualScheduleId = sl.Id;
                                    lsd.ContractId = sl.ContractId;
                                    var proCode = reader.GetValue(i - (resetCount - 1)).ToString();
                                    var p = projects.FirstOrDefault(p => p.ProjectCode.ToLower() == proCode?.ToLower());
                                    lsd.ProjectId = p?.Id;

                                    lsd.PrincipalAmount = Convert.ToDecimal(reader.GetValue(i - (resetCount - 2)));
                                    lsd.BalanceAmount = Convert.ToDecimal(reader.GetValue(i - (resetCount - 3)));
                                    lsd.InterestAmount = Convert.ToDecimal(reader.GetValue(i - (resetCount - 4)));
                                    lsd.Wht14 = Convert.ToDecimal(reader.GetValue(i - (resetCount - 5)));
                                    lsd.TotalPayment = Convert.ToDecimal(reader.GetValue(i - (resetCount - 6)));
                                    _context.ContractIndividualScheduleDetails.Add(lsd);
                                    await _context.SaveChangesAsync();
                                    resetCount = 0;
                                }

                                resetCount++;
                            }

                            total_records++;

                        }

                        ts.Complete();
                    }
                }
            }

            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }
    }
}
