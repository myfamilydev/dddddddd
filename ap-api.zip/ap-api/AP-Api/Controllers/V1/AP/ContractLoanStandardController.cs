﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ContractLoanStandardController : ControllerBase
    {
        private readonly APContext _context;

        public ContractLoanStandardController(IHttpContextAccessor httpContextAccessor, APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VContractLoanStandard>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VContractLoanStandards
                        .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ContractCode == filter.Search || s.LoanBankRef == filter.Search) && s.IsActive == 1)
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VContractLoanStandards
                            .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ContractCode == filter.Search || s.LoanBankRef == filter.Search) && s.IsActive == 1)
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ContractStandardLoan>> GetById(int id)
        {
            var data = await _context.ContractStandardLoans.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<ContractStandardLoan>> Create(ContractStandardLoan data)
        {
            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.ContractStandardLoans.Where(x => x.ContractCode.EndsWith(year) && x.IsActive == 1).MaxAsync(x => x.ContractCode);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.ContractCode = "STL:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.ContractCode = "STL:" + "00001" + year;
            }

            try
            {
                var _auth = new CustomUserIdentity(User);

                data.CreatedAt = DateTime.Now;
                data.CreatedBy = _auth.Id;
                data.IsActive = 1;

                _context.ContractStandardLoans.Add(data);

                await _context.SaveChangesAsync();

                return data;
            } catch
            {
                return BadRequest();
            }
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(ContractStandardLoan data)
        {
            var valid = await _context.ContractStandardLoans.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.IsActive == 1);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            _context.Entry(data).Property(x => x.ContractCode).IsModified = false;
            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> Inactive(ContractStandardLoan data)
        {
            var valid = await _context.ContractStandardLoans.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = data.IsActive;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("{id}/BanksItems")]
        public async Task<ActionResult<IEnumerable<VLoanBanksItem>>> GetAllBankItems(int id)
        {
            return await _context.VLoanBanksItems
                            .Where(x => x.ContractId == id)
                           .ToListAsync();
        }

        [HttpGet("BanksItems/{id}")]
        public async Task<ActionResult<VLoanBanksItem>> GetBankItemById(int id)
        {
            var data = await _context.VLoanBanksItems.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("BanksItems/add")]
        public async Task<ActionResult<LoanBanksItem>> AddLoanBankItem(LoanBanksItem data)
        {

            _context.LoanBanksItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("BanksItems/update")]
        public async Task<IActionResult> UpdateBankItem(LoanBanksItem data)
        {
            var valid = await _context.LoanBanksItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("BanksItems/{id}/delete")]
        public async Task<IActionResult> BankItemDelete(int id)
        {
            var data = await _context.LoanBanksItems.FirstOrDefaultAsync(x=>x.Id == id);

            try
            {
                _context.LoanBanksItems.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }


        [HttpGet("{id}/HtdItems")]
        public async Task<ActionResult<IEnumerable<LoanHtdItem>>> GetAllHtdItem(int id)
        {
            return await _context.LoanHtdItems
                .Where(x => x.ContractId == id)
                .ToListAsync();
        }

        [HttpGet("HtdItems/{id}")]
        public async Task<ActionResult<LoanHtdItem>> Getitemtypes(int id)
        {
            var data = await _context.LoanHtdItems.FirstOrDefaultAsync(x=>x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("HtdItems/add")]
        public async Task<ActionResult<LoanHtdItem>> AddHtdItem(LoanHtdItem data)
        {

            _context.LoanHtdItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("HtdItems/update")]
        public async Task<IActionResult> UpdateHtdItem(LoanHtdItem data)
        {
            var valid = await _context.LoanHtdItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("HtdItems/{id}/delete")]
        public async Task<IActionResult> HtdItemDelete(int id)
        {
            var valid = await _context.LoanHtdItems.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            try
            {
                _context.LoanHtdItems.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }


        [HttpGet("{id}/DisburementItems")]
        public async Task<ActionResult<object>> GetAllDisburementItem(int id)
        {
            var useFunds = await _context.VLoanUseFunds.Where(x => x.ContractId == id).ToListAsync();

            var costCenters = await _context.VLoanCostCenters.Where(x => x.ContractId == id).ToListAsync();

            var disburementItems = await _context.VLoanDisburementItems.Where(x => x.ContractId == id).ToListAsync();

            return Ok(new
            {
                costCenters = costCenters,
                useFunds = useFunds,
                disburementItems = disburementItems
            });
        }

        [HttpGet("DisburementItems/{id}")]
        public async Task<ActionResult<VLoanDisburementItem>> GetDisburementItemById(int id)
        {
            var data = await _context.VLoanDisburementItems.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("DisburementItems/add")]
        public async Task<ActionResult<LoanDisburementItem>> AddLoanDesburementItem(LoanDisburementItem data)
        {
            try
            {
                var scheduleInfo = new LoanSchedulesInfo();
                var getMax = await _context.LoanSchedulesInfos.Where(x => x.ContractId == data.ContractId && x.IsActive == 1).MaxAsync(x => x.ScheduleNumber);

                if (getMax != null)
                {
                    scheduleInfo.ScheduleNumber = (Convert.ToInt32(getMax) + 1).ToString();
                }
                else
                {
                    scheduleInfo.ScheduleNumber = "1";
                } 

                var _auth = new CustomUserIdentity(User);

                data.CreatedAt = DateTime.Now;

                data.CreatedBy = _auth.Id;

                data.IsActive = 1;

                _context.LoanDisburementItems.Add(data);

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    scheduleInfo.LoanDisbursmentId = data.Id;

                    scheduleInfo.ContractId = data.ContractId;

                    scheduleInfo.LoanPhaseNo = data.LoanPhaseNo;

                    scheduleInfo.IsActive = 1;

                    _context.LoanSchedulesInfos.Add(scheduleInfo);

                    await _context.SaveChangesAsync();

                    ts.Complete();
                }

                return data;
            }catch
            {
                return BadRequest();
            }
        }

        [HttpPut("DisburementItems/update")]
        public async Task<IActionResult> UpdateDisburementItems(LoanDisburementItem data)
        {
            var valid = await _context.LoanDisburementItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.LoanPhaseNo).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("DisburementItems/{id}/delete")]
        public async Task<ActionResult> DisburementItemAdd(int id)
        {
            var valid = await _context.LoanDisburementItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            var scheduleInfo = await _context.LoanSchedulesInfos.AsNoTracking().FirstOrDefaultAsync(x => x.LoanDisbursmentId == valid.Id);
            
            if (scheduleInfo == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;
            _context.Entry(scheduleInfo).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = 0;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;
            scheduleInfo.IsActive = 0;
            scheduleInfo.UpdatedAt = DateTime.Now;
            scheduleInfo.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("DisburementItems/{id}/UseFunds")]
        public async Task<ActionResult<IEnumerable<VLoanUseFund>>> GetAllUseFunds(int id)
        {
            return await _context.VLoanUseFunds.Where(x => x.LoanDisburementId == id).ToListAsync();
        }

        [HttpGet("UseFunds/{id}")]
        public async Task<ActionResult<VLoanUseFund>> GetUseFundsById(int id)
        {
            var data = await _context.VLoanUseFunds.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("UseFunds/add")]
        public async Task<ActionResult<LoanUseFund>> AddUseFunds(LoanUseFund data)
        {

            _context.LoanUseFunds.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("UseFunds/update")]
        public async Task<IActionResult> UpdateUseFunds(LoanUseFund data)
        {
            var valid = await _context.LoanUseFunds.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("UseFunds/{id}/delete")]
        public async Task<ActionResult> UseFundsAdd(int id)
        {
            var valid = await _context.LoanUseFunds.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            try
            {
                _context.LoanUseFunds.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpGet("DisburementItems/{id}/CostCenters")]
        public async Task<ActionResult<IEnumerable<VLoanCostCenter>>> GetCostCentersByDisId(int id)
        {
            var data = await _context.VLoanCostCenters.Where(x => x.LoanDisburementId == id).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("CostCenters/{id}")]
        public async Task<ActionResult<VLoanCostCenter>> GetCostCentersById(int id)
        {
            var data = await _context.VLoanCostCenters.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("CostCenters/add")]
        public async Task<ActionResult<LoanCostCenter>> AddCostCenters(LoanCostCenter data)
        {
            var exists = await _context.LoanCostCenters.FirstOrDefaultAsync(x => x.LoanDisburementId == data.LoanDisburementId && x.ProjectId == data.ProjectId);

            if(exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Project cost center is already exists!", "400"));
            }

            _context.LoanCostCenters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("CostCenters/update")]
        public async Task<IActionResult> UpdateCostCenters(LoanCostCenter data)
        {
            var valid = await _context.LoanCostCenters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("CostCenters/{id}/delete")]
        public async Task<ActionResult> CostCentersAdd(int id)
        {
            var valid = await _context.LoanCostCenters.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            try
            {
                _context.LoanCostCenters.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpGet("{id}/DocumentsRequirement")]
        public async Task<ActionResult<IEnumerable<LoanDocumentsRequirement>>> GetAllDocumentsRequirement(int id)
        {
            return await _context.LoanDocumentsRequirements
                .Where(x => x.ContractId == id)
                .ToListAsync();
        }

        [HttpGet("DocumentsRequirement/{id}")]
        public async Task<ActionResult<LoanDocumentsRequirement>> GetLoanDocumentsRequirementById(int id)
        {
            var data = await _context.LoanDocumentsRequirements.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("DocumentsRequirement/add")]
        public async Task<ActionResult<LoanDocumentsRequirement>> AddDocumentsRequirement(LoanDocumentsRequirement data)
        {

            _context.LoanDocumentsRequirements.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("DocumentsRequirement/update")]
        public async Task<IActionResult> UpdateDocumentsRequirement(LoanDocumentsRequirement data)
        {
            var valid = await _context.LoanDocumentsRequirements.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("DocumentsRequirement/{id}/delete")]
        public async Task<IActionResult> DocumentsRequirementDelete(int id)
        {
            var valid = await _context.LoanDocumentsRequirements.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            try
            {
                _context.LoanDocumentsRequirements.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpPost("Schedules/add")]
        public async Task<ActionResult<LoanStandardSchedule>> AddSchedules(LoanStandardSchedule data)
        {
            var exists = _context.LoanStandardSchedules.AsNoTracking()
                            .FirstOrDefault(x => x.ContractId == data.ContractId && x.RepayDate == data.RepayDate);

            if (exists != null)
            {
                return BadRequest(new ApiResponse("failed", "Repay date is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.IsActive = 1;

            _context.LoanStandardSchedules.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Schedules/update")]
        public async Task<ActionResult> UpdateSchedules(LoanStandardSchedule data)
        {

            var valid = await _context.LoanStandardSchedules.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.ContractId).IsModified = false;
            _context.Entry(data).Property(x => x.LoanScheduleInfoId).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Schedules/{id}/delete")]
        public async Task<ActionResult> DeleteSchedules(int id)
        {

            var valid = await _context.LoanStandardSchedules.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            var data = await _context.LoanStandardScheduleDetails.Where(x => x.LoanStandardScheduleId == valid.Id).ToListAsync();

            try
            {
                data.ForEach(x => x.IsActive = 0);
                valid.IsActive = 0;
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpGet("{id}/Schedules")]
        public async Task<ActionResult<object>> GetAllSchedules(int id)
        {
            var scheduleDetails = await _context.VSchedulesDetails.Where(x => x.ContractId == id).ToListAsync();

            var schdules = await _context.VSchedulesStandardLoans.Where(x => x.ContractId == id && x.IsActive ==1).ToListAsync();

            return Ok(new
            {
                scheduleDetails = scheduleDetails,
                schdules = schdules
            });
        }

        [HttpGet("Schedules/{id}")]
        public async Task<ActionResult<LoanStandardSchedule>> GetSchedulesById(int id)
        {
            var data = await _context.LoanStandardSchedules.FirstOrDefaultAsync(x => x.Id == id && x.IsActive == 1);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("SchedulesDetails/add")]
        public async Task<ActionResult<LoanStandardScheduleDetail>> AddSchedulesDetails(LoanStandardScheduleDetail data)
        {
            data.IsActive = 1;
            _context.LoanStandardScheduleDetails.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("SchedulesDetails/update")]
        public async Task<ActionResult> UpdateSchedulesDetails(LoanStandardScheduleDetail data)
        {

            var valid = await _context.LoanStandardScheduleDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.ContractId).IsModified = false;
            _context.Entry(data).Property(x => x.LoanStandardScheduleId).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("SchedulesDetails/{id}/delete")]
        public async Task<ActionResult> DeleteSchedulesDetails(int id)
        {

            var valid = await _context.LoanStandardScheduleDetails.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;
            valid.IsActive = 0;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpPost("Schedules/import/{id}")]
        public async Task<ActionResult<object>> ImportSchedules(IFormFile file, int id)
        {

            int total_records = 0;
            DateTime created_at = DateTime.Now;

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())

            {
                
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    reader.Read(); 
                    
                    int countField = 0;
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        var cell = reader[i]?.ToString();
                        if (i > 500)
                        {
                            break;
                        }

                        if (cell != null)
                        {
                            countField++;
                        }
                    }

                    var bk = await _context.LoanBanks.AsNoTracking().ToListAsync();
                    var schedules = await _context.LoanStandardSchedules.AsNoTracking().ToListAsync();
                    var projects = await _context.VDbliveProjects.AsNoTracking().ToListAsync();
                    var scheduleInfo = await _context.LoanSchedulesInfos.FirstOrDefaultAsync(x => x.Id == id);

                    if(scheduleInfo == null)
                    {
                        return BadRequest(new ApiResponse("failed", "Schedule Info Id doesn't exists!", "400"));
                    }

                    using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                    {
                        while (reader.Read()) //Each ROW
                        {
                            string repayDate = reader.GetDateTime(1).ToString("yyyy-MM-dd");
                            var scheduleList = schedules.FirstOrDefault(x => x.LoanScheduleInfoId == id && x.RepayDate?.ToString("yyyy-MM-dd") == repayDate && x.IsActive == 1);

                            if (scheduleList != null)
                            {
                                return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Repay Date is already exists!", "400"));
                            }

                            var _bk = bk.FirstOrDefault(x => x.BankShort.ToLower() == reader.GetValue(0)?.ToString().ToLower());
                            if(_bk == null )
                            {
                                return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 2).ToString() + " Bank doesn't exists!", "400"));
                            }
                            var _auth = new CustomUserIdentity(User);

                            LoanStandardSchedule sl = new LoanStandardSchedule();

                            sl.ContractId = scheduleInfo.ContractId;
                            sl.LoanBankId = _bk?.Id;
                            sl.LoanScheduleInfoId = id;
                            sl.RepayDate = reader.GetDateTime(1);
                            sl.StartDate = reader.GetDateTime(2);
                            sl.FromDate = reader.GetDateTime(3);
                            sl.Days = Convert.ToInt32(reader.GetValue(4));
                            sl.Rate = Convert.ToDecimal(reader.GetValue(5));
                            sl.CreatedAt = created_at;
                            sl.CreatedBy = _auth.Id;
                            sl.IsActive = 1;

                            _context.LoanStandardSchedules.Add(sl);
                            await _context.SaveChangesAsync();
                            int resetCount = 1;

                            for (int i = 6; i < countField; i++)
                            {
                                 
                                if(resetCount == 6)
                                {
                                    
                                    LoanStandardScheduleDetail lsd = new LoanStandardScheduleDetail();
                                    lsd.LoanStandardScheduleId = sl.Id;
                                    lsd.ContractId = sl.ContractId;
                                    var proCode = reader.GetValue(i - (resetCount-1)).ToString();
                                    var p = projects.FirstOrDefault(p => p.ProjectCode.ToLower() == proCode?.ToLower());
                                    lsd.ProjectId = p?.Id;
                   
                                    lsd.PrincipalAmount = Convert.ToDecimal(reader.GetValue(i-(resetCount-2)));
                                    lsd.BalanceAmount = Convert.ToDecimal(reader.GetValue(i- (resetCount - 3)));
                                    lsd.InterestAmount = Convert.ToDecimal(reader.GetValue(i - (resetCount - 4)));
                                    lsd.Wht14 = Convert.ToDecimal(reader.GetValue(i - (resetCount -5)));
                                    lsd.TotalPayment = Convert.ToDecimal(reader.GetValue(i - (resetCount - 6)));
                                    _context.LoanStandardScheduleDetails.Add(lsd);
                                    await _context.SaveChangesAsync();
                                    resetCount = 0;
                                }

                                resetCount++;
                            }

                            total_records++;

                        }

                        ts.Complete();
                    }
                }
            }

            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }
    }
}
