﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Text;
using ExcelDataReader;
using System.Transactions;
using OneSignalApi.Model;
using System.IO;

namespace Web.Controllers.AP.ChartAccounts
{
    [Route("api/v1/ChartOAC/")]
    [ApiController]
    [Authorize]
    public class ChartAccountToProjectController : ControllerBase
    {
        private readonly APContext _context;

        private readonly ManualDbContext _manualDbContext;

        public ChartAccountToProjectController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }


        [HttpGet("{AccountStandardId}/project")]
        public async Task<ActionResult<IEnumerable<VChartAccountToProject>>> GetChartAccountToProject(int AccountStandardId)
        {
            return await _context.VChartAccountToProjects
                    .Where(x => x.AccountStandardId == AccountStandardId && x.Status == true)
                    .ToListAsync();
        }


        [HttpGet("project/{id}")]
        public async Task<ActionResult<VChartAccountToProject>> GetById(int id)
        {
            var data = await _context.VChartAccountToProjects.FirstOrDefaultAsync(x => x.Id == id);

            if(data == null) return NotFound();

            return Ok(data);
        }

        [HttpPost("project/add")]
        public async Task<ActionResult<ChartAccountsToProject>> Add(ChartAccountsToProject data)
        {
            var _auth = new CustomUserIdentity(User);

            if(checkExisted(data))
            {
                return BadRequest(new ApiResponse("failed", "This project already mapping", "400"));
            }
            
            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            try
            {
                _context.ChartAccountsToProjects.Add(data);

                await _context.SaveChangesAsync();
            }

            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return data;
        }

        private bool checkExisted(ChartAccountsToProject data, int? Id = null)
        {
            return  _context.ChartAccountsToProjects
                .AsNoTracking().Any(x => x.AccountStandardId == data.AccountStandardId && x.ProId == data.ProId && (Id == null || x.Id != data.Id));
        }

        [HttpPut("project/update")]
        public async Task<IActionResult> Update(ChartAccountsToProject data)
        {
            var _auth = new CustomUserIdentity(User);

            var valid = await _context.ChartAccountsToProjects.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true && x.AccountStandardId == data.AccountStandardId);
            
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Invalid Id", "400"));
            }

            if (checkExisted(data, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This project already mapping", "400"));
            }


            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
            }

            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return Ok();
        }

        [HttpDelete("project/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeletePaymentVoucher(int id)
        {
            try
            {
                var valid = await _context.ChartAccountsToProjects.AsNoTracking().FirstOrDefaultAsync(x => x.Id ==id && x.Status == true);
                
                if (valid == null)
                {
                    return BadRequest(new ApiResponse("failed", "Invalid Id", "400"));
                }

                _context.Entry(valid).State = EntityState.Modified;

                valid.Status = false;
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

    }
}
