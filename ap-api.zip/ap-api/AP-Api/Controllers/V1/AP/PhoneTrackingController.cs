﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class PhoneTrackingController : ControllerBase
    {
        private readonly APContext _context;

        public PhoneTrackingController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VPhoneTracking>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VPhoneTrackings
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Project == validFilter.Search || s.HouseNumber == validFilter.Search))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VPhoneTrackings
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Project == validFilter.Search || s.HouseNumber == validFilter.Search)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VPhoneTracking>> GetById(int id)
        {
            var data = await _context.VPhoneTrackings.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<PhoneTracking>> Add(PhoneTracking data)
        {

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.PhoneTrackings.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(PhoneTracking data)
        {
            var valid = await _context.PhoneTrackings.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(data);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> UpdateStatus(PhoneTracking data)
        {
            var valid = await _context.PhoneTrackings.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
