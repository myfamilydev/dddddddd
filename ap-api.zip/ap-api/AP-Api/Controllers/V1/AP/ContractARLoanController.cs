﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using ExcelDataReader;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ContractARLoanController : ControllerBase
    {
        private readonly APContext _context;

        public ContractARLoanController(IHttpContextAccessor httpContextAccessor, APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VContractArLoan>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VContractArLoans
                        .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ContractCode == filter.Search || s.LoanBankRef == filter.Search))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VContractArLoans
                            .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ContractCode == filter.Search || s.LoanBankRef == filter.Search) && s.IsActive == 1)
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VContractArLoan>> GetById(int id)
        {
            var data = await _context.VContractArLoans.FirstOrDefaultAsync(x => x.Id==id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<ContractArLoan>> Create(ContractArLoan data)
        {
            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.ContractArLoans.Where(x => x.ContractCode.EndsWith(year) && x.IsActive == 1).MaxAsync(x => x.ContractCode);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.ContractCode = "ARL:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.ContractCode = "ARL:" + "00001" + year;
            }

            try
            {
                var _auth = new CustomUserIdentity(User);

                data.CreatedAt = DateTime.Now;
                data.CreatedBy = _auth.Id;
                data.IsActive = 1;

                _context.ContractArLoans.Add(data);

                await _context.SaveChangesAsync();

                return data;
            } catch
            {
                return BadRequest();
            }
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(ContractArLoan data)
        {
            var valid = await _context.ContractArLoans.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.IsActive == 1);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            
            _context.Entry(data).Property(x => x.ContractCode).IsModified = false;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> Inactive(ContractArLoan data)
        {
            var valid = await _context.ContractArLoans.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = data.IsActive;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("Disbursments")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursment>>> GetAllDisbursments()
        {
            return await _context.VContractArDisbursments
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("{id}/Disbursments")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursment>>> GetAllDisbursments(int id)
        {
            return await _context.VContractArDisbursments
                .Where(x => x.ContractId == id)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("Disbursments/{id}")]
        public async Task<ActionResult<VContractArDisbursment>> GetDisbursmentsById(int id)
        {
            var data = await _context.VContractArDisbursments.FirstOrDefaultAsync(x=>x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Disbursments/add")]
        public async Task<ActionResult<ContractArDisbursment>> AddHtdItem(ContractArDisbursment data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.ContractArDisbursments.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Disbursments/update")]
        public async Task<IActionResult> UpdateDisbursments(ContractArDisbursment data)
        {
            var valid = await _context.ContractArDisbursments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Disbursments/{id}/delete")]
        public async Task<IActionResult> DisbursmentsDelete(int id)
        {
            var valid = await _context.ContractArDisbursments.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = 0;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("Disbursments/Htds")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursmentsHtd>>> GetAllDisbursmentsHtds()
        {
            return await _context.VContractArDisbursmentsHtds.ToListAsync();
        }

        [HttpGet("Disbursments/{id}/Htds")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursmentsHtd>>> GetAllDisbursmentsHtds(int id)
        {
            return await _context.VContractArDisbursmentsHtds
                .Where(x => x.ContractId == id)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("Disbursments/Htds/{id}")]
        public async Task<ActionResult<VContractArDisbursmentsHtd>> GetDisbursmentsHtdsById(int id)
        {
            var data = await _context.VContractArDisbursmentsHtds.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Disbursments/Htds/add")]
        public async Task<ActionResult<ContractArDisbursmentsHtd>> AddDisbursmentHtds(ContractArDisbursmentsHtd data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractArDisbursmentsHtds.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Disbursments/Htds/update")]
        public async Task<IActionResult> UpdateDisbursmentsHtds(ContractArDisbursmentsHtd data)
        {
            var valid = await _context.ContractArDisbursmentsHtds.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Disbursments/Htds/{id}/delete")]
        public async Task<IActionResult> DisbursmentsHtdDelete(int id)
        {
            var valid = await _context.ContractArDisbursmentsHtds.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("Disbursments/UseFunds")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursmentsUseFund>>> GetAllDisbursmentsUseFunds()
        {
            return await _context.VContractArDisbursmentsUseFunds.ToListAsync();
        }

        [HttpGet("Disbursments/{id}/UseFunds")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursmentsUseFund>>> GetAllDisbursmentsUseFunds(int id)
        {
            return await _context.VContractArDisbursmentsUseFunds
                .Where(x => x.ContractId == id)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("Disbursments/UseFunds/{id}")]
        public async Task<ActionResult<VContractArDisbursmentsUseFund>> GetDisbursmentsUseFundsById(int id)
        {
            var data = await _context.VContractArDisbursmentsUseFunds.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Disbursments/UseFunds/add")]
        public async Task<ActionResult<ContractArDisbursmentsUseFund>> AddDisbursmentUseFunds(ContractArDisbursmentsUseFund data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractArDisbursmentsUseFunds.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Disbursments/UseFunds/update")]
        public async Task<IActionResult> UpdateDisbursmentsUseFunds(ContractArDisbursmentsHtd data)
        {
            var valid = await _context.ContractArDisbursmentsUseFunds.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Disbursments/UseFunds/{id}/delete")]
        public async Task<IActionResult> DisbursmentsUseFundsDelete(int id)
        {
            var valid = await _context.ContractArDisbursmentsUseFunds.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpGet("Disbursments/CostCenters")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursmentsCostCenter>>> GetAllDisbursmentsCostCenters()
        {
            return await _context.VContractArDisbursmentsCostCenters.ToListAsync();
        }

        [HttpGet("Disbursments/{id}/CostCenters")]
        public async Task<ActionResult<IEnumerable<VContractArDisbursmentsCostCenter>>> GetAllDisbursmentsCostCenters(int id)
        {
            return await _context.VContractArDisbursmentsCostCenters
                .Where(x => x.ContractId == id)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("Disbursments/CostCenters/{id}")]
        public async Task<ActionResult<VContractArDisbursmentsCostCenter>> GetDisbursmentsCostCentersById(int id)
        {
            var data = await _context.VContractArDisbursmentsCostCenters.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Disbursments/CostCenters/add")]
        public async Task<ActionResult<ContractArDisbursmentsCostCenter>> AddDisbursmentCostCenters(ContractArDisbursmentsCostCenter data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractArDisbursmentsCostCenters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Disbursments/CostCenters/update")]
        public async Task<IActionResult> UpdateDisbursmentsCostCenters(ContractArDisbursmentsCostCenter data)
        {
            var valid = await _context.ContractArDisbursmentsCostCenters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Disbursments/CostCenters/{id}/delete")]
        public async Task<IActionResult> DisbursmentsCostCentersDelete(int id)
        {
            var valid = await _context.ContractArDisbursmentsCostCenters.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("AdminFees")]
        public async Task<ActionResult<IEnumerable<VContractAdminFee>>> GetAllAdminFees()
        {
            return await _context.VContractAdminFees
                    .AsNoTracking()
                    .ToListAsync();
        }

        [HttpGet("{id}/AdminFees")]
        public async Task<ActionResult<IEnumerable<VContractAdminFee>>> GetAllAdminFees(int id)
        {
            return await _context.VContractAdminFees
                    .Where(x => x.ContractId == id)
                    .AsNoTracking()
                    .ToListAsync();
        }

        [HttpGet("AdminFees/{id}")]
        public async Task<ActionResult<VContractAdminFee>> GetAdminFeeById(int id)
        {
            var data = await _context.VContractAdminFees.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("AdminFees/add")]
        public async Task<ActionResult<ContractArAdminFee>> AddAdminFee(ContractArAdminFee data)
        {
            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractArAdminFees.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("AdminFees/update")]
        public async Task<IActionResult> UpdateAdminFee(ContractArAdminFee data)
        {
            var valid = await _context.ContractArAdminFees.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("AdminFees/{id}/delete")]
        public async Task<ActionResult> AdminFeesAdd(int id)
        {
            var valid = await _context.ContractArAdminFees.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("DocumentsRequirement")]
        public async Task<ActionResult<IEnumerable<VContractArDocumentRequirement>>> GetAllDocumentsRequirement()
        {
            return await _context.VContractArDocumentRequirements
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("{id}/DocumentsRequirement")]
        public async Task<ActionResult<IEnumerable<VContractArDocumentRequirement>>> GetAllDocumentsRequirement(int id)
        {
            return await _context.VContractArDocumentRequirements
                .Where(x => x.ContractId == id)
                .ToListAsync();
        }

        [HttpGet("DocumentsRequirement/{id}")]
        public async Task<ActionResult<VContractArDocumentRequirement>> GetLoanDocumentsRequirementById(int id)
        {
            var data = await _context.VContractArDocumentRequirements.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("DocumentsRequirement/add")]
        public async Task<ActionResult<ContractArDocumentsRequirement>> AddDocumentsRequirement(ContractArDocumentsRequirement data)
        {
            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            _context.ContractArDocumentsRequirements.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("DocumentsRequirement/update")]
        public async Task<IActionResult> UpdateDocumentsRequirement(ContractArDocumentsRequirement data)
        {
            var valid = await _context.ContractArDocumentsRequirements.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("DocumentsRequirement/{id}/delete")]
        public async Task<IActionResult> DocumentsRequirementDelete(int id)
        {
            var valid = await _context.ContractArDocumentsRequirements.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("Settlements")]
        public async Task<ActionResult<IEnumerable<ContractArSettlement>>> GetAllSettlements()
        {
            return await _context.ContractArSettlements
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("{id}/Settlements")]
        public async Task<ActionResult<IEnumerable<ContractArSettlement>>> GetAllSettlements(int id)
        {
            return await _context.ContractArSettlements.AsNoTracking()
                .Where(x => x.ContractId == id)
                .ToListAsync();
        }

        [HttpGet("Settlements/{id}")]
        public async Task<ActionResult<VContractArSettlement>> GetSettlementsById(int id)
        {
            var data = await _context.VContractArSettlements.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Settlements/add")]
        public async Task<ActionResult<ContractArSettlement>> AddSettlements(ContractArSettlement data)
        {
            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.IsActive = 1;

            _context.ContractArSettlements.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Settlements/update")]
        public async Task<IActionResult> UpdateSettlements(ContractArSettlement data)
        {
            var valid = await _context.ContractArSettlements.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Settlements/{id}/delete")]
        public async Task<IActionResult> SettlementsDelete(int id)
        {
            var valid = await _context.ContractArSettlements.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = 0;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("PaymentTerms")]
        public async Task<ActionResult<IEnumerable<ContractArPaymentTerm>>> GetAllPaymentTerm()
        {
            return await _context.ContractArPaymentTerms.AsNoTracking().Where(x => x.Status == true).ToListAsync();
        }

        [HttpGet("{id}/PaymentTerms")]
        public async Task<ActionResult<IEnumerable<ContractArPaymentTerm>>> GetAllPaymentTerms(int id)
        {
            return await _context.ContractArPaymentTerms
                .Where(x => x.ContractId == id && x.Status == true)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("PaymentTerm/{id}")]
        public async Task<ActionResult<ContractArPaymentTerm>> GetPaymentTermById(int id)
        {
            var data = await _context.ContractArPaymentTerms.FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("PaymentTerm/add")]
        public async Task<ActionResult<ContractArPaymentTerm>> AddPaymentTerm(ContractArPaymentTerm data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractArPaymentTerms.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("PaymentTerm/update")]
        public async Task<IActionResult> UpdatePaymentTerm(ContractArPaymentTerm data)
        {
            var valid = await _context.ContractArPaymentTerms.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("PaymentTerm/{id}/delete")]
        public async Task<IActionResult> PaymentTermDelete(int id)
        {
            var valid = await _context.ContractArPaymentTerms.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("LimitPrincipals")]
        public async Task<ActionResult<IEnumerable<ContractArLimitPrincipal>>> GetAllLimitPrincipal()
        {
            return await _context.ContractArLimitPrincipals.AsNoTracking().Where(x => x.Status == true).ToListAsync();
        }

        [HttpGet("{id}/LimitPrincipals")]
        public async Task<ActionResult<IEnumerable<ContractArLimitPrincipal>>> GetAllLimitPrincipals(int id)
        {
            return await _context.ContractArLimitPrincipals
                .Where(x => x.ContractId == id && x.Status == true)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("LimitPrincipal/{id}")]
        public async Task<ActionResult<ContractArLimitPrincipal>> GetLimitPrincipalById(int id)
        {
            var data = await _context.ContractArLimitPrincipals.FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("LimitPrincipal/add")]
        public async Task<ActionResult<ContractArLimitPrincipal>> AddLimitPrincipal(ContractArLimitPrincipal data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.ContractArLimitPrincipals.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("LimitPrincipal/update")]
        public async Task<IActionResult> UpdateLimitPrincipal(ContractArLimitPrincipal data)
        {
            var valid = await _context.ContractArLimitPrincipals.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("LimitPrincipal/{id}/delete")]
        public async Task<IActionResult> LimitPrincipalDelete(int id)
        {
            var valid = await _context.ContractArLimitPrincipals.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = false;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
