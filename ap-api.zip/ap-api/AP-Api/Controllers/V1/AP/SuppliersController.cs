﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Telegram.Bot.Types;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class SuppliersController : ControllerBase
    {
        private readonly APContext _context;
        
        private readonly ManualDbContext _manualDbContext;

        public SuppliersController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetSupplierAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.Suppliers
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search) 
                        || s.NameKh.Contains(filter.Search)
                        || s.BehaviorDescription.ToLower().Contains(filter.Search.ToLower())
                        || s.NameOnCheque.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierType.ToLower().Contains(filter.Search.ToLower())
                        || s.ContactNumber.ToLower().Contains(filter.Search.ToLower())
                        || s.PaymentCollector.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierLocation.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierCode.ToLower().Contains(filter.Search.ToLower())
                        || s.NameEn.ToLower().Contains(filter.Search.ToLower()))))
                           .OrderBy(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.Suppliers
                        .Where(s => (s.CompanyId == user.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.NameKh.Contains(filter.Search)
                        || s.BehaviorDescription.ToLower().Contains(filter.Search.ToLower())
                        || s.NameOnCheque.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierType.ToLower().Contains(filter.Search.ToLower())
                        || s.ContactNumber.ToLower().Contains(filter.Search.ToLower())
                        || s.PaymentCollector.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierLocation.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierCode.ToLower().Contains(filter.Search.ToLower())
                        || s.NameEn.ToLower().Contains(filter.Search.ToLower()))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetSuppliersBasicAsync()
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VSuppliersBasics.Where(x => x.CompanyId == user.CompanySessionId).ToListAsync();
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetSupplierAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.Suppliers.FirstOrDefaultAsync(x => x.Id == id && user.CompanySessionId == x.CompanyId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.suppliers", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Supplier>> AddSupplierAsync(Supplier data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var suffix = "/" + DateTime.Now.ToString("yy");

            data.SupplierCode = await new MaxCode().GetStandardCodeAsync("dbo.suppliers", "supplier_code", user.CompanySessionId,"SC:", suffix);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.RecStatus = 0;

            data.CompanyId = user.CompanySessionId;

            _context.Suppliers.Add(data);

            await _context.SaveChangesAsync();

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.suppliers", data.Id, _auth.Id);

            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateSupplierAsync(Supplier data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.Suppliers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true && x.CompanyId == user.CompanySessionId);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.SupplierCode).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteSupplierAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var valid = await _context.Suppliers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.Suppliers.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }
                throw;
            }
            return Ok();
        }

        [HttpGet("items")]
        public async Task<ActionResult<IEnumerable<object>>> GetAllItemsAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VSuppliersItems
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search)
                           || s.UomKh.ToLower().Contains(filter.Search.ToLower())
                           || s.ItemCode.ToLower().Contains(filter.Search.ToLower())
                           || s.ItemType.ToLower().Contains(filter.Search.ToLower())
                           || s.Name.ToLower().Contains(filter.Search.ToLower())
                           || s.Description.ToLower().Contains(filter.Search.ToLower())
                           || s.UomEn.ToLower().Contains(filter.Search.ToLower())
                           || s.QbItemCode.ToLower().Contains(filter.Search.ToLower())
                           || s.Project.ToLower().Contains(filter.Search.ToLower())
                           //|| s.AccountCode.ToLower().Contains(filter.Search.ToLower())
                           )))
                           .OrderBy(x => x.Name)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VSuppliersItems
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search)
                           || s.UomKh.ToLower().Contains(filter.Search.ToLower())
                           || s.ItemCode.ToLower().Contains(filter.Search.ToLower())
                           || s.ItemType.ToLower().Contains(filter.Search.ToLower())
                           || s.Name.ToLower().Contains(filter.Search.ToLower())
                           || s.Description.ToLower().Contains(filter.Search.ToLower())
                           || s.UomEn.ToLower().Contains(filter.Search.ToLower())
                           || s.QbItemCode.ToLower().Contains(filter.Search.ToLower())
                           || s.Project.ToLower().Contains(filter.Search.ToLower())
                           //|| s.AccountCode.ToLower().Contains(filter.Search.ToLower())
                           )))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("items/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetItemsBasicAsync([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VSuppliersItemsBasics.Where(x => x.ProjectId == filter.ProId && x.CompanyId == user.CompanySessionId).ToListAsync();
        }

        [HttpGet("items/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetItemByIdAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VSuppliersItems.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.suppliers_items", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("items/add")]
        public async Task<ActionResult<SuppliersItem>> AddSupplierItemAsync(SuppliersItem data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);

            var suffix = "-" + pro.ProjectCode.Substring(1, 2);

            data.ItemCode = await new MaxCode().GetStandardCodeV1Async("dbo.suppliers_items", "item_code", user.CompanySessionId, "G-ST-", suffix, "D7");

            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            data.RecStatus = 0;

            data.CompanyId = user.CompanySessionId;

            _context.SuppliersItems.Add(data);

            await _context.SaveChangesAsync();

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.suppliers_items", data.Id, _auth.Id);

            return data;
        }

        [HttpPut("items/update")]
        public async Task<IActionResult> UpdateSupplierItemAsync(SuppliersItem data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (valid == null)
            {
                return BadRequest();
            }

            if(data.ProjectId != valid.ProjectId)
            {
                var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);

                var suffix = "-" + pro.ProjectCode.Substring(1, 2);

                data.ItemCode = await new MaxCode().GetStandardCodeV1Async("dbo.suppliers_items", "item_code", user.CompanySessionId, "G-ST-", suffix, "D7");
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.ItemCode).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("items/{id}/delete")]
        public async Task<IActionResult> DeleteSupplierItemAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var valid = await _context.SuppliersItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.SuppliersItems.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }
                throw;
            }
            return Ok();
        }


        [HttpGet("item-types")]
        public async Task<ActionResult<IEnumerable<object>>> ItemTypeGetAll([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.SuppliersItemsTypes
                           .Where(s =>  ((String.IsNullOrEmpty(filter.Search) || s.ItemType == filter.Search) && s.IsActive == true))
                           .OrderBy(x => x.ItemType)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.SuppliersItemsTypes
                           .Where(s => (String.IsNullOrEmpty(filter.Search) || s.ItemType == filter.Search))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("item-types/basic")]
        public async Task<ActionResult<IEnumerable<object>>> ItemTypeBasic()
        {
            return await _context.SuppliersItemsTypes
                            .Where(x => x.IsActive == true)
                           .ToListAsync();
        }

        [HttpGet("item-types/{id}")]
        public async Task<ActionResult<SuppliersItemsType>> Getitemtypes(short id)
        {
            var data = await _context.SuppliersItemsTypes.FirstOrDefaultAsync(x=>x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("item-types/add")]
        public async Task<ActionResult<SuppliersItemsType>> Additemtypes(SuppliersItemsType data)
        {
            var check = await _context.SuppliersItemsTypes.FirstOrDefaultAsync(x=>x.ItemType == data.ItemType && x.Id != data.Id);

            if(check != null)
            {
                return BadRequest(new ApiResponse("failed","Item type already exists!","200"));
            }

            data.IsActive = true;

            _context.SuppliersItemsTypes.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("item-types/update")]
        public async Task<IActionResult> Updateitemtypes(SuppliersItemsType data)
        {
            var valid = await _context.SuppliersItemsTypes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.IsActive).IsModified = false;


            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("item-types/{id}/delete")]
        public async Task<IActionResult> DeleteItemTypeAsync(int id)
        {
            var valid = await _context.SuppliersItemsTypes.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.IsActive = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpGet("contracts")]
        public async Task<ActionResult<IEnumerable<object>>> GetContractAllAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VSuppliersContracts
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search) 
                           || s.SupplierName.ToLower().Contains(filter.Search.ToLower())
                           || s.ItemName.ToLower().Contains(filter.Search.ToLower())
                           || s.ContractCode.ToLower().Contains(filter.Search.ToLower())
                           || s.ContractPo.ToLower().Contains(filter.Search.ToLower())
                           //|| s.AccountCode.ToLower().Contains(filter.Search.ToLower())
                           || s.TermPay.ToLower().Contains(filter.Search.ToLower())
                           || s.Project.ToLower().Contains(filter.Search.ToLower())
                           || s.PaymentMethod.ToLower().Contains(filter.Search.ToLower()))
                           ))
                           .OrderBy(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VSuppliersContracts
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search)
                           || s.SupplierName.ToLower().Contains(filter.Search.ToLower())
                           || s.ItemName.ToLower().Contains(filter.Search.ToLower())
                           || s.ContractCode.ToLower().Contains(filter.Search.ToLower())
                           || s.ContractPo.ToLower().Contains(filter.Search.ToLower())
                           //|| s.AccountCode.ToLower().Contains(filter.Search.ToLower())
                           || s.TermPay.ToLower().Contains(filter.Search.ToLower())
                           || s.Project.ToLower().Contains(filter.Search.ToLower())
                           || s.PaymentMethod.ToLower().Contains(filter.Search.ToLower()))
                           ))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("contracts/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetContractBasicAsync([FromQuery] FilterBy filterBy)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VSuppliersContractsBasics.Where(x => x.ProjectId == filterBy.ProId && x.CompanyId == user.CompanySessionId).ToListAsync();
        }

        [HttpGet("contracts/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetContractAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VSuppliersContracts.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            //var _auth = new CustomUserIdentity(User);

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.suppliers_contracts", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("contracts/add")]
        public async Task<ActionResult<SuppliersContract>> ContractAdd(SuppliersContract data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersContracts.FirstOrDefaultAsync(x => x.ContractPo == data.ContractPo && x.CompanyId == user.CompanySessionId);

            if(valid != null)
            {
                return BadRequest(new ApiResponse("failed", "Contract PO already exists!", "400"));
            }

            string year = DateTime.Now.ToString("yy");

            var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);

            if(pro == null)
            {
                return BadRequest(new ApiResponse("failed", "Project not exists!", "400"));
            }

            var suffix = "/" + year + "-" + pro.ProjectCode.Substring(1, 2);

            data.ContractCode = await new MaxCode().GetStandardCodeAsync("dbo.suppliers_contracts", "contract_code",user.CompanySessionId ,"SC:", suffix, "D5");

            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            data.RecStatus = 0;

            data.CompanyId = user.CompanySessionId;

            _context.SuppliersContracts.Add(data);

            await _context.SaveChangesAsync();

            _manualDbContext.Database.ExecuteSqlRaw("exec [dbo].[sp_sync_contract_account_code_from_item] {0}", data.Id);

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.suppliers_contracts", data.Id, _auth.Id);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/update")]
        public async Task<IActionResult> ContractUpdate(SuppliersContract data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract ID found!", "400"));
            }

            var validPo = await _context.SuppliersContracts.FirstOrDefaultAsync(x => x.ContractPo == data.ContractPo && x.Id != data.Id);

            if (validPo != null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Purchase already exists!", "400"));
            }

            if(data.ProjectId != valid?.ProjectId)
            {
                var proOld = "-" + _context.VDbliveProjects.FirstOrDefault(x => x.Id == valid.ProjectId)?.ProjectCode?.Substring(1, 2);

                var proNew = "-" + _context.VDbliveProjects.FirstOrDefault(x => x.Id == data.ProjectId)?.ProjectCode?.Substring(1, 2);

                data.ContractCode = data?.ContractCode?.Replace(proOld, proNew);
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;



            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();

                _manualDbContext.Database.ExecuteSqlRaw("exec [dbo].[sp_sync_contract_account_code_from_item] {0}", data.Id);

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/{id}/delete")]
        public async Task<IActionResult> DeleteSupplierContract(int id)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var valid = await _context.SuppliersContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.SuppliersContracts.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }
                throw;
            }
            return Ok();
        }

        [HttpGet("contracts/{id}/items")]
        public async Task<ActionResult<SuppliersContractsItem>> GetContractItemAsync(int id)
        {
            var valid = await _context.SuppliersContractsItems.FirstOrDefaultAsync(x => x.ContractId == id && x.Status == 1);

            if (valid == null)
            {
                return NoContent();
            }

            return valid;
        }

        [HttpPost("contracts/items/add")]
        public async Task<ActionResult<SuppliersContractsItem>> AddContractItemAsync(SuppliersContractsItem data)
        {
            var valid = await _context.SuppliersContractsItems.FirstOrDefaultAsync(x => x.ValidDate >= data.ValidDate && x.ContractId == data.ContractId);

            if (valid != null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Item already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.Status = 1;

            _context.SuppliersContractsItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/items/update")]
        public async Task<ActionResult<SuppliersContractsItem>> UpdateContractItemAsync(SuppliersContractsItem data)
        {
            var valid = await _context.SuppliersContractsItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Item already exists!", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.Status).IsModified = false;


            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("contracts/{id}/items/sub")]
        public async Task<ActionResult<IEnumerable<SuppliersContractsItemsSub>>> GetContractItemSubAsync(int id)
        {
            return await _context.SuppliersContractsItemsSubs
                        .Where(x => x.ContractId == id)
                        .ToListAsync();
        }

        [HttpPost("contracts/items/sub/add")]
        public async Task<ActionResult<SuppliersContractsItemsSub>> AddContractItemSubAsync(SuppliersContractsItemsSub data)
        {
            var valid = await _context.SuppliersContractsItems.FirstOrDefaultAsync(x => x.Id == data.ContractItemId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Item not exists!", "400"));
            }

            if (valid.ValidDate < DateTime.Now)
            {
                return BadRequest(new ApiResponse("failed", "Contract Validate is expired!", "400"));
            }

            if (valid.Status == 0)
            {
                return BadRequest(new ApiResponse("failed", "Contract status is inactive!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.SuppliersContractsItemsSubs.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/items/sub/update")]
        public async Task<ActionResult<SuppliersContractsItemsSub>> UpdateContractItemSubAsync(SuppliersContractsItemsSub data)
        {
            var check = await _context.SuppliersContractsItemsSubs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (check == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Item Sub already exists!", "400"));
            }

            var valid = await _context.SuppliersContractsItems.FirstOrDefaultAsync(x => x.Id == data.ContractItemId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Item not exists!", "400"));
            }

            if (valid.ValidDate < DateTime.Now)
            {
                return BadRequest(new ApiResponse("failed", "Contract Validate is expired!", "400"));
            }

            if (valid.Status == 0)
            {
                return BadRequest(new ApiResponse("failed", "Contract status is inactive!", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("contracts/items/sub/{id}")]

        public async Task<ActionResult<SuppliersContractsItemsSub>> GetContractItemSubByIdAsync(int id)
        {
            var valid = await _context.SuppliersContractsItemsSubs.FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return NoContent();
            }

            return valid;

        }

        [HttpDelete("contracts/items/sub/{id}/delete")]

        public async Task<IActionResult> DeleteContractItemSubAsync(int id)
        {
            var valid = await _context.SuppliersContractsItemsSubs.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.SuppliersContractsItemsSubs.Remove(valid);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/{id}/payment-terms")]
        public async Task<ActionResult<IEnumerable<SuppliersContractsPaymentTerm>>> GetContractPaymentTermsAsync(int id)
        {
            return await _context.SuppliersContractsPaymentTerms
                        .Where(x => x.ContractId == id)
                        .ToListAsync();
        }

        [HttpGet("contracts/payment-terms/{id}")]
        public async Task<ActionResult<SuppliersContractsPaymentTerm>> GetContractPaymentTermsByIdAsync(int id)
        {
            var data = await _context.SuppliersContractsPaymentTerms
                        .FirstOrDefaultAsync(x => x.Id == id);
            if(data == null)
            {
                return NoContent();
            }

            return data;
                        
        }

        [HttpPost("contracts/payment-terms/add")]
        public async Task<ActionResult<SuppliersContractsPaymentTerm>> AddContractPaymentTermAsync(SuppliersContractsPaymentTerm data)
        {
            var valid = await _context.SuppliersContracts.FirstOrDefaultAsync(x => x.Id == data.ContractId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract not exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            decimal totalPerc = (decimal)await _context.SuppliersContractsPaymentTerms
                    .Where(x => x.ContractId == data.ContractId)
                    .SumAsync(x => x.Percentage);

            if(totalPerc + data.Percentage > 100)
            {
                return BadRequest(new ApiResponse("failed", "Payment term percentage over 100%", "400"));
            }

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.SuppliersContractsPaymentTerms.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/payment-terms/update")]
        public async Task<ActionResult<SuppliersContractsPaymentTerm>> UpdateContractPaymentTermAsync(SuppliersContractsPaymentTerm data)
        {
            var valid = await _context.SuppliersContracts.FirstOrDefaultAsync(x => x.Id == data.ContractId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract not exists!", "400"));
            }

            var validdata = await _context.SuppliersContractsPaymentTerms.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if(validdata == null)
            {
                return BadRequest(new ApiResponse("failed", "Data not exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            decimal totalPerc = (decimal)await _context.SuppliersContractsPaymentTerms
                    .Where(x => x.ContractId == data.ContractId)
                    .SumAsync(x => x.Percentage);

            if ((totalPerc + data.Percentage) - validdata.Percentage > 100)
            {
                return BadRequest(new ApiResponse("failed", "Payment term percentage over 100%", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/payment-terms/{id}/delete")]
        [Obsolete]
        public async Task<IActionResult> ContractPaymentTermDelete(int id)
        {
            var valid = await _context.SuppliersContractsPaymentTerms.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.SuppliersContractsPaymentTerms.Remove(valid);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }


        [HttpGet("contracts/terminates")]
        public async Task<ActionResult<IEnumerable<VSuppliersTerminate>>> GetSuppliersContractsTerminate([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VSuppliersTerminates
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search)
                           || s.SupplierKh.ToLower().Contains(filter.Search.ToLower())
                           || s.SupplierEn.ToLower().Contains(filter.Search.ToLower())
                           || s.TerminateCode.ToLower().Contains(filter.Search.ToLower())
                           || s.Project.ToLower().Contains(filter.Search.ToLower())
                           || s.ContractCode.ToLower().Contains(filter.Search.ToLower()))

                           ))
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VSuppliersTerminates
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search)
                           || s.SupplierKh.ToLower().Contains(filter.Search.ToLower())
                           || s.SupplierEn.ToLower().Contains(filter.Search.ToLower())
                           || s.TerminateCode.ToLower().Contains(filter.Search.ToLower())
                           || s.Project.ToLower().Contains(filter.Search.ToLower())
                           || s.ContractCode.ToLower().Contains(filter.Search.ToLower()))
                           ))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("contracts/terminates/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetSuppliersContractsTerminateAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VSuppliersTerminates.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            //var _auth = new CustomUserIdentity(User);

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.suppliers_contracts_terminates", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }


        [HttpPost("contracts/terminates/add")]
        public async Task<ActionResult<SuppliersContractsTerminate>> AddcontractsTerminateAsync(SuppliersContractsTerminate data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.ContractId && x.CompanyId == user.CompanySessionId);

            if(valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract not exists!", "400"));
            }

            var exist = await _context.SuppliersContractsTerminates.AsNoTracking().FirstOrDefaultAsync(x => x.ContractId == data.ContractId && x.CompanyId == user.CompanySessionId);

            if(exist != null)
            {
                return BadRequest(new ApiResponse("failed", "Contract already exists!", "400"));
            }

            var year = DateTime.Now.ToString("yy");

            var suffix = "/" + year;

            data.TerminateCode = await new MaxCode().GetStandardCodeAsync("dbo.suppliers_contracts_terminates", "terminate_code", user.CompanySessionId,"SCT:", suffix);


             //var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.RecStatus = 0;

            data.CreateAt = DateTime.Now;

            data.CreateBy = _auth.Id;

            data.ContractId = user.CompanySessionId;

            _context.SuppliersContractsTerminates.Add(data);

            await _context.SaveChangesAsync();

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.suppliers_contracts_terminates", data.Id, _auth.Id);

            await _context.SaveChangesAsync();

            return data;
        }


        [HttpPut("contracts/terminates/update")]
        public async Task<ActionResult<SuppliersContractsTerminate>> UpdateContractsTerminateAsync(SuppliersContractsTerminate data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersContractsTerminates.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);


            var exist = await _context.SuppliersContractsTerminates.AsNoTracking().FirstOrDefaultAsync(x => x.ContractId == data.ContractId && x.RecStatus == 3 && x.CompanyId == user.CompanySessionId);

            if (exist != null && exist.Id != valid.Id)
            {
                return BadRequest(new ApiResponse("failed", "Contract already exists!", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            _context.Entry(data).Property(x => x.TerminateCode).IsModified = false;

            _context.Entry(data).Property(x => x.CreateAt).IsModified = false;

            _context.Entry(data).Property(x => x.CreateBy).IsModified = false;

            //var _auth = new CustomUserIdentity(User);

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("contracts/terminates/approve/{id}")]
        public async Task<ActionResult> ApproveContractTerminateAsync(int id)
        {

            try
            {
                var valid = await _context.SuppliersContractsTerminates
                                           .AsNoTracking()
                                           .FirstOrDefaultAsync(x => x.Id == id);
                var data = await _context.SuppliersContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Status == true && x.Id == valid.ContractId);

                _context.Entry(data).State = EntityState.Modified;

                data.Status = false;

                return Ok();
            }
            catch
            {
                return Ok();
            }
        }

        [HttpGet("settle-payment-materials")]
        public async Task<ActionResult<IEnumerable<VSettlePaymentMaterial>>> GetSettlePaymentMaterialAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VSettlePaymentMaterials
                        .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.SupplierNameKh.Contains(filter.Search)
                        || s.SupplierNameEn.ToLower().Contains(filter.Search.ToLower())
                        || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                        || s.ItemName.ToLower().Contains(filter.Search.ToLower())
                        || s.ItemType.ToLower().Contains(filter.Search.ToLower()))))
                           .OrderBy(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VSettlePaymentMaterials
                        .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search)
                        || s.SupplierNameKh.Contains(filter.Search)
                        || s.SupplierNameEn.ToLower().Contains(filter.Search.ToLower())
                        || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                        || s.ItemName.ToLower().Contains(filter.Search.ToLower())
                        || s.ItemType.ToLower().Contains(filter.Search.ToLower()))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("settle-payment-materials/{id}")]
        public async Task<ActionResult<VSettlePaymentMaterial>> GetSettlePaymentMaterialAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VSettlePaymentMaterials.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && user.CompanySessionId== x.CompanyId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("settle-payment-materials/add")]
        public async Task<ActionResult<SettlePaymentMaterial>> AddSettlePaymentMaterialAsync(SettlePaymentMaterial data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);

            var suffix = "/" + DateTime.Now.ToString("yy") + "-" + pro.ProjectCode.Substring(1, 2);

            data.SettlePaymentCode = await new MaxCode().GetStandardCodeAsync("dbo.settle_payment_materials", "settle_payment_code",user.CompanySessionId ,"MS:", suffix);

            //var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;


            _context.SettlePaymentMaterials.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("settle-payment-materials/update")]
        public async Task<IActionResult> UpdateSettlePaymentMaterialAsync(SettlePaymentMaterial data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SettlePaymentMaterials.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if(data.ProjectId != valid.ProjectId)
            {
                var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);

                var suffix = "/" + DateTime.Now.ToString("yy") + "-" + pro.ProjectCode.Substring(1, 2);

                data.SettlePaymentCode = await new MaxCode().GetStandardCodeAsync("dbo.settle_payment_materials", "settle_payment_code", user.CompanySessionId,"MS:", suffix);
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            if (data.ProjectId == valid.ProjectId)
            {
                _context.Entry(data).Property(x => x.SettlePaymentCode).IsModified = false;
            }
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            data.CompanyId = user.CompanySessionId;


            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("settle-payment-materials/{id}/delete")]
        public async Task<IActionResult> DeleteSettlePaymentMaterialAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SettlePaymentMaterials.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;
            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpGet("share-cost-standard")]
        public async Task<ActionResult<IEnumerable<MShareCostStandEffective>>> GetShareCostStandardAsync()
        {
            var list = await _manualDbContext.MShareCostStandEffectives.FromSqlRaw(@"exec dbo.sp_get_cost_standard_effective").ToListAsync();

            return list;
        }

    }
}
