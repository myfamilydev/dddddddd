﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class CustomerRequestController : ControllerBase
    {
        private readonly APContext _context;

        public CustomerRequestController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VCustomerRequest>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VCustomerRequests
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.RequestCode == validFilter.Search || s.ProjectShort == validFilter.Search || s.Number == validFilter.Search || s.Customer1 == validFilter.Search || s.Customer2 == validFilter.Search))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VCustomerRequests
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.RequestCode == validFilter.Search || s.ProjectShort == validFilter.Search || s.Number == validFilter.Search || s.Customer1 == validFilter.Search || s.Customer2 == validFilter.Search)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetById(int id)
        {
            var data = await _context.VCustomerRequests.FirstOrDefaultAsync(x => x.Id == id);
            var _auth = new CustomUserIdentity(User);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("arch.customer_requests", data.Id, _auth.Id, 0);
            wf.workflowModel.Data = data;

            return wf.workflowModel;

        }

        [HttpPost("code")]
        public async Task<ActionResult<CustomerRequest>> GetByCode(CodeInput codeInput)
        {
            var data = await _context.VCustomerRequests.FirstOrDefaultAsync(x => x.RequestCode == codeInput.Code);
            var _auth = new CustomUserIdentity(User);

            if (data == null)
            {
                return NoContent();
            }

           

            return Ok(data);

        }


        [HttpPost("add")]
        public async Task<ActionResult<CustomerRequest>> Add(CustomerRequest data)
        {
            try
            {
                var _auth = new CustomUserIdentity(User);
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    string year = "/" + DateTime.Now.ToString("yy");
                    var getMax = await _context.CustomerRequests.Where(x => x.RequestCode.EndsWith(year)).MaxAsync(x => x.RequestCode);

                    if (getMax != null)
                    {
                        getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                        var maxNumber = Regex.Match(getMax, @"\d+").Value;
                        data.RequestCode = "CR:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
                    }
                    else
                    {
                        data.RequestCode = "CR:" + "00001" + year;
                    }
                    

                    data.CreatedAt = DateTime.Now;
                    data.CreatedBy = _auth.Id;
                    data.Status = 1;
                    data.RecStatus = 0;

                    _context.CustomerRequests.Add(data);

                    await _context.SaveChangesAsync();
                   
                    ts.Complete();
                    
                    
                }
                
                new WorkflowDetailModel().WorkflowHistoryDraft("arch.customer_requests", data.Id, _auth.Id);
                return data;
            }
            catch {
                return BadRequest();
            }            
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(CustomerRequest data)
        {
            var valid = await _context.CustomerRequests.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(data);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> InactiveStatus(CustomerRequest data)
        {
            var valid = await _context.CustomerRequests.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null && valid?.RecStatus >= 3)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("detail/{id}")]
        public async Task<ActionResult<IEnumerable<VCustomerRequestDetail>>> GetDetail(int id)
        {
            return await _context.VCustomerRequestDetails.Where(x => x.CustomerRequestId == id).ToListAsync();
        }

        [HttpPost("detail/add")]
        public async Task<ActionResult<CustomerRequestDetail>> DetailAdd(CustomerRequestDetail data)
        {

            data.Status = 1;

            _context.CustomerRequestDetails.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("detail/update")]
        public async Task<ActionResult<CustomerRequestDetail>> DetailUpdate(CustomerRequestDetail data)
        {

            var valid = await _context.CustomerRequestDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("detail/update/status")]
        public async Task<ActionResult<CustomerRequestDetail>> DetailUpdateStatus(CustomerRequestDetail data)
        {

            var valid = await _context.CustomerRequestDetails.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = data.Status;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<VCustomerRequestBasic>>> GetAllCustomerRequest()
        {
            return await _context.VCustomerRequestBasics.OrderByDescending(x => x.CreatedAt).ToListAsync();
        }
    }
}
