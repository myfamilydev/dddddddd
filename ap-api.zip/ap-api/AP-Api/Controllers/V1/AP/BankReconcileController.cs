﻿using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models.Filter;
using DataAccess.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AP_Api.Controllers.V1.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class BankReconcileController : ControllerBase
    {
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;

        public BankReconcileController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet ("bank_reconcile")]
        public async Task<ActionResult<IEnumerable<VBankReconcile>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;
            var list = new List<short>();
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                .ToList();
            }

            var pagedData = _context.VBankReconciles
                               .Where(s => (s.CompanyId == user.CompanySessionId) &&  (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.BankName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.GenerateMonth.ToLower().Contains(validFilter.Search.ToLower())
                                   
                                    )))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VBankReconciles
                                .Where(s => (s.CompanyId == user.CompanySessionId) &&  (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.BankName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.GenerateMonth.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }
        [HttpGet("bank_reconcile/{id}")]
        public async Task<ActionResult<VBankReconcile>> GetById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.VBankReconciles.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }
        [HttpPost("bank_reconcile/add")]
        public async Task<ActionResult<BankReconcile>> Add(BankReconcile data)

        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var exist = await _context.BankReconciles.AsNoTracking().FirstOrDefaultAsync(x => x.BankId == data.BankId && x.Id == data.Id);

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "This bank already exist!", "400"));
            }


            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
        
            data.Status = true;

            _context.BankReconciles.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("bank_reconcile/update")]
        public async Task<IActionResult> UpdateBankReconcile(BankReconcile data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.BankReconciles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
     

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("bank_reconcile/{id}/delete")]
        public async Task<IActionResult> DeleteBankReconcile(int id)
        {
            var data_delete = await _context.BankReconciles.FirstOrDefaultAsync(x => x.Id == id);
            try
            {
                _context.BankReconciles.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }
            return Ok();
        }

    }
}
