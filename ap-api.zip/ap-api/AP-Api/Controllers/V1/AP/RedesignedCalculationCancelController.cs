﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Transactions;
using AP_Api.Helpers;
using System.Text.RegularExpressions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class RedesignedCalcuationCancelController : ControllerBase
    {
        private readonly APContext _context;

        public RedesignedCalcuationCancelController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VRedesignedCalculationCancel>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VRedesignedCalculationCancels
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.RedesignedCancelCode == validFilter.Search || s.HouseNumber == validFilter.Search || s.Project.Contains(validFilter.Search ?? "")))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VRedesignedCalculationCancels
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.RedesignedCancelCode == validFilter.Search || s.HouseNumber == validFilter.Search || s.Project.Contains(validFilter.Search ?? "")))
                               )
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetById(int id)
        {
            var data = await _context.VRedesignedCalculationCancels.FirstOrDefaultAsync(x => x.Id == id);

            var _auth = new CustomUserIdentity(User);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("arch.redesigned_calculations_cancels", data.Id, _auth.Id, 0);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }



        [HttpPost("add")]
        public async Task<ActionResult<RedesignedCalculationsCancel>> Add(RedesignedCalculationsCancel data)
        {
            try
            {
                string year = "/" + DateTime.Now.ToString("yy");
                var getMax = await _context.RedesignedCalculationsCancels.Where(x => x.RedesignedCancelCode.EndsWith(year) && x.IsActive == 1).MaxAsync(x => x.RedesignedCancelCode);
                
                if (getMax != null)
                {
                    getMax = getMax.Replace(@"\w+:\w+-", "").Replace(year, "");
                    var maxNumber = Regex.Match(getMax, @"\d+").Value;
                    data.RedesignedCancelCode = "RC:C-" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
                }
                else
                {
                    data.RedesignedCancelCode = "RC:C-" + "00001" + year;
                }

                var _auth = new CustomUserIdentity(User);

                data.CreatedAt = DateTime.Now;
                data.CreatedBy = _auth.Id;
                data.IsActive = 1;
                data.RecStatus = 0;

                _context.RedesignedCalculationsCancels.Add(data);
                _context.SaveChanges();
                new WorkflowDetailModel().WorkflowHistoryDraft("arch.redesigned_calculations_cancels", data.Id, _auth.Id);
                return data;

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        
        [Authorize]
        [HttpPost("webhook/inactive/{id}")]
        public async Task WebhookInactiveRedesignedCalculation(int id)
        {
            try
            {
                var redesignedCal = await _context.RedesignedCalculations
                                                .FirstOrDefaultAsync(x => x.Id == id && x.IsActive == 1);
                _context.Entry(redesignedCal).State = EntityState.Modified;
                redesignedCal.IsActive = 0;
                redesignedCal.UpdatedAt = DateTime.Now;
                redesignedCal.UpdatedBy = 116;
                await _context.SaveChangesAsync();
            }
            catch
            {

            }
        }


        [HttpPut("update")]
        public async Task<IActionResult> UpdateRedesignedCalculationCancel(RedesignedCalculationsCancel data)
        {

            var valid = await _context.RedesignedCalculationsCancels.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }
            

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.IsActive).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> UpdateStatus(RedesignedCalculationsCancel data)
        {
            var valid = await _context.RedesignedCalculationsCancels.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.IsActive = data.IsActive;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
