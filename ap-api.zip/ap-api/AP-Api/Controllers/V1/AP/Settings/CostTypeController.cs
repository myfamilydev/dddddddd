﻿
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/settings/cost_type")]
    [ApiController]
    [Authorize]
    public class CostTypeController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private CustomUserIdentity _auth;

        public CostTypeController(IHttpContextAccessor httpContextAccessor, APContext context)
        {
            _context = context;
        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetCostTypeBasicAsync()
        {
            return await _context.CostTypes.AsNoTracking().ToListAsync();
        }
    }
}
