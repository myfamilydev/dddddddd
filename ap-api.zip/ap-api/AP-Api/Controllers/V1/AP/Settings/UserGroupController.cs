﻿
using AP_Api.Helpers;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;

namespace Web.Controllers.AP
{
    [Route("api/v1/settings/groups")]
    [ApiController]
    [Authorize]
    public class UserGroupController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public UserGroupController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllGroupAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;

            var pagedData = _context.UsersGroups
                           .Where(s => ((String.IsNullOrEmpty(filter.Search)
                           || s.Name.Contains(filter.Search)))
                          )
                           .OrderBy(x => x.Name)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.UsersGroups
                           .Where(s => (String.IsNullOrEmpty(filter.Search)
                               || s.Name.Contains(filter.Search))
                              )
                            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetGroupBasicAsync()
        {
            return await _context.UsersGroups.AsNoTracking().ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<UsersGroup>> GetGroupAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.UsersGroups.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<UsersGroup>> AddGroupAsync(UsersGroup data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            bool valid = await _context.UsersGroups.AnyAsync(x => x.Name.ToLower().Trim() == data.Name.ToLower().Trim());

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Group is already exists!", "400"));
            }

            //_auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Locked = false;

            data.CompanyId = user.CompanySessionId;

            _context.UsersGroups.Add(data);

            await _context.SaveChangesAsync();

            return data;

        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateGroupAsync(UsersGroup data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var validData = await _context.UsersGroups.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            
            if (validData == null)
            {
                return BadRequest();
            }

            if(validData != null && validData.Locked == true)
            {
                return BadRequest(new ApiResponse("failed", "Group has been locked! Please contact to administrator(085919266)", "400"));
            }

            bool valid = await _context.UsersGroups.AnyAsync(x => x.Name.ToLower().Trim() == data.Name.ToLower().Trim() && data.Id != x.Id);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Group is already exists!", "400"));
            }

            //var _auth = new CustomUserIdentity(User);

            data.Id = validData.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteGroupAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.UsersGroups.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            if (valid != null && valid.Locked == true)
            {
                return BadRequest(new ApiResponse("failed", "Group has been locked! Please contact to administrator(085919266)", "400"));
            }

            _context.UsersGroups.Remove(valid);


            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpGet("{id}/permissions")]
        public async Task<ActionResult<IEnumerable<object?>>> GetPermissionByIdAsync(int id)

        {

            return await _context.VUsersGroupsPermisssions
                            .Where(x => x.UserGroupId == id)
                            .Select(x => new
                            {
                                Id = x.UserPermissionId,
                                Name = x.Name
                            })
                            .ToListAsync();
        }

        [HttpGet("permissions/available")]
        public async Task<ActionResult<IEnumerable<object?>>> GetPermissionAvailableAsync(int id)

        {
            return await _context.VUsersPermissions
                            .OrderBy(x => x.Ordering)
                            .ToListAsync();
        }

        [HttpPut("{id}/permissions")]
        public async Task<IActionResult> UpdatePermissionAsync(int id, List<int> list)
        {
            string ids = string.Join(",", list);

            _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_update_permission] {0}, {1}", id, ids);

            return Ok(id);
        }

        [HttpGet("workflow/{workflowId}/roles")]
        public async Task<IEnumerable<object?>> GetAvailableWorkflowRoleAsync(int workflowId)
        {
            return _context.ExecuteQuery($"exec [dbo].[sp_get_workflow_roles] {workflowId}").ToList();
        }

        [HttpGet("workflow/{workflowId}/actions")]
        public async Task<IEnumerable<object?>> GetAvailableWorkflowActionAsync(int workflowId)
        {
            return _context.ExecuteQuery($"exec [dbo].[sp_get_workflow_roles_action] {workflowId}").ToList();
        }

        [HttpGet("{id}/workflow/{workflowId}/roles")]
        public async Task<IEnumerable<object?>> GetAssingedWorkflowRoleAsync(int id, int workflowId)
        {
            return _context.ExecuteQuery($"exec [dbo].[sp_get_group_workflow_roles] {id}, {workflowId}").Select(x => x["user_role_id"]).ToList();
        }

        [HttpPut("{groupId}/role/{roleId}/{append}")]
        public async Task<ActionResult> ApplyWorkflowRoleAsync(int groupId, int roleId, bool append)
        {
            try
            {

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_apply_group_roles_to_users] {0}, {1}, {2}", groupId, roleId, append);

                    ts.Complete();
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpGet("user_group/{groupId}")]
        public async Task<ActionResult<object>> Get(int groupId)
        {
            return _manualDbContext.ExecuteQuery($"exec [dbo].[sp_clone_user_group] {groupId}")
                      .AsEnumerable()
                      .FirstOrDefault();
        }

    }
}
