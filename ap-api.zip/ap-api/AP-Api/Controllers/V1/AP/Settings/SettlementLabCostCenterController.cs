﻿
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class SettlementLabCostCenterController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private CustomUserIdentity _auth;

        public SettlementLabCostCenterController(IHttpContextAccessor httpContextAccessor, APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VendorsSettlementLabCostCenter>>> GetVendorsSettlementLabCostCenter()
        {

            return await _context.VendorsSettlementLabCostCenters.AsNoTracking().ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<VendorsSettlementLabCostCenter>> GetVendorsSettlementLabCostCenterById(int id)
        {
            var data = await _context.VendorsSettlementLabCostCenters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }
        [HttpPost("add")]
        public async Task<ActionResult<VendorsSettlementLabCostCenter>> AddVendorsSettlementLabCostCenter(VendorsSettlementLabCostCenter data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            decimal? Amount = await _context.VendorsSettlementLabCostCenters
                                            .Where(x => x.SummaryLabItemId == data.SummaryLabItemId)
                                            .Select(x => x.Amount)
                                            .SumAsync();

            var valid = await _context.VendorsSettlementLabItems.AnyAsync(x => x.RequestAmount != data.Amount && x.Id == data.SummaryLabItemId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "The amounts entered do not match. Please make sure the amounts and request amounts in both fields are equal and try again.!"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            _context.VendorsSettlementLabCostCenters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("update")]
        public async Task<ActionResult> UpdateVendorsSettlementLabCostCenter(VendorsSettlementLabCostCenter data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsSettlementLabItems.AnyAsync(x => x.RequestAmount != data.Amount && x.Id == data.SummaryLabItemId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "The amounts entered do not match. Please make sure the amounts and request amounts in both fields are equal and try again.!"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            await _context.SaveChangesAsync();

            return Ok();
        }
        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> VendorsSettlementLabCostCenterDelete(int id)
        {
            var data = await _context.VendorsSettlementLabCostCenters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.VendorsSettlementLabCostCenters.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }
    }
}
