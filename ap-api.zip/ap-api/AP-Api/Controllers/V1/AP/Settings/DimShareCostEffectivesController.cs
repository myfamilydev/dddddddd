﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models.Filter;
using DataAccess.Models;
using OneSignalApi.Model;
using System.IO;
using Microsoft.AspNetCore.Authorization;

namespace AP_Api.Controllers.V1.AP.Settings
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class DimShareCostEffectivesController : ControllerBase
    {
        private readonly APContext _context;

        public DimShareCostEffectivesController(APContext context)
        {
            _context = context;
        }

        // GET: api/DimShareCostEffectives
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DimShareCostEffective>>> GetDimShareCostEffectives([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            var pagedData = _context.DimShareCostEffectives
            .Where(s => s.CompanyId == user.CompanySessionId && s.Status == true && ((String.IsNullOrEmpty(filter.Search) || (s.EffectiveDate.ToString() == filter.Search))))
            .OrderByDescending(s => s.EffectiveDate)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
            await _context.DimShareCostEffectives
            .Where(s => s.CompanyId == user.CompanySessionId && s.Status == true && ((String.IsNullOrEmpty(filter.Search) || (s.EffectiveDate.ToString() == filter.Search && s.Status == true))))
            .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
            //return await _context.DimShareCostEffectives.ToListAsync();
        }

        // GET: api/DimShareCostEffectives/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DimShareCostEffective>> GetDimShareCostEffective(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var dimShareCostEffective = await _context.DimShareCostEffectives
                .FirstOrDefaultAsync(x => x.Id ==id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (dimShareCostEffective == null)
            {
                return NotFound();
            }

            return dimShareCostEffective;
        }

        // PUT: api/DimShareCostEffectives/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDimShareCostEffective(int id, DimShareCostEffective dimShareCostEffective)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            if (id != dimShareCostEffective.Id)
            {
                return BadRequest();
            }

            var isExisted = await _context.DimShareCostEffectives.AnyAsync(x => (x.EffectiveDate ?? new DateTime()).Date == (dimShareCostEffective.EffectiveDate ?? new DateTime()).Date && id != x.Id && x.Status == true);

            if (isExisted)
            {
                return BadRequest(new ApiResponse("failed", "Effective date is exist!", "400"));
            }

            _context.Entry(dimShareCostEffective).State = EntityState.Modified;

            _context.Entry(dimShareCostEffective).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(dimShareCostEffective).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(dimShareCostEffective).Property(x => x.Status).IsModified = false;

            dimShareCostEffective.UpdatedAt = DateTime.Now;

            dimShareCostEffective.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DimShareCostEffectiveExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok();
        }

        // POST: api/DimShareCostEffectives
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DimShareCostEffective>> PostDimShareCostEffective(DimShareCostEffective dimShareCostEffective)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var isExisted = await _context.DimShareCostEffectives.AnyAsync(x => (x.EffectiveDate ?? new DateTime()).Date == (dimShareCostEffective.EffectiveDate ?? new DateTime()).Date && x.Status == true);
            
            if (isExisted)
            {
                return BadRequest(new ApiResponse("failed", "Effective date is exist!", "400"));
            }

            dimShareCostEffective.CreatedAt = DateTime.Now;

            dimShareCostEffective.CreatedBy = _auth.Id;

            dimShareCostEffective.CompanyId = user.CompanySessionId;

            dimShareCostEffective.Status = true;

            _context.DimShareCostEffectives.Add(dimShareCostEffective);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDimShareCostEffective", new { id = dimShareCostEffective.Id }, dimShareCostEffective);
        }

        // DELETE: api/DimShareCostEffectives/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDimShareCostEffective(int id)
        {
            var dimShareCostEffective = await _context.DimShareCostEffectives.FindAsync(id);
            if (dimShareCostEffective == null)
            {
                return NotFound();
            }

            _context.Entry(dimShareCostEffective).State = EntityState.Modified;

            dimShareCostEffective.Status = false;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("{id}/DimShareCostStandards")]
        public async Task<ActionResult<IEnumerable<VShareCostStandard>>> GetDimShareCostStandard(int id)
        {
            return await _context.VShareCostStandards.Where(x => x.EffectiveId== id).ToListAsync();
        }

        private bool DimShareCostEffectiveExists(int id)
        {
            return _context.DimShareCostEffectives.Any(e => e.Id == id && e.Status == true);
        }
    }
}
