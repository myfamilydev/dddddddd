﻿using Bogus.DataSets;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Collections.Generic;

namespace AP_Api.Controllers.V1.AP.Settings
{
    [Route("api/v1/group-payments")]
    [ApiController]
    [Authorize]
    public class GroupPaymentsController : ControllerBase
    {
        private readonly APContext _context;

        private readonly ManualDbContext _manualDbContext;

        public GroupPaymentsController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VGroupPayment>>> GetAllAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            filter.TotalRecords = await _context.VGroupPayments.AsNoTracking()
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search)
                                || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                                || s.AliasName.ToLower().Contains(filter.Search.ToLower())))
                                ).CountAsync();

            var data = await _context.VGroupPayments.AsNoTracking()
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search)
                                || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                                || s.AliasName.ToLower().Contains(filter.Search.ToLower()))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VGroupPayment>> GetByIdAsync(int id)
        {
			var _auth = new CustomUserIdentity(User);
			var user = await _context.Users.FindAsync(_auth.Id);
			var data = await _context.VGroupPayments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);
			if (data == null)
			{
				return NoContent();
			}

            return Ok(data);
		}

        [HttpPost]
        public async Task<ActionResult<GroupPayment>> AddAsync(GroupPayment data)
        {

			var _auth = new CustomUserIdentity(User);

			var user = await _context.Users.FindAsync(_auth.Id);

            data.CompanyId = user.CompanySessionId;
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = true;

            _context.GroupPayments.Add(data);

            await _context.SaveChangesAsync();

			return Ok(data);
        }

        [HttpPut]
        public async Task<ActionResult> UpdateAsync(GroupPayment data)
        {
            var valid = await _context.GroupPayments.FindAsync(data.Id);

            if(valid == null)
            {
                return NoContent();
            }

			_context.Entry(valid).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            valid.AliasName = data.AliasName;
            valid.ProjectId = data.ProjectId;

            await _context.SaveChangesAsync();

            return Ok();

		}

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAsync(int id)
        {
			var valid = await _context.GroupPayments.FindAsync(id);

            try
            {
                _context.GroupPayments.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (valid == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();
        }

        [HttpGet("{id}/houses")]
        public async Task<ActionResult<IEnumerable<VGroupPaymentHouseAvailable>>> GetAllHouseAsync(int id)
        {
            var data = await _context.VGroupPaymentHouseAvailables.AsNoTracking()
				.Where(x => x.GroupPaymentId == id).ToListAsync();
            return data;
        }

        [HttpGet("house/{id}")]
		public async Task<ActionResult<IEnumerable<VGroupPaymentHouseAvailable>>> GetHouseByIdAsync(int id)
		{
			var data = await _context.VGroupPaymentHouseAvailables.FirstOrDefaultAsync(x => x.Id==id);

			if (data == null)
			{
				return NoContent();
			}
			return Ok(data);
		}

		private bool isExistHouseId(int? houseId, int? id)
		{
			return _context.GroupPaymentHouses.Any(cas => cas.HouseId == houseId && (id == null || cas.Id != id));
		}

		[HttpPost("house/add")]
        public async Task<ActionResult<GroupPaymentHouse>> AddGroupPaymentHouseAsync(GroupPaymentHouse data)
        {
            if (isExistHouseId(data.HouseId, null))
            {
                return BadRequest(new ApiResponse("failed", "The house is already exists!","400"));
            }

            data.Status = true;


			_context.GroupPaymentHouses.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

		[HttpPut("house/update")]
		public async Task<ActionResult<GroupPaymentHouse>> UpdateGroupPaymentHouseAsync(GroupPaymentHouse data)
		{
            var valid = _context.GroupPaymentHouses.Any(x => x.Id == data.Id);

            if (!valid)
            {
                return NoContent();
            }

			if (isExistHouseId(data.HouseId, data.Id))
			{
				return BadRequest(new ApiResponse("failed", "The house is already exists!", "400"));
			}

			_context.Entry(data).State = EntityState.Modified;

			_context.Entry(data).Property(x => x.GroupPaymentId).IsModified = false;

			_context.Entry(data).Property(x => x.Status).IsModified = false;

			await _context.SaveChangesAsync();

			return Ok();
		}

        [HttpDelete("house/{id}/delete")]
        public async Task<ActionResult> DeleteGroupPaymentHouseAsync(int id)
        {
			var valid = await _context.GroupPaymentHouses.FindAsync(id);

			if (valid == null)
			{
				return NoContent();
			}

           _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

			await _context.SaveChangesAsync();

			return Ok();
		}

        [HttpGet("{proId}/house/availables")]
        public async Task<ActionResult<IEnumerable<object>>> GetHouseAvailableAsync(int proId)
        {
			var data = await _context.VHouseAvailables.AsNoTracking()
				.Where(x => x.ProjectId == proId)
                .Select(x => new
                {
                    Value = x.Id,
                    Label = x.Number
                })
                .ToListAsync();

            return Ok(data);

		}
	}
}
