﻿using AP_Api.Helpers;
using AP_Api.Models;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MongoDB.Bson.IO;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Transactions;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class SettingsController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;
        private CustomUserIdentity _auth;

        public SettingsController(IHttpContextAccessor httpContextAccessor, APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<Setting>> GetSettingAsync()
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.Settings.AsNoTracking().FirstOrDefaultAsync(x => x.CompanyId == user.CompanySessionId);

            return Ok(data);
        }

        [HttpPut]
        public async Task<ActionResult> UpdateSettingAsync(Setting data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.Settings.AsNoTracking().FirstOrDefaultAsync(x => x.CompanyId == user.CompanySessionId);

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("company/cost-center")]
        public async Task<ActionResult<IEnumerable<VCompanyCostCenter>>> CostCenterGetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VCompanyCostCenters
                           .Where(s => (String.IsNullOrEmpty(filter.Search) || s.CompanyId == Convert.ToInt16(filter.Search)))
                           .OrderBy(x => x.CompanyName)
                           .ToListAsync();
            return Ok(data);
        }

        [HttpGet("company/cost-center/{id}")]
        public async Task<ActionResult<CompanyCostCenter>> GetCostCenter(short id)
        {
            var data = await _context.CompanyCostCenters.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("company/cost-center/add")]
        public async Task<ActionResult<CompanyCostCenter>> AddCostCenter(CompanyCostCenter data)
        {
            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.CompanyCostCenters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("company/cost-center/update")]
        public async Task<IActionResult> UpdateCostCenter(CompanyCostCenter data)
        {
            var valid = await _context.CompanyCostCenters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("company/cost-center/changeStatus")]
        public async Task<IActionResult> InactiveCostCenter(CompanyCostCenter data)
        {
            var valid = await _context.CompanyCostCenters.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            _auth = new CustomUserIdentity(User);

            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;
            valid.Status = data.Status;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("redesign-fees")]
        public async Task<ActionResult<IEnumerable<VRedesignFee>>> RedesignFeeGetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VRedesignFees
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.ProjectShort == validFilter.Search) && s.Status == 1)
                               )
                               .OrderByDescending(s => s.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VRedesignFees
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.ProjectShort == validFilter.Search) && s.Status == 1
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }




        [HttpGet("redesign-fee/{id}")]
        public async Task<ActionResult<RedesignFee>> GetRedesignFeeById(int id)
        {
            var data = await _context.RedesignFees.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("redesign-fee/add")]
        public async Task<ActionResult<RedesignFee>> AddRedesignFee(RedesignFee data)
        {
            var exist = await _context.RedesignFees.AnyAsync(x => x.ProjectId == data.ProjectId && x.HouseCategoryId == data.HouseCategoryId && x.Status == 1);

            if (exist)
            {
                return BadRequest(new ApiResponse("failed", "Project and House Category is already exists!", "400"));
            }
            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.RedesignFees.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("redesign-fee/update")]
        public async Task<ActionResult<RedesignFee>> UpdateRedesignFee(RedesignFee data)
        {
            var valid = await _context.RedesignFees.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("redesign-fee/change-status")]
        public async Task<ActionResult<RedesignFloor>> redesignFeeChangeStatus(RedesignFee data)
        {
            var valid = await _context.RedesignFees.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("redesign-floors")]
        public async Task<ActionResult<IEnumerable<VRedesignFloor>>> RedesignFloorGetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.VRedesignFloors
                           .Where(s => (String.IsNullOrEmpty(filter.Search)))
                           .OrderBy(x => x.ProjectShort)
                           .ToListAsync();
            return Ok(data);
        }

        [HttpGet("redesign-floor/{id}")]
        public async Task<ActionResult<RedesignFloor>> GetRedesignFloorById(int id)
        {
            var data = await _context.RedesignFloors.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("redesign-floor/add")]
        public async Task<ActionResult<RedesignFloor>> AddRedesignFloor(RedesignFloor data)
        {
            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.RedesignFloors.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("redesign-floor/update")]
        public async Task<ActionResult<RedesignFloor>> UpdateRedesignFloor(RedesignFloor data)
        {
            var valid = await _context.RedesignFloors.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("redesign-floor/change-status")]
        public async Task<ActionResult<RedesignFloor>> redesignFloorChangeStatus(RedesignFloor data)
        {
            var valid = await _context.RedesignFloors.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("redesign-jobs")]
        public async Task<ActionResult<IEnumerable<RedesignJob>>> RedesignJobGetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.RedesignJobs
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Name == validFilter.Search) && s.Status == 1)
                               )
                               .OrderByDescending(s => s.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.RedesignJobs
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Name == validFilter.Search) && s.Status == 1
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("redesign-job/{id}")]
        public async Task<ActionResult<RedesignJob>> GetRedesignJobById(int id)
        {
            var data = await _context.RedesignJobs.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("redesign-job/add")]
        public async Task<ActionResult<RedesignJob>> AddRedesignJob(RedesignJob data)
        {

            var getMax = await _context.RedesignJobs.Where(x => x.Code.StartsWith("JC:") && x.Status == 1).MaxAsync(x => x.Code.Replace(@"\w+:", ""));

            if (getMax != null)
            {
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.Code = "JC:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5");
            }
            else
            {
                data.Code = "JC:" + "00001";
            }
            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.RedesignJobs.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("redesign-job/update")]
        public async Task<ActionResult<RedesignJob>> UpdateRedesignJob(RedesignJob data)
        {
            var valid = await _context.RedesignJobs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == 1);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("redesign-job/change-status")]
        public async Task<ActionResult<RedesignJob>> redesignJobChangeStatus(RedesignFee data)
        {
            var valid = await _context.RedesignJobs.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("behavior-types")]
        public async Task<ActionResult<IEnumerable<CustomerBehaviorType>>> behaviorTypesGetAll([FromQuery] PaginationFilter filter)
        {
            var data = await _context.CustomerBehaviorTypes
                           .Where(s => (String.IsNullOrEmpty(filter.Search)))
                           .OrderBy(x => x.Ordering)
                           .ToListAsync();
            return Ok(data);
        }

        [HttpGet("projects")]
        public async Task<ActionResult<IEnumerable<object>>> GetAllProject()
        {
            var _auth = new CustomUserIdentity(User);

            return _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => new { projectId = x.Id, projectCode = x.ProjectShort })
                            .OrderBy(x => x.projectCode)
                           .ToList();
        }
		[HttpGet("cost_center/basic")]
		public ActionResult<IEnumerable<object>> GetAllCostCenter()
		{
			var _auth = new CustomUserIdentity(User);

            return _context.ExecuteQuery("exec [dbo].[sp_get_cost_center_basic]")
                .AsEnumerable()
                .ToList();
		}

		[HttpGet("project/{id}/houses")]
        public async Task<ActionResult<IEnumerable<object>>> GetAllHouse(int id, [FromQuery] FilterBy filterBy)
        {
            //System.Threading.Thread.Sleep(50);
            return await _context.VHousesLists
                .Where(x => x.ProjectId == id)
                .OrderBy(x => x.Number)
                .Select(x => new
                {
                    id= x.Id,
                    number = x.Number
                })
                .ToListAsync();
        }

        [HttpGet("project/{id}/house-categories")]
        public async Task<ActionResult<IEnumerable<VProjectHouseCategory>>> GetAllHouseCategory(int id)
        {
            return await _context.VProjectHouseCategories
                .Where(x => x.ProjectId == id)
                .OrderBy(x => x.Name)
                           .ToListAsync();
        }

        [HttpGet("house-categories")]
        public async Task<ActionResult<IEnumerable<VProjectHouseCategory>>> GetAllHouseCategories()
        {
            return await _context.VProjectHouseCategories
                .OrderBy(x => x.Name)
                           .ToListAsync();
        }

        [HttpGet("house/{id}/customers")]
        public async Task<ActionResult<VContractsCustomer>> GetAllCustomerByHouse(int id)
        {
            return Ok(await _context.VContractsCustomers.FirstOrDefaultAsync(x => x.HouseId == id));
        }

        [HttpGet("house/{id}/redesigned-fee")]
        public async Task<ActionResult<VRedesignFee>> GetFeeByHouse(int id)
        {
            var data = await _context.VHouseCategories.FirstOrDefaultAsync(x => x.HouseId == id);
            if (data == null)
            {
                return BadRequest();
            }

            return Ok(await _context.VRedesignFees
                .FirstOrDefaultAsync(x => x.HouseCategoryId == data.HouseCategoryId && x.ProjectId == data.ProjectId));
        }


        [HttpGet("LoanBanks")]
        public async Task<ActionResult<IEnumerable<VBank>>> GetAllLoanBank()
        {
            return await _context.VBanks.ToListAsync();
        }


        //[HttpGet("LoanBanks/{id}")]
        //public async Task<ActionResult<VBank>> GetLoanBankById(int id)
        //{
        //    var data = await _context.VBanks.FirstOrDefaultAsync(x => x.Id == id);
        //    if (data == null)
        //    {
        //        return NoContent();
        //    }

        //    return data;
        //}

        [HttpGet("LoanTypes")]
        public async Task<ActionResult<IEnumerable<LoanType>>> GetAllLoanType()
        {
            return await _context.LoanTypes.ToListAsync();
        }

        [HttpGet("LoanTypes/{id}")]
        public async Task<ActionResult<LoanType>> GetLoanTypeById(int id)
        {
            var data = await _context.LoanTypes.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("BankLocations")]
        public async Task<ActionResult<IEnumerable<BankLocation>>> GetBankLocations()
        {
            var data = await _context.BankLocations.AsNoTracking().ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }




        //[HttpGet("BankLocations")]
        //public async Task<ActionResult<IEnumerable<BankLocation>>> GetBankLocations()
        //{
        //    var data = await _context.BankLocations.AsNoTracking().ToListAsync();

        //    if (data == null)
        //    {
        //        return NoContent();
        //    }

        //    return data;
        //}

        [HttpGet("Currencies")]
        public async Task<ActionResult<IEnumerable<Currency>>> GetCurrencies()
        {
            var data = await _context.Currencies.AsNoTracking().ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("SettlementMethods")]
        public async Task<ActionResult<IEnumerable<VendorsSettlementMethod>>> GetSettlementMethods()
        {
            var data = await _context.VendorsSettlementMethods.AsNoTracking().ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("AccountCodes")]
        public async Task<ActionResult<IEnumerable<VChartAccount>>> GetAccountCodes([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            return await _context.VChartAccounts
                    .AsNoTracking()
                    .Where(x =>  (x.Inactivate == false || x.Inactivate == null) && x.RecStatus == 3 && x.CompanyId == u.CompanySessionId)
                    .ToListAsync();
        }

        [HttpGet("positions")]
        public async Task<ActionResult<IEnumerable<UsersPosition>>> GetPositions()
        {
            var data = await _context.UsersPositions.AsNoTracking().Where(x => x.IsActive == true).ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("daily-cleaner-wage")]
        public async Task<ActionResult<IEnumerable<VDailyCleanerWage>>> GetDailyCleanerWage()
        {

            return await _context.VDailyCleanerWages.AsNoTracking().ToListAsync();
        }

        [HttpGet("daily-cleaner-wage/{id}")]
        public async Task<ActionResult<VDailyCleanerWage>> GetDailyCleanerWage(int id)
        {
            var data = await _context.VDailyCleanerWages.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("item_name")]
        public async Task<ActionResult<IEnumerable<ItemName>>> GetItemNames()
        {
            var data = await _context.ItemNames.AsNoTracking().ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("ItemType")]
        public async Task<ActionResult<IEnumerable<ItemType>>> GetItemType()
        {
            return await _context.ItemTypes.ToListAsync();
        }

        [HttpGet("BankList")]
        public async Task<ActionResult<IEnumerable<BankList>>> GetAllBankList()
        {
            return await _context.BankLists.ToListAsync();
        }

        [HttpGet("ChequeBookUsers")]
        public async Task<ActionResult<IEnumerable<VChequeBookUser>>> GetAllChequeBookUser()
        {
            return await _context.VChequeBookUsers.ToListAsync();
        }

        [HttpGet("exchange-rates")]
        public async Task<ActionResult<IEnumerable<object>>> GetAllExhangeRateAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.ExchangeRates
                               .Where(s => s.CompanyId == user.CompanySessionId && s.Status == true && ((String.IsNullOrEmpty(filter.Search) || (s.EffectiveDate.ToString() == filter.Search))))
                               .OrderByDescending(s => s.EffectiveDate)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.ExchangeRates
                               .Where(s => s.CompanyId == user.CompanySessionId && s.Status == true && ((String.IsNullOrEmpty(filter.Search) || (s.EffectiveDate.ToString() == filter.Search && s.Status == true))))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("exchange-rates/{id}")]
        public async Task<ActionResult<ExchangeRate>> GetAllExhangeRateAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ExchangeRates.FirstOrDefaultAsync(x => x.Id == id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("exchange-rates/add")]
        public async Task<ActionResult<ExchangeRate>> AddExhangeRateAsync(ExchangeRate data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            bool valid = await _context.ExchangeRates.AnyAsync(x => x.EffectiveDate.Value == data.EffectiveDate.Value && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (data.EffectiveDate < DateTime.Now)
            {
                return BadRequest(new ApiResponse("failed", "Effective date is expired!", "400"));
            }

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Already Added", "400"));
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.IsActive = true;

            data.Status = true;

            data.CompanyId = user.CompanySessionId;

            _context.ExchangeRates.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("exchange-rates/update")]
        public async Task<ActionResult> UpdateExhangeRateAsync(ExchangeRate data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            bool valid = await _context.ExchangeRates.AnyAsync(x => x.Id == data.Id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "doesn't exists", "400"));
            }


            valid = await _context.ExchangeRates.AnyAsync(x => x.EffectiveDate.Value == data.EffectiveDate.Value && x.Status == true && x.Id != data.Id && user.CompanySessionId == x.CompanyId);

            if (data.EffectiveDate < DateTime.Now)
            {
                return BadRequest(new ApiResponse("failed", "Effective date is expired!", "400"));
            }

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Already Added", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.IsActive).IsModified = false;

            data.CompanyId = user.CompanySessionId;

            await _context.SaveChangesAsync();

            return Ok();
        }


        [HttpDelete("exchange-rates/{id}/delete")]
        public async Task<ActionResult> DeleteExhangeRateAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ExchangeRates.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "doesn't exists", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpGet("budgets-lines")]
        public async Task<ActionResult<IEnumerable<VDblhdBudgetsLine>>> GetAllBudgetLines()
        {
            return await _context.VDblhdBudgetsLines.ToListAsync();
        }

        [HttpGet("term_pay")]
        public async Task<ActionResult<IEnumerable<VLaborTermPay>>> LaborTermPayGetAll([FromQuery] PaginationFilter filter)
        {
            
            var list = new List<short>();

            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();


            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VLaborTermPays
                               .Where(s => list.Contains((short)s.ProjectId) && (String.IsNullOrEmpty(filter.Search)))
                               .OrderByDescending(s => s.ProjectShort)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VLaborTermPays
                               .Where(s => list.Contains((short)s.ProjectId) && (String.IsNullOrEmpty(filter.Search)))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("term_pay/basic")]
        public async Task<ActionResult<IEnumerable<VLaborTermPay>>> TermPayBasic([FromQuery] FilterBy filter)
        {
        
 
            var data = await _context.VLaborTermPays

                .ToListAsync();
            return Ok(data);
        }

        [HttpGet("term_pay/{id}")]
        public async Task<ActionResult<VLaborTermPay>> LaborTermPayById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VLaborTermPays.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("term_pay/add")]
        public async Task<ActionResult<LaborTermPay>> AddLaborTermPay(LaborTermPay data)
        {
            var valid = await _context.LaborTermPays.AsNoTracking().AnyAsync(x => x.ProjectId == data.ProjectId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Project Name is exist!"));
            }

            data.Status = true;

            _context.LaborTermPays.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("term_pay/update")]
        public async Task<IActionResult> UpdateLaborTermPay(LaborTermPay data)
        {
            var valid = await _context.LaborTermPays.AsNoTracking().AnyAsync(x => x.ProjectId == data.ProjectId && x.Id != data.Id);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Project Name is exist!"));
            }

            var Datavalid = await _context.LaborTermPays.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (Datavalid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

			_context.Entry(data).Property(x => x.Status).IsModified = false;


			try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("term_pay/{id}/delete")]
        public async Task<IActionResult> LaborTermPayDelete(int id)
        {
            var data_delete = await _context.LaborTermPays.FirstOrDefaultAsync(x => x.Id == id);

            try
            {

                _context.LaborTermPays.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                return NoContent();
            }

            return Ok();

        }

        [HttpGet("term_pay/{projectId}/project")]
        public async Task<ActionResult<object>> Get(int projectId)
        {
            return _manualDbContext.ExecuteQuery($"exec [dbo].[sp_get_labor_term_pay] {projectId}")
                      .AsEnumerable()
                      .FirstOrDefault();
        }

        [HttpGet("banks")]
        public async Task<ActionResult<IEnumerable<Object>>> GetAllBanks([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.ExecuteQuery($"exec dbo.sp_v_banks {user.CompanySessionId},'{filter.Search}'")
                .AsEnumerable()
                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                .Take(validFilter.PageSize)
                .ToList();


            validFilter.TotalRecords = _context.ExecuteQuery($"exec dbo.sp_v_banks {user.CompanySessionId}, '{filter.Search}'")
                .AsEnumerable()
                .Count();
			

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
        }

        [HttpGet("banks/basic")]
        public async Task<ActionResult<IEnumerable<Bank>>> BanksBasic([FromQuery] FilterBy filter)
        {
            var data = await _context.Banks.ToListAsync();
            return Ok(data);
        }

        [HttpGet("bank/{id}")]
        public async Task<ActionResult<object>> GetBankById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return _context.ExecuteQuery($"exec dbo.sp_v_banks {user.CompanySessionId},'', {id}")
                .AsEnumerable()
                .FirstOrDefault();

		}


        [HttpPut("bank/{id}")]
        public async Task<IActionResult> PutBank(int id, ClsBankInput bankInput)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var bank = bankInput.Bank;

            if (id != bank.Id)
            {
                return BadRequest();
            }

            //var isExisted = await _context.Banks.AnyAsync(x => x.BankName  == bank.BankName  && id != x.Id && x.Status == true);

            //if (isExisted)
            //{
            //    return BadRequest(new ApiResponse("failed", "Bank Name is exist!", "400"));
            //}

            _context.Entry(bank).State = EntityState.Modified;

            _context.Entry(bank).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(bank).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(bank).Property(x => x.Status).IsModified = false;

			_context.Entry(bank).Property(x => x.CompanyId).IsModified = false;

			bank.UpdatedAt = DateTime.Now;

            bank.UpdatedBy = _auth.Id;

			if (!BankExists(id))
			{
				return NotFound();
			}

			try
			{
				var projectChildRemove = await _context.BanksProjectsChildren.Where(x => x.ParentId == id).ToListAsync();
             

				var projectChildList = new List<BanksProjectsChild>();

				bankInput.ChildrenIds.ForEach(x =>
				{
					projectChildList.Add(new BanksProjectsChild { ParentId = bank.Id, ProjectId = x });

				});

				_context.BanksProjectsChildren.RemoveRange(projectChildRemove);

				_context.BanksProjectsChildren.AddRange(projectChildList);

				using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
				{

					await _context.SaveChangesAsync();

					_context.Database.ExecuteSqlRaw(@"exec dbo.sp_check_exist_bank {0}", bank.Id);

					ts.Complete();
				}
			}
			catch (Exception ex)
			{
				return BadRequest(new ApiResponse("failed", ex.Message, "400"));
			}

			return Ok();
        }

        [HttpPost("bank")]
        public async Task<ActionResult<Bank>> PostBank(ClsBankInput bankInput)
        {
            var _auth = new CustomUserIdentity(User);

            var bank = bankInput.Bank;

            var user = await _context.Users.FindAsync(_auth.Id);

            //var isExisted = await _context.Banks.AnyAsync(x => x.BankName == bank.BankName && x.Status == true && x.EffectiveDate);

            //if (isExisted)
            //{
            //    return BadRequest(new ApiResponse("failed", "Bank Name is exist!", "400"));
            //}

            bank.CreatedAt = DateTime.Now;

            bank.CreatedBy = _auth.Id;

            bank.Status = true;

            bank.CompanyId = user.CompanySessionId;

            _context.Banks.Add(bank);

            var projectChildList = new List<BanksProjectsChild>();



            try
            {
				using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
				{
					await _context.SaveChangesAsync();


					bankInput.ChildrenIds.ForEach(x =>
					{
						projectChildList.Add(new BanksProjectsChild { ParentId = bank.Id, ProjectId = x });

					});

					_context.BanksProjectsChildren.AddRange(projectChildList);

					await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec dbo.sp_check_exist_bank {0}", bank.Id);

                    ts.Complete();
				}
			} catch(Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return CreatedAtAction("GetBank", new { id = bank.Id }, bank);
        }

        [HttpDelete("bank/{id}")]
        public async Task<IActionResult> DeleteBank(int id)
        {
            var bank = await _context.Banks.FindAsync(id);
            if (bank == null)
            {
                return NotFound();
            }

            _context.Entry(bank).State = EntityState.Modified;

            bank.Status = false;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpGet("houselists")]
        public async Task<ActionResult<IEnumerable<VHousesListsAll>>> GethouseLists([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }
            var pagedData = await _context.VHousesListsAlls
                                .Where(x => (list.Contains((short)x.ProjectId) || x.ProjectId == filter.ProId) &&
                                    (String.IsNullOrEmpty(filter.Search) ||
                                    (x.ProjectShort.ToLower().Contains(filter.Search.ToLower()) || 
                                     x.HouseCategory.ToLower().Contains(filter.Search.ToLower()) ||
                                     x.HouseType.ToLower().Contains(filter.Search.ToLower()))))
                                .OrderBy(x => x.ProjectShort)
                                .Skip((filter.PageNumber - 1) * filter.PageSize)
                                .Take(filter.PageSize)
                                .ToListAsync();

            filter.TotalRecords = await _context.VHousesListsAlls
                                .Where(x => (list.Contains((short)x.ProjectId) || x.ProjectId == filter.ProId) &&
                                    (String.IsNullOrEmpty(filter.Search) ||
                                    (x.ProjectShort.ToLower().Contains(filter.Search.ToLower()) || 
                                    x.HouseCategory.ToLower().Contains(filter.Search.ToLower()) ||
                                     x.HouseType.ToLower().Contains(filter.Search.ToLower()))))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, filter));

        }

        [HttpGet("houselists/{id}")]
        public async Task<ActionResult<VHousesListsAll>> GethouseListsById(int id)
        {
            var data = await _context.VHousesListsAlls.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        private bool BankExists(int id)
        {
            return _context.Banks.Any(e => e.Id == id && e.Status == true);
        }

        [HttpGet("transaaction_type")]
        public async Task<ActionResult<IEnumerable<TransactionType>>> GetTransactionType()
        {
            return await _context.TransactionTypes.ToListAsync();
        }

        [HttpGet("cash_flow_type")]
        public async Task<ActionResult<IEnumerable<CashFlowType>>> GetCashFlowType()
        {
            return await _context.CashFlowTypes.ToListAsync();
        }

        [HttpGet("cost-center")]
        public async Task<ActionResult<IEnumerable<object>>> GetCostCenter()
        {
            return await _context.CostCenters.Where(x=>x.Status==true)
                                                .Select(x=>new { id= x.Id, projectId=x.ProjectIds,costCenter=x.CostCenter1})
                                                .ToListAsync();
        }

        [HttpGet("redesign/category")]
        public async Task<ActionResult<IEnumerable<VendorsRedesignsCategory>>> GetRedesignCategory()
        {
            return await _context.VendorsRedesignsCategories.Where(x => x.Status == 1).ToListAsync();
        }

        [HttpGet("redesign/type")]
        public async Task<ActionResult<IEnumerable<VendorsRedesignsType>>> GetRedesignType()
        {
            return await _context.VendorsRedesignsTypes.Where(x => x.Status == 1).ToListAsync();
        }
    }
}
