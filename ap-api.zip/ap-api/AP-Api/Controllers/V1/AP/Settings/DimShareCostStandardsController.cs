﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using System.IO;

namespace AP_Api.Controllers.V1.AP.Settings
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class DimShareCostStandardsController : ControllerBase
    {
        private readonly APContext _context;

        public DimShareCostStandardsController(APContext context)
        {
            _context = context;
        }
       

        // GET: api/DimShareCostStandards/5
        [HttpGet("{id}")]
        public async Task<ActionResult<VShareCostStandard>> GetDimShareCostStandard(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var dimShareCostStandard = await _context.VShareCostStandards.FirstOrDefaultAsync(x => x.Id == id);

            if (dimShareCostStandard == null)
            {
                return NotFound();
            }

            return dimShareCostStandard;
        }

        // PUT: api/DimShareCostStandards/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDimShareCostStandard(int id, DimShareCostStandard dimShareCostStandard)
        {
            var _auth = new CustomUserIdentity(User);

            if (id != dimShareCostStandard.Id)
            {
                return BadRequest();
            }

            if (ShareCostProjectExists(dimShareCostStandard, id))
            {
                return BadRequest(new ApiResponse("failed", "This project already share cost", "400"));
            }

            if (ShareCostOver(dimShareCostStandard, id))
            {
                return BadRequest(new ApiResponse("failed", "Can't share cost over 100%", "400"));
            }

            _context.Entry(dimShareCostStandard).State = EntityState.Modified;

            _context.Entry(dimShareCostStandard).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(dimShareCostStandard).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(dimShareCostStandard).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DimShareCostStandardExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Ok();
        }

        

        // POST: api/DimShareCostStandards
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DimShareCostStandard>> PostDimShareCostStandard(DimShareCostStandard dimShareCostStandard)
        {
            var _auth = new CustomUserIdentity(User);

            if (ShareCostProjectExists(dimShareCostStandard))
            {
                return BadRequest(new ApiResponse("failed", "This project already share cost", "400"));
            }

            if (ShareCostOver(dimShareCostStandard))
            {
                return BadRequest(new ApiResponse("failed", "Can't share cost over 100%", "400"));
            }

            dimShareCostStandard.CreatedAt = DateTime.Now;

            dimShareCostStandard.CreatedBy = _auth.Id;

            dimShareCostStandard.Status = true;

            _context.DimShareCostStandards.Add(dimShareCostStandard);

            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDimShareCostStandard", new { id = dimShareCostStandard.Id }, dimShareCostStandard);
        }

        private bool ShareCostProjectExists(DimShareCostStandard dimShareCostStandard, int? id = null)
        {
            return _context.DimShareCostStandards
                        .Any(x => x.ProjectId == dimShareCostStandard.ProjectId && (id == null || x.Id != id) && x.Status == true && x.EffectiveId == dimShareCostStandard.EffectiveId);
        }

        private bool ShareCostOver(DimShareCostStandard dimShareCostStandard, int? id = null)
        {
            decimal? _amount = null;

            _amount =  _context.DimShareCostStandards
                        .Where(x => x.EffectiveId == dimShareCostStandard.EffectiveId && (id == null || x.Id != id) && x.Status == true)
                        .Sum(x => x.CostRate);

            if (_amount != null)
            {
                if ((_amount + dimShareCostStandard.CostRate ?? 0) > 100)
                {
                    return true;
                }
            }

            return false;
        }

        // DELETE: api/DimShareCostStandards/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDimShareCostStandard(int id)
        {
            var dimShareCostStandard = await _context.DimShareCostStandards.FindAsync(id);

            if (dimShareCostStandard == null)
            {
                return NotFound();
            }

            _context.Entry(dimShareCostStandard).State = EntityState.Modified;

            dimShareCostStandard.Status = false;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DimShareCostStandardExists(int id)
        {
            return _context.DimShareCostStandards.Any(e => e.Id == id);
        }
    }
}
