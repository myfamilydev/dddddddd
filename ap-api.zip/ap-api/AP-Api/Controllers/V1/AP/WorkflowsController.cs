﻿using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Libraries;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestSharp;
using System.Transactions;
using Telegram.Bot;
using OneSignalApi.Api;
using OneSignalApi.Client;
using OneSignalApi.Model;
using System.Diagnostics;
using System;
using AP_Api.Services;
using Microsoft.Extensions.Logging;
using Telegram.Bot.Types;
using Telegram.Bot;
using Npgsql;
using AP_Api.Models;
//using AP_Api.Services;
using AP_Api.Helpers;
using Microsoft.Data.SqlClient;

namespace AP_Api.Controllers
{
#pragma warning disable CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning disable CS8602 // Dereference of a possibly null reference.
    [Route("api/v1/workflows")]
    [ApiController]
    [Authorize]
    //[CustomAuthorizeAttribute]
    public class WorkflowsController : Controller
    {
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbctx;
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private CustomUserIdentity _auth;
        //BackgroundJobs _backgroundJobs;
        private readonly BackgroundWorkerQueue _backgroundWorkerQueue;
        private readonly ILogger<WorkflowsController> _logger;
        private readonly HttpClient client = new HttpClient();

        public WorkflowsController(ILogger<WorkflowsController> logger, APContext context, IConfiguration config,
                    IHttpContextAccessor httpContextAccessor, ManualDbContext manualDbctx, BackgroundWorkerQueue backgroundWorkerQueue)
        {
            _httpContextAccessor = httpContextAccessor;
            _context = context;
            _manualDbctx = manualDbctx;
            _config = config;
            _logger = logger;
            _backgroundWorkerQueue = backgroundWorkerQueue;

            //var appConfig = new Configuration();

            //appConfig.BasePath = "https://onesignal.com/api/v1";

            //appConfig.AccessToken = _config.GetSection("OnSignal:Token").Value;

            //_appInstance = new DefaultApi(appConfig);



            if (_auth == null && _httpContextAccessor.HttpContext.User.Identity.IsAuthenticated == true)
                _auth = new CustomUserIdentity(_httpContextAccessor.HttpContext.User);

        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<WorkflowStatus>>> GetBasicAsync()
        {
            return await _context.WorkflowStatuses.ToListAsync();
        }

        private async Task sendNotification(string subject, string url, long telId, int proId = 0)
        {
            try
            {
                
                var postURL = _config.GetSection("ChatHub:Url").Value + "/api/Notifications/push/" + (proId == 0 ? "all" : "project_"+ proId);
                var response = await client.PostAsJsonAsync(postURL, new { 
                    Message = subject, 
                    Url = url, 
                    Name = _auth.FullName, 
                    TelId = telId  
                });

            }
            catch (ApiException ex)
            {
                //throw new Exception(ex.Message);
            }
            

        }
        [HttpPost("submit")]
        [Obsolete]
        public async Task<ActionResult<WorkflowDetail>> WorkflowSubmit(WorkflowSubmit data)
        {

            try
            {
                //var _auth = new CustomUserIdentity(User);
                

                var _auth = new CustomUserIdentity(User);

                var user = await _context.Users.FindAsync(_auth.Id);

                var settings = await _context.Settings.AsNoTracking().FirstOrDefaultAsync(x => x.CompanyId == user.CompanySessionId);

                var telToken = settings.TelegramBotToken ?? _config.GetSection("Tel:Token").Value;

                long? chatId = null;

                if (settings.TelegramChatId != null)
                {
                    chatId = Int64.Parse(settings.TelegramChatId);
                }

                var chatGroupId = (int?)chatId ?? 1;

               var wf = await _context.WorkflowDetails.AsNoTracking().FirstOrDefaultAsync(x => x.WfDetailUuid == data.WfDetailUuid);
                bool isSendMail = true;

                if (wf != null)
                {
     
                    //using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                    //{
                        
                        string action_label = wf.ActionLabel;
                        string workflow_name = wf.WorkflowLabel;

                        byte postStatus;

                        if (wf.CurLabel != "Parallel Approval")
                        {
                            postStatus = (byte)wf.PostStatus;
                        }
                        else
                        {
                            var workflow = _manualDbctx.ApprovalWorkflow.FromSqlRaw("exec [dbo].[sp_getWorkflow] @workflow_id={0}, @ref_id={1}", wf.WorkflowId, data.RefId).ToList();
                            int count = 0;
                            int count_isdone = 0;

                            foreach (var item in workflow)
                            {
                                if (item.role_name == wf.RoleName)
                                {
                                    if (item.is_done == true)
                                    {
                                        count_isdone++;
                                    }
                                    count++;
                                }
                            }
                            if (count == count_isdone + 1)
                            {
                                postStatus = (byte)wf.PostStatus;
                            }
                            else
                            {
                                isSendMail = false;
                                postStatus = (byte)wf.CurStatus;
                            }

                        }
                    string table_name = _context.Workflows.AsNoTracking().SingleOrDefault(x => x.Id == wf.WorkflowId).WorkflowName;
                    string sql = "exec dbo.sp_workflow_submit @table_name = '" + table_name + "', @ref_id = " + data.RefId + ", @rec_status = " + postStatus;
                    using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                    {
                        
                        List<ExecuteAffectedRow> result;

                        result = _manualDbctx.ExecuteAffectedRow.FromSqlRaw(sql).ToList();
                        if (result[0].affected_row == 0) return BadRequest(new ApiResponse("Failed", "Can not update workflow status!", "400"));


                        byte? is_done = 1;

                        // update status in workflow history
                        if (wf.PostStatus == 0)
                        {
                            is_done = null;

                            sql = @" update dbo.workflow_history
                                    set is_done = null
                                    where workflow_id = {0}
                                    and ref_id = {1}";
                            var sqlPeople = @" update dbo.workflow_people
                                    set is_done = 0, updated_at = null
                                    where ref_id = {0}";

                            _ = _context.Database.ExecuteSqlRaw(sql, wf.WorkflowId, data.RefId);
                            _ = _context.Database.ExecuteSqlRaw(sqlPeople, data.RefId);
                        }

                        WorkflowHistory workflowHistory = new WorkflowHistory
                        {
                            WorkflowId = wf.WorkflowId,
                            RefId = data.RefId,
                            RecStatus = wf.CurStatus,
                            PostStatus = wf.PostStatus,
                            IsDone = is_done,
                            Comment = data.Comment,
                            CreatedAt = DateTime.Now,
                            CreatedBy = _auth.Id
                        };

                        _context.WorkflowHistories.Add(workflowHistory);
                        await _context.SaveChangesAsync();

                        if (wf.ExecuteSp != null)
                        {
                            string sqlSP = @"exec " + wf.ExecuteSp + " {0}";
                            _context.Database.ExecuteSqlRaw(sqlSP, data.RefId);
                        }

                        if (wf.ExecuteSpSpecial != null)
                        {
                            _context.Database.ExecuteSqlRaw(@"exec " + wf.ExecuteSpSpecial + " {0}", data.RefId);
                        }
                            ts.Complete();
                    }

                    if (wf.ExecuteApiId != null)
                    {
                        string AppBaseUrl = this.Request.Scheme + "://" + this.Request.Host + this.Request.PathBase + "/api/v1/";
                        var api = _context.WorkflowApis.Find(wf.ExecuteApiId);

                        var client = new RestClient(AppBaseUrl + api.Url + data.RefId);
                        var request = new RestRequest("", Method.POST);

                        request.AddHeader("Authorization", this.Request.Headers["Authorization"]);

                        var response = await client.ExecuteAsync(request);
                    }

                    if (wf.DisabledNotify == true)
                    {
                        return Ok();
                    }

                    var notif = await _context.WorkflowNotifContents.AsNoTracking().FirstOrDefaultAsync(x => x.Id == wf.EmailContentId);

                    string subject = notif.NotifSubject + "";

                    NotifModel notifModel = new NotifModel();

                    if (!String.IsNullOrEmpty(notif.ParamJson))
                    {
                        notifModel = await _manualDbctx.NotifModel.FromSqlRaw(notif.ParamJson, data.RefId).AsNoTracking().SingleOrDefaultAsync();
                    }

                    string email_content = "";
                    string email_to = "";
                    string email_cc = "";


                    

                    

                    subject = subject.Replace("{user_full_name}", _auth.FullName);
                        subject = subject.Replace("{status}", action_label);
                        subject = subject.Replace("{action_label}", workflow_name);
                        subject = subject.Replace("{house_type}", notifModel?.HouseType ?? "");
                        subject = subject.Replace("{house_no}", notifModel?.HouseNo ?? "");
                        subject = subject.Replace("{project}", notifModel?.Project ?? "");
                        //subject = subject.Replace("{content1}", content1);
                        var baseContentUrl = await _context.WorkflowNotifContentUrls
                                                    .AsNoTracking()
                                                    .FirstOrDefaultAsync(x => x.Id == notif.ContentUrlId);
                        var baseUrl = baseContentUrl == null ? _config.GetSection("Tel:Url").Value : baseContentUrl?.BaseUrl;
                        //subject += "\nComment: " + data.Comment + "\n<a href=\"" + notif.NotifTo + data.RefId +"\">Click here</a>";
                        string url = baseUrl + notif.NotifTo + data.RefId;
                        string comment = "Comment: " + data.Comment;

                        var wf_role = await _context.WorkflowDetails.AsNoTracking().FirstOrDefaultAsync(x => x.WorkflowId == wf.WorkflowId && x.CurStatus == wf.PostStatus);

                        /***************************************** workflow email here ****************************************/

                        //if(wf.PostStatus != 0) { 
                        // update workflow people when workflow move
                        if (wf.PostStatus != 0)
                        {
                            sql = @"exec dbo.sp_workflow_people_update	@workflow_id = {0},
	                    @ref_id = {1},
	                    @user_id = {2},
	                    @rec_status = {3},
	                    @post_status = {4}";

                            _auth = new CustomUserIdentity(User);

                            await _context.Database.ExecuteSqlRawAsync(sql, wf.WorkflowId, data.RefId, _auth.Id, wf.CurStatus, wf.PostStatus);

                        }

                    


                    TelegramLog tlLog = new TelegramLog()
                    {
                        RefId = data.RefId,
                        WorkflowId = wf.WorkflowId,
                        TelegramContent = subject,
                        TelegramGroupId = wf.SmsContentId,
                        CreatedAt = DateTime.Now,
                        CreatedBy = _auth.Id,
                        RoleId = wf_role == null ? null : wf_role.CurRole,
                        Comment = data.Comment,
                        UserName = _auth.FullName,
                        ActionLabel = action_label,
                        WorkflowName = workflow_name,
                        HouseType = notifModel.HouseType ?? null,
                        HouseNo = notifModel.HouseNo ?? null,
                        Project = notifModel.Project ?? null,
                        Url = url,
                        ProjectId = notifModel.ProjectId ?? null,
                        CompanyId = user.CompanySessionId ?? null,
                    };
                        _context.TelegramLogs.Add(tlLog);
                        

                        await _context.SaveChangesAsync();
                    string message = subject + "\n<br/><i>Comment: " + data.Comment + "</i>\n<div class='overflow-clip max-w-[290px]'>" + url + "</div>";
                    subject += "\n<i>Comment: " + data.Comment + "</i>\n" + url;
					var live = _config.GetSection("Tel:Live").Value;
					if (bool.Parse(live))
                    {
						_backgroundWorkerQueue.QueueBackgroundWorkItem(async token =>
						{
							this.sendNotification(message, url, tlLog.Id, notifModel.ProjectId ?? 0);
						});
					}
						

                    if (wf.SmsContentId != null)
                            {
                                int TelegramGroupId = (int)wf.SmsContentId;


                                TelegramBotClient tel = new TelegramBotClient(telToken);

                        try
                                {
                                   
                                    
                                    
                                    if (bool.Parse(live))
                                    {
                                        _backgroundWorkerQueue.QueueBackgroundWorkItem(async token =>
                                        {
                                            try
                                            {
                                                await tel.SendTextMessageAsync(TelegramGroupId, subject, Telegram.Bot.Types.Enums.ParseMode.Html, disableWebPagePreview: true);
                                            } catch
                                            {

                                            }
                                        });
                                    }
                                    else
                                    {
                                        if(chatId != null)
                                        {
                                            _backgroundWorkerQueue.QueueBackgroundWorkItem(async token =>
                                            {
                                                try
                                                {
                                                    await tel.SendTextMessageAsync(chatId, subject, Telegram.Bot.Types.Enums.ParseMode.Html, disableWebPagePreview: true);
                                                }catch
                                                {

                                                }
                                            });
                                        }
                                        
                                    }
                                }
                                catch (Exception ex)
                                {
                                    throw new Exception(ex.Message);
                                }
                            }

                            //ts.Complete();

                            return Ok();

                        

                    //}
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            return NotFound();

        }

        [HttpGet("module/{workflow_name}")]
        public async Task<ActionResult<WorkflowDetailModel>> GetWorkflowByModule(string workflow_name)
        {
            return Ok(new WorkflowDetailModel("dbo." + workflow_name, 0, _auth.Id));
        }

        [HttpPut("notifications/update-check")]
        public async Task<IActionResult> NotificationCheck(DeleteModel data)
        {
            var notif = _context.WorkflowNotifications.SingleOrDefault(x => x.Id == data.Id && x.IsRead == 0 && x.ToUserId == _auth.Id);

            if (notif == null)
            {
                return NoContent();
            }

            notif.IsRead = 1;
            notif.UpdatedAt = DateTime.Now;

            try
            {
                _context.Entry(notif).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch
            {
                throw;
            }

            return Ok();

        }

        [HttpPut("notifications/mark-all-as-read")]

        public IActionResult NotificationMaskAsRead()
        {
            var _auth = new CustomUserIdentity(User);
            string sql = @"[dbo].[sp_mark_as_read] {0}";

            try
            {
                _context.Database.ExecuteSqlRaw(sql, _auth.Id);
            }
            catch
            {
                throw;
            }

            return Ok();

        }

        [HttpGet("notifications/count")]
        public async Task<ActionResult<object>> GetNotificationCount()
        {
            
            var _auth = new CustomUserIdentity(User);
       
            var data =  _manualDbctx.ExecuteQuery($"exec dbo.sp_get_notification_count {_auth.Id}")
                      .AsEnumerable()
                      .FirstOrDefault();


            return Ok(data);

        }



        [HttpGet("notifications")]
        public async Task<ActionResult<IEnumerable<VTelegramLog>>> GetNotification([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            string search = filter.Search ?? "";

            var list = _manualDbctx.VTelegramLogs.FromSqlRaw("exec dbo.sp_get_telegram_log {0},{1}", _auth.Id, search)
                .AsEnumerable()
                .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                .Take(validFilter.PageSize)
                .ToList();

            validFilter.TotalRecords = _manualDbctx
                                        .VTelegramLogs
                                        .FromSqlRaw("exec dbo.sp_get_telegram_log {0},{1}", _auth.Id, search)
                                        .AsEnumerable()
                                        .Count();

            return Ok(new PagedResponse<IEnumerable<object>>(list, validFilter));

        }

        [HttpGet("notifications/{id}")]
        public async Task<ActionResult<VTelegramLog>> GetNotification(int Id)
        {
            var _auth = new CustomUserIdentity(User);

            return _manualDbctx.VTelegramLogs
                    .FromSqlRaw("exec [dbo].[sp_get_telegram_log_by_id] {0},{1}", _auth.Id, Id)
                    .AsEnumerable()
                    .FirstOrDefault();

        }

        [HttpPost("notifications/visited/{id}")]
        public async Task<ActionResult> SMSLogVisited(long id)
        {
            var _auth = new CustomUserIdentity(User);

            var telegram_log = await _context.TelegramLogs.FindAsync(id);

            if (telegram_log != null)
            {
                _context.TelegramLogVisiteds.Add(new TelegramLogVisited()
                {
                    TelegramLogId = telegram_log.Id,
                    VisitedAt = DateTime.Now,
                    UserId = _auth.Id
                });
                await _context.SaveChangesAsync();
                return Ok("success");
            }
            else
            {
                return BadRequest("fail");
            }
        }







        /* Workflow email
         * 
         * sql = @"exec [dbo].[sp_getEmailFromConfigWorkflow] @notif_id = {0}, @workflow_id = {1}, @cur_status = {2}, @ref_id = {3}";

                var emails = await _manualDbctx.WorkflowEmail.FromSqlRaw(sql, wf.EmailContentId, wf.WorkflowId, wf.CurStatus, data.RefId).ToListAsync();

                foreach(var email in emails)
                {
                    WorkflowNotification wnf = new WorkflowNotification()
                    {
                        WorkflowId = wf.WorkflowId,
                        RefId = (int)data.RefId,
                        NotifTitle = subject,
                        FromUserId = _userIdentity.Id,
                        ToUserId = email.user_id,
                        IsRead = 0,
                        CreatedAt = DateTime.Now
                    };

                    if(email_content == "")
                    {
                        email_content = email.email_content;
                    }

                    if (email.isTo == 1)
                    {
                        if (!email_to.Equals(""))
                            email_to += ";";

                        email_to += email.email;

                        wnf.NotifType = 1;

                    }

                    if (email.isCC == 1)
                    {
                        if (!email_cc.Equals(""))
                            email_cc += ";";

                        email_cc += email.email;

                        wnf.NotifType = 2;
                    }

                    _context.WorkflowNotifications.Add(wnf);

                    // insert to queue
                    MessageQueue.PubString("notif",wnf.ToString());

                }


                if (data.Comment.IndexOf("<testing>", 0) >= 0)
                {
                    email_content += "<br/><br/>Email to: " + email_to + "<br/>Email CC: " + email_cc;
                    email_to = "thao.sokvitou@cellcard.com.kh";
                    //email_to = "you.sotheara@cellcard.com.kh";
                    //email_cc = "sam.sanstar@cellcard.com.kh";
                }

                if (isSendMail)
                {
                    QueryModel queryModel = new QueryModel();

                    EngineEmail ee = new EngineEmail()
                    {
                        Subject = subject,
                        ReceiptTo = email_to,
                        ReceiptCc = email_cc,
                        BodyContent = email_content,
                        Status = 0,
                        CreatedAt = DateTime.Now,
                        CreatedBy = _userIdentity.Id
                    };
                    
                    _context.Add(ee);

                    await _context.SaveChangesAsync();

                    // insert data to email to users for checking email box
                    sql = "exec po3.sp_users_to_email @workflow_id = {0}, @email_id = {1}, @receipt = {2}";

                    _ = _context.Database.ExecuteSqlRaw(sql, wf.WorkflowId, ee.Id, email_to + ";" + email_cc);
                }
        */
    }
#pragma warning restore CS8600 // Converting null literal or possible null value to non-nullable type.
#pragma warning restore CS8602 // Dereference of a possibly null reference.
}


