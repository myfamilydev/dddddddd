﻿using AP_Api.Helpers;
using AP_Api.Models;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class CentralCashBookController : ControllerBase
    {
        private readonly APContext _context;
        private readonly ManualDbContext _manualDbContext;

        public CentralCashBookController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VCentralCashBook>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;
            var list = new List<short>();
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                .ToList();
            }

            var pagedData = _context.VCentralCashBooks
                               .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.ProjectShort.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.RefCode.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.ChequeRef.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.SupplierName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.StatusName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankName.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                               .OrderByDescending(x => x.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VCentralCashBooks
                                .Where(s => (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.ProjectShort.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.RefCode.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.ChequeRef.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.SupplierName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.StatusName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankName.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter)); 
            
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VCentralCashBook>> GetById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VCentralCashBooks.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return Ok(data);
        }

        [HttpPost("add")]
        public async Task<ActionResult<CentralCashBook>> Add(CentralCashBook data)

        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            if (isExistChequeRef(data.ChequeRef, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This ChequeRef already use!"));
            }

            if (isExistRefCode(data.RefCode, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This RefCode already use!"));
            }

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;
            data.RecStatus = 0;
            data.Status = true;
            

            if(data.TransactionTypeId== 1)
            {
                data.StatusName = "Deposit";
				data.Amount = Math.Abs(data.Amount ?? 0);

			} else
            {
				data.Amount = Math.Abs(data.Amount ?? 0) * (-1);
				data.StatusName = "Processing";
				data.StatementDate = null;
			}

            _context.CentralCashBooks.Add(data);

            await _context.SaveChangesAsync();

			_context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_cash_excel_book_update_status] {0}", data.Id);

			return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(CentralCashBook data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.CentralCashBooks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            if (isExistChequeRef(data.ChequeRef, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This ChequeRef already use!"));
            }
            if (isExistRefCode(data.RefCode, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This RefCode already use!"));
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.CompanyId = user.CompanySessionId;

			if (data.TransactionTypeId == 1)
			{
				data.Amount = Math.Abs(data.Amount ?? 0);

			}
			else
			{
				data.Amount = Math.Abs(data.Amount ?? 0) * (-1);
			}

			try
            {
                await _context.SaveChangesAsync();

                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_cash_excel_book_update_status] {0}", data.Id);
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
        private bool isExistChequeRef(string chequeRef, int? id)
        {
            if (chequeRef.Trim().ToLower() == "n/a") return false;

            return _context.CentralCashBooks.Any(cas => cas.Status == true && cas.ChequeRef == chequeRef && (id == null || cas.Id != id));
        }

        private bool isExistRefCode(string refCode, int? id)
        {
			if (refCode.Trim().ToLower() == "n/a") return false;

			return _context.CentralCashBooks.Any(cas => cas.Status == true && cas.RefCode == refCode && (id == null || cas.Id != id));
        }
        [HttpPost("cheque_ref/available")]
        public async Task<ActionResult<object>> CheckAvailableChequeRef(ClsAvailableCheque data)
        {
            bool isExisted = isExistChequeRef(data.ChequeRef, data.Id);

            string Message = isExisted ? "Cheque ref isn't available" : "Cheque ref is Available";

            return Ok(new
            {
                Availble = !isExisted,
                Message = Message
            });
        }
        [HttpPost("ref_code/available")]
        public async Task<ActionResult<object>> CheckAvailableRefCode(ClsAvailableRefCode data)
        {
            bool isExisted = isExistRefCode(data.RefCode, data.Id);

            string Message = isExisted ? "Ref code isn't available" : "Ref code is Available";

            return Ok(new
            {
                Availble = !isExisted,
                Message = Message
            });
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await _context.CentralCashBooks.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.CentralCashBooks.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("ownership/{ownership}/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetBankBasic(string ownership)
        {
            return _context.ExecuteQuery($"exec [dbo].[sp_v_bank_active_basic] {ownership}")
                .AsEnumerable()
                .ToList();
        }

	}
}
