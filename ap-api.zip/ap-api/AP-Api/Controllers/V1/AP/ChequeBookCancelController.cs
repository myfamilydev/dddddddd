﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ChequeBookCancelController : ControllerBase
    {
        private readonly APContext _context;

        public ChequeBookCancelController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VChequeBookCancel>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VChequeBookCancels
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.BankNameKh.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankNameEn.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountNumber.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.ProjectShort.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.CancelNo.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.Reason.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VChequeBookCancels
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.BankNameKh.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankNameEn.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountNumber.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.ProjectShort.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.CancelNo.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.Reason.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));
            
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ChequeBookCancel>> GetById(int id)
        {
            var data = await _context.ChequeBookCancels.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }


        [HttpPost("add")]
        public async Task<ActionResult<ChequeBookCancel>> Add(ChequeBookCancel data)
        {
            var project = _context.VDbliveProjects.First(x => x.Id == data.ProjectId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);
            var suffix = "/" + year + "-" + project;
            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            try
            {
                _context.ChequeBookCancels.Add(data);
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(ChequeBookCancel data)
        {
            var valid = await _context.VChequeBookCancels.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            var _auth = new CustomUserIdentity(User);
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }


        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var valid = await _context.ChequeBookCancels.FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);
            valid.Status = 0;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                _context.ChequeBookCancels.Remove(valid);
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

    }
}
