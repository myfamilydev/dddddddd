﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Text;
using ExcelDataReader;
using System.Transactions;
using OneSignalApi.Model;
using System.IO;
using AP_Api.Models;
using AP_Api.Helpers;
using Microsoft.CodeAnalysis;

namespace Web.Controllers.AP.Suppliers
{
    [Route("api/v1/payment-vouchers")]
    [ApiController]
    [Authorize]
    public class PaymentVouchersController : ControllerBase
    {
        private readonly APContext _context;

        private readonly ManualDbContext _manualDbContext;

        public PaymentVouchersController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<VPaymentVourcher>>> GetPaymentVoucher([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;
            var list = new List<short>();
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                .ToList();
            }

            filter.TotalRecords = await _context.VPaymentVourchers
                           .Where(s => (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                                || s.ChequeDesc.Contains(filter.Search)
                                || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                                || s.CompanyName.ToLower().Contains(filter.Search.ToLower())
                                || s.BankName.ToLower().Contains(filter.Search.ToLower())
                                || s.SupplierName.ToLower().Contains(filter.Search.ToLower())
                                || s.PayeeName.ToLower().Contains(filter.Search.ToLower())
                                || s.ChequeRef.ToLower().Contains(filter.Search.ToLower())
                                || s.PvRef.ToLower().Contains(filter.Search.ToLower())
                                || s.SettlementCode.ToLower().Contains(filter.Search.ToLower())))
                           .CountAsync();

            var data = await _context.VPaymentVourchers
                           .Where(s => (list.Contains((short)s.ProId) || s.ProId == filter.ProId)  && (String.IsNullOrEmpty(filter.Search)
                                || s.ChequeDesc.Contains(filter.Search)
                                || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                                || s.CompanyName.ToLower().Contains(filter.Search.ToLower())
                                || s.BankName.ToLower().Contains(filter.Search.ToLower())
                                || s.SupplierName.ToLower().Contains(filter.Search.ToLower())
                                || s.PayeeName.ToLower().Contains(filter.Search.ToLower())
                                || s.ChequeRef.ToLower().Contains(filter.Search.ToLower())
                                || s.PvRef.ToLower().Contains(filter.Search.ToLower())
                                || s.SettlementCode.ToLower().Contains(filter.Search.ToLower())))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetById(int id)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var data = await _context.PaymentVouchers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true && x.CompanyId == user.CompanySessionId);
            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.payment_vouchers", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("add")]
        public async Task<ActionResult<PaymentVoucher>> Add(PaymentVoucher data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            //var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode;

            //var bank = _context.Banks.FirstOrDefault(x => x.Id == data.BankId).RefCode.ToString();

            //var year = DateTime.Now.ToString("yy");
            //var month = DateTime.Now.ToString("MM");

            //var suffix = project + bank + "-" + month + year + "-";

            //var getMax = await _context.PaymentVouchers.Where(x => (x.CompanyId == user.CompanySessionId) && x.PvRef.StartsWith(suffix)).MaxAsync(x => x.PvRef);

            //if (getMax != null)
            //{
            //    data.PvRef = suffix + toPVRef(getMax, suffix);
            //}
            //else
            //{
            //    data.PvRef = suffix + "1";
            //}

            if (isExistRef(data.PvRef, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This pvRef already use!"));
            }

            if(data.NoCheque == true)
            {
                data.ChequeRef = null;
            }

			if (data.NoCheque != true && isExistChequeRef(data.ChequeRef, data.Id))
			{
				return BadRequest(new ApiResponse("failed", "This cheque ref is already use!"));
			}


			data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            //data.ChequeRef = null;

            _context.PaymentVouchers.Add(data);

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_update_payment_voucher_ref] {0}", data.Id);

                    ts.Complete();
                }
            }

            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.payment_vouchers", data.Id, _auth.Id);

            return data;
        }

        private string toPVRef(string code, string suffix)
        {
            code = code.Replace(suffix, "");
            return (Convert.ToInt32(code) + 1).ToString();
        }

		[HttpPost("detail/copy")]
		public async Task<IActionResult> ClonePaymentVoucher(CloneVoucherInput data)
        {
            try
            {
                _manualDbContext.Database.ExecuteSqlRaw("exec [dbo].[sp_clone_payment_voucher_allocation] {0},{1}", data.Id, data.Amount);
                return Ok();
            }catch(Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }


		[HttpPut("update")]
        public async Task<IActionResult> UpdatePaymentVoucher(PaymentVoucher data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var valid = await _context.PaymentVouchers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true && x.CompanyId == user.CompanySessionId);
            if (valid == null)
            {
                return BadRequest();
            }
            data.Id = valid.Id;

            if (isExistRef(data.PvRef, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This pvRef is already use!"));
            }

			if (data.NoCheque == true)
			{
				data.ChequeRef = null;
			}

			if (data.NoCheque != true && isExistChequeRef(data.ChequeRef, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This cheque ref is already use!"));
            }

            //var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode;

            //var bank = _context.Banks.FirstOrDefault(x => x.Id == data.BankId).RefCode.ToString();

            //var year = DateTime.Now.ToString("yy");
            //var month = DateTime.Now.ToString("MM");

            //var suffix = project + bank + "-" + month + year + "-";

            //if (data.ProId != valid.ProId)
            //{
            //    var getMax = await _context.PaymentVouchers.Where(x => x.CompanyId == user.CompanySessionId && x.PvRef.StartsWith(suffix)).MaxAsync(x => x.PvRef);

            //    if (getMax != null)
            //    {
            //        data.PvRef = suffix + toPVRef(getMax, suffix);
            //    }
            //    else
            //    {
            //        data.PvRef = suffix + "1";
            //    }
            //}
            //else
            //{
            //    _context.Entry(data).Property(x => x.PvRef).IsModified = false;
            //}

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;
            //_context.Entry(data).Property(x => x.ChequeRef).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_update_payment_voucher_ref] {0}", data.Id);
                    ts.Complete();
                }
            }

            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return Ok();
        }

        private bool isExistRef(string pvRef, int? id)
        {
            return _context.PaymentVouchers.Any(cas => cas.Status == true && cas.PvRef == pvRef && (id == null || cas.Id != id));
        }

        private bool isExistChequeRef(string chequeRef, int? id)
        {
            return _context.PaymentVouchers.Any(cas => cas.Status == true && cas.ChequeRef == chequeRef && (id == null || cas.Id != id));
        }

        private bool isExistPvRef(string pvRef, int? id)
        {
            return _context.PaymentVouchers.Any(cas => cas.Status == true && cas.PvRef == pvRef && (id == null || cas.Id != id));
        }



        [HttpPost("cheque_ref/available")]
        public async Task<ActionResult<object>> CheckAvailableChequeRef(ClsAvailableCheque data)
        {
            bool isExisted = isExistChequeRef(data.ChequeRef, data.Id);

            string Message = isExisted ? "Cheque ref isn't available" : "Cheque ref is Available";

            return Ok(new
            {
                Availble = !isExisted,
                Message = Message
            });
        }

        [HttpPost("pv_ref/available")]
        public async Task<ActionResult<object>> CheckAvailablePvRef(ClsAvailablePVRef data)
        {
            bool isExisted = isExistPvRef(data.PvRef, data.Id);

            string Message = isExisted ? "Pv ref isn't available" : "Pv ref is Available";

            return Ok(new
            {
                Availble = !isExisted,
                Message = Message
            });
        }

        [HttpDelete("{id}/delete")]
        public async Task<ActionResult> DeletePaymentVoucher(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.payment_vouchers", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("{id}/detail")]
        public async Task<ActionResult<IEnumerable<VPaymentVouchersDetail>>> GetPaymentVoucherDetail(int id)
        {
            return await _context.VPaymentVouchersDetails
                           .Where(s => s.PaymentVoucherId == id)
                           .ToListAsync();
        }

        [HttpPut("detail/update")]
        public async Task<IActionResult> UpdatePaymentVoucherDetailDetail(PaymentVouchersDetail data)
        {
            var valid = await _context.PaymentVouchersDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);
            
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Invalid data", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.PaymentDescription = data.PaymentDescription;

			var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("settlement/basic")]
        public async Task<ActionResult<IEnumerable<VPaymentSettlementsBasic>>> GetPaymentSettlementBasic([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

			var spectialPro = new List<short?>
            {
                1,4
            };

			if (spectialPro.Contains(filter.ProId))
            {
				return await _context.VPaymentSettlementsBasics.Where(x => (x.CompanyId == user.CompanySessionId) && (spectialPro.Contains(x.ProId))).ToListAsync();
			}

            return await _context.VPaymentSettlementsBasics.Where(x => (x.CompanyId == user.CompanySessionId) && (x.ProId == filter.ProId)).ToListAsync();
        }

        [HttpGet("settlement/pretty/basic")]
        public async Task<ActionResult<IEnumerable<VPaymentSettlementsPrettyCashBasic>>> GetPaymentSettlementPrettyBasic([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

			var spectialPro = new List<short?>
			{
				1,4
			};

            if (spectialPro.Contains(filter.ProId))
            {

                return await _context.VPaymentSettlementsPrettyCashBasics.Where(x => (x.CompanyId == user.CompanySessionId) && (x.ProId == filter.ProId)).ToListAsync();
            }

			return await _context.VPaymentSettlementsPrettyCashBasics.Where(x => (x.CompanyId == user.CompanySessionId) && (x.ProId == filter.ProId)).ToListAsync();
        }

        [HttpGet("banks/{projectId}/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetBankBasic(int projectId)
        {
            var data = _context.ExecuteQuery($"exec dbo.sp_v_bank_basic {projectId}")
                .AsEnumerable().ToList();
            return Ok(data);

        }

		[HttpPost("detail/preview")]
		public ActionResult<object> GetPrevPaymentVoucherDetail(PaymentVoucherPro paymentVoucherPro)
		{
            var info = _context.ExecuteQuery($"exec [dbo].[sp_get_voucher_preview_info] '{paymentVoucherPro.SettleIds}'")
						   .AsEnumerable()
                           .FirstOrDefault();

			var detail = _context.ExecuteQuery($"exec [dbo].[sp_get_voucher_preview] {paymentVoucherPro.ProId},'{paymentVoucherPro.SettleIds}'")
						   .ToList();

            return new
            {
                info = info,
                detail = detail
            };
		}

		[HttpGet("{id}/reverse-penalty")]
		public async Task<ActionResult<object>> GetReversePenalty(int id)
		{
			
			return _context.ExecuteQuery($"exec dbo.sp_reverse_penalty_get {id}").AsEnumerable().FirstOrDefault();
		}

		private bool isExistPettyCashRef(string pvRef, int? id)
		{
			return _context.PaymentPettyCashes.Any(cas => cas.Status == 1 && cas.PvRef == pvRef && (id == null || cas.Id != id));
		}

		[HttpPut("reverse-penalty-ref/update")]
		public async Task<IActionResult> UpdatePaymentVoucherRef(ClsVoucherOrPettyCashInput data)
		{
			if (data.Type == "voucher")
            {
				var valid = await _context.PaymentVouchers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

				if (valid == null)
				{
					return BadRequest(new ApiResponse("failed", "Invalid data", "400"));
				}

				_context.Entry(valid).State = EntityState.Modified;

				if (isExistRef(data.PvRef, data.Id))
				{
					return BadRequest(new ApiResponse("failed", "This pvRef is already use!"));
				}


				valid.PvRef = data.PvRef;

                
			} else
            {
				var valid = await _context.PaymentPettyCashes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

				if (valid == null)
				{
					return BadRequest(new ApiResponse("failed", "Invalid data", "400"));
				}

				if (isExistPettyCashRef(data.PvRef, data.Id))
				{
					return BadRequest(new ApiResponse("failed", "This pvRef already use!"));
				}

				_context.Entry(valid).State = EntityState.Modified;

				valid.PvRef = data.PvRef;
			}

			try
			{
				await _context.SaveChangesAsync();
				return Ok();
			}
			catch (DbUpdateConcurrencyException)
			{

			}

			return NoContent();
		}

        [HttpPut("reverse-cheque-ref/update")]
        public async Task<IActionResult> UpdatePaymentVoucherChequeRef(ClsVoucherReverseChequeInput data)
        {
            if (data.Type == "voucher")
            {
                var valid = await _context.PaymentPenaltyReverseCheques.AsNoTracking().FirstOrDefaultAsync(x => x.ChequeId == data.Id && x.DeleteAt == null);

                if (valid == null)
                {
                    return BadRequest(new ApiResponse("failed", "Invalid data", "400"));
                }

                var valid_data = await _context.PaymentVouchers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == valid.VoucherRefId && x.Status == true);

                if (valid_data == null)
                {
                    return BadRequest(new ApiResponse("failed", "Invalid data", "400"));
                }

                _context.Entry(valid).State = EntityState.Modified;
                _context.Entry(valid_data).State = EntityState.Modified;

                if (isExistChequeRef(data.ChequeRef, data.Id))
                {
                    return BadRequest(new ApiResponse("failed", "This chequeRef is already use!"));
                }

                valid.ChequeRef = data.ChequeRef;
                valid_data.ChequeRef = data.ChequeRef;
                valid_data.ChequeId = valid.ChequeId;
            }
          
            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
