﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;
using Polly.Caching;

namespace Web.Controllers.AP
{
    [Route("api/v1/settle/payments")]
    [ApiController]
    [Authorize]
    public class SettlePaymentController : ControllerBase
    {
        private readonly APContext _context;
        
        private readonly ManualDbContext _manualDbContext;

        public SettlePaymentController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet("{id}/invoices")]
        public async Task<ActionResult<IEnumerable<SettlePaymentInvoice>>> GetInvoiceAsync(int id)
        {
            return await _context.SettlePaymentInvoices
                .Where(x => x.SupplierSettlePaymentId == id && x.Status == true)
                .ToListAsync();
        }

        [HttpGet("invoices/{id}")]
        public async Task<ActionResult<SettlePaymentInvoice>> GetInvoiceByIdAsync(int id)
        {
            var data = await _context.SettlePaymentInvoices.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("invoices/add")]
        public async Task<ActionResult<SettlePaymentInvoice>> AddInvoiceAsync(SettlePaymentInvoice data)
        {

            var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.SettlePaymentInvoices.Add(data);

            await _context.SaveChangesAsync();

            if (data.Id != null)
            {
                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_settle_payment_to_invoice] {0}", data.Id);
            }

            return data;
        }

        [HttpPut("invoices/update")]
        public async Task<IActionResult> UpdateInvoiceAsync(SettlePaymentInvoice data)
        {
            var valid = await _context.SettlePaymentInvoices.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.AccountCode).IsModified = false;

            _context.Entry(data).Property(x => x.ItemId).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();

                if (data.Id != null)
                {
                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_settle_payment_to_invoice] {0}", data.Id);
                }

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("invoices/{id}/delete")]
        public async Task<IActionResult> DeleteInvoiceAsync(int id)
        {
            var valid = await _context.SettlePaymentInvoices.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpGet("{id}/details")]
        public async Task<ActionResult<IEnumerable<SettlePaymentInvoicesDetail>>> GetInvoiceDetailAsync(int id)
        {
            return await _context.SettlePaymentInvoicesDetails
                .Where(x => x.SettlePaymentId == id && x.Status == true)
                .ToListAsync();
        }

        [HttpGet("invoices/{id}/details")]
        public async Task<ActionResult<IEnumerable<SettlePaymentInvoicesDetail>>> GetInvoiceDetailByInvoiceAsync(int id)
        {
            return await _context.SettlePaymentInvoicesDetails
                .Where(x => x.InvoiceId == id && x.Status == true)
                .ToListAsync();
        }

        [HttpGet("invoices/details/{id}")]
        public async Task<ActionResult<SettlePaymentInvoicesDetail>> GetInvoiceDetailByIdAsync(int id)
        {
            var data = await _context.SettlePaymentInvoicesDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("invoices/details/add")]
        public async Task<ActionResult<SettlePaymentInvoicesDetail>> AddInvoiceDetailAsync(SettlePaymentInvoicesDetail data)
        {

            var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;
            

            _context.SettlePaymentInvoicesDetails.Add(data);

            await _context.SaveChangesAsync();

            
            return data;
        }

        [HttpPut("invoices/details/update")]
        public async Task<IActionResult> UpdateInvoiceDetailAsync(SettlePaymentInvoicesDetail data)
        {
            var valid = await _context.SettlePaymentInvoicesDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedBy = _auth.Id;

            data.UpdatedAt = DateTime.Now;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("invoices/details/{id}/delete")]
        public async Task<IActionResult> DeleteInvoiceDetailAsync(int id)
        {
            var valid = await _context.SettlePaymentInvoicesDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpGet("{id}/invoice-non-stocks")]
        public async Task<ActionResult<IEnumerable<SettlePaymentInvoicesNonstock>>> GetInvoiceNonStockAsync(int id)
        {
            return await _context.SettlePaymentInvoicesNonstocks
                .Where(x => x.SupplierSettlePaymentId == id && x.Status == true)
                .ToListAsync();
        }

        [HttpGet("invoice-non-stocks/{id}")]
        public async Task<ActionResult<SettlePaymentInvoicesNonstock>> GetInvoiceNonStockByIdAsync(int id)
        {
            var data = await _context.SettlePaymentInvoicesNonstocks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("invoice-non-stocks/add")]
        public async Task<ActionResult<SettlePaymentInvoicesNonstock>> AddInvoiceNonStockAsync(SettlePaymentInvoicesNonstock data)
        {

            var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.SettlePaymentInvoicesNonstocks.Add(data);

            await _context.SaveChangesAsync();

            
            return data;
        }

        [HttpPut("invoice-non-stocks/update")]
        public async Task<IActionResult> UpdateInvoiceStockAsync(SettlePaymentInvoicesNonstock data)
        {
            var valid = await _context.SettlePaymentInvoicesNonstocks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("invoice-non-stocks/{id}/delete")]
        public async Task<IActionResult> DeleteInvoiceNonStockAsync(int id)
        {
            var valid = await _context.SettlePaymentInvoicesNonstocks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("{id}/invoice-non-stocks/details")]
        public async Task<ActionResult<IEnumerable<SettlePaymentInvoicesNonstocksDetail>>> GetInvoiceNonStockDetailBySettleAsync(int id)
        {
            return await _context.SettlePaymentInvoicesNonstocksDetails
                .Where(x => x.SettlePaymentId == id && x.Status == true)
                .ToListAsync();
        }

        [HttpGet("invoice-non-stocks/{id}/details")]
        public async Task<ActionResult<IEnumerable<SettlePaymentInvoicesNonstocksDetail>>> GetInvoiceNonStockDetailAsync(int id)
        {
            return await _context.SettlePaymentInvoicesNonstocksDetails
                .Where(x => x.SettlePaymentId == id && x.Status == true)
                .ToListAsync();
        }

        [HttpGet("invoice-non-stocks/details/{id}")]
        public async Task<ActionResult<SettlePaymentInvoicesNonstocksDetail>> GetInvoiceNonStockDetailByIdAsync(int id)
        {
            var data = await _context.SettlePaymentInvoicesNonstocksDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("invoice-non-stocks/details/add")]
        public async Task<ActionResult<SettlePaymentInvoicesNonstocksDetail>> AddInvoiceNonStockDetailAsync(SettlePaymentInvoicesNonstocksDetail data)
        {

            var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.SettlePaymentInvoicesNonstocksDetails.Add(data);

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_refresh_share_cost] {0}", data.Id);

                    ts.Complete();
                }
                
            }
            catch(Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return data;
        }

        [HttpPut("invoice-non-stocks/details/update")]
        public async Task<IActionResult> UpdateInvoiceNonStockDetailAsync(SettlePaymentInvoicesNonstocksDetail data)
        {
            var valid = await _context.SettlePaymentInvoicesNonstocksDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_refresh_share_cost] {0}", data.Id);

                    ts.Complete();
                }
                return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpDelete("invoice-non-stocks/details/{id}/delete")]
        public async Task<IActionResult> DeleteInvoiceNonStockDetailAsync(int id)
        {
            var valid = await _context.SettlePaymentInvoicesNonstocksDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var costList = await _context.SettlePaymentInvoicesNonstocksDetailCosts.AsNoTracking().Where(x => x.NonStockDetailId== id).ToListAsync();

            if(costList.Count > 0)
            {
                _context.SettlePaymentInvoicesNonstocksDetailCosts.RemoveRange(costList);
            }

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("{id}/invoice-non-stocks/details/costs")]
        public async Task<ActionResult<IEnumerable<VSettlePaymentInvoicesNonstocksDetailCost>>> GetInvoiceNonStockDetailCostsBySettleAsync(int id)
        {
            return await _context.VSettlePaymentInvoicesNonstocksDetailCosts
                .Where(x => x.SettlePaymentId == id)
                .ToListAsync();
        }

        [HttpGet("invoice-non-stocks/details/{id}/costs")]
        public async Task<ActionResult<IEnumerable<VSettlePaymentInvoicesNonstocksDetailCost>>> GetInvoiceNonStockDetailCostsAsync(int id)
        {
            return await _context.VSettlePaymentInvoicesNonstocksDetailCosts
                .Where(x => x.SettlePaymentId == id)
                .ToListAsync();
        }

        [HttpGet("invoice-non-stocks/details/costs/{id}")]
        public async Task<ActionResult<VSettlePaymentInvoicesNonstocksDetailCost>> GetInvoiceNonStockDetailCostByIdAsync(int id)
        {
            var data = await _context.VSettlePaymentInvoicesNonstocksDetailCosts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("invoice-non-stocks/details/costs/add")]
        public async Task<ActionResult<SettlePaymentInvoicesNonstocksDetailCost>> AddInvoiceNonStockDetailCostAsync(SettlePaymentInvoicesNonstocksDetailCost data)
        {

            var detail = await _context.SettlePaymentInvoicesNonstocksDetails.FindAsync(data.NonStockDetailId);
            if (detail == null)
            {
                return BadRequest(new ApiResponse("failed", "Invalid detail id", "400"));
            }
            decimal total = (decimal) await _context.SettlePaymentInvoicesNonstocksDetailCosts.AsNoTracking()
                            .Where(x => x.NonStockDetailId == data.NonStockDetailId && x.Status == true)
                            .SumAsync(x => x.Amount);
            var _auth = new CustomUserIdentity(User);

            if (detail.ShareCostType != "share_not_standard")
            {
                return BadRequest(new ApiResponse("failed", "Can't add share for this share cost type", "400"));
            }

             data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.SettlePaymentId = detail.SettlePaymentId;

            data.Locked = false;

            if (data.Amount + total > detail.Qty * detail.UnitPrice)
            {
                return BadRequest(new ApiResponse("failed", "Can't share cost percentage over 100%", "400"));
            }

            data.Percentage = Math.Round((data.Amount * 100) / (detail.Qty * detail.UnitPrice) ?? 0);

            _context.SettlePaymentInvoicesNonstocksDetailCosts.Add(data);

            await _context.SaveChangesAsync();


            return data;
        }

        [HttpPut("invoice-non-stocks/details/costs/update")]
        public async Task<IActionResult> UpdateInvoiceNonStockDetailCostAsync(SettlePaymentInvoicesNonstocksDetailCost data)
        {
            var valid = await _context.SettlePaymentInvoicesNonstocksDetailCosts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            var detail = await _context.SettlePaymentInvoicesNonstocksDetails.FindAsync(data.NonStockDetailId);
            if (detail == null)
            {
                return BadRequest(new ApiResponse("failed", "Invalid detail id", "400"));
            }

            decimal total = (decimal)await _context.SettlePaymentInvoicesNonstocksDetailCosts.AsNoTracking()
                            .Where(x => x.NonStockDetailId == data.NonStockDetailId && x.Status == true && x.Id != data.Id)
                            .SumAsync(x => x.Amount);

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.EffectiveId).IsModified = false;

            _context.Entry(data).Property(x => x.SettlePaymentId).IsModified = false;

            
            //data.SettlePaymentId = detail.SettlePaymentId;

            if (detail.ShareCostType != "share_not_standard")
            {
                _context.Entry(data).Property(x => x.ProjectId).IsModified = false;

                _context.Entry(data).Property(x => x.Amount).IsModified = false;

                _context.Entry(data).Property(x => x.Percentage).IsModified = false;

                _context.Entry(data).Property(x => x.Locked).IsModified = false;
            } else
            {
                if (data.Amount + total > detail.Qty * detail.UnitPrice)
                {
                    return BadRequest(new ApiResponse("failed", "Can't share cost percentage over 100%", "400"));
                }

                data.Percentage = Math.Round((data.Amount * 100) / (detail.Qty * detail.UnitPrice) ?? 0);
            }

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("invoice-non-stocks/details/costs/{id}/delete")]
        public async Task<IActionResult> DeleteInvoiceNonStockDetailCostAsync(int id)
        {
            var valid = await _context.SettlePaymentInvoicesNonstocksDetailCosts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
