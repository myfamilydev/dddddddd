﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Text;
using ExcelDataReader;
using System.Transactions;

namespace Web.Controllers.AP.Suppliers
{
    [Route("api/v1/schedule/payments")]
    [ApiController]
    [Authorize]
    public class SchedulePaymentController : ControllerBase
    {
        private readonly APContext _context;
        
        private readonly ManualDbContext _manualDbContext;

        public SchedulePaymentController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VSuppliersSchedulesPayment>>> GetAllSchedulePaymentAsync([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VSuppliersSchedulesPayments
                        .Where(s => (s.CompanyId == user.CompanySessionId) && (s.Status == true) && (s.ProjectId == filter.ProId || filter.ProId == 0) && ((String.IsNullOrEmpty(filter.Search)
                        || s.SchedulePaymentCode.ToLower().Contains(filter.Search.ToLower())
                        || s.AccountCode.ToLower().Contains(filter.Search.ToLower())
                        || s.SupplierNameKh.Contains(filter.Search)
                        || s.SupplierNameEn.ToLower().Contains(filter.Search.ToLower())
                        || s.ItemType.ToLower().Contains(filter.Search.ToLower())
                        || s.TermPay.ToLower().Contains(filter.Search.ToLower()))))
                           .OrderBy(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VSuppliersSchedulesPayments
                        .Where(s => (s.CompanyId == user.CompanySessionId) && (s.Status == true) && (s.ProjectId == filter.ProId || filter.ProId == 0) && ((String.IsNullOrEmpty(filter.Search)
                        || s.SupplierNameKh.Contains(filter.Search)
                        || s.SupplierNameEn.ToLower().Contains(filter.Search.ToLower())
                        || s.ItemType.ToLower().Contains(filter.Search.ToLower())
                        || s.TermPay.ToLower().Contains(filter.Search.ToLower()))))
                        .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VSuppliersSchedulesPayment>> GetSchedulePaymentAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VSuppliersSchedulesPayments
                       .AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<SuppliersSchedulesPayment>> AddSchedulePaymentAsync(SuppliersSchedulesPayment data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId && x.CompanyId == user.CompanySessionId);

            var suffix = "-" + pro.ProjectCode.Substring(1, 2);

            data.SchedulePaymentCode = await new MaxCode().GetStandardCodeAsync("dbo.suppliers_schedules_payments", "schedule_payment_code",user.CompanySessionId ,"SP:", suffix);

            //var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            _context.SuppliersSchedulesPayments.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateSchedulePaymentAsync(SuppliersSchedulesPayment data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersSchedulesPayments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if(valid.ProjectId != data.ProjectId)
            {
                var pro = await _context.VDbliveProjects.FirstOrDefaultAsync(x => x.Id == data.ProjectId);

                var suffix = "-" + pro.ProjectCode.Substring(1, 2);

                data.SchedulePaymentCode = await new MaxCode().GetStandardCodeAsync("dbo.suppliers_schedules_payments", "schedule_payment_code", user.CompanySessionId,"SP:", suffix);
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeleteSchedulePaymentAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.SuppliersSchedulesPayments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("{id}/details")]
        public async Task<ActionResult<IEnumerable<SuppliersSchedulesPaymentsDetail>>> GetAllSchedulePaymentDetailAsync(int id)
        {
            return await _context.SuppliersSchedulesPaymentsDetails.
                Where(x => x.SchedulePaymentId == id && x.Status == true)
                .OrderBy(x => x.ScheduleDate)
                .ToListAsync();
        }

        [HttpGet("details/{id}")]
        public async Task<ActionResult<SuppliersSchedulesPaymentsDetail>> GetSchedulePaymentDetailAsync(int id)
        {
            var data = await _context.SuppliersSchedulesPaymentsDetails
                       .AsNoTracking()
                       .FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("exchange-rate-info")]
        public async Task<ActionResult<ExchangeRate>> GetSchedulePaymentExchangeAsync()
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ExchangeRates
                       .AsNoTracking()
                       .OrderByDescending(x => x.EffectiveDate)
                       .FirstOrDefaultAsync(x => x.Status == true && x.EffectiveDate < DateTime.Now.AddDays(1) && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("details/add")]
        public async Task<ActionResult<SuppliersSchedulesPaymentsDetail>> AddSchedulePaymentDetailAsync(SuppliersSchedulesPaymentsDetail data)
        {
            

            var _auth = new CustomUserIdentity(User);

            data.Status = true;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Type = "form";

            _context.SuppliersSchedulesPaymentsDetails.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("details/update")]
        public async Task<IActionResult> UpdateSchedulePaymentDetailAsync(SuppliersSchedulesPaymentsDetail data)
        {
            var valid = await _context.SuppliersSchedulesPaymentsDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.PvRef).IsModified = false;

            _context.Entry(data).Property(x => x.ExchangeRate).IsModified = false;

            _context.Entry(data).Property(x => x.PaidAmount).IsModified = false;

            _context.Entry(data).Property(x => x.PaidAt).IsModified = false;

            _context.Entry(data).Property(x => x.Type).IsModified = false;

            var _auth = new CustomUserIdentity(User);


            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                return BadRequest(ex.Message);
            }

            return NoContent();
        }

        [HttpDelete("details/{id}/delete")]
        public async Task<IActionResult> DeleteSchedulePaymentDetailAsync(int id)
        {
            var valid = await _context.SuppliersSchedulesPaymentsDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.Status == true);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("{id}/details/import")]
        public async Task<ActionResult<object>> ImportScheduleAsync(IFormFile file, int id)
        {
            bool valid = await _context.SuppliersSchedulesPayments.AnyAsync(x => x.Id == id && x.Status == true);

            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "Payment Schedule doesn't exists!", "400"));
            }

            int total_records = 0;

            DateTime created_at = DateTime.Now;

            Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            try
            {
                List<string> scheduleDateList = new List<string>();

                var scheduleDetailList = await _context.SuppliersSchedulesPaymentsDetails.Where(x => x.SchedulePaymentId == id && x.Status == true).ToListAsync();

                using (var stream = file.OpenReadStream())
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        reader.Read(); //ignore first row

                        using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                        {

                            while (reader.Read())
                            {
                                SuppliersSchedulesPaymentsDetail data = new SuppliersSchedulesPaymentsDetail();

                                if(reader.FieldCount > 3)
                                {
                                    return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 1).ToString() + " Invalid format!", "400"));
                                }

                                string scheduleDate = reader.GetDateTime(0).ToString("yyyy-MM-dd");

                                if (scheduleDateList.Contains(scheduleDate) || scheduleDetailList.Where(x => x.ScheduleDate?.ToString("yyyy-MM-dd") == scheduleDate).Count() > 0)
                                {
                                    return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 1).ToString() + " Schedule Date is already exists!", "400"));
                                }

                                scheduleDateList.Add(scheduleDate);

                                data.SchedulePaymentId = id;

                                data.ScheduleDate = reader.GetDateTime(0);

                                data.AmountKh = Convert.ToDecimal(reader.GetValue(1));

                                data.AmountUsd = Convert.ToDecimal(reader.GetValue(2));

                                data.Type = "import";

                                data.Status = true;

                                _context.SuppliersSchedulesPaymentsDetails.Add(data);

                                await _context.SaveChangesAsync();
                                total_records++;
                            }

                            ts.Complete();
                        }
                    }
                }
            }catch(Exception ex)
            {
                total_records = 0;
                return BadRequest(ex.Message);
            }

            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }
    }
}
