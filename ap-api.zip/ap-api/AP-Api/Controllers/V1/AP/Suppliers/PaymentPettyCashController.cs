﻿using DataAccess.DBcontext;
using DataAccess.dbcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Text;
using ExcelDataReader;
using System.Transactions;
using OneSignalApi.Model;
using System.IO;
using Org.BouncyCastle.Crypto;

namespace Web.Controllers.AP.Suppliers
{
    [Route("api/v1/payment-pettycash")]
    [ApiController]
    [Authorize]
    public class PaymentPettyCashController : ControllerBase
    {
        private readonly APContext _context;

        private readonly ManualDbContext _manualDbContext;

        public PaymentPettyCashController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<VPaymentPettyCash>>> GetPaymentPettyCash([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);
            filter.Status = filter.Status - 1;
            var list = new List<short>();
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                .ToList();
            }

            filter.TotalRecords = await _context.VPaymentPettyCashes
                           .Where(s => (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                                || s.ProjectShort.Contains(filter.Search)
                                || s.PvRef.Contains(filter.Search)
                                || s.SettlementCode.Contains(filter.Search)
                                || s.PayeeName.Contains(filter.Search)
                                ))
                           .CountAsync();

            var data = await _context.VPaymentPettyCashes
                           .Where(s => (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                                || s.ProjectShort.Contains(filter.Search)
                                || s.PvRef.Contains(filter.Search)
                                || s.SettlementCode.Contains(filter.Search)
                                || s.PayeeName.Contains(filter.Search)
                                ))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetPaymentPettyCashAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.PaymentPettyCashes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.payment_petty_cashes", data.Id, _auth.Id);
            wf.workflowModel.Data = data;
            return wf.workflowModel;
        }


        [HttpPost("add")]
        public async Task<ActionResult<PaymentPettyCash>> AddPaymentPettyCash(PaymentPettyCash data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

     
            data.Status = 1;
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.RecStatus = 0;

            if (isExistRef(data.PvRef, null))
            {
                return BadRequest(new ApiResponse("failed", "This pvRef already use!"));
            }

            data.CompanyId = user.CompanySessionId;

            _context.PaymentPettyCashes.Add(data);
            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_generate_payment_pretty_cash_detail] {0},{1}", data.Id, data.SettlementId);

                    ts.Complete();
                }
            }

            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            await _context.SaveChangesAsync();

            new WorkflowDetailModel()
                .WorkflowHistoryDraft("dbo.payment_petty_cashes", data.Id, _auth.Id);

            return data;
        }
        private string toPVRef(string code, string suffix)
        {
            code = code.Replace(suffix, "");
            return (Convert.ToInt32(code) + 1).ToString();
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdatePaymentPettyCash(PaymentPettyCash data)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.PaymentPettyCashes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id );

            if (valid == null)
            {
                return BadRequest();
            }

            if(isExistRef(data.PvRef, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This pvRef already use!"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;


            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_generate_payment_pretty_cash_detail] {0},{1}", data.Id, data.SettlementId);

                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return Ok();
        }

        private bool isExistRef(string pvRef, int? id)
        {
            return _context.PaymentPettyCashes.Any(cas => cas.Status == 1 && cas.PvRef == pvRef && (id == null || cas.Id != id));
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> DeletePaymentPettyCash(int id)
        {
            var _auth = new CustomUserIdentity(User);
            var user = await _context.Users.FindAsync(_auth.Id);
            var valid = await _context.PaymentPettyCashes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id );
            try
            {
                _context.PaymentPettyCashes.Remove(valid);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if(valid == null)
                {
                    return NoContent();
                }
                throw;
            }
            return Ok();
        }

        [HttpGet("{id}/detail")]
        public async Task<ActionResult<object>> GetPaymentPettyCashDetailAsync(int id)
        {
            return await _context.VPaymentPettyCashDetails
                .AsNoTracking()
                .Where(x => x.PaymentPrettyCashId == id)
                .ToListAsync();
        }

        [HttpGet("detail/{id}")]
        public async Task<ActionResult<object>> GetPaymentPettyCashDetailByIdAsync(int id)
        {
            var data = await _context.VPaymentPettyCashDetails
               .AsNoTracking()
               .FirstOrDefaultAsync(x => x.Id == id);

            if(data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPut("detail/update")]
        public async Task<ActionResult<object>> UpdatePaymentPettyCashDetailByIdAsync(PaymentPettyCashesDetail data)
        {
            var valid = await _context.PaymentPettyCashesDetails.FirstOrDefaultAsync(x => x.Id == data.Id && x.Status == true);

            if(valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Invalid data", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.PaymentDescription= data.PaymentDescription;

            await _context.SaveChangesAsync();

            return Ok();
        }
    }
}
