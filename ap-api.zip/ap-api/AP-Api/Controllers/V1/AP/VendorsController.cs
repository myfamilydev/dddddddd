﻿using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Text.RegularExpressions;
using System.Transactions;
using AP_Api.Helpers;
using System.IO;
using ExcelDataReader;
using System.Text;
using AP_Api.Models;
using OneSignalApi.Model;
using System.Diagnostics.Contracts;
using Polly;
using Google.Protobuf.Collections;
using Bogus.DataSets;
using DataAccess.LHDEntities;
using AP_Api.Librabies.Customize;
using MongoDB.Driver.Linq;
using Microsoft.AspNetCore.SignalR;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class VendorsController : ControllerBase
    {
        private readonly APContext _context;

        private CustomUserIdentity _auth;

        private readonly ManualDbContext _manualDbContext;

        public VendorsController(APContext context, ManualDbContext manualDbContext)
        {
            _context = context;
            _manualDbContext = manualDbContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetAllVendorAsync([FromQuery] PaginationFilter filter)
        {
            _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsInfos
                           //.Where(x => EF.Functions.Like(x.NameKh, $"%{filter.Search}%"))

                           .Where(s => (s.CompanyId == u.CompanySessionId) && (String.IsNullOrEmpty(filter.Search) ||
                            s.NameKh.Contains(filter.Search) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.NameEn.ToLower().Contains(filter.Search.ToLower()) ||
                            s.PhoneContract.ToLower().Contains(filter.Search.ToLower()) ||
                            s.PhoneNumberUpdate.ToLower().Contains(filter.Search.ToLower())))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VVendorsInfos
                           .Where(s => (s.CompanyId == u.CompanySessionId) && (String.IsNullOrEmpty(filter.Search) ||
                            s.NameKh.Contains(filter.Search) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.NameEn.ToLower().Contains(filter.Search.ToLower()) ||
                            s.PhoneContract.ToLower().Contains(filter.Search.ToLower()) ||
                            s.PhoneNumberUpdate.ToLower().Contains(filter.Search.ToLower())))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetAllVendors([FromQuery] FilterBy filter)
        {
            _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            return await _context.VVendors
                .AsNoTracking()
                .Where(s => (s.CompanyId == u.CompanySessionId) && (filter.Category == s.VendorCategory || String.IsNullOrEmpty(filter.Category)))
                .Select(x => new
                {
                    Id = x.Id,
                    VendorCode = x.VendorCode,
                    CreatedAt = x.CreatedAt,
                    NameEn = x.NameEn
                })
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetVendor(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsInfos.FirstOrDefaultAsync(x => (x.CompanyId == u.CompanySessionId) && x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            //var _auth = new CustomUserIdentity(User);
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors", data.Id, _auth.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("add")]
        public async Task<ActionResult<Vendor>> AddVendor(Vendor data)
        {
            try
            {
                var _auth = new CustomUserIdentity(User);

                var u = await _context.Users.FindAsync(_auth.Id);

                var year = DateTime.Now.Year.ToString().Substring(2, 2);

                var suffix = "/" + year;

                var getMax = await _context.Vendors.AsNoTracking().Where(x => (x.CompanyId == u.CompanySessionId) && x.VendorCode.EndsWith(suffix)).MaxAsync(x => x.VendorCode);

                if (getMax != null)
                {
                    data.VendorCode = "VID:" + (Convert.ToInt32(getMax.Substring(4, 4)) + 1).ToString("D4") + suffix;
                }
                else
                {
                    data.VendorCode = "VID:0001" + suffix;
                }

                var exist = await _context.Vendors.AsNoTracking().FirstOrDefaultAsync(x => x.NidNo.Trim() == data.NidNo.Trim() && x.CompanyId == u.CompanySessionId && x.VendorCategory == data.VendorCategory);

                if (exist != null)
                {
                    return BadRequest(new ApiResponse("failed", "NID No is already exists!", "400"));
                }

                //var _auth = new CustomUserIdentity(User);

                data.CreatedAt = DateTime.Now;

                data.CompanyId = u?.CompanySessionId;

                data.CreatedBy = _auth.Id;

                data.IsEditable = true;

                data.ApproveTime = 1;

                data.RecStatus = WorkflowStatusModel.APPROVED;

                _context.Vendors.Add(data);

                await _context.SaveChangesAsync();
                if (data.Id != null)
                {
                    _context.Database.ExecuteSqlRaw("exec dbo.sp_update_attachment_ref {0},{1}", data.AttachmentRefTemp, data.Id);
                    _context.Database.ExecuteSqlRaw(@"exec dbo.sp_edit_vendor_info {0}", data.Id); //Add History
                    new WorkflowDetailModel().WorkflowHistoryDraftNotSave("dbo.vendors", data.Id, _auth.Id);

                }

                return data;
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPut("update")]
        public async Task<IActionResult> UpdateVendor(Vendor data)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.Vendors.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == u.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            var exist = await _context.Vendors.FirstOrDefaultAsync(x => x.NidNo.Trim() == data.NidNo.Trim() && x.VendorCategory == data.VendorCategory && x.Id != data.Id && (x.CompanyId == u.CompanySessionId));

            if (exist != null)
            {
                return BadRequest(new ApiResponse("failed", "NID No is already exists!", "400"));
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.IsEditable).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            _context.Entry(data).Property(x => x.VendorCode).IsModified = false;



            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = u.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteVendorAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.vendors", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpPost("approve-time/update/{id}")]
        public async Task<IActionResult> approveTimeUpdate(int id)
        {
            var valid = await _context.Vendors.FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.UpdatedAt = DateTime.Now;

            valid.UpdatedBy = _auth.Id;

            valid.ApproveTime = 2;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPost("modify_edit_state/{state}/{id}")]
        public async Task<IActionResult> UpdateVendor(short state, int id)
        {
            var valid = await _context.Vendors.FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.UpdatedAt = DateTime.Now;

            valid.UpdatedBy = _auth.Id;

            valid.IsEditable = Convert.ToBoolean(state);

            valid.ApproveTime = (valid.ApproveTime ?? 1) + 1;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpGet("items")]
        public async Task<ActionResult<IEnumerable<VVendorsItem>>> GetVendorItems([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var u = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsItems
                           .Where(s => (s.CompanyId == u.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search) ||
                            s.ItemName.Contains(filter.Search) ||
                            s.ItemDescription.Contains(filter.Search) ||
                            s.ItemCode.ToLower().Contains(filter.Search.ToLower()) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountCode.Contains(filter.Search))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VVendorsItems
                          .Where(s => (s.CompanyId == u.CompanySessionId) && ((String.IsNullOrEmpty(filter.Search) ||
                            s.ItemName.Contains(filter.Search) ||
                            s.ItemDescription.Contains(filter.Search) ||
                            s.ItemCode.ToLower().Contains(filter.Search.ToLower()) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.AccountCode.Contains(filter.Search))))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("items/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetVendorItems(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsItems.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors_items", data.Id, _auth.Id);
            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }
        private string getVendorShort(string vendorCategory)
        {
            List<ClsCustomCategory> lst = new List<ClsCustomCategory>();
            lst.Add(new ClsCustomCategory {_name = "Sub-Contractor", _value = "Sub-Contractor", _short = "SC" });
            lst.Add(new ClsCustomCategory { _name = "Labor", _value = "Labor", _short = "LB" });
            var obj = lst.Find(x => x._value == vendorCategory);
            string CategoryShort = "";
            if (obj != null) CategoryShort = obj._short;
            return CategoryShort;   

        }
        [HttpPost("items/add")]
        public async Task<ActionResult<VendorsItem>> VendorItemsAdd(VendorsItem data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
            data.VendorShort = getVendorShort(data.VendorCategory);

            var getMax = await _context.VendorsItems.Where(x => (x.CompanyId == user.CompanySessionId) && x.ItemCode.StartsWith(data.VendorShort)).MaxAsync(x => x.ItemCode);
            //data.VendorShort = getVendorShort(data.VendorCategory);

            if (getMax != null)
            {
                data.ItemCode = data.VendorShort + ":" + (Convert.ToInt32(getMax.Substring(data.VendorShort.Length + 1, 5)) + 1).ToString("D5");
            }
            else
            {
                data.ItemCode = data.VendorShort + ":00001";
            }

            var valid = await _context.VendorsItems.AsNoTracking().FirstOrDefaultAsync(x => x.ItemName.ToLower().Trim() == data.ItemName.ToLower().Trim() && x.ChartAccountId == data.ChartAccountId && x.VendorCategory == data.VendorCategory);

            if (valid != null)
            {
                return BadRequest(new ApiResponse("failed", "Item Name is already exists!", "400"));
            }

            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.RecStatus = 0;

            data.IsActive = true;

            data.CompanyId = user.CompanySessionId;

            _context.VendorsItems.Add(data);

            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.vendors_items", data.Id, _auth.Id);
            return data;
        }

        [HttpPut("items/update")]
        public async Task<IActionResult> VendorItemsUpdate(VendorsItem data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            _context.Entry(data).Property(x => x.IsActive).IsModified = false;

            if (valid.VendorShort != data.VendorShort)
            {
                var getMax = await _context.VendorsItems.Where(x => x.CompanyId == user.CompanySessionId && x.ItemCode.EndsWith(data.VendorShort)).MaxAsync(x => x.ItemCode);

                if (getMax != null)
                {
                    data.ItemCode = data.VendorShort + ":" + (Convert.ToInt32(getMax.Substring(data.VendorShort.Length + 1, 5)) + 1).ToString("D5");
                }
                else
                {
                    data.ItemCode = data.VendorShort + ":00001";
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.ItemCode).IsModified = false;
            }

            var existValid = await _context.VendorsItems.AsNoTracking().FirstOrDefaultAsync(x => x.ItemName.ToLower().Trim() == data.ItemName.ToLower().Trim() && x.Id != data.Id);

            if (existValid != null)
            {
                return BadRequest(new ApiResponse("failed", "Item Name is already exists!", "400"));
            }

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.CompanyId = user.CompanySessionId;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("items/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteVendorItemAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.vendors_items", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("contracts")]
        public async Task<ActionResult<IEnumerable<VVendorContract>>> GetVendorContracts([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            filter.Status = filter.Status - 1;

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VVendorContracts
                           .Where(s => (s.IsTerminated == filter.Terminated) && (filter.Status == -1 || s.RecStatus == ((byte?)filter.Status)) && (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                            s.NameKh.Contains(filter.Search) ||
                            s.MasterNames.Contains(filter.Search) ||
                            s.ContractCode.Contains(filter.Search) ||
							s.Project.ToLower().Contains(filter.Search.ToLower()) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.NameEn.ToLower().Contains(filter.Search.ToLower()) ||
                            s.PhoneNumber.Contains(filter.Search) ||
                            s.Items.Contains(filter.Search) ||
                            s.StatusName.ToLower().Contains(filter.Search.ToLower())))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VVendorContracts
                           .Where(s => (s.IsTerminated == filter.Terminated) && (filter.Status == -1 || s.RecStatus == ((byte?)filter.Status)) && (s.CompanyId == user.CompanySessionId) && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                            s.NameKh.Contains(filter.Search) ||
                            s.MasterNames.Contains(filter.Search) ||
                            s.Project.ToLower().Contains(filter.Search.ToLower()) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.NameEn.ToLower().Contains(filter.Search.ToLower()) ||
                            s.PhoneNumber.Contains(filter.Search) ||
                            s.ContractCode.Contains(filter.Search) ||
                            s.Items.Contains(filter.Search) ||
                            s.StatusName.ToLower().Contains(filter.Search.ToLower())))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("contracts/basic")]
        public async Task<ActionResult<IEnumerable<VVendorContractBasic>>> GetVendorContractsBasic([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VVendorContractBasics
                    .Where(x => (x.CompanyId == user.CompanySessionId) && (x.ProId == filter.ProId) && x.VendorCategory == filter.Category)
                    .ToListAsync();
        }

        [HttpGet("contracts/basic/labor")]
        public async Task<ActionResult<IEnumerable<VVendorContractBasic>>> GetVendorContractsBasicLabor()
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VVendorContractBasics.Where(x => (x.CompanyId == user.CompanySessionId) && x.VendorCategory == "Labor").ToListAsync();
        }

        [HttpGet("contracts/basic/sub-contractor")]
        public async Task<ActionResult<IEnumerable<VVendorContractBasic>>> GetVendorContractsSubBasic()
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VVendorContractBasics.Where(x => (x.CompanyId == user.CompanySessionId) && x.VendorCategory == "Sub-Contractor").ToListAsync();
        }

        [HttpGet("contracts/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetVendorContracts(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorContracts.FirstOrDefaultAsync(x => (x.CompanyId == user.CompanySessionId) && x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            //var _auth = new CustomUserIdentity(User);
            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors_contracts", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("contracts/add")]
        public async Task<ActionResult<VendorsContract>> contractsAddCompany(VendorsContract data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            if (isExistContractPo(user.CompanySessionId, data, null))
            {
                return BadRequest(new ApiResponse("failed", "This contract PO is already use!"));
            }

            var suffix = "/" + year + "-" + project;

            var getMax = await _context.VendorsContracts.Where(x => (x.CompanyId == user.CompanySessionId) && x.ContractCode.EndsWith(suffix)).MaxAsync(x => x.ContractCode);

            if (getMax != null)
            {
                data.ContractCode = "VC:" + (Convert.ToInt32(getMax.Substring(3, 4)) + 1).ToString("D4") + suffix;
            }
            else
            {
                data.ContractCode = "VC:0001" + suffix;
            }

            //var _auth = new CustomUserIdentity(User);

            data.Locked = false;

            if (data.VendorCategory == "Labor")
            {
                var labor = await _context.LaborTermPays.FirstOrDefaultAsync(x => x.ProjectId == data.ProId);

                if (labor == null)
                {
                    return BadRequest(new ApiResponse("failed", "Invalid term pay. Please check term pays setting", "400"));
                }

                data.TermPayment = labor.TermPay;
            }

            data.CompanyId = user.CompanySessionId;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.RecStatus = 0;

            _context.VendorsContracts.Add(data);

            await _context.SaveChangesAsync();

            new WorkflowDetailModel().WorkflowHistoryDraft("dbo.vendors_contracts", data.Id, _auth.Id);

            return data;
        }

        private bool isExistContractPo(int? companySessionId, VendorsContract contract, int? id)
        {
            return _context.VendorsContracts.Any(cas => cas.CompanyId == companySessionId && cas.VendorCategory == contract.VendorCategory && cas.ContractPurchaseId == contract.ContractPurchaseId && (id == null || cas.Id != id) && cas.RecStatus != 5);
        }

        [HttpPut("contracts/update")]
        public async Task<IActionResult> contractsUpdateCompany(VendorsContract data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id not found!", "400"));
            }

            if (isExistContractPo(user.CompanySessionId, data, data.Id))
            {
                return BadRequest(new ApiResponse("failed", "This contract PO is already use!"));
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            _context.Entry(data).Property(x => x.IsCovered).IsModified = false;

            _context.Entry(data).Property(x => x.IsFinal).IsModified = false;

            _context.Entry(data).Property(x => x.CostTypeId).IsModified = false;

            _context.Entry(data).Property(x => x.IsTerminated).IsModified = false;

            _context.Entry(data).Property(x => x.IsNotMatch).IsModified = false;

            _context.Entry(data).Property(x => x.Items).IsModified = false;

            _context.Entry(data).Property(x => x.TermPayment).IsModified = false;
			_context.Entry(data).Property(x => x.Locked).IsModified = false;

			// auto contract
			if (valid.ProId != data.ProId)
            {
                var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);

                var year = DateTime.Now.Year.ToString().Substring(2, 2);
                var suffix = "/" + year + "-" + project;

                var getMax = await _context.VendorsContracts.Where(x => x.CompanyId == user.CompanySessionId && x.ContractCode.EndsWith(suffix)).MaxAsync(x => x.ContractCode);

                if (getMax != null)
                {
                    data.ContractCode = "VC:" + (Convert.ToInt32(getMax.Substring(3, 4)) + 1).ToString("D4") + suffix;
                }
                else
                {
                    data.ContractCode = "VC:0001" + suffix;
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.ContractCode).IsModified = false;
            }

            if (data.VendorCategory == "Labor")
            {
                var labor = await _context.LaborTermPays.FirstOrDefaultAsync(x => x.ProjectId == data.ProId);

                if (labor == null)
                {
                    return BadRequest(new ApiResponse("failed", "Invalid term pay. Please check term pays setting", "400"));
                }

                data.TermPayment = labor.TermPay;
            }

            data.UpdatedAt = DateTime.Now;

            data.CompanyId = user.CompanySessionId;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteContractAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.vendors_contracts", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpPut("contracts/cost_type/update")]
        public async Task<IActionResult> ContractUpdateCostType(VendorsContract data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id not found!", "400"));
            }


            _context.Entry(valid).State = EntityState.Modified;

            valid.CostTypeId = data.CostTypeId;

            valid.Reason = data.Reason;

            valid.UpdatedAt = DateTime.Now;

            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpGet("items/basic")]
        public async Task<ActionResult<IEnumerable<Object>>> GetVendorContractsItemsBasic([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VendorsItems
                           .AsNoTracking()
                           .Where(x => x.CompanyId == user.CompanySessionId && x.IsActive == true && (filter.Category == x.VendorCategory || String.IsNullOrEmpty(filter.Category)))
                           .OrderByDescending(x => x.CreatedAt)
                           .Select(x => new
                           {
                               id = x.Id,
                               itemName = x.ItemName,
                               itemCode = x.ItemCode
                           })
                           .ToListAsync();
        }

        [HttpGet("{vendorId}/items/basic")]
        public async Task<ActionResult<IEnumerable<object>>> GetVendorItemsBasic(int vendorId)
        {
            return _manualDbContext.ExecuteQuery($"exec [dbo].[sp_get_lab_items_by_vendor] {vendorId}")
                      .AsEnumerable()
                      .ToList();
        }

        [HttpGet("contracts/{contract_id}/items")]
        public async Task<ActionResult<IEnumerable<VVendorsContractItem>>> GetVendorContractsItems(int contract_id)
        {
            return await _context.VVendorsContractItems
                           .Where(s => s.VendorContractId == contract_id)
                           .OrderBy(x => x.ItemName)
                           .ToListAsync();
        }



        [HttpGet("contracts/items/{id}")]
        public async Task<ActionResult<VVendorsContractItem>> GetVendorContractsItemById(int id)
        {
            var data = await _context.VVendorsContractItems.FirstOrDefaultAsync(x => x.Id == id);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("contracts/item/add")]
        public async Task<ActionResult<VendorsContractsItem>> contractsAddItems(VendorsContractsItem data)
        {
            var valid = await _context.VendorsContractsItems.FirstOrDefaultAsync(x => x.ItemId == data.ItemId && x.VendorContractId == data.VendorContractId);

            if (valid != null)
            {

                return BadRequest(new ApiResponse("failed", " This Item already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            data.Locked = false;

            VendorsContractsPrice vendorsContractsPrice = new VendorsContractsPrice();

            vendorsContractsPrice.VendorContractId = data.VendorContractId;

            vendorsContractsPrice.Status = 1;
            vendorsContractsPrice.ItemId = data.ItemId;
            vendorsContractsPrice.CreatedAt = DateTime.Now;
            vendorsContractsPrice.CreatedBy = _auth?.Id;
            vendorsContractsPrice.Locked = false;

            VendorsContractsPaymentTerm vendorsContractsPaymentTerm = new VendorsContractsPaymentTerm();
            vendorsContractsPaymentTerm.VendorContractId = data.VendorContractId;
            vendorsContractsPaymentTerm.Status = 1;
            vendorsContractsPaymentTerm.ItemId = data.ItemId;
            vendorsContractsPaymentTerm.AllowRequestNumHouse = false;
            vendorsContractsPaymentTerm.CreatedAt = DateTime.Now;
            vendorsContractsPaymentTerm.CreatedBy = _auth?.Id;
            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    _context.VendorsContractsItems.Add(data);

                    await _context.SaveChangesAsync();

                    vendorsContractsPrice.ContractItemId = data.Id;
                    vendorsContractsPaymentTerm.ContractItemId = data.Id;
                    _context.VendorsContractsPrices.Add(vendorsContractsPrice);
                    _context.VendorsContractsPaymentTerms.Add(vendorsContractsPaymentTerm);

                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_check_require_reason_house_all_item] {0}", data.VendorContractId);
                    ts.Complete();
                }
                _context.Database.ExecuteSqlRaw("exec [dbo].[sp_sync_item_to_contract] {0}", data.VendorContractId);
            }
            catch
            {
                return BadRequest();
            }

            return data;
        }

        [HttpDelete("contracts/item/{id}/delete")]
        public async Task<IActionResult> ContractItemDelete(int id)
        {
            var data_delete = await _context.VendorsContractsItems.FirstOrDefaultAsync(x => x.Id == id);
            var dataVendorContractPrice = await _context.VendorsContractsPrices.FirstOrDefaultAsync(x => x.ContractItemId == id);
            var dataItemPaymentTerm = await _context.VendorsContractsPaymentTerms.FirstOrDefaultAsync(x => x.ContractItemId == id);
            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    _context.VendorsContractsItems.Remove(data_delete);
                    _context.VendorsContractsPrices.Remove(dataVendorContractPrice);
                    _context.VendorsContractsPaymentTerms.Remove(dataItemPaymentTerm);


                    await _context.SaveChangesAsync();

					_context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_check_require_reason_house_all_item] {0}", data_delete.VendorContractId);

					_context.Database.ExecuteSqlRaw("exec [dbo].[sp_sync_item_to_contract] {0}", data_delete.VendorContractId);

					ts.Complete();
                }
                

            }
            catch
            {
                return NoContent();
            }

            return Ok();

        }

        [HttpGet("contracts/{contract_id}/master")]
        public async Task<ActionResult<IEnumerable<VVendorsContractsMaster>>> GetVendorContractsMaster(int contract_id)
        {
            return await _context.VVendorsContractsMasters
                           .Where(s => s.VendorContractId == contract_id)
                           .OrderBy(x => x.HouseNumber)
                           .ToListAsync();
        }

        [HttpGet("contracts/{contract_id}/master/basic")]
        public async Task<ActionResult<IEnumerable<MVendorHouseByContract>>> GetVendorContractsMasterBasic(int contract_id)
        {
            return await _manualDbContext.MVendorHouseByContracts
                           .FromSqlRaw("exec [dbo].[sp_get_houses_by_contract] {0}", contract_id)
                           .ToListAsync();
        }



        [HttpGet("contracts/{contract_id}/master/redo")]
        public async Task<ActionResult<IEnumerable<VVendorsContractsMaster>>> GetVendorContractsMasterRedo(int contract_id)
        {
            return await _context.VVendorsContractsMasters
                           .Where(s => s.VendorContractId == contract_id && s.HouseRedesignId != null)
                           .OrderBy(x => x.HouseNumber)
                           .ToListAsync();
        }

        [HttpGet("settlement/{id}/houses")]
        public async Task<ActionResult<IEnumerable<VendorContractHouse>>> GetVendorContractHousesBySettlement(int id)
        {
            return await _manualDbContext.VendorContractHouses
                           .FromSqlRaw("exec [dbo].[sp_get_contract_house] {0}", id)
                           .ToListAsync();
        }
        //check house when sumary 

        [HttpGet("settlement/{id}/houses/physical")]
        public async Task<ActionResult<IEnumerable<VendorContractHouse>>> GetVendorContractHousesPhysical(int id)
        {
            return await _manualDbContext.VendorContractHouses
                           .FromSqlRaw("exec [dbo].[sp_get_contract_house_physical] {0}", id)
                           .ToListAsync();
        }


        [HttpGet("contracts/master/{id}")]
        public async Task<ActionResult<VVendorsContractsMaster>> GetVendorContractsMasterById(int id)
        {
            var data = await _context.VVendorsContractsMasters.FirstOrDefaultAsync(x => x.Id == id);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("contracts/master/add")]
        public async Task<ActionResult<VendorsContractsMaster>> contractsAddmaster(VendorsContractsMaster data)
        {
            var contract = await _context.VVendorContracts.FirstOrDefaultAsync(x => x.Id == data.VendorContractId);

            if (contract == null)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!", "400"));
            }
            if (contract.CostTypeId == 1)
            {
                var valid = await _context.VHousesLists.AnyAsync(x => x.Id == data.HouseId);

                if (!valid)
                {
                    return BadRequest(new ApiResponse("failed", "House Id not found!", "400"));
                }

                valid = await _context.VendorsContractsMasters.AnyAsync(x => x.HouseId == data.HouseId && x.VendorContractId == data.VendorContractId);

                if (valid)
                {
                    var vHouse = await _context.VHousesLists.FirstOrDefaultAsync(x => x.Id == data.HouseId);

                    return BadRequest(new ApiResponse("failed", "House Number " + vHouse?.Number + " already exists!", "400"));
                }
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.RequireReason = false;

            data.Locked = false;

            _context.VendorsContractsMasters.Add(data);

            await _context.SaveChangesAsync();

            _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_check_require_reason_house] {0},{1}", data.VendorContractId, data.HouseId);

            return data;
        }

        [HttpPost("contracts/{id}/master/import")]
        public async Task<ActionResult<object>> ImportMasterAsync(IFormFile file, int id)
        {
            var _auth = new CustomUserIdentity(User);

            var contract = await _context.VendorsContracts.FirstOrDefaultAsync(x => x.Id == id);

            if (contract == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id doesn't exists!", "400"));
            }

            int total_records = 0;

            DateTime created_at = DateTime.Now;

            Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            try
            {
                var houseList = await _context.VHousesLists.Where(x => contract.ProId == x.ProjectId).ToListAsync();

                using (var stream = file.OpenReadStream())
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        reader.Read();

                        using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                        {

                            while (reader.Read())
                            {
                                VendorsContractsMaster data = new VendorsContractsMaster();

                                data.VendorContractId = id;

                                data.CreatedAt = DateTime.Now;

                                data.CreatedBy = _auth.Id;

                                data.Locked = false;

                                if (reader.FieldCount > 2)
                                {
                                    return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 1).ToString() + " Invalid format!", "400"));
                                }

                                if (contract.CostTypeId == 1)
                                {

                                    var house = houseList.FirstOrDefault(x => x.Number.ToLower().Trim() == reader.GetValue(0).ToString().ToLower().Trim());

                                    if (house == null)
                                    {
                                        return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 1).ToString() + " Invalid house!", "400"));
                                    }

                                    bool valid = await _context.VendorsContractsMasters.AsNoTracking().AnyAsync(x => x.VendorContractId == id && house.Id == x.HouseId);

                                    if (valid)
                                    {

                                        return BadRequest(new ApiResponse("failed", "Row #" + (total_records + 1).ToString() + " House Number " + house?.Number + " already exists!", "400"));
                                    }

                                    data.HouseId = house.Id;
                                }
                                else
                                {
                                    data.CostName = reader.GetValue(0).ToString();
                                }

                                _context.VendorsContractsMasters.Add(data);

                                await _context.SaveChangesAsync();

                                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_check_require_reason_house] {0},{1}", id, data.HouseId);

                                total_records++;
                            }

                            ts.Complete();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                total_records = 0;
                return BadRequest(ex.Message);
            }

            return new { Result = total_records.ToString() + " record(s) have been uploaded successfully!" };
        }

        [HttpPost("contracts/master/redo/add")]
        public async Task<ActionResult<VendorsContractsMaster>> contractsAddmasterRedo(VendorsContractsMaster data)
        {
            var valid = await _context.VHousesLists.AnyAsync(x => x.Id == data.HouseRedesignId);

            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "House Id not found!", "400"));
            }

            valid = await _context.VVendorContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.VendorsContractsMasters.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/master/update")]
        public async Task<ActionResult<VendorsContractsMaster>> contractsUpdatemaster(VendorsContractsMaster data)
        {
            var ContractValid = await _context.VVendorContracts.FirstOrDefaultAsync(x => x.Id == data.VendorContractId);

            if (ContractValid == null)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!", "400"));
            }

            var dataValid = await _context.VendorsContractsMasters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (ContractValid.CostTypeId == 1)
            {

                var valid = await _context.VHousesLists.AnyAsync(x => x.Id == data.HouseId);

                if (!valid)
                {
                    return BadRequest(new ApiResponse("failed", "House Id not found!", "400"));
                }

                var exist = await _context.VendorsContractsMasters.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.VendorContractId == data.VendorContractId);


                if (exist != null && dataValid != null && exist.Id != dataValid?.Id)
                {
                    var vHouse = await _context.VHousesLists.FirstOrDefaultAsync(x => x.Id == data.HouseId);

                    return BadRequest(new ApiResponse("failed", "House Number " + vHouse?.Number + " already exists!", "400"));
                }
            }

            if (dataValid == null)
            {
                return BadRequest();
            }

            data.Id = dataValid.Id;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

			_context.Entry(data).Property(x => x.Locked).IsModified = false;
			try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("contracts/master/redo/update")]
        public async Task<ActionResult<VendorsContractsMaster>> contractsUpdateMasterRedo(VendorsContractsMaster data)
        {
            var valid = await _context.VHousesLists.AnyAsync(x => x.Id == data.HouseRedesignId);

            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "House Id not found!", "400"));
            }

            valid = await _context.VVendorContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!", "400"));
            }

            var dataValid = await _context.VendorsContractsMasters.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);


            if (dataValid == null)
            {
                return BadRequest();
            }

            data.Id = dataValid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;


            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/master/{id}/delete")]
        [Obsolete]
        public async Task<IActionResult> CarItemDelete(int id)
        {
            var data_delete = await _context.VendorsContractsMasters.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.VendorsContractsMasters.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/{contract_id}/price")]
        public async Task<ActionResult<IEnumerable<VVendorsContractsPricing>>> GetVendorContractsPrice(int contract_id)
        {
            return await _context.VVendorsContractsPricings
                           .Where(s => s.VendorContractId == contract_id)
                           .OrderByDescending(x => x.Id)
                           .ToListAsync();
        }

        [HttpGet("contracts/price/{id}")]
        public async Task<ActionResult<VVendorsContractsPricing>> GetVendorContractsPriceById(int id)
        {
            var data = await _context.VVendorsContractsPricings
                           .FirstOrDefaultAsync(s => s.Id == id && s.Status == 1);
            if (data == null)
            {
                return NoContent();
            }

            return data;

        }

        [HttpPost("contracts/price/add")]
        public async Task<ActionResult<VendorsContractsPrice>> contractsAddmaster(VendorsContractsPrice data)
        {
            if (data.ValidDateUntil < DateTime.Now && data.ValidDateUntil != null)
            {
                return BadRequest(new ApiResponse("failed", "Valid date is expired!", "400"));
            }

            var valid = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);
            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id not found!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            data.Locked = false;

            _context.VendorsContractsPrices.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/price/update")]
        public async Task<ActionResult<VendorsContractsPrice>> contractsUpdatemaster(VendorsContractsPrice data)
        {
            if (data.ValidDateUntil < DateTime.Now && data.ValidDateUntil != null)
            {
                return BadRequest(new ApiResponse("failed", "Valid date is expired!", "400"));
            }

            var valid = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);
            if (!valid)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id not found!", "400"));
            }

            var dataValid = await _context.VendorsContractsPrices.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (dataValid == null)
            {
                return BadRequest();
            }

            var _auth = new CustomUserIdentity(User);

            data.Id = dataValid.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
			_context.Entry(data).Property(x => x.Locked).IsModified = false;

			try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent(); ;
        }

        [HttpDelete("contracts/price/delete")]
        [Obsolete]
        public async Task<IActionResult> contractsDeletePrice(DeleteModel data)
        {
            var data_delete = await _context.VendorsContractsPrices.FirstOrDefaultAsync(x => x.Id == data.Id);

            try
            {
                var items = await _context.VendorsContractsPriceItems.Where(x => x.ContractPriceId == data.Id).ToListAsync();

                _context.VendorsContractsPriceItems.RemoveRange(items);

                _context.VendorsContractsPrices.Remove(data_delete);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/price/{vendorContractId}/items")]
        public async Task<ActionResult<IEnumerable<VVendorsContractsPriceItem>>> GetVendorContractsPriceItem(int vendorContractId)
        {
            return await _context.VVendorsContractsPriceItems
                           .Where(s => s.VendorContractId == vendorContractId)
                           .OrderByDescending(x => x.Id)
                           .ToListAsync();
        }

        [HttpGet("contracts/price/item/{id}")]
        public async Task<ActionResult<VendorsContractsPriceItem>> GetVendorContractsPriceItemById(int id)
        {
            var data = await _context.VendorsContractsPriceItems.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;

        }

        [HttpPost("contracts/price/item/add")]
        public async Task<ActionResult<VendorsContractsPriceItem>> contractsAdditem(VendorsContractsPriceItem data)
        {
            var validContract = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!validContract)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id is not found!", "400"));
            }

            var check = await _context.VendorsContractsPrices.FirstOrDefaultAsync(x => x.Id == data.ContractPriceId);

            if (check == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Price ID is not found!", "400"));
            }
            else
            {
                if (check.ValidDateUntil < DateTime.Now)
                {
                    return BadRequest(new ApiResponse("failed", "Contract Price valid date is expired!", "400"));
                }

                if (check.Status == 0)
                {
                    return BadRequest(new ApiResponse("failed", "Contract Price status is inactive!", "400"));
                }
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.VendorsContractsPriceItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/price/item/update")]
        public async Task<IActionResult> contractsUpdateItem(VendorsContractsPriceItem data)
        {
            var validContract = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!validContract)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id is not found!", "400"));
            }

            var check = await _context.VendorsContractsPrices.FirstOrDefaultAsync(x => x.Id == data.ContractPriceId);

            if (check == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Price is not found!", "400"));
            }
            else
            {
                if (check.ValidDateUntil < DateTime.Now)
                {
                    return BadRequest(new ApiResponse("failed", "Contract Price valid date is expired!", "400"));
                }

                if (check.Status == 0)
                {
                    return BadRequest(new ApiResponse("failed", "Contract Price status is inactive!", "400"));
                }
            }

            var valid = await _context.VendorsContractsPriceItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/price/item/{id}/delete")]
        public async Task<IActionResult> contractsDeletePriceItem(int id)
        {
            var data_delete = await _context.VendorsContractsPriceItems.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.VendorsContractsPriceItems.Remove(data_delete);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/payment-term/{vendorContractId}/items")]
        public async Task<ActionResult<IEnumerable<VendorsContractsPaymentTermsItem>>> GetVendorContractsPaymentTermItem(int vendorContractId)
        {
            return await _context.VendorsContractsPaymentTermsItems
                           .Where(s => s.VendorContractId == vendorContractId)
                           .OrderBy(x => x.Phase)
                           .ToListAsync();
        }

        [HttpGet("contracts/payment-term/item/{id}")]
        public async Task<ActionResult<VendorsContractsPaymentTermsItem>> GetVendorContractsPaymentTermItemById(int id)
        {
            var data = await _context.VendorsContractsPaymentTermsItems.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;

        }

        [HttpPost("contracts/payment-term/item/add")]
        public async Task<ActionResult<VendorsContractsPaymentTermsItem>> contractsAddPaymentTermItem(VendorsContractsPaymentTermsItem data)
        {
            var validContract = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!validContract)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id is not found!", "400"));
            }

            var check = await _context.VendorsContractsPaymentTerms.FirstOrDefaultAsync(x => x.Id == data.ContractPaymentTermId);

            if (check == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Payment Term is not found!", "400"));
            }


            var itemList = _context.VendorsContractsPaymentTermsItems.Where(x => x.ContractPaymentTermId == data.ContractPaymentTermId);
            var getMax = await itemList.MaxAsync(x => x.Phase);
            var totalPerc = await itemList.SumAsync(x => x.Percentage);

            if (getMax != null)
            {
                data.Phase = (Convert.ToInt32(getMax) + 1).ToString();
            }
            else
            {
                data.Phase = "1";
            }

            if (totalPerc != null && (totalPerc + data.Percentage) > 100)
            {
                return BadRequest(new ApiResponse("failed", "Percent is max 100%!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.VendorsContractsPaymentTermsItems.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/payment-term/item/update")]
        public async Task<IActionResult> contractsUpdatePaymentTermItem(VendorsContractsPaymentTermsItem data)
        {
            var validContract = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!validContract)
            {
                return BadRequest(new ApiResponse("failed", "Contract Id is not found!", "400"));
            }

            var check = await _context.VendorsContractsPaymentTerms.FirstOrDefaultAsync(x => x.Id == data.ContractPaymentTermId);

            if (check == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Payment Term is not found!", "400"));
            }

            var valid = await _context.VendorsContractsPaymentTermsItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            var itemList = _context.VendorsContractsPaymentTermsItems.Where(x => x.ContractPaymentTermId == data.ContractPaymentTermId && x.Id != data.Id);
            var totalPerc = await itemList.SumAsync(x => x.Percentage);

            if (totalPerc != null && (totalPerc + data.Percentage) > 100)
            {
                return BadRequest(new ApiResponse("failed", "Percent is max 100%!", "400"));
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/payment-term/item/{id}/delete")]
        public async Task<IActionResult> contractsPaymentTermItemDelete(int id)
        {
            var data_delete = await _context.VendorsContractsPaymentTermsItems.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.VendorsContractsPaymentTermsItems.Remove(data_delete);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/{contract_id}/payment-terms")]
        public async Task<ActionResult<IEnumerable<VVendorsContractsPaymentTerm>>> GetVendorContractsPaymentTerm(int contract_id)
        {

            return await _context.VVendorsContractsPaymentTerms
                           .Where(s => s.VendorContractId == contract_id)
                           .OrderByDescending(x => x.Id)
                           .ToListAsync();
        }

        [HttpGet("contracts/payment-term/{id}")]
        public async Task<ActionResult<VVendorsContractsPaymentTerm>> GetVendorContractsPaymentTermById(int id)
        {
            var data = await _context.VVendorsContractsPaymentTerms.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;

        }

        [HttpPost("contracts/payment-term/add")]
        public async Task<ActionResult<VendorsContractsPaymentTerm>> contractsPaymentTermAdd(VendorsContractsPaymentTerm data)
        {
            var check = await _context.VendorsContractsPaymentTerms.FirstOrDefaultAsync(x => x.ItemId == data.ItemId && x.VendorContractId == data.VendorContractId && x.Status == 1);

            if (check != null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Payment is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.VendorsContractsPaymentTerms.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/payment-term/update")]
        public async Task<IActionResult> contractsPaymentTermUpdate(VendorsContractsPaymentTerm data)
        {

            var valid = await _context.VendorsContractsPaymentTerms.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Payment term is not found!", "400"));
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.ContractItemId).IsModified = false;
            _context.Entry(data).Property(x => x.ItemId).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("contracts/payment-term/update/allow-per-time")]
        public async Task<IActionResult> contractsPaymentTermUpdateAsync(VendorsContractsPaymentTerm data)
        {

            var valid = await _context.VendorsContractsPaymentTerms.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Payment term is not found!", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            try
            {


                //if (data?.AllowRequestNumHouse == true && valid.AllowRequestNumHouse == false)
                //{
                //    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_refresh_vendor_contract_payment_term] {0}", data.Id);
                //}

                //if (data?.AllowRequestNumHouse == false && valid.AllowRequestNumHouse == true)
                //{
                //    var vcp = await _context.VendorsContractsPaymentTermsItems
                //              .AsNoTracking()
                //              .Where(x => x.ContractPaymentTermId == data.Id).ToListAsync();

                //    if (vcp != null && vcp?.Count() > 0)
                //    {
                //        _context.VendorsContractsPaymentTermsItems.RemoveRange(vcp);
                //    }

                //}

                valid.AllowRequestNumHouse = false;

                valid.MinSettleHouse = data.MinSettleHouse;

                await _context.SaveChangesAsync();

                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/payment-term/delete")]
        [Obsolete]
        public async Task<IActionResult> contractsPaymentTermDelete(DeleteModel data)
        {
            var data_delete = await _context.VendorsContractsPaymentTerms.FirstOrDefaultAsync(x => x.Id == data.Id);

            try
            {
                var items = await _context.VendorsContractsPaymentTermsItems.Where(x => x.ContractPaymentTermId == data.Id).ToListAsync();

                _context.VendorsContractsPaymentTermsItems.RemoveRange(items);

                _context.VendorsContractsPaymentTerms.Remove(data_delete);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/{contract_id}/settlement-info")]
        public async Task<ActionResult<IEnumerable<object>>> GetVendorContractsSettlementInfo(int contract_id, [FromQuery] PaginationFilter filter)
        {
            var data = await _context.VendorsContractsSettlementInfos
                           .Where(s => s.VendorContractId == contract_id)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VendorsContractsSettlementInfos
                           .Where(s => s.VendorContractId == contract_id)
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpPost("contracts/settlement-info/add")]
        public async Task<ActionResult<VendorsContractsSettlementInfo>> contractsSettlementInfoAdd(VendorsContractsSettlementInfo data)
        {
            var check_contract = await _context.VendorsContracts.AnyAsync(x => x.Id == data.VendorContractId);

            if (!check_contract)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract ID is not found!", "400"));
            }

            var check = await _context.VendorsContractsSettlementInfos.FirstOrDefaultAsync(x => x.VendorContractId == data.VendorContractId && x.Status == 1);

            if (check != null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Settlement Info is already exists!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;

            _context.VendorsContractsSettlementInfos.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("contracts/settlement-info/update")]
        public async Task<IActionResult> contractsSettlementInfoUpdate(VendorsContractsSettlementInfo data)
        {

            var valid = await _context.VendorsContractsSettlementInfos.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Settlement Info is not found!", "400"));
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("contracts/settlement-info/delete")]
        [Obsolete]
        public async Task<IActionResult> contractsSettlementInfoDelete(DeleteModel data)
        {
            var data_delete = await _context.VendorsContractsSettlementInfos.FirstOrDefaultAsync(x => x.Id == data.Id);

            try
            {
                _context.VendorsContractsSettlementInfos.Remove(data_delete);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data_delete == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("contracts/terminate")]
        public async Task<ActionResult<IEnumerable<VVendorsContractsTermination>>> GetVendorContractsTerminate([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            filter.Status = filter.Status - 1;

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VVendorsContractsTerminations
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (filter.Status == -1 || s.RecStatus == ((byte?)filter.Status)) && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                            s.TerminateReason.Contains(filter.Search) ||
                            s.ProjectShort.ToLower().Contains(filter.Search.ToLower()) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.ContractTerminateCode.ToLower().Contains(filter.Search.ToLower()) ||
                            s.ContractCode.Contains(filter.Search)))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VVendorsContractsTerminations
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (filter.Status == -1 || s.RecStatus == ((byte?)filter.Status)) && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                            s.TerminateReason.Contains(filter.Search) ||
                            s.ProjectShort.ToLower().Contains(filter.Search.ToLower()) ||
                            s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                            s.ContractTerminateCode.ToLower().Contains(filter.Search.ToLower()) ||
                            s.ContractCode.Contains(filter.Search)))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("contracts/terminate/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetVendorContractsTerminate(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsContractsTerminations.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors_contracts_terminations", data.Id, _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("contracts/terminate/add")]
        public async Task<ActionResult<VendorsContractsTermination>> contractsTerminateAdd(VendorsContractsTermination data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            var suffix = "/" + year + "-" + project;

            var getMax = await _context.VendorsContractsTerminations.Where(x => x.CompanyId == user.CompanySessionId && x.ContractTerminateCode.EndsWith(suffix)).MaxAsync(x => x.ContractTerminateCode);

            if (getMax != null)
            {
                data.ContractTerminateCode = "VCT:" + (Convert.ToInt32(getMax.Substring(4, 4)) + 1).ToString("D4") + suffix;
            }
            else
            {
                data.ContractTerminateCode = "VCT:0001" + suffix;
            }

            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CreatedBy = 0;

            data.RecStatus = 0;

            data.CompanyId = user.CompanySessionId;

            _context.VendorsContractsTerminations.Add(data);

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_contract_house_sub_to_terminate_all] {0}", data.Id);

                    new WorkflowDetailModel().WorkflowHistoryDraft("dbo.vendors_contracts_terminations", data.Id, _auth.Id);
                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }

            return data;
        }

        [HttpPut("contracts/terminate/update")]
        public async Task<IActionResult> contractsTerminateUpdate(VendorsContractsTermination data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsContractsTerminations.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            var contractId = valid.VendorContractId;

            // auto contract
            var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);
            var suffix = "/" + year + "-" + project;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;

            if (data.ProId != valid.ProId)
            {
                var getMax = await _context.VendorsContractsTerminations.Where(x => x.CompanyId == user.CompanySessionId && x.ContractTerminateCode.EndsWith(suffix)).MaxAsync(x => x.ContractTerminateCode);

                if (getMax != null)
                {
                    data.ContractTerminateCode = "VCT:" + (Convert.ToInt32(getMax.Substring(4, 4)) + 1).ToString("D4") + suffix;
                }
                else
                {
                    data.ContractTerminateCode = "VCT:0001" + suffix;
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.ContractTerminateCode).IsModified = false;
            }

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            //data.CompanyId = user.CompanySessionId;

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    if (contractId != data.VendorContractId)
                    {
                        _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_contract_house_sub_to_terminate_all] {0}", data.Id);
                    }

                    ts.Complete();
                }
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        


        [HttpGet("received-documents")]
        public async Task<ActionResult<IEnumerable<VReceivedDocument>>> ReceivedDocument([FromQuery] PaginationFilter filter)
        {
         
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VReceivedDocuments
                           .Where(s => (
                           filter.StartDate == null || s.ReceivedDate >= filter.StartDate) 
                           && (filter.EndDate == null || s.ReceivedDate <= filter.EndDate) 
                           &&( s.CompanyId == user.CompanySessionId)
                           &&(list.Contains((short)s.ProId) || filter.ProId == s.ProId)
                           && (s.ReceivedStatus == filter.ReceivedStatus)
                           && (String.IsNullOrEmpty(filter.Search)
                          
                           || s.VendorName.ToLower().Contains(filter.Search.ToLower()) 
                           ||s.DocumentCode.ToLower().Contains(filter.Search.ToLower()) 
                           ||s.ProjectCode.ToLower().Contains(filter.Search.ToLower()) 
                           ||s.DocumentType.ToLower().Contains(filter.Search.ToLower()) 
                           ||s.InvoiceNo.ToLower().Contains(filter.Search.ToLower()) 
                           ||s.Remark.ToLower().Contains(filter.Search.ToLower()) 
                           ||s.VendorCode.ToLower().Contains(filter.Search.ToLower())
                           ))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VReceivedDocuments
                           .Where(s => (
                           filter.StartDate == null || s.ReceivedDate >= filter.StartDate) 
                           &&(filter.EndDate == null || s.ReceivedDate <= filter.EndDate) 
                           &&(s.CompanyId == user.CompanySessionId) 
                           && (list.Contains((short)s.ProId) || filter.ProId == s.ProId) 
                           && (String.IsNullOrEmpty(filter.Search) ||
                                s.VendorName.ToLower().Contains(filter.Search.ToLower()) ||
                                s.DocumentCode.ToLower().Contains(filter.Search.ToLower()) ||
                                s.ProjectCode.ToLower().Contains(filter.Search.ToLower()) ||
                                s.DocumentType.ToLower().Contains(filter.Search.ToLower()) ||
                                s.InvoiceNo.ToLower().Contains(filter.Search.ToLower()) ||
                                s.Remark.ToLower().Contains(filter.Search.ToLower()) ||
                                s.VendorCode.ToLower().Contains(filter.Search.ToLower())
                                ))
                           .CountAsync();
            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("received-documents/{id}")]
        public async Task<ActionResult<VReceivedDocument>> ReceivedDocument(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VReceivedDocuments.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("received-documents/basic")]
        public async Task<ActionResult<IEnumerable<VReceivedDocumentBasic>>> ReceivedDocumentBasic([FromQuery] FilterBy filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VReceivedDocumentBasics
                .AsNoTracking()
                .Where(x => x.CompanyId == user.CompanySessionId && (filter.ProId == x.ProId || filter.ProId == 0))
                .OrderByDescending(x => x.CreatedAt)
                .ToListAsync();
        }

        [HttpPost("received-documents/add")]
        public async Task<ActionResult<ReceivedDocument>> ReceivedDocumentAdd(ReceivedDocument data)
        {

            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            var suffix = "/" + year + "-" + project;

            var getMax = await _context.ReceivedDocuments.Where(x => x.CompanyId == user.CompanySessionId && x.DocumentCode.EndsWith(suffix)).MaxAsync(x => x.DocumentCode);

            if (getMax != null)
            {
                data.DocumentCode = "Doc:" + (Convert.ToInt32(getMax.Substring(4, 5)) + 1).ToString("D5") + suffix;
            }
            else
            {
                data.DocumentCode = "Doc:00001" + suffix;
            }

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            _context.ReceivedDocuments.Add(data);
            await _context.SaveChangesAsync();

            var attach= await _context.Attachments.Where(x => x.FileRefId == -1 && x.CreatedBy == _auth.Id && x.FileRef == "ReceivedDocument").ToListAsync();
            attach.ForEach(x => x.FileRefId = data.Id);
            await _context.SaveChangesAsync();


            //_context.SaveChangesAsync();

            return data;
        }

        [HttpPut("received-documents/update")]
        public async Task<IActionResult> ReceivedDocumentUpdate(ReceivedDocument data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ReceivedDocuments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            bool hasTransaction = await _context.ReceivedDocumentsCancels.AnyAsync(x => x.ReceivedDocumentId == data.Id);

            if (hasTransaction)
            {
                return BadRequest(new ApiResponse("failed", "This document is already cancel. Please check again!", "400"));
            }

            hasTransaction = await _context.VendorsSettlementSubs.AnyAsync(x => x.DocumentId == data.Id && x.RecStatus == 3);

            if (hasTransaction)
            {
                return BadRequest(new ApiResponse("failed", "This document is already settlement. Please check again!", "400"));
            }

            // auto contract
            var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            var suffix = "/" + year + "-" + project;

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.SettlementAt).IsModified = false;

            _context.Entry(data).Property(x => x.CancelAt).IsModified = false;

            _context.Entry(data).Property(x => x.AttachRef).IsModified = false;

            if (data.ProId != valid.ProId)
            {
                var getMax = await _context.ReceivedDocuments.Where(x => x.CompanyId == user.CompanySessionId && x.DocumentCode.EndsWith(suffix)).MaxAsync(x => x.DocumentCode);

                if (getMax != null)
                {
                    data.DocumentCode = "Doc:" + (Convert.ToInt32(getMax.Substring(4, 5)) + 1).ToString("D5") + suffix;
                }
                else
                {
                    data.DocumentCode = "Doc:00001" + suffix;
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.DocumentCode).IsModified = false;
            }


            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.CompanyId = user.CompanySessionId;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("received-documents/{id}/delete")]
        public async Task<IActionResult> ReceivedDocumentDelete(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            bool hasTransaction = await _context.ReceivedDocumentsCancels.AnyAsync(x => x.ReceivedDocumentId == id);

            if (hasTransaction)
            {
                return BadRequest(new ApiResponse("failed", "This document is already cancel. Please check again!", "400"));
            }

            hasTransaction = await _context.VendorsSettlementSubs.AnyAsync(x => x.DocumentId == id && x.RecStatus == 3);

            if (hasTransaction)
            {
                return BadRequest(new ApiResponse("failed", "This document is already settlement. Please check again!", "400"));
            }


            var data = await _context.ReceivedDocuments.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            try
            {
                _context.ReceivedDocuments.Remove(data);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("received-documents/cancel")]
        public async Task<ActionResult<IEnumerable<VReceivedDocumentsCancel>>> ReceivedDocumentCancel([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VReceivedDocumentsCancels
                           .Where(s => s.CompanyId == user.CompanySessionId && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search) ||
                           s.VendorName.ToLower().Contains(filter.Search.ToLower()) ||
                           s.ProjectCode.ToLower().Contains(filter.Search.ToLower()) ||
                           s.DocumentType.ToLower().Contains(filter.Search.ToLower()) ||
                           s.InvoiceNo.ToLower().Contains(filter.Search.ToLower()) ||
                           s.Remark.ToLower().Contains(filter.Search.ToLower()) ||
                           s.CancelReason.ToLower().Contains(filter.Search.ToLower()) ||
                           s.Code.ToLower().Contains(filter.Search.ToLower()) ||
                           s.DocumentCode.ToLower().Contains(filter.Search.ToLower()) ||
                           s.VendorCode.ToLower().Contains(filter.Search.ToLower()))
                           ))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VReceivedDocumentsCancels
                           .Where(s => s.CompanyId == user.CompanySessionId && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && ((String.IsNullOrEmpty(filter.Search) ||
                           s.VendorName.ToLower().Contains(filter.Search.ToLower()) ||
                           s.ProjectCode.ToLower().Contains(filter.Search.ToLower()) ||
                           s.DocumentType.ToLower().Contains(filter.Search.ToLower()) ||
                           s.InvoiceNo.ToLower().Contains(filter.Search.ToLower()) ||
                           s.Remark.ToLower().Contains(filter.Search.ToLower()) ||
                           s.CancelReason.ToLower().Contains(filter.Search.ToLower()) ||
                           s.Code.ToLower().Contains(filter.Search.ToLower()) ||
                           s.DocumentCode.ToLower().Contains(filter.Search.ToLower()) ||
                           s.VendorCode.ToLower().Contains(filter.Search.ToLower()))
                           ))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("received-documents/cancel/{id}")]
        public async Task<ActionResult<VReceivedDocumentsCancel>> ReceivedDocumentCancel(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VReceivedDocumentsCancels.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("received-documents/cancel/add")]
        public async Task<ActionResult<ReceivedDocumentsCancel>> ReceivedDocumentCancelAdd(ReceivedDocumentsCancel data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var doc = _context.ReceivedDocuments.AsNoTracking().First(x => x.Id == data.ReceivedDocumentId && x.CompanyId == user.CompanySessionId);

            var proId = doc.ProId;

            var project = _context.VDbliveProjects.First(x => x.Id == proId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);
            var suffix = "/" + year + "-" + project;

            var getMax = await _context.ReceivedDocumentsCancels.Where(x => x.CompanyId == user.CompanySessionId && x.DocumentCode.EndsWith(suffix)).MaxAsync(x => x.DocumentCode);

            if (getMax != null)
            {
                data.DocumentCode = "C-Doc:" + (Convert.ToInt32(getMax.Substring(6, 5)) + 1).ToString("D5") + suffix;
            }
            else
            {
                data.DocumentCode = "C-Doc:00001" + suffix;
            }

            //_context.Entry(doc).State = EntityState.Modified;

            //doc.CancelAt = DateTime.Now;

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            _context.ReceivedDocumentsCancels.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("received-documents/cancel/update")]
        public async Task<IActionResult> ReceivedDocumentCancelUpdate(ReceivedDocumentsCancel data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ReceivedDocumentsCancels.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;


            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            if (data.ReceivedDocumentId != valid.ReceivedDocumentId)
            {
                // auto contract
                var proId = _context.ReceivedDocuments.AsNoTracking().First(x => x.Id == data.ReceivedDocumentId && x.CompanyId == user.CompanySessionId).ProId;
                var project = _context.VDbliveProjects.First(x => x.Id == proId).ProjectCode.Substring(1, 2);
                var year = DateTime.Now.Year.ToString().Substring(2, 2);
                var suffix = "/" + year + "-" + project;

                var getMax = await _context.ReceivedDocumentsCancels.Where(x => x.CompanyId == user.CompanySessionId && x.DocumentCode.EndsWith(suffix)).MaxAsync(x => x.DocumentCode);

                if (getMax != null)
                {
                    data.DocumentCode = "C-Doc:" + (Convert.ToInt32(getMax.Substring(6, 5)) + 1).ToString("D5") + suffix;
                }
                else
                {
                    data.DocumentCode = "C-Doc:00001" + suffix;
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.DocumentCode).IsModified = false;
            }

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("received-documents/cancel/{id}/delete")]
        public async Task<IActionResult> ReceivedDocumentCancelDelete(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.ReceivedDocumentsCancels.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            try
            {
                _context.ReceivedDocumentsCancels.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpDelete("received-document/cancel/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteReceivedDocumentcancelAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.received_documents_cancel", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpPut("received-documents/cancel/approved/{id}")]
        public async Task<IActionResult> ReceivedDocumentCancelApprove(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.ReceivedDocumentsCancels.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if (valid.RecStatus == 3)
            {
                return BadRequest(new ApiResponse("failed", "This Received Document Cancel is already approved!", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.RecStatus = 3;

            try
            {

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_approve_receive_document_cancel] {0}", id);

                    ts.Complete();
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

        }

        [HttpGet("SubJobUnlinks")]
        public async Task<ActionResult<IEnumerable<VSubJobUnlink>>> GetAllSubJobUnlinks()
        {
            return await _context.VSubJobUnlinks.AsNoTracking().ToListAsync();
        }

        [HttpGet("settlement/sub")]
        public async Task<ActionResult<IEnumerable<VVendorsSettlementsSub>>> SettlementSub([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            filter.Status = filter.Status - 1;

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VVendorsSettlementsSubs
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (filter.Status == -1 || s.RecStatus == ((byte?)filter.Status)) && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                                s.Reason.ToLower().Contains(filter.Search.ToLower()) ||
                                s.ItemName.ToLower().Contains(filter.Search.ToLower()) ||
                                s.Project.ToLower().Contains(filter.Search.ToLower()) ||
                                s.VendorNameEn.ToLower().Contains(filter.Search.ToLower()) ||
                                s.SettlementCode.ToLower().Contains(filter.Search.ToLower())))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VVendorsSettlementsSubs
                           .Where(s => (s.CompanyId == user.CompanySessionId) && (filter.Status == -1 || s.RecStatus == ((byte?)filter.Status)) && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                                s.Reason.ToLower().Contains(filter.Search.ToLower()) ||
                                s.ItemName.ToLower().Contains(filter.Search.ToLower()) ||
                                s.Project.ToLower().Contains(filter.Search.ToLower()) ||
                                s.VendorNameEn.ToLower().Contains(filter.Search.ToLower()) ||
                                s.SettlementCode.ToLower().Contains(filter.Search.ToLower())))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("settlement/sub/{id}")]
        public async Task<ActionResult<WorkflowModel>> SettlementSubAsync(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsSettlementsSubs.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors_settlement_sub", ((int)data.Id), _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpGet("settlement/sub/history")]
        public async Task<ActionResult<IEnumerable<MVendorSettlementSubHistory>>> GetSettlementHistory([FromQuery] FilterSubHistory obj)
        {
            var data = await _manualDbContext
                .MVendorSettlementSubHistories.FromSqlRaw("exec [dbo].[sp_get_sub_settlement_history] {0}, {1}", obj?.ContractId, obj?.ItemId)
                .ToListAsync();

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("settlement/sub/basic")]
        public async Task<ActionResult<IEnumerable<VVendorsSettlementSubBasic>>> SettlementSubBasic([FromQuery] FilterBy filterBy)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VVendorsSettlementSubBasics.AsNoTracking().Where(x => (x.CompanyId == user.CompanySessionId) && (filterBy.ProId == 0 || filterBy.ProId == x.ProId)).ToListAsync();
        }

        [HttpGet("settlement/lab/basic")]
        public async Task<ActionResult<IEnumerable<VVendorsSettlementLabBasic>>> SettlementLabBasic([FromQuery] FilterBy filterBy)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VVendorsSettlementLabBasics
                                .AsNoTracking()
                                .Where(x => (x.CompanyId == user.CompanySessionId) && (filterBy.ProId == 0 || filterBy.ProId == x.ProId))
                                .ToListAsync();
        }

        [HttpPost("settlement/sub/add")]
        public async Task<ActionResult<VendorsSettlementSub>> SettlementSubAdd(VendorsSettlementSub data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var project = _context.VDbliveProjects.AsNoTracking().First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);
            var suffix = "/" + year + "-" + project;

            var getMax = await _context.VendorsSettlementSubs.AsNoTracking().Where(x => x.CompanyId == user.CompanySessionId && x.SettlementCode.EndsWith(suffix) && x.SettlementCode.StartsWith("Sub:")).MaxAsync(x => x.SettlementCode);

            if (getMax != null)
            {
                data.SettlementCode = "Sub:" + toSubRef(getMax, suffix) + suffix;
            }
            else
            {
                data.SettlementCode = "Sub:00001" + suffix;
            }

            data.IsNoContract = false;

            if (data.IsNoContract == false)
            {
                var contract = await _context.VendorsContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.ContractId && x.CompanyId == user.CompanySessionId);



                if (contract == null)
                {
                    return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!"));
                }

                data.CostTypeId = contract.CostTypeId;
            }
            /*
                var isDraft = await _context.VendorsSettlementSubs.AsNoTracking().AnyAsync(x => x.VendorItem == data.VendorItem && x.CompanyId == user.CompanySessionId && x.ContractId == data.ContractId && x.RecStatus < 3 && x.IsNoContract == false);

                if (isDraft)
                {
                    return BadRequest(new ApiResponse("failed", "This Vendor Contract Id is already draft. Please check again!"));
                }
            */

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;
            // Auto Confirm Self Review
            data.RecStatus = 1;

            _context.VendorsSettlementSubs.Add(data);

            await _context.SaveChangesAsync();

            _context.Database.ExecuteSqlRaw(@"exec dbo.sp_auto_lock_unfollow_contract {0}", data.Id);

            new WorkflowDetailModel().WorkflowHistoryDraftConfirm("dbo.vendors_settlement_sub", ((int)data.Id), _auth.Id);

            return data;
        }

        private string toSubRef(string code, string suffix)
        {
            code = code.Replace(suffix, "").Replace("Sub:", "");
            return (Convert.ToInt32(code) + 1).ToString("D5");
        }

        [HttpPut("settlement/sub/update")]
        public async Task<IActionResult> SettlementSubUpdate(VendorsSettlementSub data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsSettlementSubs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            // auto contract
            var project = _context.VDbliveProjects.First(x => x.Id == data.ProId).ProjectCode.Substring(1, 2);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            var suffix = "/" + year + "-" + project;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;
            _context.Entry(data).Property(x => x.AutoLock).IsModified = false;

            if (data.ProId != valid.ProId)
            {
                var getMax = await _context.VendorsSettlementSubs.Where(x => x.CompanyId == user.CompanySessionId && x.SettlementCode.EndsWith(suffix) && x.SettlementCode.StartsWith("Sub:")).MaxAsync(x => x.SettlementCode);

                if (getMax != null)
                {
                    data.SettlementCode = "Sub:" + toSubRef(getMax, suffix) + suffix;
                }
                else
                {
                    data.SettlementCode = "Sub:00001" + suffix;
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.SettlementCode).IsModified = false;
            }

            data.IsNoContract = false;

            if (data.IsNoContract == false)
            {
                var contract = await _context.VendorsContracts.FirstOrDefaultAsync(x => x.ContractPurchaseId == data.ContractPurchaseId && x.CompanyId == user.CompanySessionId);



                if (contract == null)
                {
                    return BadRequest(new ApiResponse("failed", "PO Contract Id not found!"));
                }

                data.CostTypeId = contract.CostTypeId;
            }

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();

                _context.Database.ExecuteSqlRaw(@"exec dbo.sp_auto_lock_unfollow_contract {0}", data.Id);

                return Ok();
            }
            catch (Exception ex)
            {

            }

            return NoContent();
        }

        [HttpDelete("settlement/sub/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteSettlementSubAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.vendors_settlement_sub", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("settlement/sub/{id}/items")]
        public async Task<IEnumerable<object>> SettlementSubItem(int id)
        {
            var data = _manualDbContext.ExecuteQuery($"exec [dbo].[sp_get_settlement_sub_items] {id}")
                .AsEnumerable()
                .ToList();

            return data;
        }

        [HttpPost("settlement/sub/claim/history")]
        public async Task<object> SettlementSubItemClaimHistory(SubClaimHistory claim)
        {
            var data = _manualDbContext.MVendorSettlementSubClaimHistories
                .FromSqlRaw("exec [dbo].[sp_get_settlement_sub_claim_history] {0},{1},{2}", claim.SettlementSubId, claim.HouseId, claim.PriceItemId)
                .AsEnumerable()
                .FirstOrDefault();

            return data;
        }

        [HttpGet("settlement/sub-re/{id}/claim/{houseId}/history")]
        public async Task<object> SettlementSubReItemClaimHistory(int id, int houseId)
        {
            var data = _manualDbContext.MVendorSettlementSubReClaimHistories
                .FromSqlRaw("exec [dbo].[sp_get_settlement_sub_re_claim_history] {0},{1}", id, houseId)
                .AsEnumerable()
                .FirstOrDefault();

            return data;
        }

        [HttpGet("settlement/sub/{contractId}/deadline/{receivedDocumentId}")]
        public async Task<object> SettlementSubDeadline(int contractId, int receivedDocumentId)
        {
            var data = _manualDbContext.SettlementSubDeadlines
                .FromSqlRaw("exec [dbo].[sp_get_settlement_sub_deadline] {0},{1}", contractId, receivedDocumentId)
                .AsEnumerable()
                .FirstOrDefault();

            return data;
        }

        [HttpGet("settlement/sub/{id}/items/redesign")]
        public async Task<IEnumerable<object>> SettlementSubItemRedesign(int id)
        {
            var data = await _manualDbContext.VendorSettlementSubItemRedesigns.FromSqlRaw("exec [dbo].[sp_get_settlement_sub_redesign_items] {0}", id).ToListAsync();

            return data;
        }
        [HttpGet("settlement/sub/items/redesign/{id}")]
        public async Task<ActionResult<VendorSettlementSubItemRedesign>> SettlementSubItemRedesignById(long id)
        {
            var data = await _context.VendorsSettlementSubRedesigns.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            var list = await _manualDbContext.VendorSettlementSubItemRedesigns.FromSqlRaw("exec [dbo].[sp_get_settlement_sub_redesign_items] {0}", data?.SettlementSubId).ToListAsync();

            return list.FirstOrDefault(x => x.Id == id);
        }
        [HttpPost("settlement/sub/items/redesign/add")]
        public async Task<ActionResult<VendorsSettlementSubRedesign>> VendorSettlementSubItemRedesignAdd(VendorsSettlementSubRedesign data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var settlement = await _context.VendorsSettlementSubs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.SettlementSubId && user.CompanySessionId == x.CompanyId);

            if (settlement == null)
            {
                return BadRequest(new ApiResponse("failed", "Settlement Sub Id not found!"));
            }

            var contract = await _context.VendorsContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == settlement.ContractId && x.CompanyId == user.CompanySessionId);

            if (contract == null)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!"));
            }

            var house = await _context.VHouses.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId);

            if (house == null)
            {
                return BadRequest(new ApiResponse("failed", "House Id not found!"));
            }

            var valid = await _context.VendorsSettlementSubRedesigns.AsNoTracking().AnyAsync(x => x.SettlementSubId == data.SettlementSubId && x.PriceItemId == data.PriceItemId && x.HouseId == data.HouseId);

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "House Number " + house?.HouseNumber + " is exist!"));
            }

            var price = await _context.VendorsContractsPriceItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.PriceItemId);

            if (price == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Price Item Id not found!"));
            }

            if (data.Quantity == null || data.Quantity <= 0)
            {
                return BadRequest(new ApiResponse("failed", "Invalid Quantity"));
            }

            var project = _context.VDbliveProjects.First(x => x.Id == settlement.ProId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);


            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;
            data.TotalPrice = data.UnitPrice * data.Quantity;

            data.TotalPrice = data.Quantity * data.UnitPrice;

            data.ItemId = settlement.VendorItem;

            _context.VendorsSettlementSubRedesigns.Add(data);



            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    if (contract.CostTypeId != 1)
                    {
                        return BadRequest(new ApiResponse("failed", "Invalid cost type!"));
                    }
                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_tracking_redesign_houses] {0},{1},{2}", settlement.ContractId, settlement.VendorItem, data.HouseId);

                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_perc_from_contract_redesign] {0},{1},{2}", settlement.Id, data.ItemId, data.Id);

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_generate_cost_center_redesign] {0},{1}", settlement.ProId, data.Id);

                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }

            return data;
        }

        [HttpPut("settlement/sub/items/redesign/update")]
        public async Task<IActionResult> VendorSettlementSubItemRedesignUpdate(VendorsSettlementSubRedesign data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsSettlementSubRedesigns.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            var settlement = await _context.VendorsSettlementSubs.FirstOrDefaultAsync(x => x.Id == data.SettlementSubId && x.CompanyId == user.CompanySessionId);

            if (settlement == null)
            {
                return BadRequest(new ApiResponse("failed", "Settlement Sub Id not found!"));
            }

            var contract = await _context.VendorsContracts.FirstOrDefaultAsync(x => x.Id == settlement.ContractId && user.CompanySessionId == x.CompanyId);

            if (contract == null)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!"));
            }

            var house = await _context.VHouses.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId);

            if (house == null)
            {
                return BadRequest(new ApiResponse("failed", "House Id not found!"));
            }

            var price = await _context.VendorsContractsPriceItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.PriceItemId);

            if (price == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Price Item Id not found!"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            if (data.Quantity == null || data.Quantity <= 0)
            {
                return BadRequest(new ApiResponse("failed", "Invalid Quantity"));
            }

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            data.TotalPrice = data.UnitPrice * data.Quantity;

            data.ItemId = settlement.VendorItem;

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    if (contract.CostTypeId != 1)
                    {
                        return BadRequest(new ApiResponse("failed", "Invalid cost type!"));
                    }
                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_tracking_redesign_houses] {0},{1},{2}", settlement.ContractId, settlement.VendorItem, data.HouseId);

                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_perc_from_contract_redesign] {0},{1},{2}", settlement.Id, data.ItemId, data.Id);

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_generate_cost_center_redesign] {0},{1}", settlement.ProId, data.Id);

                    ts.Complete();
                }
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("settlement/sub/items/redesign/{id}/delete")]
        public async Task<IActionResult> VendorSettlementSubItemRedesignDelete(int id)
        {
            var data_delete = await _context.VendorsSettlementSubRedesigns.FirstOrDefaultAsync(x => x.Id == id);

            try
            {

                _context.VendorsSettlementSubRedesigns.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                return NoContent();
            }

            return Ok();

        }

        [HttpGet("settlement/sub/{id}/redesign/confirm")]
        public async Task<IEnumerable<object>> SettlementSubItemRedesignConfirm(int id)
        {
            var data = await _manualDbContext.VendorSettlementSubRedesignConfirms.FromSqlRaw("exec [dbo].[sp_get_settlement_sub_redesign_confirm] {0}", id).ToListAsync();

            return data;
        }

        [HttpGet("settlement/{id}/items")]
        public async Task<IEnumerable<object>> SettlementItem(int id)
        {
            var data = await _manualDbContext.VendorContractPriceItems.FromSqlRaw("exec [dbo].[sp_get_contract_item_by_settlement] {0}", id).ToListAsync();

            return data;
        }

        [HttpGet("settlement/sub/items/{id}")]
        public async Task<ActionResult<object>> SettlementSubItem(long id)
        {
            //var data = await _context.VendorsSettlementSubItems.FirstOrDefaultAsync(x => x.Id == id);

            //if (data == null)
            //{
            //    return NoContent();
            //}


            return _manualDbContext.ExecuteQuery($"exec [dbo].[sp_get_settlement_sub_items_by_id] {id}")
                .AsEnumerable()
                .FirstOrDefault();

        }

        [HttpGet("settlement/sub/{id}/cost_center")]
        public async Task<ActionResult<IEnumerable<object>>> GetSettlementSubItemCostCenter(int id)
        {
            //var data = await _context.VendorsSettlementSubItems.FirstOrDefaultAsync(x => x.Id == id);

            //if (data == null)
            //{
            //    return NoContent();
            //}


            return _manualDbContext.ExecuteQuery($"exec [dbo].[sp_get_cost_center_items] {id}")
                .AsEnumerable()
                .ToList();

        }

        [HttpGet("settlement/sub/redesigns/{id}/cost_center")]
        public async Task<ActionResult<IEnumerable<object>>> GetSettlementSubRedesignCostCenter(int id)
        {
            //var data = await _context.VendorsSettlementSubItems.FirstOrDefaultAsync(x => x.Id == id);

            //if (data == null)
            //{
            //    return NoContent();
            //}


            return _manualDbContext.ExecuteQuery($"exec [dbo].[sp_get_cost_center_items_redesigns] {id}")
                .AsEnumerable()
                .ToList();

        }

        [HttpPost("settlement/sub/items/add")]
        public async Task<ActionResult<VendorsSettlementSubItem>> SettlementSubItemAdd(VendorsSettlementSubItem data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);
          
            var settlement = await _context.VendorsSettlementSubs.AsNoTracking().FirstOrDefaultAsync(
                x => x.Id == data.SettlementSubId && user.CompanySessionId == x.CompanyId
             );

            if (settlement == null)
            {
                return BadRequest(new ApiResponse("failed", "Settlement Sub Id not found!"));
            }

            var contract = await _context.VendorsContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == settlement.ContractId && x.CompanyId == user.CompanySessionId);

            if (contract == null)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!"));
            }
         
            if (contract.CostTypeId == 1)
            {

                var house = await _context.VHouses.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId);

                if (house == null)
                {
                    return BadRequest(new ApiResponse("failed", "House Id not found!"));
                }

                var valid = await _context.VendorsSettlementSubItems.AsNoTracking().AnyAsync(x => x.SettlementSubId == data.SettlementSubId && x.PriceItemId == data.PriceItemId && x.HouseId == data.HouseId);

                if (valid)
                {
                    return BadRequest(new ApiResponse("failed", "House Number " + house?.HouseNumber + " is exist!"));
                }
                /**
                var checkFirstSettlement =  await _context.VendorsSettlementSubs.AsNoTracking().FirstOrDefaultAsync(x => x.ContractId == settlement.ContractId && user.CompanySessionId == x.CompanyId);

                if (checkFirstSettlement != null)
                {
                    var first_valid_house = await _context.VendorsSettlementSubItems.AsNoTracking().AnyAsync(
                        x => x.SettlementSubId == checkFirstSettlement.Id 
                        && x.PriceItemId == data.PriceItemId 
                        && x.HouseId == data.HouseId
                    );
                    if (first_valid_house)
                    {
                        return BadRequest(new ApiResponse("failed", "House Number " + house?.HouseNumber + " is exist!"));
                    }
                }
                **/
            }
            else
            {
                var valid = await _context.VendorsSettlementSubItems.AsNoTracking().AnyAsync(x => x.SettlementSubId == data.SettlementSubId && x.PriceItemId == data.PriceItemId && x.HouseId == data.HouseId);

                if (valid)
                {
                    return BadRequest(new ApiResponse("failed", "Cost Name  is exist!"));
                }
            }

            var price = await _context.VendorsContractsPriceItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.PriceItemId);

            if (price == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Price Item Id not found!"));
            }

            //var claimCount = await _context.VendorsContractsTrackingHouses.Where(x => x.ContractId == settlement.ContractId && x.ItemId == settlement.VendorItem && x.HouseId).CountAsync();

            //var project = _context.VDbliveProjects.First(x => x.Id == settlement.ProId).ProjectCode.Substring(1, 2);
            //var year = DateTime.Now.Year.ToString().Substring(2, 2);

            //var code = project + "_" + data.HouseId + "_" + contract.ContractCode + "_" + year + "_" + claimCount.ToString();

            //var _auth = new CustomUserIdentity(User);

            //if (data.Quantity == null || data.Quantity <= 0)
            //{
            //    return BadRequest(new ApiResponse("failed", "Invalid Quantity"));
            //}

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            //data.ClaimId = code;

            //data.ClaimTime = claimCount;

            data.TotalPrice = data.UnitPrice * data.Quantity;

            data.ItemId = settlement.VendorItem;

            _context.VendorsSettlementSubItems.Add(data);

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_sync_perc_from_contract] {0},{1},{2}", data.SettlementSubId, settlement.VendorItem, data.Id);

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_generate_cost_center] {0},{1}", settlement.ProId, data.Id);

                    //_context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_balancing_sub_item_per_house] {0},{1},{2}", data.SettlementSubId, data.HouseId, (data.Perc / 100));

                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }
            return data;
        }

        [HttpPut("settlement/sub/items/update")]
        public async Task<IActionResult> SettlementSubUpdate(VendorsSettlementSubItemInput input)
        {
            var _auth = new CustomUserIdentity(User);


            var data = input.SubItem;

            var costCenter = input.CostCenter;

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsSettlementSubItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (valid == null)
            {
                return BadRequest();
            }

            var settlement = await _context.VendorsSettlementSubs.FirstOrDefaultAsync(x => x.Id == data.SettlementSubId && x.CompanyId == user.CompanySessionId);

            if (settlement == null)
            {
                return BadRequest(new ApiResponse("failed", "Settlement Sub Id not found!"));
            }

            var contract = await _context.VendorsContracts.FirstOrDefaultAsync(x => x.Id == settlement.ContractId && user.CompanySessionId == x.CompanyId);

            if (contract == null)
            {
                return BadRequest(new ApiResponse("failed", "Vendor Contract Id not found!"));
            }
            if (contract.CostTypeId == 1)
            {

                var house = await _context.VHouses.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId);

                if (house == null)
                {
                    return BadRequest(new ApiResponse("failed", "House Id not found!"));
                }
            }

            var price = await _context.VendorsContractsPriceItems.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.PriceItemId);

            if (price == null)
            {
                return BadRequest(new ApiResponse("failed", "Contract Price Item Id not found!"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            // prevent wrong claim ID
            _context.Entry(data).Property(x => x.ClaimId).IsModified = false;

            _context.Entry(data).Property(x => x.SettlementSubId).IsModified = false;

            _context.Entry(data).Property(x => x.HouseId).IsModified = false;

            _context.Entry(data).Property(x => x.ClaimTime).IsModified = false;

            data.TotalPrice = data.UnitPrice * data.Quantity;

            //var _auth = new CustomUserIdentity(User);

            //if (data.Quantity == null || data.Quantity <= 0)
            //{
            //    return BadRequest(new ApiResponse("failed", "Invalid Quantity"));
            //}

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.ItemId = settlement.VendorItem;

            try
            {
                decimal? totalAmountCostCenter = costCenter.Sum(x => x.Amount);
                var costCenterList = await _context.VendorsSettlementSubCostCenters
                    .AsNoTracking()
                    .Where(x => x.SummarySubItemId == data.Id && x.Status == true)
                    .ToListAsync();

                // Use string interpolation instead of string concatenation

                var records = new List<VendorsSettlementSubCostCenter>();

                if (records.Count < 0 && settlement.CostTypeId != 1)
                {
                    return BadRequest(new ApiResponse("failed", $"The amount allocated to the cost center does not match the amount claimed!"));
                }

                // Use switch expressions instead of if-else statements
                foreach (var item in costCenter)
                {
                    if (records.Any(x => (x.CostCenterId == null) && settlement.CostTypeId != 1))
                    {
                        return BadRequest(new ApiResponse("failed", "The cost center is invalid"));
                    }

                    if (records.Any(x => (x.Amount == 0 || x.Amount == null) && settlement.CostTypeId != 1))
                    {
                        return BadRequest(new ApiResponse("failed", "The cost center amount invalid"));
                    }

                    if (records.Any(x => x.CostCenterId == item.CostCenterId && settlement.CostTypeId != 1))
                    {
                        return BadRequest(new ApiResponse("failed", "The cost center already exists."));
                    }

                    records.Add(new VendorsSettlementSubCostCenter
                    {
                        CostCenterId = item.CostCenterId,
                        SummarySubItemId = item.SummarySubItemId,
                        Amount = item.Amount,
                        Status = true,
                        CreatedAt = DateTime.Now,
                        CreatedBy = _auth.Id
                    });
                }

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();
                    _context.Database.ExecuteSqlRaw(@"[dbo].[sp_sync_perc_from_contract] {0},{1},{2}", data.SettlementSubId, settlement.VendorItem, valid.Id);

                    if (settlement.CostTypeId == 1)
                    {
                        _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_generate_cost_center] {0},{1}", settlement.ProId, data.Id);
                    }
                    else
                    {
                        var newSubItem = await _context.VendorsSettlementSubItems
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x => x.Id == data.Id);

                        if (newSubItem.ClaimAmount != totalAmountCostCenter)
                        {
                            return BadRequest(new ApiResponse("failed", $"The amount allocated to the cost center does not match the amount claimed!"));
                        }


                        _context.VendorsSettlementSubCostCenters.RemoveRange(costCenterList);

                        _context.VendorsSettlementSubCostCenters.AddRange(records);

                        await _context.SaveChangesAsync();
                    }

                    //_context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_balancing_sub_item_per_house] {0},{1},{2}", data.SettlementSubId, data.HouseId, (data.Perc / 100));

                    ts.Complete();

                    return Ok();
                }
            }
            catch (DbUpdateConcurrencyException)
            {

            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }

            return NoContent();
        }

        [HttpDelete("settlement/sub/items/{id}/delete")]
        public async Task<IActionResult> SettlementSubItemDelete(int id)
        {
            var data_delete = await _context.VendorsSettlementSubItems.FirstOrDefaultAsync(x => x.Id == id);
            var settlementId = data_delete.SettlementSubId;
            var houseId = data_delete.HouseId;
            var perc = (data_delete.Perc / 100);

            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    _context.VendorsSettlementSubItems.Remove(data_delete);
                    await _context.SaveChangesAsync();

                    //_context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_balancing_sub_item_per_house] {0},{1},{2}", settlementId, houseId, perc);

                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }

            return Ok();
        }

        [HttpGet("physical-check/sub")]
        public async Task<ActionResult<IEnumerable<VVendorsPhysicalCheckLabsRemark>>> GetPhysicalCheckSub([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VendorsPhysicalCheckSubs
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search) ||
                           s.Remark.ToLower().Contains(filter.Search.ToLower()) ||
                           s.PhysicalCode.ToLower().Contains(filter.Search.ToLower()))))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VendorsPhysicalCheckSubs
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search) ||
                           s.Remark.ToLower().Contains(filter.Search.ToLower()) ||
                           s.PhysicalCode.ToLower().Contains(filter.Search.ToLower()))))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("physical-check/sub/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetPhisicalCheckSub(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VPhysicalCheckSubs.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors_physical_check_subs", ((int)data.Id), _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("physical-check/sub/add")]
        public async Task<ActionResult<VendorsPhysicalCheckSub>> GetPhysicalCheckSub(VendorsPhysicalCheckSub data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            var suffix = "/" + year;

            var getMax = await _context.VendorsPhysicalCheckSubs.Where(x => x.CompanyId == user.CompanySessionId && x.PhysicalCode.EndsWith(suffix)).MaxAsync(x => x.PhysicalCode);

            if (getMax != null)
            {
                //getMax = getMax.Replace(@"VPC-S:", "").Replace(suffix, "");
                //var maxNumber = Regex.Match(getMax, @"\d+").Value;

                data.PhysicalCode = "VPC-S:" + toPhysicalSubRef(getMax, suffix) + suffix;
            }
            else
            {
                data.PhysicalCode = "VPC-S:00001" + suffix;
            }



            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.RecStatus = 0;

            data.Status = true;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            _context.VendorsPhysicalCheckSubs.Add(data);


            try
            {
                await _context.SaveChangesAsync();

                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_suggest_physical_check_sub] {0}", data.Id);

                new WorkflowDetailModel().WorkflowHistoryDraft("dbo.vendors_physical_check_subs", ((int)data.Id), _auth.Id);

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }
        }

        private string toPhysicalSubRef(string code, string suffix)
        {
            code = code.Replace(suffix, "").Replace("VPC-S:", "");
            return (Convert.ToInt32(code) + 1).ToString("D5");
        }

        [HttpPut("physical-check/sub/update")]
        public async Task<IActionResult> UpdatePhysicalCheckSub(VendorsPhysicalCheckSub data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid1 = await _context.VendorsPhysicalCheckSubs.AsNoTracking().FirstOrDefaultAsync(x => x.SettlementId == data.SettlementId && x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            var valid = await _context.VendorsPhysicalCheckSubs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if (valid1?.SettlementId != valid.SettlementId)
            {
                var vendorSettlement = await _context.VendorsPhysicalCheckSubsDetails.Where(x => x.VendorPhysicalCheckSubId == data.Id).ToArrayAsync();

                if (vendorSettlement != null)
                {
                    _context.VendorsPhysicalCheckSubsDetails.RemoveRange(vendorSettlement);
                }
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.PhysicalCode).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            //var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();

                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_suggest_physical_check_sub] {0}", data.Id);
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("physical-check/sub/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeletePhysicalCheckSubAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.vendors_physical_check_subs", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("physical-check/sub/{id}/details/suggest")]
        public async Task<ActionResult<IEnumerable<PhysicalCheckHouse>>> GetPhisicalCheckSubDetailSuggest(int id)
        {
            return await _manualDbContext.PhysicalCheckHouses
                            .FromSqlRaw("exec [dbo].[sp_get_physical_check_sub] {0}", id)
                           .ToListAsync();
        }

        [HttpGet("physical-check/sub/{id}/details")]
        public async Task<ActionResult<IEnumerable<VVendorsPhysicalCheckSubsDetail>>> GetPhisicalCheckSubDetail(int id)
        {
            return await _context.VVendorsPhysicalCheckSubsDetails
                           .Where(s => s.VendorPhysicalCheckSubId == id)
                           .OrderByDescending(x => x.CreatedAt)
                           .ToListAsync();
        }

        [HttpGet("physical-check/sub/detail/{id}")]
        public async Task<ActionResult<VVendorsPhysicalCheckSubsDetail>> GetPhisicalCheckSubDetailById(int id)
        {
            var data = await _context.VVendorsPhysicalCheckSubsDetails.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("physical-check/sub/detail/add")]
        public async Task<ActionResult<VendorsPhysicalCheckSubsDetail>> GetPhisicalCheckSubDetailAdd(VendorsPhysicalCheckSubsDetail data)
        {
            var exist = await _context.VendorsPhysicalCheckSubs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.VendorPhysicalCheckSubId);

            if (exist == null)
            {
                return BadRequest(new ApiResponse("failed", "VendorPhysicalCheckSubId is not found!"));
            }

            var house = await _context.VHouses.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId);

            if (house == null)
            {
                return BadRequest(new ApiResponse("failed", "House " + house?.HouseNumber + " is not found!"));
            }

            var valid = await _context.VendorsPhysicalCheckSubsDetails.AnyAsync(x => x.HouseId == data.HouseId && x.VendorPhysicalCheckSubId == data.VendorPhysicalCheckSubId);

            if (valid)
            {
                var vHouse = await _context.VHousesLists.FirstOrDefaultAsync(x => x.Id == data.HouseId);

                return BadRequest(new ApiResponse("failed", "House Number " + vHouse?.Number + " already exists!", "400"));
            }


            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.VendorsPhysicalCheckSubsDetails.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("physical-check/sub/detail/update")]
        public async Task<IActionResult> UpdatePhisicalCheckSubDetail(VendorsPhysicalCheckSubsDetail data)
        {
            var exist = await _context.VendorsPhysicalCheckSubsDetails.AsNoTracking().FirstOrDefaultAsync(x => x.HouseId == data.HouseId && x.VendorPhysicalCheckSubId == data.VendorPhysicalCheckSubId);
            var dataValid = await _context.VendorsPhysicalCheckSubsDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);

            if (exist != null && dataValid != null && exist.Id != dataValid?.Id)
            {
                var vHouse = await _context.VHousesLists.FirstOrDefaultAsync(x => x.Id == data.HouseId);

                return BadRequest(new ApiResponse("failed", "House Number " + vHouse?.Number + " already exists!", "400"));
            }

            if (dataValid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.VendorPhysicalCheckSubId).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }


        [HttpDelete("physical-check/sub/detail/{id}/delete")]
        public async Task<IActionResult> DeletePhisicalCheckSubDetail(int id)
        {

            var dataValid = await _context.VendorsPhysicalCheckSubsDetails.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (dataValid == null)
            {
                return NoContent();
            }

            _context.VendorsPhysicalCheckSubsDetails.Remove(dataValid);

            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("physical-check/lab")]
        public async Task<ActionResult<IEnumerable<object>>> GetPhysicalCheckLab([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VendorsPhysicalCheckLabs
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search)
                                || s.Code.ToLower().Contains(filter.Search)
                                )))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VendorsPhysicalCheckLabs
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search) || s.Code.ToLower().Contains(filter.Search))))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("physical-check/lab/{id}")]
        public async Task<ActionResult<WorkflowModel>> GetPhisicalCheckLab(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VPhysicalCheckLabs.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("dbo.vendors_physical_check_labs", ((int)data.Id), _auth.Id);

            wf.workflowModel.Data = data;

            return wf.workflowModel;
        }

        [HttpPost("physical-check/lab/add")]
        public async Task<ActionResult<VendorsPhysicalCheckLab>> GetPhysicalCheckLab(VendorsPhysicalCheckLab data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var year = DateTime.Now.Year.ToString().Substring(2, 2);

            var suffix = "/" + year;

            var getMax = await _context.VendorsPhysicalCheckLabs.Where(x => x.CompanyId == user.CompanySessionId && x.Code.EndsWith(suffix)).MaxAsync(x => x.Code);

            if (getMax != null)
            {
                //getMax = getMax.Replace(@"VPC-L:", "").Replace(suffix, "");
                //var maxNumber = Regex.Match(getMax, @"\d+").Value;

                data.Code = "VPC-L:" + toPhysicalLabRef(getMax, suffix) + suffix;
            }
            else
            {
                data.Code = "VPC-L:00001" + suffix;
            }



            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CompanyId = user.CompanySessionId;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            data.RecStatus = 0;

            _context.VendorsPhysicalCheckLabs.Add(data);

            try
            {
                await _context.SaveChangesAsync();

                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_suggest_physical_check_lab] {0}", data.Id);

                new WorkflowDetailModel().WorkflowHistoryDraft("dbo.vendors_physical_check_labs", ((int)data.Id), _auth.Id);

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }
        }

        private string toPhysicalLabRef(string code, string suffix)
        {
            code = code.Replace(suffix, "").Replace("VPC-L:", "");
            return (Convert.ToInt32(code) + 1).ToString("D5");
        }

        [HttpPut("physical-check/lab/update")]
        public async Task<IActionResult> UpdatePhysicalCheckLab(VendorsPhysicalCheckLab data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsPhysicalCheckLabs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            //var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_suggest_physical_check_lab] {0}", data.Id);
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("physical-check/lab/{id}/delete")]
        public async Task<IActionResult> PhysicalCheckLabDelete(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VendorsPhysicalCheckLabs.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            try
            {
                _context.VendorsPhysicalCheckLabs.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }


        [HttpGet("physical-check/lab/{id}/covers")]
        public async Task<ActionResult<IEnumerable<object>>> GetPhysicalCheckLabItemsAsync(int Id)
        {
            return await _context.VPhysicalCheckLabCovers.Where(x => x.PhysicalCheckLabId == Id).ToListAsync();
        }

        [HttpGet("physical-check/lab/covers/{id}")]
        public async Task<ActionResult<VPhysicalCheckLabCover>> GetPhysicalCheckLabItemAsync(int Id)
        {
            return await _context.VPhysicalCheckLabCovers.FirstOrDefaultAsync(x => x.Id == Id);
        }

        [HttpPost("physical-check/lab/covers/add")]
        public async Task<ActionResult<VendorsPhysicalCheckLabsCover>> AddPhysicalCheckLabItemsAsync(VendorsPhysicalCheckLabsCover data)
        {
            var _auth = new CustomUserIdentity(User);

            var valid = await _context.VendorsPhysicalCheckLabs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.PhysicalCheckLabId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Physical check is not found!"));
            }

            var cover = await _context.VendorsSettlementLabItems.FirstOrDefaultAsync(x => data.CoverId == x.LaborCoverId && valid.SettlementId == x.SettlementLabId);

            if (cover == null)
            {
                return BadRequest(new ApiResponse("failed", "Cover is not found!"));
            }

            bool isExist = await _context.VendorsPhysicalCheckLabsCovers.AnyAsync(x => x.CoverId == data.CoverId && x.PhysicalCheckLabId == data.PhysicalCheckLabId);

            if (isExist)
            {
                return BadRequest(new ApiResponse("failed", "Cover is exist!"));
            }

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.SettlementLabItemId = (int)cover.Id;

            _context.VendorsPhysicalCheckLabsCovers.Add(data);

            try
            {
                await _context.SaveChangesAsync();

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }


        }

        [HttpPut("physical-check/lab/covers/update")]
        public async Task<ActionResult> UpdatePhysicalCheckLabItemsAsync(VendorsPhysicalCheckLabsCover data)
        {
            var _auth = new CustomUserIdentity(User);

            var valid = await _context.VendorsPhysicalCheckLabs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.PhysicalCheckLabId);

            if (valid == null)
            {
                return BadRequest(new ApiResponse("failed", "Physical check is not found!"));
            }

            var cover = await _context.VendorsSettlementLabItems.FirstOrDefaultAsync(x => data.CoverId == x.LaborCoverId && valid.SettlementId == x.SettlementLabId);

            if (cover == null)
            {
                return BadRequest(new ApiResponse("failed", "Cover is not found!"));
            }

            bool isExist = await _context.VendorsPhysicalCheckLabsCovers.AnyAsync(x => x.CoverId == data.CoverId && x.PhysicalCheckLabId == data.PhysicalCheckLabId && x.Id != data.Id);

            if (isExist)
            {
                return BadRequest(new ApiResponse("failed", "Cover is exist!"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.SettlementLabItemId = (int)cover.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message));
            }
        }

        [HttpDelete("physical-check/lab/covers/{id}/delete")]
        public async Task<IActionResult> DeletePhysicalCheckLabItemsAsync(int id)
        {
            var valid = await _context.VendorsPhysicalCheckLabsCovers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.VendorsPhysicalCheckLabsCovers.Remove(valid);

            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpGet("physical-check/lab/{id}/remark")]
        public async Task<ActionResult<IEnumerable<VendorsPhysicalCheckLabsRemark>>> GetVendorsPhysicalCheckLabsRemark(int id)
        {
            return await _context.VendorsPhysicalCheckLabsRemarks
                           .Where(s => s.PhysicalCheckLabId == id)
                           .OrderByDescending(x => x.CreatedAt)
                           .ToListAsync();
        }

        [HttpGet("physical-check/lab/remark/{id}")]
        public async Task<ActionResult<VendorsPhysicalCheckLabsRemark>> GetVendorsPhysicalCheckLabsRemarkById(int id)
        {
            var data = await _context.VendorsPhysicalCheckLabsRemarks.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("physical-check/lab/remark/add")]
        public async Task<ActionResult<VendorsPhysicalCheckLabsRemark>> AddVendorsPhysicalCheckLabsRemark(VendorsPhysicalCheckLabsRemark data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.VendorsPhysicalCheckLabsRemarks.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("physical-check/lab/remark/update")]
        public async Task<IActionResult> UpdateVendorsPhysicalCheckLabsRemark(VendorsPhysicalCheckLabsRemark data)
        {
            var valid = await _context.VendorsPhysicalCheckLabsRemarks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }
            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("physical-check/lab/remark/{id}/delete")]
        public async Task<IActionResult> VendorsPhysicalCheckLabsRemarkDelete(int id)
        {
            var data = await _context.VendorsPhysicalCheckLabsRemarks.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.VendorsPhysicalCheckLabsRemarks.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("settlement/sub/redesign/confirmed/{id}")]
        public async Task<ActionResult<VendorSettlementSubRedesignConfirm>> GetVendorSettlementSubRedesignConfirmById(long id)
        {
            var validData = await _context.VendorsSettlementSubRedesigns.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);


            if (validData == null)
            {
                return NoContent();
            }

            var list = await _manualDbContext.VendorSettlementSubRedesignConfirms
                                .FromSqlRaw("exec [dbo].[sp_get_settlement_sub_redesign_confirm] {0}", validData?.SettlementSubId)
                                .ToListAsync();
            var data = list.FirstOrDefault(x => x.Id == id);
            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("settlement/sub/{id}/redesign/confirmed")]
        public async Task<ActionResult<IEnumerable<VendorSettlementSubRedesignConfirm>>> GetVendorSettlementSubRedesignConfirm(int id)
        {
            return await _manualDbContext.VendorSettlementSubRedesignConfirms
                                .FromSqlRaw("exec [dbo].[sp_get_settlement_sub_redesign_confirm] {0}", id)
                                .ToListAsync();
        }

        [HttpPost("settlement/sub/redesign/confirmed/add")]
        public async Task<ActionResult<VendorsSettlementSubRedesign>> SettlementSubItemRedesignAdd(VendorsSettlementSubRedesign data)
        {


            var settlement = await _context.VendorsSettlementSubs.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.SettlementSubId);

            if (settlement == null)
            {
                return BadRequest(new ApiResponse("failed", "Settlement Sub Id not found!"));
            }

            var contract = await _context.VendorsContracts.AsNoTracking().FirstOrDefaultAsync(x => x.Id == settlement.ContractId);

            if (contract != null && contract.CostTypeId != 1)
            {
                return BadRequest(new ApiResponse("failed", "Contract Sub Id not found!"));
            }

            var isExist = await _context.VendorsSettlementSubRedesigns.AnyAsync(x => x.SettlementSubId == data.SettlementSubId && x.HouseId == data.HouseId);

            if (isExist)
            {
                return BadRequest(new ApiResponse("failed", "House Number confirm already!", "400"));
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            _context.VendorsSettlementSubRedesigns.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("settlement/sub/redesign/confirmed/update")]
        public async Task<IActionResult> SettlementSubUpdate(VendorsSettlementSubRedesign data)
        {
            var valid = await _context.VendorsSettlementSubRedesigns.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            var settlement = await _context.VendorsSettlementSubs.FirstOrDefaultAsync(x => x.Id == data.SettlementSubId);

            if (settlement == null)
            {
                return BadRequest(new ApiResponse("failed", "Settlement Sub Id not found!"));
            }


            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.SettlementSubId).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("settlement/sub/redesign/confirmed/{id}/delete")]
        public async Task<IActionResult> SettlementSubRedesignConfirmDelete(int id)
        {
            var data_delete = await _context.VendorsSettlementSubRedesigns.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.VendorsSettlementSubRedesigns.Remove(data_delete);
                await _context.SaveChangesAsync();
            }
            catch
            {
                return NoContent();
            }

            return Ok();

        }

        [HttpGet("penalties")]
        public async Task<ActionResult<IEnumerable<VVendorsPenalty>>> GetVendorPenalties([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _manualDbContext.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            try
            {
                var data = await _context.VVendorsPenalties
                          .Where(s => s.CompanyId == user.CompanySessionId && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                          s.NameKh.ToLower().Contains(filter.Search.ToLower()) ||
                          s.NameEn.ToLower().Contains(filter.Search.ToLower()) ||
                          s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                          s.ProjectShort.ToLower().Contains(filter.Search.ToLower()) ||
                          s.PenaltyCode.ToLower().Contains(filter.Search.ToLower()) ||
                          s.SettlementCode.ToLower().Contains(filter.Search.ToLower()))
                          )
                          .OrderByDescending(x => x.CreatedAt)
                          .Skip((filter.PageNumber - 1) * filter.PageSize)
                          .Take(filter.PageSize)
                          .ToListAsync();

                filter.TotalRecords = await _context.VVendorsPenalties
                               .Where(s => s.CompanyId == user.CompanySessionId && (list.Contains((short)s.ProjectId) || s.ProjectId == filter.ProId) && (String.IsNullOrEmpty(filter.Search) ||
                               s.NameKh.ToLower().Contains(filter.Search.ToLower()) ||
                               s.NameEn.ToLower().Contains(filter.Search.ToLower()) ||
                               s.VendorCategory.ToLower().Contains(filter.Search.ToLower()) ||
                               s.ProjectShort.ToLower().Contains(filter.Search.ToLower()) ||
                               s.PenaltyCode.ToLower().Contains(filter.Search.ToLower()) ||
                               s.SettlementCode.ToLower().Contains(filter.Search.ToLower()))
                               )
                               .CountAsync();

                return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("penalties/{id}")]
        public async Task<ActionResult<VVendorsPenalty>> GetVendorPenaltiesById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VVendorsPenalties.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }


            return data;
        }

        [HttpPost("penalties/add")]
        public async Task<ActionResult<VendorsPenalty>> VendorPenaltiesAdd(VendorsPenalty data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var project = _context.VDbliveProjects.First(x => x.Id == data.ProjectId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);
            var suffix = "/" + year + "-" + project;

            var getMax = await _context.VendorsPenalties.Where(x => x.CompanyId == user.CompanySessionId && x.PenaltyCode.EndsWith(suffix)).MaxAsync(x => x.PenaltyCode);


            if (getMax != null)
            {
                getMax = getMax.Replace("PCO:", "").Replace(suffix, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.PenaltyCode = "PCO:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + suffix;
            }
            else
            {
                data.PenaltyCode = "PCO:" + "00001" + suffix;
            }

            if (data.VendorCategory == "Labor")

            {
                data.VendorId = null;
            }

            //var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = 1;

            data.CompanyId = user.CompanySessionId;

            _context.VendorsPenalties.Add(data);


            try
            {

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec dbo.sp_generate_vendor_penalty_cost_center {0}", data.Id);

                    ts.Complete();
                }

                return data;
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }


        }

        [HttpPut("penalties/update")]
        public async Task<IActionResult> VendorPenaltiesUpdate(VendorsPenalty data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsPenalties.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;

            if (valid.ProjectId != data.ProjectId)
            {
                var project = _context.VProjects.First(x => x.Id == data.ProjectId).ProjectCode.Substring(1, 2);
                var year = DateTime.Now.Year.ToString().Substring(2, 2);
                var suffix = "/" + year + "-" + project;

                var getMax = await _context.VendorsPenalties.Where(x => x.CompanyId == user.CompanySessionId && x.PenaltyCode.EndsWith(suffix)).MaxAsync(x => x.PenaltyCode);

                if (getMax != null)
                {
                    getMax = getMax.Replace("PCO:", "").Replace(suffix, "");
                    var maxNumber = Regex.Match(getMax, @"\d+").Value;
                    data.PenaltyCode = "PCO:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + suffix;
                }
                else
                {
                    data.PenaltyCode = "PCO:" + "00001" + suffix;
                }
            }
            else
            {
                _context.Entry(data).Property(x => x.PenaltyCode).IsModified = false;
            }

            //var _auth = new CustomUserIdentity(User);

            if (data.VendorCategory == "Labor")

            {
                data.VendorId = null;
            }

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("penalties/approved/{id}")]
        public async Task<IActionResult> VendorPenaltiesUpdate(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsPenalties.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if (valid.RecStatus == 3)
            {
                return BadRequest(new ApiResponse("failed", "This penalty is already approved!", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.RecStatus = 3;

            try
            {

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_approve_penalty] {0}", id);

                    ts.Complete();
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

        }

        [HttpDelete("penalties/{id}/delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.VendorsPenalties.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if (valid.RecStatus == 3)
            {
                return BadRequest(new ApiResponse("failed", "This penalty is already approved!", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            //var _auth = new CustomUserIdentity(User);

            valid.Status = 0;

            valid.UpdatedAt = DateTime.Now;

            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("penalty/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeletePenaltyAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.vendors_penalties", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("penalties/covers")]
        public async Task<ActionResult<IEnumerable<VVendorsPenaltiesCover>>> GetAllVendorPenaltySubterm()
        {
            return await _context.VVendorsPenaltiesCovers
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("penalties/covers/{id}")]
        public async Task<ActionResult<VVendorsPenaltiesCover>> GetVendorPenaltySubtermsById(int id)
        {
            var data = await _context.VVendorsPenaltiesCovers.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpGet("penalties/{id}/covers")]
        public async Task<ActionResult<IEnumerable<VVendorsPenaltiesCover>>> GetVendorPenaltySubterms(int id)
        {
            return await _context.VVendorsPenaltiesCovers
                           .Where(s => s.VendorPenaltyId == id)
                           .OrderByDescending(x => x.CreatedAt)
                           .ToListAsync();
        }

        [HttpPost("penalties/covers/add")]
        public async Task<ActionResult<VendorsPenaltiesCover>> AddVendorPenaltySubterm(VendorsPenaltiesCover data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.VendorsPenaltiesCovers.Add(data);
            try
            {
                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {

                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw(@"exec [dbo].[sp_generate_vendor_penalty_labor_cost_center] {0}", data.Id);

                    await _context.SaveChangesAsync();

                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return data;
        }

        [HttpPut("penalties/covers/update")]
        public async Task<IActionResult> UpdateVendorPenaltySubterm(VendorsPenaltiesCoverInput input)
        {
            var data = input.PenaltiesCover;

            var costCenter = input.CostCenter;

            var valid = await _context.VendorsPenaltiesCovers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);


            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;
            try
            {
                decimal? totalAmountCostCenter = costCenter.Sum(x => x.Amount);
                var costCenterList = await _context.VendorsPenaltiesCoversCostCenters
                    .AsNoTracking()
                    .Where(x => x.PenaltyCoverId == data.Id && x.Status == true)
                    .ToListAsync();

                var records = new List<VendorsPenaltiesCoversCostCenter>();

                if (records.Count < 0)
                {
                    return BadRequest(new ApiResponse("failed", $"The amount allocated to the cost center does not match the amount claimed!"));
                }

                foreach (var item in costCenter)
                {
                    if (records.Any(x => (x.CostCenterId == null)))
                    {
                        return BadRequest(new ApiResponse("failed", "The cost center is invalid"));
                    }

                    if (records.Any(x => (x.Amount == 0 || x.Amount == null)))
                    {
                        return BadRequest(new ApiResponse("failed", "The cost center amount invalid"));
                    }

                    if (records.Any(x => x.CostCenterId == item.CostCenterId))
                    {
                        return BadRequest(new ApiResponse("failed", "The cost center already exists."));
                    }

                    records.Add(new VendorsPenaltiesCoversCostCenter
                    {
                        CostCenterId = item.CostCenterId,
                        PenaltyCoverId = item.PenaltyCoverId,
                        Amount = item.Amount,
                        Status = true,
                        CreatedAt = DateTime.Now,
                        CreatedBy = _auth.Id
                    });
                }

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {

                    await _context.SaveChangesAsync();

                    if (data.Amount != totalAmountCostCenter)
                    {
                        return BadRequest(new ApiResponse("failed", $"The amount allocated to the cost center does not match the amount claimed!"));
                    }


                    _context.VendorsPenaltiesCoversCostCenters.RemoveRange(costCenterList);

                    _context.VendorsPenaltiesCoversCostCenters.AddRange(records);

                    await _context.SaveChangesAsync();

                    ts.Complete();
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }

            return NoContent();
        }

        [HttpDelete("penalties/covers/{id}/delete")]
        public async Task<IActionResult> VendorPenaltySubtermDelete(int id)
        {
            var data = await _context.VendorsPenaltiesCovers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            var costCenterList = await _context.VendorsPenaltiesCoversCostCenters.AsNoTracking().Where(x => x.PenaltyCoverId == id).ToListAsync();

            try
            {
                _context.VendorsPenaltiesCovers.Remove(data);

                _context.VendorsPenaltiesCoversCostCenters.RemoveRange(costCenterList);

                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("{id}/sub/contracts")]
        public async Task<ActionResult<IEnumerable<VendorContractLab>>> GetVendorContract(int id)
        {
            return await _manualDbContext.VendorContractLabs.FromSqlRaw("exec [dbo].[sp_get_contract_by] {0}", id).ToListAsync();
        }

        [HttpGet("project/{id}/sub/settlements")]
        public async Task<ActionResult<IEnumerable<MVendorSettlementSub>>> GetVendorSettlementSub(int id)
        {
            return await _manualDbContext.MVendorSettlementSubs.FromSqlRaw("exec [dbo].[sp_get_settlement_sub_project] {0}", id).ToListAsync();
        }

        [HttpPost("settlement/sub/adjustment")]
        public async Task<ActionResult<VendorsRedesignsSettlementSubItemsAdjAmount>> SettlementSubAdjustment(VendorsRedesignsSettlementSubItemsAdjAmount data)
        {
            var adj = await _context.VendorsRedesignsSettlementSubItemsAdjAmounts.SingleOrDefaultAsync(x => x.VendorsSettlementsSubId == data.VendorsSettlementsSubId);
            if (adj == null)
            {
                _context.VendorsRedesignsSettlementSubItemsAdjAmounts.Add(data);
                await _context.SaveChangesAsync();
            }
            else
            {                
                adj.AdjTotalAmount = data.AdjTotalAmount;
                adj.AdjTotalRequestAmount = data.AdjTotalRequestAmount;
                adj.AdjTotalPreopenAmount = data.AdjTotalPreopenAmount;
                adj.AdjTotalRemainAmount = data.AdjTotalRemainAmount;
                await _context.SaveChangesAsync();
                data = adj;
            }
            return data;
        }

        [HttpGet("settlement/sub/adjustment/settlementid/{vendor_settlement_id}")]
        public async Task<ActionResult<VendorsRedesignsSettlementSubItemsAdjAmount>> GetSettlementSubAdjustmentBySettlementId(int vendor_settlement_id)
        {
            var data = await _context.VendorsRedesignsSettlementSubItemsAdjAmounts.SingleOrDefaultAsync(x => x.VendorsSettlementsSubId == vendor_settlement_id);
            return data;
        }


    }
}
