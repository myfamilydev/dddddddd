﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models.Filter;
using DataAccess.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Polly;
using System.Linq.Expressions;

namespace AP_Api.Controllers.V1.AP.Special
{
	[Route("api/v1/[controller]")]
	[ApiController]
	public class SpecialPaymentController : ControllerBase
	{
		private readonly APContext _context;

		public SpecialPaymentController(APContext context)
		{
			_context = context;
		}

		[HttpGet("{typeId}/basic")]
		public async Task<IEnumerable<object>> GetVendorInfoBasicAsync(int typeId)
		{

			switch (typeId)
			{
				case 1:
					return await _context.Vendors
						.Where(x => x.RecStatus == 3 && x.VendorCategory == "Sub-Contractor")
						.Select(x => new
						{
							Value = x.Id,
							Label = x.VendorCode + " - " + x.NameEn
						}).ToListAsync();
				case 2:
					return await _context.Vendors
						.Where(x => x.RecStatus == 3 && x.VendorCategory == "Labor")
						.Select(x => new
						{
							Value = x.Id,
							Label = x.VendorCode + " - " + x.NameEn
						}).ToListAsync();


			}

			return new List<object>();
		}

		[HttpGet("{typeId}/items/basic")]
		public async Task<ActionResult<IEnumerable<Object>>> GetVendorItemsBasic(int typeId)
		{
			var _auth = new CustomUserIdentity(User);

			var user = await _context.Users.FindAsync(_auth.Id);

			switch (typeId)
			{
				case 1:
					return await _context.VendorsItems
						.Where(x => x.CompanyId == user.CompanySessionId && x.IsActive == true && x.VendorCategory == "Sub-Contractor")
						.Select(x => new
						{
							Value = x.Id,
							Label = x.ItemCode + " - " + x.ItemName
						}).ToListAsync();
				case 2:
					return await _context.VendorsItems
						.AsNoTracking()
						.Where(x => x.RecStatus == 3 && x.VendorCategory == "Labor")
						.Select(x => new
						{
							Value = x.Id,
							Label = x.ItemCode + " - " + x.ItemName
						}).ToListAsync();


			}

			return new List<object>();
		}
	}
}
