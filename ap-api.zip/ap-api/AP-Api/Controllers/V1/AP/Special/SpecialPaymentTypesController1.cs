﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AP_Api.Controllers.V1.AP.Special
{
	[Route("api/v1/[controller]")]
	[ApiController]
	public class SpecialPaymentTypesController : ControllerBase
	{
		private readonly APContext _context;

		public SpecialPaymentTypesController(APContext context)
		{
			_context = context;
		}

		[HttpGet("basic")]
		public async Task<IEnumerable<object>> GetSpecialPaymentTypeAsync()
		{
			return _context.SpecialPaymentTypes
				.Where(x => x.Status == true)
				.Select(x => new
				{
					Value = x.Id,
					Label = x.Type
				}).ToList();
		}
	}
}
