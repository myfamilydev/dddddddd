﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;
using Telegram.Bot.Types;

namespace Web.Controllers.AP
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class CleanersController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly APContext _context;
        private CustomUserIdentity _auth;

        public CleanersController(IHttpContextAccessor httpContextAccessor, APContext context)
        {
            _context = context;
        }

        [HttpGet("daily-info")]
        public async Task<ActionResult<IEnumerable<VDailyCleanerInfo>>> GetPhisicalCheckSub([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VDailyCleanerInfos
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search)
                           || s.NameKh.ToLower().Contains(filter.Search.ToLower())
                           || s.PositionKh.ToLower().Contains(filter.Search.ToLower())
                           || s.NameEn.ToLower().Contains(filter.Search.ToLower())
                           || s.PositionEn.ToLower().Contains(filter.Search.ToLower())
                           || s.Contact.ToLower().Contains(filter.Search.ToLower())
                           || s.Address.ToLower().Contains(filter.Search.ToLower())
                           || s.Code.ToLower().Contains(filter.Search.ToLower())
                           )))
                           .OrderBy(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VDailyCleanerInfos
                           .Where(s => s.CompanyId == user.CompanySessionId && ((String.IsNullOrEmpty(filter.Search)
                           || s.NameKh.ToLower().Contains(filter.Search.ToLower())
                           || s.PositionKh.ToLower().Contains(filter.Search.ToLower())
                           || s.NameEn.ToLower().Contains(filter.Search.ToLower())
                           || s.PositionEn.ToLower().Contains(filter.Search.ToLower())
                           || s.Contact.ToLower().Contains(filter.Search.ToLower())
                           || s.Address.ToLower().Contains(filter.Search.ToLower())
                           || s.Code.ToLower().Contains(filter.Search.ToLower())
                           )))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }
        [HttpGet("daily-info/basic")]
        public async Task<ActionResult<IEnumerable<VDailyCleanerInfoBasic>>> DailyInfoBasic()
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            return await _context.VDailyCleanerInfoBasics.AsNoTracking().Where(x => x.CompanyId == user.CompanySessionId).ToListAsync();
        }

        [HttpGet("daily-info/{id}")]
        public async Task<ActionResult<VDailyCleanerInfo>> GetCompany(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VDailyCleanerInfos.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("daily-info/add")]
        public async Task<ActionResult<DailyCleanerInfo>> AddCompany(DailyCleanerInfo data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.DailyCleanerInfos.Where(x =>  x.CompanyId == user.CompanySessionId && x.Code.EndsWith(year)).MaxAsync(x => x.Code);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.Code = "DC:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.Code = "DC:" + "00001" + year;
            }

            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.CompanyId = user.CompanySessionId;

            _context.DailyCleanerInfos.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("daily-info/update")]
        public async Task<IActionResult> UpdateCompany(DailyCleanerInfo data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.DailyCleanerInfos.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && user.CompanySessionId == x.CompanyId);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Code).IsModified = false;
            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;
  

            _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;

            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("daily-info/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteDailyInfoAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.daily_cleaner_info", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }


        [HttpGet("settlement")]
        public async Task<ActionResult<IEnumerable<VDailyCleanerSettlement>>> Settlement([FromQuery] PaginationFilter filter)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var list = new List<short>();

            if (filter.ProId == 0)
            {
                list = _context.VDbliveProjects
                .FromSqlRaw(@"exec [dbo].[sp_get_project_by_user] {0}", _auth.Id)
                .AsEnumerable()
                .Select(x => x.Id)
                 .ToList();
            }

            var data = await _context.VDailyCleanerSettlements
                           .Where(s => s.CompanyId == user.CompanySessionId && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                                || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                                || s.Code.ToLower().Contains(filter.Search.ToLower())
                                ))
                           .OrderBy(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.VDailyCleanerSettlements
                           .Where(s => s.CompanyId == user.CompanySessionId && (list.Contains((short)s.ProId) || s.ProId == filter.ProId) && (String.IsNullOrEmpty(filter.Search)
                           || s.ProjectShort.ToLower().Contains(filter.Search.ToLower())
                           || s.Code.ToLower().Contains(filter.Search.ToLower())
                           ))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("settlement/{id}")]
        public async Task<ActionResult<VDailyCleanerSettlement>> GetSettlementById(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.VDailyCleanerSettlements.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("settlement/add")]
        public async Task<ActionResult<DailyCleanerSettle>> AddCostCenter(DailyCleanerSettle data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.DailyCleanerSettles.Where(x => x.CompanyId == user.CompanySessionId && x.Code.EndsWith(year)).MaxAsync(x => x.Code);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.Code = "DCS:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.Code = "DCS:" + "00001" + year;
            }
            _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.RecStatus = 0;

            data.CompanyId = user.CompanySessionId;

            _context.DailyCleanerSettles.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("settlement/update")]
        public async Task<IActionResult> UpdateCostCenter(DailyCleanerSettle data)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.DailyCleanerSettles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id && x.CompanyId == user.CompanySessionId);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;
            _context.Entry(data).Property(x => x.Code).IsModified = false;
            _context.Entry(data).Property(x => x.CompanyId).IsModified = false;

            

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("settlement/approve/{id}")]
        public async Task<IActionResult> DailyCleanerApprove(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var valid = await _context.DailyCleanerSettles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            if (valid == null)
            {
                return BadRequest();
            }

            if (valid.RecStatus == 3)
            {
                return BadRequest(new ApiResponse("failed", "This penalty is already approved!", "400"));
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.RecStatus = 3;
            try
            {

                using (TransactionScope ts = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    await _context.SaveChangesAsync();

                    _context.Database.ExecuteSqlRaw("exec [dbo].[sp_approve_daily_settlement_cleaner] {0}", id);

                    ts.Complete();
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "400"));
            }
        }

        [HttpDelete("settlement/{id}/delete")]
        public async Task<IActionResult> settlementDelete(int id)
        {
            var _auth = new CustomUserIdentity(User);

            var user = await _context.Users.FindAsync(_auth.Id);

            var data = await _context.DailyCleanerSettles.FirstOrDefaultAsync(x => x.Id == id && x.CompanyId == user.CompanySessionId);

            try
            {
                _context.DailyCleanerSettles.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpDelete("settlements/{id}/delete")]
        public async Task<ActionResult<WorkflowModel>> DeleteSettlementAsync(int id)
        {
            try
            {
                await _context.Database
                .ExecuteSqlRawAsync(@"exec [dbo].[sp_execute_delete_transaction] {0},{1}", "dbo.daily_cleaner_settle", id);
            }
            catch (Exception ex)
            {
                return BadRequest(new ApiResponse("failed", ex.Message, "403"));
            }
            return Ok();
        }

        [HttpGet("settlement/{id}/houses")]
        public async Task<ActionResult<IEnumerable<VDailyCleanerSettlementHouse>>> GetSettleHouses(int id)
        {
            return await _context.VDailyCleanerSettlementHouses.Where(x => x.CleanerSettleId == id).ToListAsync();
        }

        [HttpGet("settlement/house/{id}")]
        public async Task<ActionResult<VDailyCleanerSettlementHouse>> GetSettleHouseById(int id)
        {
            var data = await _context.VDailyCleanerSettlementHouses.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("settlement/house/add")]
        public async Task<ActionResult<DailyCleanerSettleHouse>> AddSettlementHouse(DailyCleanerSettleHouse data)
        {
            var valid = await _context.DailyCleanerSettleHouses.AnyAsync(x => x.HouseId == data.HouseId && x.CleanerSettleId == data.CleanerSettleId);
            if (valid)
            {
                var house = await _context.VHousesLists.FirstOrDefaultAsync(x => x.Id == data.HouseId);
                return BadRequest(new ApiResponse("failed", "House Number " + house?.Number + " is exist!"));
            }

            try
            {
                _context.DailyCleanerSettleHouses.Add(data);
                await _context.SaveChangesAsync();
                return data;
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("settlement/house/update")]
        public async Task<IActionResult> UpdateSettleHouse(DailyCleanerSettleHouse data)
        {
            var valid = await _context.DailyCleanerSettleHouses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("settlement/house/{id}/delete")]
        public async Task<IActionResult> DeleteSettlementLabHouse(int id)
        {
            var valid = await _context.DailyCleanerSettleHouses.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }
            _context.DailyCleanerSettleHouses.Remove(valid);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("settlement/{id}/info")]
        public async Task<ActionResult<IEnumerable<VDailyCleanerSettlementInfo>>> RedesignFeeGetAll(int id)
        {
            return await _context.VDailyCleanerSettlementInfos.Where(x => x.CleanerSettleId == id).ToListAsync();
        }

        [HttpGet("settlement/info/{id}")]
        public async Task<ActionResult<VDailyCleanerSettlementInfo>> GetRedesignFeeById(int id)
        {
            var data = await _context.VDailyCleanerSettlementInfos.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("settlement/info/add")]
        public async Task<ActionResult<DailyCleanerSettleInfo>> AddRedesignFee(DailyCleanerSettleInfo data)
        {
            var _auth = new CustomUserIdentity(User);
            _context.DailyCleanerSettleInfos.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("settlement/info/update")]
        public async Task<IActionResult> UpdateSettleInfo(DailyCleanerSettleInfo data)
        {
            var valid = await _context.DailyCleanerSettleInfos.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;
            var _auth = new CustomUserIdentity(User);

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("settlement/info/{id}/delete")]
        public async Task<IActionResult> DeleteSettlementLabInfo(int id)
        {
            var valid = await _context.DailyCleanerSettleInfos.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (valid == null)
            {
                return BadRequest();
            }
            _context.DailyCleanerSettleInfos.Remove(valid);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("daily-cleaner-wages")]
        public async Task<ActionResult<IEnumerable<DailyCleanerWage>>> GetDailyCleanerWageAsync([FromQuery] PaginationFilter filter)
        {
            var data = await _context.DailyCleanerWages
                           .Where(s =>s.Status == true && (String.IsNullOrEmpty(filter.Search)
                                || s.PositionKh.ToLower().Contains(filter.Search)
                                || s.Source.ToLower().Contains(filter.Search)
                                || s.PositionEn.ToLower().Contains(filter.Search)
                                ))
                           .OrderByDescending(x => x.CreatedAt)
                           .Skip((filter.PageNumber - 1) * filter.PageSize)
                           .Take(filter.PageSize)
                           .ToListAsync();

            filter.TotalRecords = await _context.DailyCleanerWages
                           .Where(s => s.Status == true && (String.IsNullOrEmpty(filter.Search)
                                || s.PositionKh.ToLower().Contains(filter.Search)
                                || s.Source.ToLower().Contains(filter.Search)
                                || s.PositionEn.ToLower().Contains(filter.Search)
                                ))
                           .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(data, filter));
        }

        [HttpGet("daily-cleaner-wages/{id}")]
        public async Task<ActionResult<DailyCleanerWage>> GetDailyCleanerWageAsync(int id)
        {
            var data = await _context.DailyCleanerWages
                    .FirstOrDefaultAsync(x => x.Status == true && x.Id == id);

            if(data == null)
            {
                return NoContent();
            }

            return data; 
        }

        [HttpPost("daily-cleaner-wages/add")]
        public async Task<ActionResult<DailyCleanerWage>> AddDailyCleanerWageAsync(DailyCleanerWage data)
        {
            var _auth = new CustomUserIdentity(User);

            bool valid = await _context.DailyCleanerWages.AsNoTracking()
                .AnyAsync(x => (x.PositionEn.ToLower().Trim() == data.PositionEn.ToLower().Trim() && x.Status == true));

            if(valid) {
                return BadRequest(new ApiResponse("failed", "Cleaner Name Already is already exists!", "400"));
            }

            data.CreatedAt = DateTime.Now;

            data.CreatedBy = _auth.Id;

            data.Status = true;

            _context.DailyCleanerWages.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("daily-cleaner-wages/update")]
        public async Task<ActionResult<DailyCleanerWage>> UpdateDailyCleanerWageAsync(DailyCleanerWage data)
        {

            bool valid = await _context.DailyCleanerWages.AsNoTracking()
                .AnyAsync(x => (x.PositionEn.ToLower().Equals(data.PositionEn.ToLower()) && x.Status == true && data.Id != x.Id));

            if (valid)
            {
                return BadRequest(new ApiResponse("failed", "Cleaner Name Already is already exists!", "400"));
            }

            valid = await _context.DailyCleanerWages.AsNoTracking()
                .AnyAsync(x => (x.Status == true && data.Id == x.Id));

            if(!valid)
            {
                return BadRequest(new ApiResponse("failed", "data doesn't exist!", "400"));
            }

            _context.Entry(data).State = EntityState.Modified;

            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;

            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            _context.Entry(data).Property(x => x.Status).IsModified = false;

            try
            {
                await _context.SaveChangesAsync();

                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("daily-cleaner-wages/{id}/delete")]
        public async Task<IActionResult> DeleteDailyCleanerWageAsync(int id)
        {
            var valid = await _context.DailyCleanerWages.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            valid.Status = false;

            await _context.SaveChangesAsync();

            return Ok();
        }

    }
}
