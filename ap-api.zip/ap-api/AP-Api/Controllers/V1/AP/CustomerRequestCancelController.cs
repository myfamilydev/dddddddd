﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class CustomerRequestCancelController : ControllerBase
    {
        private readonly APContext _context;

        public CustomerRequestCancelController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VCustomerRequestCancel>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VCustomerRequestCancels
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Project == validFilter.Search || s.HouseNumber == validFilter.Search))
                               )
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VCustomerRequestCancels
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Project == validFilter.Search || s.HouseNumber == validFilter.Search)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<WorkflowModel>> GetById(int id)
        {
            var data = await _context.VCustomerRequestCancels.FirstOrDefaultAsync(x => x.Id == id);
            var _auth = new CustomUserIdentity(User);

            if (data == null)
            {
                return NoContent();
            }

            WorkflowDetailModel wf = new WorkflowDetailModel("arch.customer_request_cancel", data.Id, _auth.Id, 0);
            wf.workflowModel.Data = data;

            return wf.workflowModel;

        }

        [HttpPost("add")]
        public async Task<ActionResult<CustomerRequestCancel>> Add(CustomerRequestCancel data)
        {
            string year = "/" + DateTime.Now.ToString("yy");
            var getMax = await _context.CustomerRequestCancels.Where(x => x.CancelCode.EndsWith(year)).MaxAsync(x => x.CancelCode);

            if (getMax != null)
            {
                getMax = getMax.Replace(@"\w+:", "").Replace(year, "");
                var maxNumber = Regex.Match(getMax, @"\d+").Value;
                data.CancelCode = "RC:" + (Convert.ToInt32(maxNumber) + 1).ToString("D5") + year;
            }
            else
            {
                data.CancelCode = "RC:" + "00001" + year;
            }

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;
            data.RecStatus = 0;
           

            _context.CustomerRequestCancels.Add(data);
            await _context.SaveChangesAsync();
            new WorkflowDetailModel().WorkflowHistoryDraft("arch.customer_request_cancel", data.Id, _auth.Id);
            

            return data;
        }

        [Authorize]
        [HttpPost("webhook/inactive/{id}")]
        public async Task WebhookInactiveCustomerRequest(int id)
        {
            try
            {
                var _data = await _context.CustomerRequestCancels
                                                .FirstOrDefaultAsync(x => x.Id == id && x.Status == 1);
                var data = await _context.CustomerRequests
                                                .FirstOrDefaultAsync(x => x.Id == _data.CustomerRequestId && x.Status == 1);
                _context.Entry(data).State = EntityState.Modified;
                data.Status = 0;
                data.UpdatedAt = DateTime.Now;
                data.UpdatedBy = 116;
                await _context.SaveChangesAsync();
            }
            catch
            {

            }
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(CustomerRequestCancel data)
        {
            var valid = await _context.CustomerRequestCancels.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CancelCode).IsModified = false;
            _context.Entry(data).Property(x => x.RecStatus).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(data);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> UpdateStatus(CustomerRequestCancel data)
        {
            var valid = await _context.CustomerRequestCancels.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
