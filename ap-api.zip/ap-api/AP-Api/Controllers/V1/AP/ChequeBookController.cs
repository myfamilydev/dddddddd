﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using System.Transactions;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ChequeBookController : ControllerBase
    {
        private readonly APContext _context;

        public ChequeBookController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<VChequeBook>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.VChequeBooks
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.BankNameKh.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.ProjectShort.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankNameEn.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountNumber.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.VChequeBooks
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search)
                                    || s.BankNameKh.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.ProjectShort.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankNameEn.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountName.ToLower().Contains(validFilter.Search.ToLower())
                                    || s.BankAccountNumber.ToLower().Contains(validFilter.Search.ToLower())
                                    )))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter)); 
            
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<VChequeBook>> GetById(int id)
        {
            var data = await _context.VChequeBooks.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<ChequeBook>> Add(ChequeBook data)
        {
            var project = _context.VDbliveProjects.First(x => x.Id == data.ProjectId).ProjectCode.Substring(1, 2);
            var year = DateTime.Now.Year.ToString().Substring(2, 2);
            var suffix = "/" + year + "-" + project;

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.ChequeBooks.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(ChequeBook data)
        {
            var valid = await _context.ChequeBooks.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("{id}/delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await _context.ChequeBooks.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.ChequeBooks.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

        [HttpGet("Subterms")]
        public async Task<ActionResult<IEnumerable<VChequeBookSubterm>>> GetAllSubterms()
        {
            return await _context.VChequeBookSubterms
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("Subterms/{id}")]
        public async Task<ActionResult<VChequeBookSubterm>> GetSubtermsById(int id)
        {
            var data = await _context.VChequeBookSubterms.FirstOrDefaultAsync(x => x.Id == id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("Subterms/add")]
        public async Task<ActionResult<ChequeBookSubterm>> AddSubterms(ChequeBookSubterm data)
        {

            var _auth = new CustomUserIdentity(User);
            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.ChequeBookSubterms.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("Subterms/update")]
        public async Task<IActionResult> UpdateSubterms(ChequeBookSubterm data)
        {
            var valid = await _context.ChequeBookSubterms.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(data).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpDelete("Subterms/{id}/delete")]
        public async Task<IActionResult> SubtermsDelete(int id)
        {
            var data = await _context.ChequeBookSubterms.FirstOrDefaultAsync(x => x.Id == id);

            try
            {
                _context.ChequeBookSubterms.Remove(data);
                await _context.SaveChangesAsync();
            }
            catch
            {
                if (data == null)
                {
                    return NoContent();
                }

                throw;
            }

            return Ok();

        }

    }
}
