﻿using DataAccess.DBcontext;
using DataAccess.Entities;
using DataAccess.Models;
using DataAccess.Models.Filter;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AP_Api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class DelegateCustomerController : ControllerBase
    {
        private readonly APContext _context;

        public DelegateCustomerController(APContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<DelegateCustomer>>> GetAll([FromQuery] PaginationFilter filter)
        {
            var validFilter = new PaginationFilter(filter.PageNumber, filter.PageSize, filter.Search);

            var pagedData = _context.DelegateCustomers
                               .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Name == validFilter.Search )) && s.Status==1
                               )
                               .OrderByDescending(s => s.CreatedAt)
                               .Skip((validFilter.PageNumber - 1) * validFilter.PageSize)
                               .Take(validFilter.PageSize)
                               .ToList();

            validFilter.TotalRecords =
                await _context.DelegateCustomers
                                .Where(s => (
                                    (String.IsNullOrEmpty(filter.Search) || s.Name == validFilter.Search)
                               ))
                                .CountAsync();

            return Ok(new PagedResponse<IEnumerable<object>>(pagedData, validFilter));

        }

        [HttpGet("{id}")]
        public async Task<ActionResult<DelegateCustomer>> GetById(int id)
        {
            var data = await _context.DelegateCustomers.FindAsync(id);

            if (data == null)
            {
                return NoContent();
            }

            return data;
        }

        [HttpPost("add")]
        public async Task<ActionResult<DelegateCustomer>> Add(DelegateCustomer data)
        {

            var _auth = new CustomUserIdentity(User);

            data.CreatedAt = DateTime.Now;
            data.CreatedBy = _auth.Id;
            data.Status = 1;

            _context.DelegateCustomers.Add(data);

            await _context.SaveChangesAsync();

            return data;
        }

        [HttpPut("update")]
        public async Task<IActionResult> Update(DelegateCustomer data)
        {
            var valid = await _context.DelegateCustomers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            data.Id = valid.Id;
            _context.Entry(data).State = EntityState.Modified;
            _context.Entry(data).Property(x => x.Status).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedBy).IsModified = false;
            _context.Entry(data).Property(x => x.CreatedAt).IsModified = false;

            var _auth = new CustomUserIdentity(User);

            data.UpdatedAt = DateTime.Now;
            data.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }

        [HttpPut("update/status")]
        public async Task<IActionResult> InactiveStatus(DelegateCustomer data)
        {
            var valid = await _context.DelegateCustomers.FirstOrDefaultAsync(x => x.Id == data.Id);
            if (valid == null)
            {
                return BadRequest();
            }

            _context.Entry(valid).State = EntityState.Modified;

            var _auth = new CustomUserIdentity(User);

            valid.Status = data.Status;
            valid.UpdatedAt = DateTime.Now;
            valid.UpdatedBy = _auth.Id;

            try
            {
                await _context.SaveChangesAsync();
                return Ok(valid);
            }
            catch (DbUpdateConcurrencyException)
            {

            }

            return NoContent();
        }
    }
}
