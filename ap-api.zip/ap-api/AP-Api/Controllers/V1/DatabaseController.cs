﻿using AP_Api.Helpers;
using DataAccess.dbcontext;
using DataAccess.DBcontext;
using DataAccess.LHDEntities;
using DataAccess.Models;
using EntityFrameworkCore.RawSQLExtensions.SqlQuery;
using Google.Protobuf.WellKnownTypes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.Scripting;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Linq;

namespace AP_Api.Controllers.V1
{
	[Route("api/v1/[controller]")]
	[ApiController]
	[Authorize]
	public class DatabaseController : ControllerBase
	{
		//private readonly APContextSource _aPContextSource;
		//private readonly ManualDbContext _manualDbContext;
		//private readonly LHDContext _lHDContext;
		private readonly IServiceScopeFactory serviceScopeFactory;
		public DatabaseController(IServiceScopeFactory serviceScopeFactory)
		{
			//_aPContextSource = aPContextSource;
			//_manualDbContext = manualDbContext;
			//_lHDContext = lHDContext;
			this.serviceScopeFactory = serviceScopeFactory;
		}

		[HttpPost("syncAllSqlFn")]
		public async Task<IActionResult> SyncAllSqlFn()
		{
			var _auth = new CustomUserIdentity(User);

			Task.Run(() => BgTask(serviceScopeFactory, _auth.Id));

			return Ok();
		}

		private async Task BgTask(IServiceScopeFactory serviceScopeFactory, int userId)
		{
			using (var scope = serviceScopeFactory.CreateScope())
			{
				var _lHDContext = scope.ServiceProvider.GetService<LHDContext>();
				var _aPContextSource = scope.ServiceProvider.GetService<APContextSource>();
				var _manualDbContext = scope.ServiceProvider.GetService<ManualDbContext>();

				var source = _aPContextSource.Database.GetDbConnection().Database;
				var destination = _manualDbContext.Database.GetDbConnection().Database;

				string[] includes = { "dbo", "arch", "report", "log" };

				var excluseProcedures = await _lHDContext.ExcluseProcedures.Select(x => x.ExcluseName).ToArrayAsync();

				var functions = _aPContextSource.ExecuteQuery("SELECT * FROM sys.objects WHERE type_desc LIKE '%FUNCTION%'").AsEnumerable().Select(x => (x["name"] ?? "").ToString().Trim()).ToList();
				var existFunctions = _manualDbContext.ExecuteQuery("SELECT * FROM sys.objects WHERE type_desc LIKE '%FUNCTION%'").AsEnumerable().Select(x => (x["name"] ?? "").ToString().Trim()).ToList();

				var storedProcedures = _aPContextSource.ExecuteQuery("SELECT t1.name, t2.name [schema] FROM sys.objects t1 inner join sys.schemas t2 on t1.schema_id=t2.schema_id WHERE type_desc LIKE '%PROCEDURE%'")
					.AsEnumerable().Select(x => x["schema"] + "." + (x["name"] ?? "").ToString().Trim()).ToList();

				var existStoredProcedures = _manualDbContext.ExecuteQuery("SELECT t1.name, t2.name [schema] FROM sys.objects t1 inner join sys.schemas t2 on t1.schema_id=t2.schema_id WHERE type_desc LIKE '%PROCEDURE%'").AsEnumerable().Select(x => x["schema"] + "." + (x["name"] ?? "").ToString().Trim()).ToList();


				foreach (var function in functions)
				{
					var scriptError = "";
					try
					{
						var fnLines = _aPContextSource.ExecuteQuery($"EXEC sp_helptext {function}").AsEnumerable()
						.Select(x => x["Text"]).ToArray();
						var textScript = string.Join("", fnLines.ToArray());
						textScript = textScript.ReplaceIgnoreCase("CREATE FUNCTION", "");
						scriptError = textScript;

						if (existFunctions.Contains(function))
						{
							var createFunctionScript = $"ALTER FUNCTION {Environment.NewLine}{textScript}";
							_manualDbContext.Database.ExecuteSqlRaw(createFunctionScript);

							SyncLog syncLog = new SyncLog();

							syncLog.ExecuteName = function;
							syncLog.Source = source;
							syncLog.Script = createFunctionScript;
							syncLog.Destination = destination;
							syncLog.CreatedBy = userId;
							syncLog.CreatedAt = DateTime.Now;
							syncLog.Type = "success";
							syncLog.ScriptType = "Function";
							_lHDContext.SyncLogs.Add(syncLog);
							_lHDContext.SaveChanges();
						}
						else
						{
							var createFunctionScript = $"CREATE FUNCTION {Environment.NewLine}{textScript}";
							_manualDbContext.Database.ExecuteSqlRaw(createFunctionScript);
							SyncLog syncLog = new SyncLog();

							syncLog.ExecuteName = function;
							syncLog.Source = source;
							syncLog.Script = createFunctionScript;
							syncLog.Destination = destination;
							syncLog.CreatedBy = userId;
							syncLog.CreatedAt = DateTime.Now;
							syncLog.Type = "success";
							syncLog.ScriptType = "Function";
							_lHDContext.SyncLogs.Add(syncLog);
							_lHDContext.SaveChanges();
						}
					}
					catch (Exception ex)
					{
						SyncLog syncLog = new SyncLog();

						syncLog.ExecuteName = function;
						syncLog.Source = source;
						syncLog.Script = scriptError;
						syncLog.Destination = destination;
						syncLog.CreatedBy = userId;
						syncLog.CreatedAt = DateTime.Now;
						syncLog.Type = "error";
						syncLog.ScriptType = "Function";
						_lHDContext.SyncLogs.Add(syncLog);
						_lHDContext.SaveChanges();
					}

				}

				storedProcedures = storedProcedures.Where(x => !excluseProcedures.Contains(x)).ToList();

				foreach (var storedProcedure in storedProcedures)
				{
					var scriptError = "";

					try
					{
						var fnLines = _aPContextSource.ExecuteQuery($"EXEC sp_helptext '{storedProcedure}'").Select(x => x["Text"]).ToArray();
						var textScript = string.Join("", fnLines.ToArray());
						textScript = textScript.ReplaceIgnoreCase("CREATE PROCEDURE", "");
						scriptError = textScript;

						if (existStoredProcedures.Contains(storedProcedure))
						{
							var createFunctionScript = $"ALTER PROCEDURE  {Environment.NewLine}{textScript}";
							_manualDbContext.Database.ExecuteSqlRaw(createFunctionScript);
							SyncLog syncLog = new SyncLog();

							syncLog.ExecuteName = storedProcedure;
							syncLog.Source = source;
							syncLog.Script = createFunctionScript;
							syncLog.Destination = destination;
							syncLog.CreatedBy = userId;
							syncLog.CreatedAt = DateTime.Now;
							syncLog.Type = "success";
							syncLog.ScriptType = "Procedure";
							_lHDContext.SyncLogs.Add(syncLog);
							_lHDContext.SaveChanges();
						}
						else
						{
							var createFunctionScript = $"CREATE PROCEDURE  {Environment.NewLine}{textScript}";
							_manualDbContext.Database.ExecuteSqlRaw(createFunctionScript);
							SyncLog syncLog = new SyncLog();

							syncLog.ExecuteName = storedProcedure;
							syncLog.Source = source;
							syncLog.Script = createFunctionScript;
							syncLog.Destination = destination;
							syncLog.CreatedBy = userId;
							syncLog.CreatedAt = DateTime.Now;
							syncLog.Type = "success";
							syncLog.ScriptType = "Procedure";
							_lHDContext.SyncLogs.Add(syncLog);
							_lHDContext.SaveChanges();
						}
					}
					catch (Exception ex)
					{
						SyncLog syncLog = new SyncLog();

						syncLog.ExecuteName = storedProcedure;
						syncLog.Source = source;
						syncLog.Script = scriptError;
						syncLog.Destination = destination;
						syncLog.CreatedBy = userId;
						syncLog.CreatedAt = DateTime.Now;
						syncLog.Type = "error";
						syncLog.ScriptType = "Procedure";
						_lHDContext.SyncLogs.Add(syncLog);
						_lHDContext.SaveChanges();
					}


				}


				var views = _aPContextSource.ExecuteQuery("SELECT * FROM INFORMATION_SCHEMA.VIEWS")
					.AsEnumerable().Select(x => new { Name = x["TABLE_SCHEMA"] + "." + (x["TABLE_NAME"] ?? "").ToString().Trim(), ViewScript = x["VIEW_DEFINITION"] }).ToList();

				var existViews = _manualDbContext.ExecuteQuery("SELECT * FROM INFORMATION_SCHEMA.VIEWS").AsEnumerable().Select(x => x["TABLE_SCHEMA"] + "." + (x["TABLE_NAME"] ?? "").ToString().Trim()).ToList();


				foreach (var view in views)
				{

					try
					{
						var textScript = view.ViewScript.ToString().ReplaceIgnoreCase("CREATE VIEW", "");
						if (existViews.Contains(view.Name))
						{
							var createFunctionScript = $"ALTER VIEW  {Environment.NewLine}{textScript}";
							_manualDbContext.Database.ExecuteSqlRaw(createFunctionScript);
							SyncLog syncLog = new SyncLog();

							syncLog.ExecuteName = view.Name;
							syncLog.Source = source;
							syncLog.Script = createFunctionScript;
							syncLog.Destination = destination;
							syncLog.CreatedBy = userId;
							syncLog.CreatedAt = DateTime.Now;
							syncLog.Type = "success";
							syncLog.ScriptType = "View";
							_lHDContext.SyncLogs.Add(syncLog);
							_lHDContext.SaveChanges();
						}
						else
						{
							var createFunctionScript = $"CREATE VIEW  {Environment.NewLine}{textScript}";
							_manualDbContext.Database.ExecuteSqlRaw(createFunctionScript);
							SyncLog syncLog = new SyncLog();

							syncLog.ExecuteName = view.Name;
							syncLog.Source = source;
							syncLog.Script = createFunctionScript;
							syncLog.Destination = destination;
							syncLog.CreatedBy = userId;
							syncLog.CreatedAt = DateTime.Now;
							syncLog.Type = "success";
							syncLog.ScriptType = "View";
							_lHDContext.SyncLogs.Add(syncLog);
							_lHDContext.SaveChanges();
						}
					}
					catch
					{
						SyncLog syncLog = new SyncLog();

						syncLog.ExecuteName = view.Name;
						syncLog.Source = source;
						syncLog.Script = view.ViewScript.ToString();
						syncLog.Destination = destination;
						syncLog.CreatedBy = userId;
						syncLog.CreatedAt = DateTime.Now;
						syncLog.Type = "error";
						syncLog.ScriptType = "View";
						_lHDContext.SyncLogs.Add(syncLog);
						_lHDContext.SaveChanges();
					}
				}
			}
		}
	}
}


