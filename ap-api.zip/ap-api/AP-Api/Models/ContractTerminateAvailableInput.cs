﻿namespace AP_Api.Models
{
    public class ContractTerminateAvailableInput
    {
        public string Category { get; set; }

        public int ProjectId { get; set; }
    }
}