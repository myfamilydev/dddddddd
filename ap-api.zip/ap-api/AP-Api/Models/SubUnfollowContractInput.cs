﻿namespace AP_Api.Models
{
    public class SubUnfollowContractInput
    {
        public int ItemId { get; set; }

		public int ContractId { get; set; }

    }
}