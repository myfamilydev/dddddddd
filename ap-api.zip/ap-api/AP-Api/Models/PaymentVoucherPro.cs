﻿namespace AP_Api.Models
{
    public class PaymentVoucherPro
    {
        public int ProId { get; set; }

        public string SettleIds { get; set; } = string.Empty;
    }
}