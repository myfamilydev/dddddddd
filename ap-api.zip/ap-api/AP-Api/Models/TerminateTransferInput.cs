﻿namespace AP_Api.Models
{
    public class TerminateTransferInput
    {
        public int VendorId { get; set; }

        public int[]? TerminateHouses { get; set; }
    }

    public class TerminateTransferHouseInput
    {
        public int TerminateCoverId { get; set; }

        public int[] HouseIds { get; set; }
    }
}