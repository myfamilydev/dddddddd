﻿using DataAccess.Entities;

namespace AP_Api.Models
{
	public class VendorsSettlementSubItemInput
	{
		public VendorsSettlementSubItem SubItem { get; set; }

		public IEnumerable<VendorsSettlementSubCostCenter> CostCenter { get; set; }
	}
}
