﻿namespace AP_Api.Models
{

    public class DbNotificationCount
    {
        public int NotificationCount { get; set; } = 0;
    }
}
