﻿using DataAccess.Entities;

namespace AP_Api.Models
{
    public class VendorsPenaltiesCoverInput
    {
		public VendorsPenaltiesCover PenaltiesCover { get; set; }

		public IEnumerable<VendorsPenaltiesCoversCostCenter> CostCenter { get; set; }
	}
}