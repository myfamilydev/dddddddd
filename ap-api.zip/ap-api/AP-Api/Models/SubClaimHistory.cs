﻿namespace AP_Api.Models
{
    public class SubClaimHistory
    {
        public int PriceItemId { get; set; }

		public int HouseId { get; set; }

		public int SettlementSubId { get; set;}
    }
}