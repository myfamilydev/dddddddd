﻿namespace AP_Api.Models
{
    public class SubContractBasic
    {
		public int? ProjectId { get; set; }

		public int? VendorId { get; set; }

        public int? ItemId { get; set;}
    }
}