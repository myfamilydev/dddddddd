﻿namespace AP_Api.Models
{
    public class CloneVoucherInput
    {
        public long Id { get; set; }
	    public decimal Amount { get; set; }
	}
}