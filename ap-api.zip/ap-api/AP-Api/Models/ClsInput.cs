﻿using DataAccess.Entities;

namespace AP_Api.Models
{
    public class ClsInput
    {

    }

    public class ClsAvailableCheque
    {
        public string ChequeRef { get; set; } = null;

        public int? Id { get; set; } = null;
    }

    public class ClsAvailableRefCode
    {
        public string RefCode { get; set; } = null;

        public int? Id { get; set; } = null;
    }

    public class ClsAvailablePVRef
    {

        public string PvRef { get; set; } = null;

        public int? Id { get; set; } = null;
    }

    public class ClsAvailableAccountCode
    {

        public string AccountCode { get; set; } = null;

        public int? Id { get; set; } = null;
    }

    public class ClsManualReportAll { 

        public string Ownership { get; set; } = null;

        public DateTime Date { get; set; }
    }
    
    public class ClsBankInput
    {
        public Bank Bank { get; set; }

        public List<int>? ChildrenIds { get; set; }
    }

	public class ClsCashFilterInput
	{
		public int BankId { get; set; }

		public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }

	public class ClsVoucherOrPettyCashInput
	{
		public int Id { get; set; }

        public string Type { get; set; }

		public string PvRef { get; set; }
	}

    public class ClsVoucherReverseChequeInput
    {
        public int Id { get; set; }

        public string Type { get; set; }

        public string ChequeRef { get; set; }
    }

    public class ClsSummaryCashFilterInput
    {
        public string Ownership { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }

    public class ClsDailyCashFlowInput
    {
        public string Ownership { get; set; }

        public DateTime Date { get; set; }
    }

    public class ClsSSOLogin
    {
        public string Username { get; set; }

        public string Email { get; set; }

        public string Token { get; set; }
    }
}
