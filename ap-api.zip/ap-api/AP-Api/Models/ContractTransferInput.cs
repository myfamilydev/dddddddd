﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;

namespace AP_Api.Models
{
    public class ContractTransferInput
    {
        public VendorsContractsTerminationsCover TerminationsCover { set; get; }

        public List<TerminateCoverTransferInput> TransferInput { get; set; }
	}

    public class TerminateCoverTransferInput
    {
		[Column("id")]
		public int Id { get; set; }
		[Column("terminate_cover_id")]
		public int? TerminateCoverId { get; set; }
		[Column("vendor_id")]
		public int? VendorId { get; set; }
		[Column("amount", TypeName = "decimal(15, 2)")]
		public decimal? Amount { get; set; }
		[Column("contract_po")]
		public string? ContractPO { get; set; }
		[Column("allow_edit_contract")]
		public bool? AllowEditContract { get; set; } = false;

		public List<int> HouseIds { get; set; }
	}
}