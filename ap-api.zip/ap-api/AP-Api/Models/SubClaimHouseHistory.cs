﻿namespace AP_Api.Models
{
    public class SubClaimHouseHistory
    {

        public int SettlementSubId { get; set; }
        public int HouseId { get; set; }

        
    }
}