﻿namespace AP_Api.Services
{
	public interface ITimeZoneService
	{
		TimeZoneInfo GetTimeZone();
	}

	public class TimeZoneService : ITimeZoneService
	{
		private readonly string _timeZoneId;

		public TimeZoneService(string timeZoneId)
		{
			_timeZoneId = timeZoneId;
		}

		public TimeZoneInfo GetTimeZone()
		{
			return TimeZoneInfo.FindSystemTimeZoneById(_timeZoneId);
		}
	}
}
