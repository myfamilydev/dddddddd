﻿using DataAccess.Models;
using Microsoft.AspNetCore.Mvc;
using RabbitMQ.Client;
using System.Text;

namespace PO_Revamp.Libraries
{
    public static class MessageQueue
    {        
        private static ConnectionFactory connectionFactory = null;

        public static void PubString(string routingKey, string message)
        {
            if (connectionFactory == null){
                connectionFactory = new ConnectionFactory
                {
                    HostName = "172.16.1.88",
                    UserName = "ap_queue",
                    Password = "ad@min2022",
                    Port = AmqpTcpEndpoint.UseDefaultPort,
                    VirtualHost = "/",
                    RequestedHeartbeat = new TimeSpan(60),
                    Ssl = { ServerName = "172.16.1.88", Enabled = false }
                };
            }

            try
            {
                using (var connection = connectionFactory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.ExchangeDeclare("apexchange.direct", ExchangeType.Direct);

                    var body = Encoding.UTF8.GetBytes(message);

                    channel.BasicPublish("apexchange.direct", routingKey, null, body);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
         
        }
    }
}
