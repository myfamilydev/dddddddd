﻿using BVMPP.ClientOauth.Models;
using System.Net.Http;
using System.Net.Http.Json;

namespace BVMPP.ClientOauth
{
    public class ClientApi
    {
        private readonly HttpClient Client = new HttpClient();

        public ClientApi(SDKConfiguration config = null)
        {
            Config = config ?? new SDKConfiguration();
        }

        public SDKConfiguration Config { get; }



        public async Task<OauthAccessToken> GetOauthAccessToken(string VerifiedCode)
        {
            var formContent = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("client_id", Config.ClienId),
            new KeyValuePair<string, string>("client_secret", Config.ClientSecret),
            new KeyValuePair<string, string>("code", VerifiedCode),
            new KeyValuePair<string, string>("grant_type", "authorization_code"),
            new KeyValuePair<string, string>("redirect_uri", Config.RedirectUri)
        });

            var response = await Client.PostAsync($"{Config.ProvideURL}/oauth/token", formContent);

            if (response.IsSuccessStatusCode == true)
            {
                return await response.Content.ReadFromJsonAsync<OauthAccessToken>();
            }
            else
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                throw new Exception($"Request failed with status code: {response.StatusCode} and error message: {errorMessage}");
            }
        }

        public async Task<OauthOwner> GetOauthOwner(string AccessToken)
        {
            Client.DefaultRequestHeaders.Add("Authorization", $"Bearer {AccessToken}");

            var response = await Client.GetAsync($"{Config.ProvideURL}/api/users/owner.json?access_token=${AccessToken}");

            if (response.IsSuccessStatusCode == true)
            {
                return await response.Content.ReadFromJsonAsync<OauthOwner>();
            }
            else
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                throw new Exception($"Request failed with status code: {response.StatusCode} and error message: {errorMessage}");
            }
        }

        public async Task<SSOAccessOwner> GetSSOAccessOwner(string VerifiedCode)
        {
            var accessToken = await GetOauthAccessToken(VerifiedCode);

            var owner = await GetOauthOwner(accessToken.access_token);

            return new SSOAccessOwner
            {
                Id = owner.id,
                Username = owner.username,
                Email = owner.email,
                AccessToken = accessToken.access_token,
                ExpiresIn = accessToken.expires_in,
                TokenType = accessToken.token_type
            };
        }

        public async Task<ResJson> SyncUser(string AccessToken, OauthUser user)
        {
            Client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AccessToken);

            var res = await Client.PostAsJsonAsync($"{Config.ProvideURL}/api/sign_up", new
            {
                user = new
                {
                    email = user.Email,
                    username = user.Username,
                    password = user.Password,
                    password_confirmation = user.Password
                }
            });

            if (res.IsSuccessStatusCode == true)
            {
                return await res.Content.ReadFromJsonAsync<ResJson>();
            }
            else
            {
                var errorMessage = await res.Content.ReadAsStringAsync();
                throw new Exception($"Request failed with status code: {res.StatusCode} and error message: {errorMessage}");
            }

        }

		public async Task<ResJsonValid> ChangePassword(string AccessToken, OauthUserPassword user)
		{
			Client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AccessToken);

			var res = await Client.PutAsJsonAsync($"{Config.ProvideURL}/api/users/change_password", new
			{
				user = new
				{
					current_password = user.CurrentPassword,
					password = user.Password,
					password_confirmation = user.Password
				}
			});

			if (res.IsSuccessStatusCode == true)
			{
				return await res.Content.ReadFromJsonAsync<ResJsonValid>();
			}
			else
			{
				var errorMessage = await res.Content.ReadAsStringAsync();
				throw new Exception($"Request failed with status code: {res.StatusCode} and error message: {errorMessage}");
			}

		}

		public async Task<ResJsonValid> ResetPassword(string AccessToken, OauthUser user, bool second = false)
        {

            //Client.DefaultRequestHeaders.Remove("Authorization");
            if (!second)
            {
                Client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AccessToken);
            }
            

            var res = await Client.PutAsJsonAsync($"{Config.ProvideURL}/api/users/reset_password?access_token={AccessToken}", new
			{
				user = new
				{
					username = user.Username,
					password = user.Password,
					password_confirmation = user.Password
				}
			});

			if (res.IsSuccessStatusCode == true)
			{
				return await res.Content.ReadFromJsonAsync<ResJsonValid>();
			}
			else
			{
				var errorMessage = await res.Content.ReadAsStringAsync();
				throw new Exception($"Request failed with status code: {res.StatusCode} and error message: {errorMessage}");
			}

		}
	}
}