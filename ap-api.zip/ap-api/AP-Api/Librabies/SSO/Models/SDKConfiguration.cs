﻿namespace BVMPP.ClientOauth.Models
{
    public class SDKConfiguration
    {
        public string ClienId { get; set; }

        public string ClientSecret { get; set; }

        public string RedirectUri { get; set; }

        public string? ProvideURL { get; set; } = "http://sso.vmpp.com";
    }
}
