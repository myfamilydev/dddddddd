﻿
namespace BVMPP.ClientOauth.Models
{
    public class OauthUserPassword
    {
        public string CurrentPassword { get; set; }
        public string Password { get; set; }
    }
}
