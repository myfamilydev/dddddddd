﻿namespace AP_Api.Librabies.Customize
{
    public class ClsCustomCategory
    {
        public  string _name { set; get; } = "";
        public string _value { set; get; } = "";
        public string _short { set; get; } = "";
    }
}
