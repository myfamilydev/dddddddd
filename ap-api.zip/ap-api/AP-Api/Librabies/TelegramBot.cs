﻿
using Newtonsoft.Json;
using System.IO;
using System;
using Telegram.Bot;

namespace DataAccess.Libraries
{
    public class TelegramConfig
    {
        public string Url { get; set; }

        public string Live { get; set; }

        public string Token { get; set; }
    }

    public class TelegramSetting
    {
        public TelegramConfig Tel { get; set; }
    }

    public class TelegramBot
    {

        public TelegramBotClient bot;

        public TelegramBot()
        {
            TelegramSetting telegramSetting;

            using (StreamReader r = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "appsettings.json"))
            {
                string json = r.ReadToEnd();

                telegramSetting = JsonConvert.DeserializeObject<TelegramSetting>(json);

                Console.WriteLine(telegramSetting.Tel.Token);

                bot = new TelegramBotClient(telegramSetting.Tel.Token);
            }


        }


    }
}
