Scaffold-DbContext Name=ConnectionStrings:APConnection Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities -Schemas arch,dbo -Context "APContext" -contextdir DBcontext -DataAnnotations -Force

--For mac
dotnet ef dbcontext Scaffold "Server=192.168.1.88\\MSSQLSERVER,1433;Database=ap_db_staging;User Id=mayura;Password=ARSystem@2021;" Microsoft.EntityFrameworkCore.SqlServer -o Entities  --context "APContext" --context-dir DBcontext --data-annotations --force

dotnet ef dbcontext Scaffold "Server=192.168.1.88\\MSSQLSERVER,1433;DatabasVExchangesRatee=db_lhd;User Id=mayura;Password=ARSystem@2021;" Microsoft.EntityFrameworkCore.SqlServer -o LHDEntities  --context "LHDContext" --context-dir DBcontext --data-annotations --force 