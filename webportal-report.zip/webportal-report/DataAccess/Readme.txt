﻿Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities -Schemas dbo -contextdir DBContexts -DataAnnotations -Force

Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities -Schemas report -contextdir DBContexts -Context ReportDBContext -DataAnnotations -Force

Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities -Schemas rbac -contextdir DBContexts -Context RbacDBContext -DataAnnotations -Force




Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities\Mayura -tables dbo.bank_settlement,dbo.regular_collections,dbo.regular_collections_details,dbo.reschedules,dbo.final_payments,dbo.users,dbo.projects  -contextdir DBContexts -Context MayuraDBContext -DataAnnotations -Force

Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura_test1;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities\AR -Schemas ar -contextdir DBContexts -Context ArDBContext -DataAnnotations -Force

Scaffold-DbContext "data source=192.168.1.88;initial catalog=Mayura_Test1;user id=mayura;password=ARSystem@2021" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Entities\Mayura -tables dbo.bank_settlement,dbo.regular_collections,dbo.regular_collections_details,dbo.reschedules,dbo.final_payments,dbo.users,dbo.projects,dbo.daily_memo,dbo.users_to_roles  -contextdir DBContexts -Context MayuraDBContext -DataAnnotations -Force