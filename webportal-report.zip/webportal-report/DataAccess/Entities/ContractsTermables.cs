﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("contracts_termables")]
    public partial class ContractsTermables
    {
        [Column("contract_term_id")]
        public int? ContractTermId { get; set; }
        [Column("contract_termable_id")]
        public int? ContractTermableId { get; set; }
        [Column("contract_termable_type")]
        [StringLength(50)]
        public string ContractTermableType { get; set; }
    }
}
