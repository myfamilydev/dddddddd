﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("general_terms")]
    public partial class GeneralTerms
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("min_construction_period")]
        [StringLength(50)]
        public string MinConstructionPeriod { get; set; }
        [Column("min_mantenance_period")]
        [StringLength(50)]
        public string MinMantenancePeriod { get; set; }
        [Column("min_principle_repay")]
        [StringLength(50)]
        public string MinPrincipleRepay { get; set; }
        [Column("min_monthly_repay")]
        [StringLength(50)]
        public string MinMonthlyRepay { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
