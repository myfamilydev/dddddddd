﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VRptHandover
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("hand_over_date", TypeName = "datetime")]
        public DateTime? HandOverDate { get; set; }
        [Column("warrenty_end_date", TypeName = "datetime")]
        public DateTime? WarrentyEndDate { get; set; }
        [Column("schedule_date", TypeName = "datetime")]
        public DateTime? ScheduleDate { get; set; }
        [Column("person_handle")]
        [StringLength(100)]
        public string PersonHandle { get; set; }
        [Column("water")]
        [StringLength(50)]
        public string Water { get; set; }
        [Column("electricity")]
        [StringLength(50)]
        public string Electricity { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
