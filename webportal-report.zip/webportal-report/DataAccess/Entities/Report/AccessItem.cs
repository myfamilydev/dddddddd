﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Report
{
    [Table("access_item", Schema = "report")]
    public partial class AccessItem
    {
        [Key]
        [Column("report_access_id")]
        public int ReportAccessId { get; set; }
        [Key]
        [Column("report_item_id")]
        public int ReportItemId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }

        [ForeignKey(nameof(ReportAccessId))]
        [InverseProperty(nameof(Access.AccessItem))]
        public virtual Access ReportAccess { get; set; }
        [ForeignKey(nameof(ReportItemId))]
        [InverseProperty(nameof(Item.AccessItem))]
        public virtual Item ReportItem { get; set; }
    }
}
