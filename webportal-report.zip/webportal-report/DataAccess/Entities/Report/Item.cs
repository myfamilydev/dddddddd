﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Report
{
    [Table("item", Schema = "report")]
    public partial class Item
    {
        public Item()
        {
            AccessItem = new HashSet<AccessItem>();
        }

        [Key]
        [Column("report_item_id")]
        public int ReportItemId { get; set; }
        [Column("server_name")]
        [StringLength(50)]
        public string ServerName { get; set; }
        [Column("report_title")]
        [StringLength(50)]
        public string ReportTitle { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }

        [InverseProperty("ReportItem")]
        public virtual ICollection<AccessItem> AccessItem { get; set; }
    }
}
