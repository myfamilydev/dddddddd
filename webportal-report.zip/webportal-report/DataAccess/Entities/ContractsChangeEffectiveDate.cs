﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("contracts_change_effective_date")]
    public partial class ContractsChangeEffectiveDate
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("contract_amount", TypeName = "decimal(15, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        [Column("payment_term_month")]
        public short? PaymentTermMonth { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [Column("new_effective_date", TypeName = "date")]
        public DateTime? NewEffectiveDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("change_date", TypeName = "date")]
        public DateTime? ChangeDate { get; set; }
        [Column("contract_history_id")]
        public int? ContractHistoryId { get; set; }
        [Column("is_generated")]
        public short? IsGenerated { get; set; }
        [Column("reschedule_count")]
        public int? RescheduleCount { get; set; }
    }
}
