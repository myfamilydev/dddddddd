﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("workflow_notif_content")]
    public partial class WorkflowNotifContent
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("notif_type")]
        [StringLength(10)]
        public string NotifType { get; set; }
        [Column("notif_function")]
        [StringLength(50)]
        public string NotifFunction { get; set; }
        [Column("notif_subject")]
        [StringLength(200)]
        public string NotifSubject { get; set; }
        [Column("notif_to")]
        [StringLength(200)]
        public string NotifTo { get; set; }
        [Column("notif_cc")]
        [StringLength(200)]
        public string NotifCc { get; set; }
        [Column("email_content")]
        public string EmailContent { get; set; }
        [Column("param_json")]
        [StringLength(1000)]
        public string ParamJson { get; set; }
    }
}
