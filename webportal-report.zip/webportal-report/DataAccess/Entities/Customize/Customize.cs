﻿using System;
using System.Collections.Generic;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DataAccess.Entities.Customize
{
    public class ClsRegularCollectionDetailSummary
    {
        public int RegularCollectionId { set; get; }
        public int TransactionType { set; get; }
        public decimal Payment { set; get; }
    }
    public class ClsHousePaid
    {       
        public DateTime? PaymentDate { set; get; }
        public decimal? PaidPrinciple { set; get; }
        public decimal? PaidInterest { set; get; }
        public decimal Payment { set; get; }

    }
    public class ClsPenaltyPaid
    {
        public decimal PaidAmount { set; get; }
        public int? LateDay { set; get; }        
    }

    public class ClsPublicServicePaid
    {

        public decimal PublicServiceDiscount { set; get; }
        public decimal PaidAmount { set; get; }
        public int NMonth { set; get; }
        public DateTime? DateFrom { set; get; }
        public DateTime? DateTo { set; get; }
    }
    public class ClsFinalPaid
    {
        public decimal PaidAmount { set; get; }
        public decimal DiscountAmount { set; get; }
        public decimal FinalPayAmount { set; get; }
        public decimal Interest { set; get; }
        public decimal OverPaid { set; get; }
        public decimal finalOutstanding { set; get; }

    }
    public class ClsContractAgreement
    {
        [Column("id")]
        public int ContractId { set; get; }
        [Column("effective_date")]
        public DateTime? EffectiveDate { set; get; }
        [Column("contract_date")]
        public DateTime? ContractDate { set; get; }
        public string CustomerName1 { set; get; }
        public DateTime? CustomerDob1 { set; get; }
        public string Nationality1 { set; get; }
        public string IdCard1 { set; get; }
        public string PhoneContact1 { set; get; }
        public string HouseNumber1 { set; get; }
        public string Street1 { set; get; }
        public string Village1 { set; get; }
        public string Commune1 { set; get; }
        public string District1 { set; get; }
        public string Province1 { set; get; }
        public string CustomerName2 { set; get; }
        public DateTime? CustomerDob2 { set; get; }
        public string Nationality2 { set; get; }
        public string IdCard2 { set; get; }
        public string PhoneContract2 { set; get; }
        public string HouseNumber2 { set; get; }
        public string Street2 { set; get; }
        public string Village2 { set; get; }
        public string Commune2 { set; get; }
        public string Distict2 { set; get; }
        public string Province2 { set; get; }
        [Column("customer_relationship")]
        public string CustomerRelationship { set; get; }
        public string HouseType { set; get; }
        public string HouseNumber { set; get; }
        public string StreetNumber { set; get; }
        public string HouseProvince { set; get; }
        public string HouseDistrict { set; get; }
        public string HouseCommune { set; get; }
        public string HouseVillage { set; get; }
        [Column(TypeName = "decimal(15,2)")]
        public decimal? contract_amount { set; get; }
        public string ContractAmountInKhmer { set; get; }
        public Int16? MonthPeriod { set; get; }
        public string MonthPeriodInKhmer { set; get; }
        //[Column(TypeName = "decimal(15,2)")]
        //public decimal? YearlyInterest { set; get; }
        //public string YearlyInterestInkhmer { set; get; }
        //public double? MonthlyPayment { set; get; }
        //public string MonthlyPaymentInKhmer { set; get; }
        public decimal? MinPaid { set; get; }
        public string MinPaidInKhmer { set; get; }
        public decimal? MinPaidMonthly { set; get; }
        public string MinPaidMonthlyInKhmer { set; get; }
        public string ProjectCode { set; get; }
    }

    public class ClsfinalPaymentInfo
    {
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [Column("nationality")]
        [StringLength(50)]
        public string Nationality { get; set; }
        [Column("id_no")]
        [StringLength(50)]
        public string IdNo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(255)]
        public string  ProjectNameKH{ get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [StringLength(255)]
        public string ProjectProvince { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? ContractAmount { get; set; }
        [StringLength(500)]
        public string ContractAmountInKhmer { get; set; }
        public double? PaidOffAmount { get; set; }
        [StringLength(500)]
        public string PaidOffAmountInKhmer { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? FinalPaymentDate { get; set; }
        public string ProjectCode { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [StringLength(50)]
        public string Nationality2 { get; set; }
        [StringLength(50)]
        public string IdNo2 { get; set; }
        public string CustomerGender1 { get; set; }
        public string CustomerGender2 { get; set; }

        public string CustomerNameOld1 { get; set; }
        public string CustomerNameOld2 { get; set; }

        public string CustomerGenderOld1 { get; set; }
        public string CustomerGenderOld2 { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal OverPaid { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal DiscountAmount { get; set; }
        [Column("rec_status")]
        public int RecStatus { get; set; }
        [Column("project_location")]
        public string ProjectLocation { get; set; }       
    }
    public class ClsContractReference
    {
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        public String FromCustomer1 { set; get; }
        public String FromCustomer2 { set; get; }
        public String ToCustomer1 { set; get; }
        public String ToCustomer2 { set; get; }
        public int Order { set; get; }
        public string Type { set; get; }
        public int SortOrder { set; get; }
        public String FromGender1 { set; get; }
        public String FromGender2 { set; get; }
        public String ToGender1 { set; get; }
        public String ToGender2   { set; get; }

    }

   
}

