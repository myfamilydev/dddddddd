﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
namespace DataAccess.Entities.Customize_AR
{
    public class ClsCollectionBookingInitialPayment
    {
        public int? ReceiptNo { set; get; }
        public DateTime? PaidDate { set; get; }
        public decimal? ReceivedAmount { set; get; }
        public string PrePrintedNumber { set; get; }
        public string TransactionNumber { set; get; }
        public int? TransactionTypeId { set; get; }
    }

    public class ClsExtraPrinciplePayment
    {
        public int PaymentScheduleInfoId { set; get; }
        public int ReceiptNo { set; get; }
        public DateTime PaidDate { set; get; }
        [Column("Paid", TypeName = "decimal(15,2)")]
        public decimal Paid { set; get; }
    }
    public class ClsProjectRevenueDailyReport
    {

        public short? projectId { set; get; }
        [Column("project_name")]
        public string ProjectName { set; get; }
        [Column("contract_id")]
        public int? ContractId { set; get; }
        [Column("name_kh")]
        public string NameKhmer { set; get; }
        [Column("house_type")]
        public string HouseType { set; get; }
        [Column("house_number")]
        public string HouseNumber { set; get; }
        [Column("street_no")]
        public string StreetNumber { set; get; }
        [Column("house_size")]
        public string HouseSize { set; get; }
        [Column("house_price", TypeName = "Decimal(15,2)")]
        public decimal? HousePrice { set; get; }

        [Column("paid_date")]
        public DateTime? PaidDate { set; get; }
        [Column("tt_date")]
        public DateTime? tt_date { set; get; }
        [Column("receipt_id")]
        public string ReceiptId { set; get; }
        [Column("preprinted_number")]
        public string PrePrintedNumber { set; get; }
        [Column("payment_method")]
        public string PaymentMethod { set; get; }
        [Column("insurance_fee")]
        public decimal? InsuranceFee { set; get; }
        [Column("principle")]
        public decimal? Principle { set; get; }
        [Column("interest")]
        public decimal? Interest { set; get; }
        [Column("penalty")]
        public decimal? Penalty { set; get; }
        [Column("booking", TypeName = "Decimal(15,2)")]
        public decimal? Booking { set; get; }
        [Column("public_service")]
        public decimal? PublicService { set; get; }

        [Column("public_service_discount")]
        public decimal? PublicServiceDiscount { set; get; }

        [Column("paid_off_discount")]
        public decimal? PaidOffDiscount { set; get; }

        [Column("other_income")]
        public decimal? OtherIncome { set; get; }
        [Column("other_collect_not_income")]
        public decimal? other_collect_not_income { set; get; }
        [Column("total", TypeName = "Decimal(15,2)")]

        public decimal? Total { set; get; }
        [Column("remark")]
        public string Remark { set; get; }
        [Column("number_of_change")]
        public short? nCol { set; get; }
        public string transactionRef { set; get; }

    }

    public class MonthlyCollectionSummuryByMethod
    {
        public decimal? Amount { set; get; }
        public string MethodName { set; get; }
        public string Remark { set; get; }
    }

    public class MonthlyCollectionSummuryByProject
    {

        public string ProjectShort { set; get; }
        [Column("principle")]
        public decimal? Principle { set; get; }
        [Column("interest")]
        public decimal? Interest { set; get; }
        [Column("penalty")]
        public decimal? Penalty { set; get; }
        [Column("booking")]
        public decimal? Booking { set; get; }
        [Column("public_service")]
        public decimal? PublicService { set; get; }
        [Column("public_service_discount")]
        public decimal? PublicServiceDiscount { set; get; }
        [Column("paid_off_discount")]
        public decimal? PaidOffDiscount { set; get; }
        [Column("other_income")]
        public decimal? OtherIncome { set; get; }
        [Column("other_collect_not_income")]
        public decimal? OtherCollectNotIncome { set; get; }
        [Column("total", TypeName = "Decimal(15,2)")]

        public decimal? Total { set; get; }
    }

    public class RevenueMonthlyCollectionReprot
    {
        public string Ownership { get; set; }
        public short? projectId { set; get; }
        [Column("project_name")]
        public string ProjectName { set; get; }
        [Column("contract_id")]
        public int? ContractId { set; get; }
        [Column("name_kh")]
        public string NameKhmer { set; get; }
        [Column("house_type")]
        public string HouseType { set; get; }
        [Column("house_number")]
        public string HouseNumber { set; get; }
        [Column("street_no")]
        public string StreetNumber { set; get; }
        [Column("house_size")]
        public string HouseSize { set; get; }
        [Column("house_price", TypeName = "Decimal(15,2)")]
        public decimal? HousePrice { set; get; }

        [Column("paid_date")]
        public DateTime? PaidDate { set; get; }
        [Column("tt_date")]
        public DateTime? tt_date { set; get; }
        [Column("receipt_id")]
        public string ReceiptId { set; get; }
        [Column("preprinted_number")]
        public string PrePrintedNumber { set; get; }
        [Column("payment_method")]
        public string PaymentMethod { set; get; }
        [Column("insurance_fee")]
        public decimal? InsuranceFee { set; get; }
        [Column("principle")]
        public decimal? Principle { set; get; }
        [Column("interest")]
        public decimal? Interest { set; get; }
        [Column("penalty")]
        public decimal? Penalty { set; get; }
        [Column("booking", TypeName = "Decimal(15,2)")]
        public decimal? Booking { set; get; }
        [Column("public_service")]
        public decimal? PublicService { set; get; }

        [Column("public_service_discount")]
        public decimal? PublicServiceDiscount { set; get; }

        [Column("paid_off_discount")]
        public decimal? PaidOffDiscount { set; get; }

        [Column("other_income")]
        public decimal? OtherIncome { set; get; }
        [Column("other_collect_not_income")]
        public decimal? other_collect_not_income { set; get; }
        [Column("total", TypeName = "Decimal(15,2)")]

        public decimal? Total { set; get; }
        [Column("remark")]
        public string Remark { set; get; }
        [Column("remark_collection")]
        public string RemarkCollection { set; get; }
        [Column("number_of_change")]
        public short? nCol { set; get; }
        public string transactionRef { set; get; }

    }

    public class ClsBookingDailyReport
    {
        [Column("project_name")]
        public string ProjectName { set; get; }
        [Column("booking_id")]
        public int? BookingId { set; get; }
        [Column("house_number")]
        public string HouseNumber { set; get; }
        [Column("street_number")]
        public string StreetNumber { set; get; }
        [Column("house_type")]
        public string HouseType { set; get; }
        [Column("house_size")]
        public string HouseSize { set; get; }
        [Column("name_kh")]
        public string NameKh { set; get; }
        [Column("name_en")]
        public string NameEn { set; get; }
        [Column("contract_number")]
        public string ContractNumber { set; get; }
        [Column("booking_date")]
        public DateTime? BookingDate { set; get; }
        [Column("booking_expired_date")]
        public DateTime? BookingExpiredDate { set; get; }
        [Column("house_price")]
        public decimal? HousePrice { set; get; }
        [Column("house_discount")]
        public decimal? HouseDiscount { set; get; }
        [Column("net_house_price")]
        public decimal? NetHousePrice { set; get; }
        [Column("booking_amount")]
        public decimal? BookingAmount { set; get; }

        [Column("total_booking")]
        public decimal? TotalBooking { set; get; }

        [Column("contract_id")]
        public int? ContractId { set; get; }
        [Column("contract_date")]
        public DateTime? ContractDate
        {
            set; get;

        }
        [Column("remark")]
        public string Remark { set; get; }
        [Column("paid_status")]
        public byte PaidStatus { set; get; }
        [Column("in_type")]
        public string InType { set; get; }
        [Column("sale_name")]
        public string SaleName { set; get; }

    }
    public class ClsBookingDailyReportExcludeTransfer
    {
        [Column("project_name")]
        public string ProjectName { set; get; }
        [Column("booking_id")]
        public int? BookingId { set; get; }
        [Column("house_number")]
        public string HouseNumber { set; get; }
        [Column("street_number")]
        public string StreetNumber { set; get; }
        [Column("house_type")]
        public string HouseType { set; get; }
        [Column("house_size")]
        public string HouseSize { set; get; }
        [Column("name_kh")]
        public string NameKh { set; get; }
        [Column("name_en")]
        public string NameEn { set; get; }
        [Column("contract_number")]
        public string ContractNumber { set; get; }
        [Column("booking_date")]
        public DateTime? BookingDate { set; get; }
        [Column("booking_expired_date")]
        public DateTime? BookingExpiredDate { set; get; }
        [Column("house_price")]
        public decimal? HousePrice { set; get; }
        [Column("house_discount")]
        public decimal? HouseDiscount { set; get; }
        [Column("net_house_price")]
        public decimal? NetHousePrice { set; get; }
        [Column("booking_amount")]
        public decimal? BookingAmount { set; get; }
        [Column("contract_id")]
        public int? ContractId { set; get; }
        [Column("contract_date")]
        public DateTime? ContractDate { set; get; }
        [Column("remark")]
        public string Remark { set; get; }
        [Column("paid_status")]
        public byte PaidStatus { set; get; }

    }

    public class ClsContractDailyReport
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        public int ContractId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("name_en")]
        public string NameEn { set; get; }
        [Column("phone_contract")]
        [StringLength(30)]
        public string PhoneContract { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("booking_date", TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column("house_price")]
        public decimal? HousePrice { get; set; }
        public decimal? Discount { get; set; }
        public decimal? NetAmount { get; set; }

        public decimal? BookingAmount { get; set; }
        [Column("StreeNumber")]
        public string StreeNumber { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("construction_period")]
        public int? ConstructionPeriod { get; set; }
        [Column("term_name")]
        public string Paymenterm { get; set; }
    }

    public class SummaySaleAndCollectionReport {

        
        public short? ProjectId { get; set; }
        [Column("id")]
        public int? CategoryId { get; set; }
        public string Ownership { get; set; }
        public string Project { get; set; }
        public string HouseType { get; set; }
        public int? TotalHousePlan { get; set; }
        public int? TotalHouse { get; set; }
        public int? TotalContract { get; set; }
        public int? OSBooking { get; set; }
        public int? TotalBooking { get; set; }
        public int? TotalRemain { get; set; }
        public decimal? NetAmount { get; set; }
        public decimal? AccPrinciple { get; set; }
        public decimal? AccPaidOffDiscount { get; set; }
        public decimal? OutstandingPrinciple { get; set; }
        public decimal? AccInterest { get; set; }
        public decimal? AccPenalty { get; set; }
        public decimal? AccPublicService { get; set; }
        
    }

    public class SummayCollectionReport
    {
        public string Ownership { get; set; }
        public string Project { get; set; }
        public string HouseNumber { get; set; }
        public string StreetNumber { get; set; }
        public string CustomerName { get; set; }
        public string HouseType { get; set; }
        public string HouseSize { get; set; }
        public DateTime? ContractDate { get; set; }
        public decimal? NetAmount { get; set; }
        public decimal? AccPrinciple { get; set; }
        public decimal? AccAdjPrinciple { get; set; }
        public decimal? AccPrincipleCurrent { get; set; }
        public decimal? TotalPrincipal { get; set; }
        public decimal? AccPaidOffDiscount { get; set; }
        public decimal? OutstandingPrincipal { get; set; }        
        public decimal? OutstandingPrincipalPercent { get; set; }
        public decimal? AccInterest { get; set; }
        public decimal? AccAdjInterest { get; set; }
        public decimal? AccInterestCurrent { get; set; }
        public decimal? TotalInterest { get; set; }
        public decimal? AccPenalty { get; set; }
        public decimal? AccAdjPenalty { get; set; }
        public decimal? AccPenaltyCurrent { get; set; }
        public decimal? TotalPenalty { get; set; }
        public decimal? AccPublicService { get; set; }
        public decimal? AccAdjPublicService { get; set; }
        public decimal? AccPublicServiceCurrent { get; set; }
        public decimal? AccPSDiscount { get; set; }
        public decimal? TotalPublicService { get; set; }
       
    }

    public class BookingNotContract
    {
        public string Ownership { get; set; }
        public string Project { get; set; }
        public string HouseNo { get; set; }
        public string StreetNo { get; set; }
        public string Customer { get; set; }
        public string HouseType { get; set; }
        public DateTime? BookDate { get; set; }
        public decimal? BookingAmount { get; set; }
        public decimal? HousePrice { get; set; }
    }

    public class DailyMessageReport
    {
        public int contract_id { get; set; }
        public string ProjectShort { get; set; }
        public string HouseNo { get; set; }
        public string StreetNo { get; set; }
        public string CustomerName { get; set; }
        public string HouseType { get; set; }
        public string CustomerPhone { get; set; }
        public DateTime? PaymentDate { get; set; }
       

    }

    



    public class SummuryCollectionTerminateReport
    {
        public string Ownership { get; set; }
        public string Project { get; set; }
        public DateTime? TerminateDate { get; set; }
        public string HouseNo { get; set; }
        public string StreetNo { get; set; }
        public string Customer { get; set; }
        public string HouseType { get; set; }
        public DateTime? ContractDate { get; set; }
        public decimal? NetAmount { get; set; }
        public decimal? AccPrinciple { get; set; }
        public decimal? AccPaidOffDiscount { get; set; }
        public decimal? OutstandingPincipal { get; set; }
        public decimal? OutstandingPincipalPercent { get; set; }
        public decimal? AccInterest { get; set; }
        public decimal? AccPenalty { get; set; }
        public decimal? AccPublicService { get; set; }
        public string TerminationType { get; set; }
        public string Remark { get; set; }
        public string Description { get; set; }
        public int TerminationTypeOrder { get; set; }
    }

}
