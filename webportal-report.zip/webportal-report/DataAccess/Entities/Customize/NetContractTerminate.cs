﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Entities.Customize
{
    public partial class NetContractTerminate
    {
        public string ProjectShort { get; set; }

        public string HouseNumber { get; set; }
        public string TerminateType { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? TerminateDate { get; set; }
        public string Remark { get; set; }

    }
}
