﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("bookings_change_house")]
    public partial class BookingsChangeHouse
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
        [Column("new_house_id")]
        public int NewHouseId { get; set; }
        [Column("new_original_price")]
        public double? NewOriginalPrice { get; set; }
        [Column("house_change_date", TypeName = "datetime")]
        public DateTime? HouseChangeDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("booking_history_id")]
        public int? BookingHistoryId { get; set; }
    }
}
