﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("penalty_amount")]
    public partial class PenaltyAmount
    {
        [Key]
        [Column("schedule_id")]
        public int ScheduleId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("penalty", TypeName = "money")]
        public decimal? Penalty { get; set; }
        [Column("paid", TypeName = "money")]
        public decimal? Paid { get; set; }
        [Column("current_paid", TypeName = "money")]
        public decimal? CurrentPaid { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("payment", TypeName = "money")]
        public decimal? Payment { get; set; }
        [Column("waive", TypeName = "money")]
        public decimal? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        [Column("tt_date", TypeName = "date")]
        public DateTime? TtDate { get; set; }
    }
}
