﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VPrintInvoiceForm
    {
        [Column("invoice_id")]
        public int InvoiceId { get; set; }
        [Column("reg_col_id")]
        [StringLength(8)]
        public string RegColId { get; set; }
        [Column("collect_method")]
        [StringLength(250)]
        public string CollectMethod { get; set; }
        [Column("payee_name")]
        [StringLength(100)]
        public string PayeeName { get; set; }
        [Column("payee_address")]
        [StringLength(100)]
        public string PayeeAddress { get; set; }
        [Column("total_amount")]
        public double? TotalAmount { get; set; }
        [Column("amount_in_word")]
        [StringLength(250)]
        public string AmountInWord { get; set; }
        [Column("reg_col_day")]
        public int? RegColDay { get; set; }
        [Column("reg_col_month")]
        public int? RegColMonth { get; set; }
        [Column("reg_col_year")]
        public int? RegColYear { get; set; }
        [Column("house_no")]
        [StringLength(50)]
        public string HouseNo { get; set; }
        [Required]
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Required]
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
