﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace DataAccess.Entities.Ar
{
    public partial class VprintOtherCollection
    {
        [StringLength(100)]
        public string ProjectName { get; set; }
        public string PrePrinted { get; set; }
        public string Street { get; set; }
        public string HouseType { get; set; }
        public string Ttref { get; set; }
        public string PaymentType { get; set; }
        public decimal? TotalAmount { get; set; }
        public string TotalAmountInKhmer { get; set; }
        public string FullName { get; set; }
        public DateTime? RefDate1 { get; set; }
        public DateTime? RefDate2 { get; set; }
        public DateTime? RefDate3 { get; set; }
        public string PhoneCall { get; set; }
        [Column("RP_No")]
        [StringLength(30)]
        public string RpNo { get; set; }
        public int ReceiptNo { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [StringLength(150)]
        public string ReceivedFrom { get; set; }
        [Required]
        [StringLength(805)]
        public string Address { get; set; }
        [StringLength(4000)]
        public string PaymentMethod { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        public short nCol { get; set; }
    }
}
