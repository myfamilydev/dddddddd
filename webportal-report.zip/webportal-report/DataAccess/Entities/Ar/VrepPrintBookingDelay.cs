﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VrepPrintBookingDelay
    {
        public int BookingDelayId { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [StringLength(50)]
        public string CustomerNationality1 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard1 { get; set; }
        [StringLength(30)]
        public string CustomerContact1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [StringLength(50)]
        public string CustomerNationality2 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard2 { get; set; }
        [StringLength(30)]
        public string CustomerContact2 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string HouseStreetNo { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [StringLength(4000)]
        public string HouseNetPrice { get; set; }
        [StringLength(500)]
        public string HouseNetPriceInKhmer { get; set; }
        [StringLength(4000)]
        public string BookingAmount { get; set; }
        [StringLength(500)]
        public string BookingAmountInKhmer { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime BookingExpireDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime BookingDelayExtendDate { get; set; }
        [Required]
        [Column("reason")]
        public string Reason { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreateDate { get; set; }
        public byte? BookingDelayRecStatus { get; set; }
        [Column("booking_history_id")]
        public int? BookingHistoryId { get; set; }

        public short projectId { get; set; }
    }
}
