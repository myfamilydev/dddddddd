﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VWaiveInterestReport
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("contract_amount", TypeName = "decimal(10, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? EndDate { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        public float? ActualPaid { get; set; }
        [Column("waive_amount")]
        public float? WaiveAmount { get; set; }
        public float? InterestAmount { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
    }
}
