﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VHousesStockReport
    {
        [Required]
        [StringLength(1)]
        public string ProjectShort { get; set; }
        [Required]
        [StringLength(1)]
        public string Name { get; set; }
        public int HouseCount { get; set; }
        public int ContractCount { get; set; }
        public int BookingOutstanding { get; set; }
        public int HouseAvailable { get; set; }
       
        public int TotalBooking { get; set; }
    }
}
