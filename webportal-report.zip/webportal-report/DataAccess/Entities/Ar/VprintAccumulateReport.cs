﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintAccumulateReport
    {
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(25)]
        public string HouseSize { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }

        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column("name_en1")]
        [StringLength(150)]
        public string NameEn1 { get; set; }

        public int ContractNumber { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? NetAmount { get; set; }
        
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? AccPrinciple { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? AccPaidOffDiscount { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? AccInterest { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? AccPenalty { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? AccPublicService { get; set; }
        
        [StringLength(123)]
        public string PhoneNumber { get; set; }
        [StringLength(123)]
        public string PhoneNumber1 { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
