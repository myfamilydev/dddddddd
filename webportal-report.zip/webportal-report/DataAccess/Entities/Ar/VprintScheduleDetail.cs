﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRT s) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintScheduleDetail
    {
        public long ScheduleId { get; set; }  //payment_schedule_info_id 
        [Column("payment_schedule_info_id")]
        public int PaymentScheduleInfoId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("PaymentAmount", TypeName = "decimal(15, 2)")]
        public decimal? PaymentAmount { get; set; }
        [Column("principle", TypeName = "decimal(15, 2)")]        
        public decimal? Principle { get; set; }
        [Column("interest", TypeName = "decimal(15, 2)")]
        public decimal? Interest { get; set; }
        [Column("accumulate_principle", TypeName = "decimal(15, 2)")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest", TypeName = "decimal(15, 2)")]
        public decimal? AccumulateInterest { get; set; }
        public int? ReceiptNo { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("PaidAmount", TypeName = "decimal(15, 2)")]
        public decimal? PaidAmount { get; set; }
        
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("paid_interest", TypeName = "decimal(15, 2)")]
        public decimal? PaidInterest { get; set; }
        [Column("paid_principle", TypeName = "decimal(15, 2)")]
        public decimal? PaidPrinciple { get; set; }
        [Column("waive_interest", TypeName = "decimal(15, 2)")]
        public decimal? WaiveInterest { get; set; }        

        [Column("end_balance", TypeName = "decimal(15, 2)")]
        public decimal? EndBalance { get; set; }
        [Column("start_balance", TypeName = "decimal(15, 2)")]
        public decimal? StartBalance { get; set; }
        public string TransactionNumber { get; set; }
        public string PrePrinted { get; set; }
        public int? IsCompleted { get; set; }
        public decimal Remain { get; set; }
    }
}
