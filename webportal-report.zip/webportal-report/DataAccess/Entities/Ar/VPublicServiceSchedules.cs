﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VPublicServiceSchedules
    {
        public int schedule_id { get; set; }
        public int public_service_id { get; set; }

        [Column(TypeName = "date")]
        public DateTime payment_date { get; set; }
        public decimal monthly_fee { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? paid_date { get; set; }
        [StringLength(200)]
        public string? preprinted_number { get; set; }
        public int? ReceiptNo { get; set; }

        [Column("discount_amount")]
        public decimal? DiscountAmount { get; set; }
        public decimal? NetPay { get; set; }
        
        [StringLength(4000)]
        public string remark { get; set; }
        public decimal? waive { get; set; }

        public int? HouseId { get; set; }
    }
}
