﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Entities.Ar
{
    public partial class VPenaltyLateReport
    {
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }

        [Column("Contract_id")]
        public int? ContractId { set; get; }

        [Column("house_id")]
        public int? HouseId { set; get; }

        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]

        [Column("late_days")]
        public int LateDays { get; set; }

        [Column("penalty_payment")]
        public decimal? PenaltyPayment { get; set; }

    }
}
