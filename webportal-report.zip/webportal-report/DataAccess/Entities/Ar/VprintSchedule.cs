﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintSchedule
    {
        public int ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        public short? DurationInterest { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        public decimal? OriginalPrice { get; set; }
        public decimal? NetAmount { get; set; }
        public decimal SpecialDiscount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalDiscount { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? InitialPayment { get; set; }
    }

    public partial class VPrintScheduleSale
    {
        public int ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        public short? DurationInterest { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(10)]
        public string HouseNo { get; set; }
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        public decimal? OriginalPrice { get; set; }
        public decimal? NetAmount { get; set; }
        public decimal SpecialDiscount { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalDiscount { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? InitialPayment { get; set; }
    }
}
