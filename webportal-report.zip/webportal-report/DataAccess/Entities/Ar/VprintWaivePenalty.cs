﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    

    public partial class VPrintWaivePublicService
    {
        public int? PublicServiceId { get; set; }
        public int? WaiveId { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(61)]
        public string PhoneNumber { get; set; }
        [Column("village")]
        [StringLength(250)]
        public string Village { get; set; }
        [Column("district")]
        [StringLength(250)]
        public string District { get; set; }
        [Column("commune")]
        [StringLength(250)]
        public string Commune { get; set; }
        [Column("province")]
        [StringLength(250)]
        public string Province { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? NetAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public DateTime? WaiveDate { get; set; }
        public decimal? WaiveAmount { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        public decimal? MonthlyFee { get; set; }
        [StringLength(10)]
        public string Ownership { get; set; }

    }
    public partial class VprintWaivePenalty
    {
        public long PenaltyPaymentId { get; set; }
        public int? WaiveId { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(61)]
        public string PhoneNumber { get; set; }
        [Column("village")]
        [StringLength(250)]
        public string Village { get; set; }
        [Column("district")]
        [StringLength(250)]
        public string District { get; set; }
        [Column("commune")]
        [StringLength(250)]
        public string Commune { get; set; }
        [Column("province")]
        [StringLength(250)]
        public string Province { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? NetAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        public int? DayPayment { get; set; }
        [Column(TypeName = "date")]
        public DateTime? StartDate { get; set; }
        public decimal? WaiveAmount { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [StringLength(10)]
        public string Ownership { get; set; }

    }


    public partial class VPrintWaiveFinalInterest
    {
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(61)]
        public string PhoneNumber { get; set; }
        [Column("village")]
        [StringLength(250)]
        public string Village { get; set; }
        [Column("district")]
        [StringLength(250)]
        public string District { get; set; }
        [Column("commune")]
        [StringLength(250)]
        public string Commune { get; set; }
        [Column("province")]
        [StringLength(250)]
        public string Province { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? NetAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("payment_date")]
        public DateTime? PaymentDate { get; set; }

        [Column("last_paid_date")]
        public DateTime? LastPaymentDate { get; set; }
        public decimal? WaiveAmount { get; set; }
        [Column("monthly_payment")]
        public decimal? MonthlyPayment { get; set; }
        [Column("reason")]
        public string Reason { get; set; }

        [Column("rec_status")]
        public byte? RecStatus { get; set; }

        [Column("nday_interest")]
        public int? NDayInterest { get; set; }
        public string WaiveAmountKh { get; set; }
        [StringLength(10)]
        public string Ownership { get; set; }
    }
}
