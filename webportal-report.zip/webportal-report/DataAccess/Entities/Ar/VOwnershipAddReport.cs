﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VOwnershipAddReport
    {
        [Required]
        [Column("Request_Date")]
        [StringLength(1)]
        public DateTime RequestDate { get; set; }
        [Required]
        [Column("Project_Short")]
        [StringLength(1)]
        public string ProjectShort { get; set; }
        [Required]
        [Column("House_Type")]
        [StringLength(1)]
        public string HouseType { get; set; }
        [Required]
        [Column("House_Number")]
        [StringLength(1)]
        public string HouseNumber { get; set; }
        [Required]
        [Column("Street_Number")]
        [StringLength(1)]
        public string StreetNumber { get; set; }
        [Column("Net_Amount", TypeName = "decimal(15, 2)")]
        public decimal? NetAmount { get; set; }
        [Required]
        [StringLength(1)]
        public string OldCustomer { get; set; }
        [Required]
        [StringLength(1)]
        public string AddedCustomer { get; set; }
    }
}
