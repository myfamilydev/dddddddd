﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VPrintCusInfoOwnership
    {
        [Column("ContractID")]
        public int ContractId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("BookingID")]
        public int? BookingId { get; set; }
        [Column("CustomerID1")]
        public int CustomerId1 { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(50)]
        public string CustomerGender1 { get; set; }
        [Column("CustomerDOB1", TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [Column("CustomerIDNo1")]
        [StringLength(50)]
        public string CustomerIdno1 { get; set; }
        [StringLength(50)]
        public string CustomerHouseNo1 { get; set; }
        [StringLength(150)]
        public string CustomerStreet1 { get; set; }
        [StringLength(150)]
        public string CustomerVillage1 { get; set; }
        [StringLength(150)]
        public string CustomerCommune1 { get; set; }
        [StringLength(150)]
        public string CustomerDistrict1 { get; set; }
        [StringLength(150)]
        public string CustomerProvince1 { get; set; }
        [StringLength(50)]
        public string CustomerNationality1 { get; set; }
        [StringLength(30)]
        public string CustomerPhoneCall1 { get; set; }
        [Column("CustomerID2")]
        public int? CustomerId2 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [StringLength(50)]
        public string CustomerGender2 { get; set; }
        [Column("CustomerDOB2", TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [Column("CustomerIDNo2")]
        [StringLength(50)]
        public string CustomerIdno2 { get; set; }
        [StringLength(50)]
        public string CustomerHouseNo2 { get; set; }
        [StringLength(150)]
        public string CustomerStreet2 { get; set; }
        [StringLength(150)]
        public string CustomerVillage2 { get; set; }
        [StringLength(150)]
        public string CustomerCommune2 { get; set; }
        [StringLength(150)]
        public string CustomerDistrict2 { get; set; }
        [StringLength(150)]
        public string CustomerProvince2 { get; set; }
        [StringLength(50)]
        public string CustomerNationality2 { get; set; }
        [StringLength(30)]
        public string CustomerPhoneCall2 { get; set; }
        [StringLength(4000)]
        public string NetHousePrice { get; set; }
        [StringLength(500)]
        public string NetHousePriceInKhmer { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [StringLength(150)]
        public string CusEng1 { get; set; }
        [StringLength(150)]
        public string CusEng2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? IdEx1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? IdEx2 { get; set; }
        [StringLength(150)]
        public string Job1 { get; set; }
        [StringLength(150)]
        public string Job2 { get; set; }
        [Column("ownershipId")]
        public int OwnershipId { get; set; }
        [Column("contract_id")]
        public int? ContractId1 { get; set; }

        [StringLength(10)]
        public string ProjectCode { get; set; }

        public DateTime? CreatedAt { get; set; }
    }
}
