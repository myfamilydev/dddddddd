﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintBookingChangeHouse
    {
        [Column(TypeName = "datetime")]
        public DateTime? ChangeDate { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [StringLength(10)]
        public string ProjectNameFrom { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeFrom { get; set; }
        [StringLength(10)]
        public string HouseNumberFrom { get; set; }
        [StringLength(150)]
        public string StreetNumberFrom { get; set; }
        [StringLength(23)]
        public string HouseSizeFrom { get; set; }
        public decimal? HousePriceFrom { get; set; }
        [StringLength(100)]
        public string ProjectNameTo { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeTo { get; set; }
        [StringLength(10)]
        public string HouseNumberTo { get; set; }
        [StringLength(150)]
        public string StreetNumberTo { get; set; }
        [StringLength(23)]
        public string HouseSizeTo { get; set; }
        public decimal? HousePriceTo { get; set; }
        public decimal? BookingAmount { get; set; }
        public int FormId { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }
    }
}
