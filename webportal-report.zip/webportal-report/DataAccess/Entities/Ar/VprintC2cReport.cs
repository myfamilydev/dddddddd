﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintC2cReport
    {
        [Column("c2c_date", TypeName = "datetime")]
        public DateTime C2cDate { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? PriceContract { get; set; }
        [StringLength(150)]
        public string OldCustomerName1 { get; set; }
        [StringLength(150)]
        public string OldCustomerName2 { get; set; }
        [StringLength(150)]
        public string NewCustomerName1 { get; set; }
        [StringLength(150)]
        public string NewCustomerName2 { get; set; }
        //[Column("remark")]
        //public string Remark { get; set; }
        //[Column("rec_status")]
        //public byte? RecStatus { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? TotalPaid { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? TotalRemain { get; set; }
        [Column("enOldCustomerName1")]
        [StringLength(150)]
        public string EnOldCustomerName1 { get; set; }
        [Column("enOldCustomerName2")]
        [StringLength(150)]
        public string EnOldCustomerName2 { get; set; }
        [Column("enNewCustomerName1")]
        [StringLength(150)]
        public string EnNewCustomerName1 { get; set; }
        [Column("enNewCustomerName2")]
        [StringLength(150)]
        public string EnNewCustomerName2 { get; set; }
    }
}
