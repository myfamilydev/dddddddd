﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VrepC2c
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("c2c_id")]
        [StringLength(20)]
        public string C2cId { get; set; }
        [Column("c2c_date", TypeName = "datetime")]
        public DateTime C2cDate { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [StringLength(150)]
        public string ContractCustomerName1 { get; set; }
        [StringLength(150)]
        public string ContractCustomerName2 { get; set; }
        [StringLength(150)]
        public string OldCustomerName1 { get; set; }
        [StringLength(50)]
        public string OldCustomerSex1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? OldCustomerDob1 { get; set; }
        [StringLength(50)]
        public string OldCustomerNationality1 { get; set; }
        [StringLength(50)]
        public string OldCustomerIdCard1 { get; set; }
        [StringLength(20)]
        public string OldCustomerHouseNo1 { get; set; }
        [StringLength(150)]
        public string OldCustomerStreet1 { get; set; }
        [StringLength(150)]
        public string OldCustomerVillage1 { get; set; }
        [StringLength(150)]
        public string OldCustomerCommune1 { get; set; }
        [StringLength(150)]
        public string OldCustomerDistrict1 { get; set; }
        [StringLength(150)]
        public string OldCustomerProvince1 { get; set; }
        [StringLength(150)]
        public string OldCustomerName2 { get; set; }
        [StringLength(50)]
        public string OldCustomerSex2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? OldCustomerDob2 { get; set; }
        [StringLength(50)]
        public string OldCustomerNationality2 { get; set; }
        [StringLength(50)]
        public string OldCustomerIdCard2 { get; set; }
        [StringLength(20)]
        public string OldCustomerHouseNo2 { get; set; }
        [StringLength(150)]
        public string OldCustomerStreet2 { get; set; }
        [StringLength(150)]
        public string OldCustomerVillage2 { get; set; }
        [StringLength(150)]
        public string OldCustomerCommune2 { get; set; }
        [StringLength(150)]
        public string OldCustomerDistrict2 { get; set; }
        [StringLength(150)]
        public string OldCustomerProvince2 { get; set; }
        [StringLength(150)]
        public string NewCustomerName1 { get; set; }
        [StringLength(50)]
        public string NewCustomerSex1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NewCustomerDob1 { get; set; }
        [StringLength(50)]
        public string NewCustomerNationality1 { get; set; }
        [StringLength(50)]
        public string NewCustomerIdCard1 { get; set; }
        [StringLength(20)]
        public string NewCustomerHouseNo1 { get; set; }
        [StringLength(150)]
        public string NewCustomerStreet1 { get; set; }
        [StringLength(150)]
        public string NewCustomerVillage1 { get; set; }
        [StringLength(150)]
        public string NewCustomerCommune1 { get; set; }
        [StringLength(150)]
        public string NewCustomerDistrict1 { get; set; }
        [StringLength(150)]
        public string NewCustomerProvince { get; set; }
        [StringLength(150)]
        public string NewCustomerName2 { get; set; }
        [StringLength(50)]
        public string NewCustomerSex2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NewCustomerDob2 { get; set; }
        [StringLength(50)]
        public string NewCustomerNationality2 { get; set; }
        [StringLength(50)]
        public string NewCustomerIdCard2 { get; set; }
        [StringLength(20)]
        public string NewCustomerHouseNo2 { get; set; }
        [StringLength(150)]
        public string NewCustomerStreet2 { get; set; }
        [StringLength(150)]
        public string NewCustomerVillage2 { get; set; }
        [StringLength(150)]
        public string NewCustomerCommune2 { get; set; }
        [StringLength(150)]
        public string NewCustomerDistrict2 { get; set; }
        [StringLength(150)]
        public string NewCustomerProvince2 { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        [StringLength(100)]
        public string ProjectAbbr { get; set; }
        [StringLength(255)]
        public string ProjectProvince { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(10)]
        public string HouseLandWidth { get; set; }
        [StringLength(10)]
        public string HouseLandLength { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [StringLength(150)]
        public string HouseStreetNo { get; set; }
        [StringLength(250)]
        public string HouseProvince { get; set; }
        [StringLength(250)]
        public string HouseDistrict { get; set; }
        [StringLength(250)]
        public string HouseCommune { get; set; }
        [StringLength(250)]
        public string HouseVillage { get; set; }
    }
}
