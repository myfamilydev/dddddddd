﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintPenaltyDetail
    {
        public int ScheduleId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("penalty")]
        public double? Penalty { get; set; }
        [Column("paid")]
        public double? Paid { get; set; }
        public int? ReceiptNo { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        public float? PaidAmount { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("waive")]
        public double? Waive { get; set; }
        [Column("payment")]
        public double? Payment { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        
    }
}
