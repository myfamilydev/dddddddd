﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VFinalPaymentReport
    {
        public int FinalpaymentId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column(TypeName = "decimal(10, 2)")]
        public decimal? NetSale { get; set; }
        [Column(TypeName = "money")]
        public decimal? FinalAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal? PaidOffDiscount { get; set; }
        [Column("final_payment_date", TypeName = "date")]
        public DateTime? FinalPaymentDate { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? TotalPrincipleAmount { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }
    }
}
