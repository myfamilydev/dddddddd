﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class LastPaymentReport
    {
        public string ProjectCode { get; set; }
        [StringLength(100)]
        public string ProjectShort { get; set; }
        public string HouseNumber { get; set; }
        public string Customer1 { get; set; }
        public string C1Phone { get; set; }
        public string Customer2 { get; set; }
        public string C2Phone { get; set; }
        public decimal? NetAmount { get; set; }
        public DateTime? ContractDate { get; set; }
        public DateTime? PaymentDate { get; set; }

        public int? TotalPaidMonth { get; set; }
    }
}