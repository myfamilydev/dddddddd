﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VDailySummaryReport
    {
        [Required]
        [Column("method_name")]
        [StringLength(1)]
        public string MethodName { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? Principle { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? Interest { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? Penalty { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? Booking { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? PublicService { get; set; }
        [Column("AdminFeeOnC2C", TypeName = "decimal(15, 2)")]
        public decimal? AdminFeeOnC2c { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? PenaltySubContractor { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? Redesign { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? UtilitiesIcome { get; set; }
        [Column(TypeName = "decimal(15, 2)")]
        public decimal? SellerCommissionAtWorkerShelter { get; set; }
    }
}
