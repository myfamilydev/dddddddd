﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintNoneInterestDetail
    {
        public long ScheduleId { get; set; }
        public long? PaidId { get; set; }
        [StringLength(4000)]
        public string ReceiptNo { get; set; }
        [StringLength(4000)]
        public string PaymentDate { get; set; }
        [Column("principle")]
        [StringLength(4000)]
        public string Principle { get; set; }
        public float? InterestInMoney { get; set; }
        [StringLength(4000)]
        public string InterestInPercent { get; set; }
        public float? PaymentMonthly { get; set; }
        public float PaidAmount { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [StringLength(4000)]
        public string PaidDate { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [StringLength(4000)]
        public string CreatedDate { get; set; }
        [StringLength(50)]
        public string CreatedBy { get; set; }
        [StringLength(4000)]
        public string UpdatedDate { get; set; }
        [Required]
        [StringLength(50)]
        public string UpdatedBy { get; set; }
    }
}
