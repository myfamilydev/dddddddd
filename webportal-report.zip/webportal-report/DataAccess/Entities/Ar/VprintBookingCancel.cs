﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintBookingCancel
    {
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CancelDate { get; set; }
        [StringLength(150)]

        [Column("booking_date")]
        public DateTime? BookingDate { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        public decimal? HousePrice { get; set; }
        public decimal? BookingAmount { get; set; }

        [Column("total_booking")]
        public decimal? TotalBooking { get; set; }
        public int FormId { get; set; }
        [Column("reason")]
        public string Reason { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }
    }
}
