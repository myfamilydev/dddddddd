﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VWaivePenaltyReport
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("contract_amount", TypeName = "decimal(10, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column(TypeName = "money")]
        public decimal? ActualPenaltyPaid { get; set; }
        [Column("waive_amount")]
        public decimal? WaiveAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal? PenaltyAmount { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
    }
}
