﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintContractCollection
    {
        [Column("id")]
        public int Id { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string Street { get; set; }
        [StringLength(303)]
        public string CustomerName { get; set; }
        [StringLength(30)]
        public string PhoneCall { get; set; }
        [StringLength(4000)]
        public string PaymentType { get; set; }
        public decimal? TotalAmount { get; set; }
        [StringLength(500)]
        public string TotalAmountInKhmer { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [StringLength(154)]
        public string BankAccount { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaymentDate { get; set; }
        [Column("transaction_no")]
        public long? TransactionNo { get; set; }
        [Column("TTref")]
        [StringLength(394)]
        public string Ttref { get; set; }
        [Column("refDate1", TypeName = "date")]
        public DateTime? RefDate1 { get; set; }
        [Column("refDate2", TypeName = "date")]
        public DateTime? RefDate2 { get; set; }
        [Column("refDate3", TypeName = "date")]
        public DateTime? RefDate3 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("prePrinted")]
        [StringLength(20)]
        public string PrePrinted { get; set; }
        public short? nCol { get; set; }
        [Column("adjustment_id")]
        public int? AdjustmentId { get; set; }
        [Column("adjustment_type")]
        public short? AdjustmentType { get; set; }
        [Column("termination_transfer")]
        public int? terminationTransfer { get; set; }
    }
}
