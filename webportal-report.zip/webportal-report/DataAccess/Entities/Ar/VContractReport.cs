﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VContractReport
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        public int ContractId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("phone_contract")]
        [StringLength(30)]
        public string PhoneContract { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("house_price")]
        public float? HousePrice { get; set; }
        public float? Discount { get; set; }
        public float? NetAmount { get; set; }
        public float? BookingAmount { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
