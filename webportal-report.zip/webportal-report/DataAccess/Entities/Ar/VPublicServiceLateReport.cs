﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Entities.Ar
{
    public partial class VPublicServiceLateReport
    {
        [Column("No")]
        public Int64? No { set; get; }

        [Column("Project")]
        [StringLength(100)]      
        public string Project { get; set; }

        [Column("House_Number")]
        [StringLength(10)]
        public string House_Number { get; set; }
        [Required]
        [StringLength(100)]

        [Column("ContractId")]
        public int? ContractId { set; get; }

        [Column("CustomerName")]
        public string Customer_Name { set; get; }
        [Column("PhoneContact")]
        [StringLength(30)]     
        public string Phone_Contact { get; set; }
        public string contact_number { set; get; }

        [Column("HouseType")]
        [StringLength(150)]
        public string House_Type { get; set; }


        [Column("StreetNo")]
        [StringLength(150)]
        public string StreetNumber { get; set; }

        [Column("PaymentDate", TypeName = "date")]
        public DateTime? NextPayment { get; set; }

        [Column("n_month")]
        public int LateMonth { get; set; }

        [Column("house_id")]
        public int? HouseId { get; set; }

        [Column("monthly_fee", TypeName = "decimal(10, 2)")]
        public decimal? MonthlyFee { get; set; }

        [Column("payment", TypeName = "decimal(10, 2)")]
        public decimal? PymentAmount { get; set; }

        [Column("LastCallDate", TypeName = "date")]
        public DateTime? Last_Call_Date { get; set; }

        [Column("CallBy")]
        [StringLength(500)]
        public string Call_By { get; set; }

        [Column("Remark")]
        [StringLength(500)]
        public string Remark { get; set; }
    }
}
