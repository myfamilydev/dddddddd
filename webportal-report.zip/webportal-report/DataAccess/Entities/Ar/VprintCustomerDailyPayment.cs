﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintCustomerDailyPayment
    {
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("payment")]
        public decimal? Payment { get; set; }
        public decimal? PaidPrinciple { get; set; }
        public decimal? PaidInterest { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [StringLength(30)]
        public string PhoneContact1 { get; set; }
        [StringLength(30)]
        public string PhoneContact2 { get; set; }
        [Column("houseNumber")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        public int ContractId { get; set; }
        [StringLength(150)]
        public string Street { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }
        [Column("name_en2")]
        [StringLength(150)]
        public string NameEn2 { get; set; }
    }
}
