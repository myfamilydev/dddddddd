﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VPrintContractTerminationTransfer
    {
      public int id { get; set; }
        [Column("cus1")]
        [StringLength(150)]
        public string Cus1 { get; set; }
        [Column("cus1dob", TypeName = "date")]
        public DateTime? Cus1dob { get; set; }
        [Column("cus1nat")]
        [StringLength(50)]
        public string Cus1nat { get; set; }
        [Column("cus1id")]
        [StringLength(50)]
        public string Cus1id { get; set; }
        [Column("cus1phone")]
        [StringLength(30)]
        public string Cus1phone { get; set; }
        [Column("cus2")]
        [StringLength(150)]
        public string Cus2 { get; set; }
        [Column("cus2dob", TypeName = "date")]
        public DateTime? Cus2dob { get; set; }
        [Column("cus2nat")]
        [StringLength(50)]
        public string Cus2nat { get; set; }
        [Column("cus2id")]
        [StringLength(50)]
        public string Cus2id { get; set; }
        [Column("cus2phone")]
        [StringLength(30)]
        public string Cus2phone { get; set; }
        [Column("houseNo")]
        [StringLength(10)]
        public string HouseNo { get; set; }
        [Required]
        [Column("houseType")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("streetNo")]
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Column("project")]
        [StringLength(100)]
        public string Project { get; set; }
        [Column("contractDate", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("houseNoTo")]
        [StringLength(10)]
        public string HouseNoTo { get; set; }
        
        [Column("houseTypeTo")]
        [StringLength(100)]
        public string HouseTypeTo { get; set; }
        [Column("streetNoTo")]
        [StringLength(150)]
        public string StreetNoTo { get; set; }
        [Column("projectTo")]
        [StringLength(100)]
        public string ProjectTo { get; set; }
        [Column("contractDateTo", TypeName = "date")]
        public DateTime? ContractDateTo { get; set; }
        [Column("terminationDate", TypeName = "datetime")]
        public DateTime? TerminationDate { get; set; }
        [Column("paid")]
        public decimal? Paid { get; set; }
        public string PaidInKhmer { get; set; }
    }
}
