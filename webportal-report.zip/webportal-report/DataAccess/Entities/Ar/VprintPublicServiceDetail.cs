﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintPublicServiceDetail
    {
        public int? ReceiptNo { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime PaymentDate { get; set; }
        public decimal MonthlyFee { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        public float? PaidAmount { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("waive")]
        public decimal? Waive { get; set; }
        public decimal GrossAmount { get; set; }
        [Column("discount_amount")]
        public decimal? DiscountAmount { get; set; }
        public decimal? NetPay { get; set; }
        [StringLength(50)]
        public string UpdateBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
