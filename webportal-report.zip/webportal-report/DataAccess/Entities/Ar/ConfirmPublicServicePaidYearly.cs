﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.AR
{
    public partial class ConfirmPublicServicePaidYearly
    {       
        public string ProjectShort { get; set; }
        public string HouseNumber { get; set; }
        public string Customer1 { get; set; }
        public string C1Phone { get; set; }
        public string Customer2 { get; set; }
        public string C2Phone { get; set; }
        public string CurrentStayName { get; set; }
        public string CurrentStayContact { get; set; }
        public decimal MonthlyFee { get; set; }
        public DateTime? LastPaymentDate { get; set; }
        public int NDayRemain { get; set; }
        
    }
}