﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintAdhocDiscount
    {
       [Column("project_id")]
        public short? ProjectId { get; set; }
        [StringLength(100)]
        public string ProjectName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string StreetNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(23)]
        public string HouseSize { get; set; }
        [StringLength(150)]
        public string CustomerName { get; set; }
        public int? ContractNumber { get; set; }
        [Column(TypeName = "date")]
        public DateTime? BookingDate { get; set; }
        public decimal? HousePrice { get; set; }
         public decimal DiscountAmount { get; set; }
       public decimal? NetSale { get; set; }
        public decimal? BookingAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("discount_date", TypeName = "date")]
        public DateTime DiscountDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("name_en")]
        [StringLength(150)]
        public string NameEn { get; set; }
       public decimal? AdhocDiscount { get; set; }
    }
}
