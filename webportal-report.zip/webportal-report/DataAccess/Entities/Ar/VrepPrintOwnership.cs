﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VrepPrintOwnership
    {
        public int OwnershipId { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName11 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob1 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard1 { get; set; }
        [StringLength(50)]
        public string CustomerNationality1 { get; set; }
        [StringLength(30)]
        public string CustomerPhoneCall1 { get; set; }
        [StringLength(150)]
        public string NewCustomerName1 { get; set; }
        [StringLength(50)]
        public string NewCustomerSex1 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NewCustomerDob1 { get; set; }
        [StringLength(50)]
        public string NewCustomerIdCard1 { get; set; }
        [StringLength(50)]
        public string NewCustomerNationality1 { get; set; }
        [StringLength(30)]
        public string NewCustomerPhoneCall1 { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseTypeName { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string HouseStreet { get; set; }
        [StringLength(250)]
        public string HouseVillage { get; set; }
        [StringLength(250)]
        public string HouseCommune { get; set; }
        [StringLength(250)]
        public string HouseDistrict { get; set; }
        [StringLength(250)]
        public string HouseProvince { get; set; }
        [StringLength(10)]
        public string HouseLandWidth { get; set; }
        [StringLength(10)]
        public string HouseLandLength { get; set; }
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [StringLength(10)]
        public string HouseLength { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateContract { get; set; }
        [StringLength(150)]
        public string ContractCustomerName1 { get; set; }
        [StringLength(150)]
        public string ContractCustomerName2 { get; set; }
        public byte? OwnershipRecStatus { get; set; }
        [Column(TypeName = "date")]
        public DateTime? OwnershipRequestDate { get; set; }
        [StringLength(30)]
        public string OwnershipRequestType { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CustomerDob2 { get; set; }
        [StringLength(50)]
        public string CustomerIdCard2 { get; set; }
        [StringLength(50)]
        public string CustomerNationality2 { get; set; }
        [StringLength(30)]
        public string CustomerPhoneCall2 { get; set; }
        [StringLength(150)]
        public string NewCustomerName2 { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NewCustomerDob2 { get; set; }
        [StringLength(50)]
        public string NewCustomerNationality2 { get; set; }
        [StringLength(30)]
        public string NewCustomerPhoneCall2 { get; set; }
        [StringLength(50)]
        public string NewCustomerIdCard2 { get; set; }
        [StringLength(50)]
        public string NewCustomerSex2 { get; set; }
        [StringLength(255)]
        public string ProjectProvince { get; set; }
        [StringLength(255)]
        public string ProjectVillage { get; set; }
        [StringLength(255)]
        public string ProjectCommune { get; set; }
        [StringLength(255)]
        public string ProjectDistrict { get; set; }
        [StringLength(255)]
        public string ProjectName { get; set; }
        [StringLength(100)]
        public string ProjectAbbr { get; set; }
    }
}
