﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.Ar
{

    public partial class VprintScheduleDetailSale
    {
        public long ScheduleId { get; set; }  //payment_schedule_info_id 
        [Column("payment_schedule_info_id")]
        public int PaymentScheduleInfoId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("PaymentAmount", TypeName = "decimal(15, 2)")]
        public decimal? PaymentAmount { get; set; }
        [Column("principle", TypeName = "decimal(15, 2)")]
        public decimal? Principle { get; set; }
        [Column("interest", TypeName = "decimal(15, 2)")]
        public decimal? Interest { get; set; }
        [Column("accumulate_principle", TypeName = "decimal(15, 2)")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest", TypeName = "decimal(15, 2)")]
        public decimal? AccumulateInterest { get; set; }
        public long? ReceiptNo { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("PaidAmount", TypeName = "decimal(15, 2)")]
        public decimal? PaidAmount { get; set; }

        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("paid_interest", TypeName = "decimal(15, 2)")]
        public decimal? PaidInterest { get; set; }
        [Column("waive_interest", TypeName = "decimal(15, 2)")]
        public decimal? WaiveInterest { get; set; }

        [Column("end_balance", TypeName = "decimal(15, 2)")]
        public decimal? EndBalance { get; set; }
        public string TransactionNumber { get; set; }
        public string PrePrinted { get; set; }
    }
}
