﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Entities.Ar
{
    public partial class VHouseHandOverReport
    {
        [Column("name_kh")]
        [StringLength(100)]
        public string Name_Kh { get; set; }

        [Column("project_short")]
        [StringLength(10)]
        public string Projects { get; set; }

        [Column("number")]
        public string House_No { set; get; }

        [Column("st_no")]
        [StringLength(150)]
        public string Street_No { get; set; }


        [Column("name")]
        [StringLength(150)]
        public string House_Types { get; set; }

        [Column("hand_over_date", TypeName = "date")]
        public DateTime? Hand_Over_Date { get; set; }

        [Column("warrenty_end_date", TypeName = "date")]
        public DateTime? Warrenty_End_Date { get; set; }

        [Column("schedule_date", TypeName = "date")]
        public DateTime? Schedule_Date { get; set; }

        [Column("person_handle")]
        [StringLength(150)]
        public string Person_Handle { get; set; }

        [Column("water")]
        public string? Water { get; set; }
        [Column("electricity")]
        public string? Electrivity { get; set; }


        [Column("remark")]
        [StringLength(500)]
        public string Remarks { get; set; }
    }
}
