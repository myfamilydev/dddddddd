﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.AR
{
    public partial class VprintInterestDetail
    {
        [Column(TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("start_balance", TypeName = "decimal(15, 2)")]
        public decimal? StartBalance { get; set; }
        public float? MonthlyPayment { get; set; }
        [Column("principle")]
        public float? Principle { get; set; }
        public float? InterestInMoney { get; set; }
        [Column("accumulate_principle", TypeName = "decimal(15, 2)")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest", TypeName = "decimal(15, 2)")]
        public decimal? AccumulateInterest { get; set; }
        [Column("end_balance", TypeName = "decimal(15, 2)")]
        public decimal? EndBalance { get; set; }
        public long? ReceiptNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PaidDate { get; set; }
        public float? PaidAmount { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [StringLength(50)]
        public string CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? UpdatedDate { get; set; }
        [StringLength(50)]
        public string UpdatedBy { get; set; }
        public long ScheduleId { get; set; }
    }
}
