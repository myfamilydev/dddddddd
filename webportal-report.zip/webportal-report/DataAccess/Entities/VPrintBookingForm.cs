﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VPrintBookingForm
    {
        [Required]
        [Column("logo")]
        [StringLength(50)]
        public string Logo { get; set; }
        [Column("booking_id")]
        public int BookingId { get; set; }
        [Column("cus1_name")]
        [StringLength(167)]
        public string Cus1Name { get; set; }
        [Column("cus1_name1")]
        [StringLength(150)]
        public string Cus1Name1 { get; set; }
        [Column("cus2_name")]
        [StringLength(167)]
        public string Cus2Name { get; set; }
        [Column("cus2_name1")]
        [StringLength(150)]
        public string Cus2Name1 { get; set; }
        [Column("cus1_address")]
        [StringLength(808)]
        public string Cus1Address { get; set; }
        [Column("cus1_tel1")]
        [StringLength(42)]
        public string Cus1Tel1 { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("land_size")]
        [StringLength(203)]
        public string LandSize { get; set; }
        [Required]
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("house_price")]
        [StringLength(4000)]
        public string HousePrice { get; set; }
        [Column("booking_amount")]
        [StringLength(4000)]
        public string BookingAmount { get; set; }
        [Column("booking_term")]
        public string BookingTerm { get; set; }
        [Column("booking_day")]
        public int? BookingDay { get; set; }
        [Column("booking_month")]
        public int? BookingMonth { get; set; }
        [Column("booking_year")]
        public int? BookingYear { get; set; }
        [Column("house_price_word")]
        [StringLength(300)]
        public string HousePriceWord { get; set; }
        [Column("cus1_tel2")]
        [StringLength(20)]
        public string Cus1Tel2 { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("exp_day")]
        public int? ExpDay { get; set; }
        [Column("exp_month")]
        public int? ExpMonth { get; set; }
        [Column("exp_year")]
        public int? ExpYear { get; set; }
    }
}
