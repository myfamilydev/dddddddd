﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("public_service_schedules_adjustment")]
    public partial class PublicServiceSchedulesAdjustment
    {
        [Key]
        [Column("public_service_adjustment_id")]
        public int PublicServiceAdjustmentId { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("public_service_id")]
        public int PublicServiceId { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime PaymentDate { get; set; }
        [Column("monthly_fee")]
        public double MonthlyFee { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("paid")]
        public double? Paid { get; set; }
        [Column("current_paid")]
        public double? CurrentPaid { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("waive")]
        public double? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        [Column("discount_amount")]
        public double? DiscountAmount { get; set; }
    }
}
