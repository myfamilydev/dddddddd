﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("penalty_payment_detail")]
    public partial class PenaltyPaymentDetail
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("schedule_id")]
        public int? ScheduleId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("schedule_date", TypeName = "date")]
        public DateTime? ScheduleDate { get; set; }
        [Column("schedule_payment", TypeName = "money")]
        public decimal? SchedulePayment { get; set; }
        [Column("schedule_paid", TypeName = "money")]
        public decimal? SchedulePaid { get; set; }
        [Column("schedule_remain", TypeName = "money")]
        public decimal? ScheduleRemain { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("penalty_payment", TypeName = "money")]
        public decimal? PenaltyPayment { get; set; }
        [Column("pre_penalty_paid", TypeName = "money")]
        public decimal? PrePenaltyPaid { get; set; }
        [Column("penalty_paid", TypeName = "money")]
        public decimal? PenaltyPaid { get; set; }
        [Column("current_paid", TypeName = "money")]
        public decimal? CurrentPaid { get; set; }
        [Column("schedule_paid_current", TypeName = "money")]
        public decimal? SchedulePaidCurrent { get; set; }
        [Column("waive", TypeName = "money")]
        public decimal? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("in_type")]
        public int? InType { get; set; }
        [Column("is_change_end_date")]
        public bool? IsChangeEndDate { get; set; }
        [Column("in_date", TypeName = "date")]
        public DateTime? InDate { get; set; }
    }
}
