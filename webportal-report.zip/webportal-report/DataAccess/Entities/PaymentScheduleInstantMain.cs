﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("payment_schedule_instant_main")]
    public partial class PaymentScheduleInstantMain
    {
        [Column("n_monthly_interest", TypeName = "decimal(8, 7)")]
        public decimal? NMonthlyInterest { get; set; }
        [Column("n_percent", TypeName = "numeric(8, 7)")]
        public decimal? NPercent { get; set; }
        [Column("n_period_month")]
        public int? NPeriodMonth { get; set; }
        [Column("n_contract_date", TypeName = "date")]
        public DateTime? NContractDate { get; set; }
        [Column("n_net_amount", TypeName = "money")]
        public decimal? NNetAmount { get; set; }
        [Column("n_discount_amount", TypeName = "money")]
        public decimal? NDiscountAmount { get; set; }
        [Column("n_contract_amount", TypeName = "money")]
        public decimal? NContractAmount { get; set; }
        [Column("monthly_interest", TypeName = "numeric(8, 7)")]
        public decimal? MonthlyInterest { get; set; }
        [Column("percent", TypeName = "numeric(8, 7)")]
        public decimal? Percent { get; set; }
        [Column("period_month")]
        public int? PeriodMonth { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("net_amount", TypeName = "money")]
        public decimal? NetAmount { get; set; }
        [Column("discount_amount", TypeName = "money")]
        public decimal? DiscountAmount { get; set; }
        [Column("contract_amount", TypeName = "money")]
        public decimal? ContractAmount { get; set; }
        [Column("booking_amount", TypeName = "money")]
        public decimal? BookingAmount { get; set; }
        [Column("initial_payment", TypeName = "money")]
        public decimal? InitialPayment { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
    }
}
