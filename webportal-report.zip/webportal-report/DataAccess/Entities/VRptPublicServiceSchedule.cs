﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VRptPublicServiceSchedule
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("project_id")]
        public int ProjectId { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("amount")]
        public double Amount { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime PaymentDate { get; set; }
        [Column("receipt_no")]
        public int? ReceiptNo { get; set; }
        [Column("actual_paid_date", TypeName = "date")]
        public DateTime? ActualPaidDate { get; set; }
        [Column("actual_paid")]
        public double? ActualPaid { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
