﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("holiday_schedule")]
    public partial class HolidaySchedule
    {
        [Key]
        [Column("year")]
        public int Year { get; set; }
        [Column("holiday_date", TypeName = "date")]
        public DateTime? HolidayDate { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
    }
}
