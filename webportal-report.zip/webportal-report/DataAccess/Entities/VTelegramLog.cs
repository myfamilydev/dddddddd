﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VTelegramLog
    {
        [Column("no")]
        public int No { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [StringLength(266)]
        public string HouseTitle { get; set; }
        [Column("telegram_content")]
        [StringLength(3000)]
        public string TelegramContent { get; set; }
        [Column("user_id")]
        public int? UserId { get; set; }
    }
}
