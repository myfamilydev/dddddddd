﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("other_collection_info")]
    public partial class OtherCollectionInfo
    {
        [Key]
        [Column("regular_collection_id")]
        public int RegularCollectionId { get; set; }
        [Column("transaction_category_id")]
        public int? TransactionCategoryId { get; set; }
        [Column("other_customer")]
        [StringLength(150)]
        public string OtherCustomer { get; set; }
        [Column("phone_contact")]
        [StringLength(20)]
        public string PhoneContact { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
    }
}
