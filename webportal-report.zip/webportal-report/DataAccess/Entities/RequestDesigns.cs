﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("request_designs")]
    public partial class RequestDesigns
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("req_id")]
        [StringLength(10)]
        public string ReqId { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("house_category_id")]
        public int HouseCategoryId { get; set; }
        [Column("house_type_id")]
        public int HouseTypeId { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("customer_id")]
        public int CustomerId { get; set; }
        [Column("customer_1")]
        public int? Customer1 { get; set; }
        [Column("customer_2")]
        public int? Customer2 { get; set; }
        [Column("request_date", TypeName = "datetime")]
        public DateTime RequestDate { get; set; }
        [Required]
        [Column("description")]
        public string Description { get; set; }
        [Column("attach_plan")]
        [StringLength(200)]
        public string AttachPlan { get; set; }
        [Required]
        [Column("customer_email")]
        [StringLength(100)]
        public string CustomerEmail { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Required]
        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime UpdatedAt { get; set; }
    }
}
