﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VPrintDiscount
    {
        [Column("discount_amount")]
        public double? DiscountAmount { get; set; }
        [Column("house_type")]
        [StringLength(124)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("village")]
        [StringLength(150)]
        public string Village { get; set; }
        [Column("commune")]
        [StringLength(150)]
        public string Commune { get; set; }
        [Column("province")]
        [StringLength(150)]
        public string Province { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("land_width")]
        [StringLength(100)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(100)]
        public string LandLength { get; set; }
        [Column("house_width")]
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [Column("house_length")]
        [StringLength(10)]
        public string HouseLength { get; set; }
    }
}
