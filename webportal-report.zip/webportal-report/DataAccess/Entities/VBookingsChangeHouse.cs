﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VBookingsChangeHouse
    {
        [Column(TypeName = "datetime")]
        public DateTime? ChangeHouseDate { get; set; }
        [StringLength(150)]
        public string KhmerName { get; set; }
        [Column("From_ProjectName")]
        [StringLength(255)]
        public string FromProjectName { get; set; }
        [Column("From_HouseType")]
        [StringLength(100)]
        public string FromHouseType { get; set; }
        [Column("From_HouseNo")]
        [StringLength(10)]
        public string FromHouseNo { get; set; }
        [Column("From_StreetNo")]
        [StringLength(150)]
        public string FromStreetNo { get; set; }
        [Column("From_HouseSize")]
        [StringLength(23)]
        public string FromHouseSize { get; set; }
        [Column("From_HousePrice")]
        public float? FromHousePrice { get; set; }
        [Column("To_ProjectName")]
        [StringLength(255)]
        public string ToProjectName { get; set; }
        [Column("To_HouseType")]
        [StringLength(100)]
        public string ToHouseType { get; set; }
        [Column("To_HouseNo")]
        [StringLength(10)]
        public string ToHouseNo { get; set; }
        [Column("To_StreetNo")]
        [StringLength(150)]
        public string ToStreetNo { get; set; }
        [Column("To_HouseSize")]
        [StringLength(24)]
        public string ToHouseSize { get; set; }
        [Column("reason")]
        [StringLength(500)]
        public string Reason { get; set; }
        public short ToProjectId { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
    }
}
