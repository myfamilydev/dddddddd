﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VContracts
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_term_id")]
        public int? ContractTermId { get; set; }
        [Column("ad_hoc_discount_id")]
        public int? AdHocDiscountId { get; set; }
        [Column("initial_payment", TypeName = "decimal(10, 2)")]
        public decimal? InitialPayment { get; set; }
        [Column("payment_term_data")]
        public string PaymentTermData { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        [Column("payment_term_month")]
        public short? PaymentTermMonth { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer_relationship")]
        [StringLength(100)]
        public string CustomerRelationship { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("contract_amount", TypeName = "decimal(10, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("merged_houses")]
        [StringLength(250)]
        public string MergedHouses { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [StringLength(30)]
        public string CustomerPhone1 { get; set; }
        [StringLength(30)]
        public string CustomerPhone2 { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [Column("effective_date", TypeName = "date")]
        public DateTime? EffectiveDate { get; set; }
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(200)]
        public string CreatedByName { get; set; }
    }
}
