﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VAdhocDiscountStatus
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int BookingId { get; set; }
        [Column("discount_amount")]
        public float DiscountAmount { get; set; }
        [Column("discount_date", TypeName = "date")]
        public DateTime DiscountDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("discount_percent")]
        public double? DiscountPercent { get; set; }
        [Column("booking_history_id")]
        public int? BookingHistoryId { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
    }
}
