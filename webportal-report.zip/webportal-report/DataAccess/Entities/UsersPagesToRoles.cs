﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("users_pages_to_roles")]
    public partial class UsersPagesToRoles
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("page_id")]
        public int? PageId { get; set; }
        [Column("role_id")]
        public int? RoleId { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }

        [ForeignKey(nameof(PageId))]
        [InverseProperty(nameof(UsersPages.UsersPagesToRoles))]
        public virtual UsersPages Page { get; set; }
        [ForeignKey(nameof(RoleId))]
        [InverseProperty(nameof(UsersRoles.UsersPagesToRoles))]
        public virtual UsersRoles Role { get; set; }
    }
}
