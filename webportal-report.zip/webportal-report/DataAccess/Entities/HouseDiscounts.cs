﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("house_discounts")]
    public partial class HouseDiscounts
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("discount_id")]
        [StringLength(10)]
        public string DiscountId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("amount")]
        public double? Amount { get; set; }
        [Column("net_price")]
        public double? NetPrice { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
