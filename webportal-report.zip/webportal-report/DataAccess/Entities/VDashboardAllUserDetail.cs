﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VDashboardAllUserDetail
    {
        [Column("project_code")]
        [StringLength(50)]
        public string ProjectCode { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("total_house")]
        public int? TotalHouse { get; set; }
        [Column("total_contracted")]
        public int? TotalContracted { get; set; }
        [Column("total_outstanding_booking")]
        public int? TotalOutstandingBooking { get; set; }
        [Column("total_remaing_house")]
        public int? TotalRemaingHouse { get; set; }
        [Column("total_house_late_payment")]
        public int? TotalHouseLatePayment { get; set; }
    }
}
