﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("payment_schedules_instant")]
    public partial class PaymentSchedulesInstant
    {
        [Column("payment_schedule_instant_info_id")]
        public int? PaymentScheduleInstantInfoId { get; set; }
        [Column("payment_no")]
        public int? PaymentNo { get; set; }
        [Column("start_balance", TypeName = "money")]
        public decimal? StartBalance { get; set; }
        [Column("end_balance", TypeName = "money")]
        public decimal? EndBalance { get; set; }
        [Column("payment", TypeName = "money")]
        public decimal? Payment { get; set; }
        [Column("principle", TypeName = "money")]
        public decimal? Principle { get; set; }
        [Column("interest", TypeName = "money")]
        public decimal? Interest { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("accumulate_principle", TypeName = "money")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest", TypeName = "money")]
        public decimal? AccumulateInterest { get; set; }
    }
}
