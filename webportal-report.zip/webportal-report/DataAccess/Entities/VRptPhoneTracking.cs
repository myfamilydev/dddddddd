﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VRptPhoneTracking
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("project_name")]
        [StringLength(255)]
        public string ProjectName { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("purpose")]
        [StringLength(50)]
        public string Purpose { get; set; }
        [Column("call_time", TypeName = "datetime")]
        public DateTime? CallTime { get; set; }
        [Column("phone_number")]
        [StringLength(50)]
        public string PhoneNumber { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
    }
}
