﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VBookingHousesExpired
    {
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("house_category_id")]
        public int? HouseCategoryId { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        public byte? ContractStatus { get; set; }
        public int? ContractHouseId { get; set; }
    }
}
