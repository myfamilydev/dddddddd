﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VHousePriceDetails
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("price")]
        public float? Price { get; set; }
        [Required]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_width")]
        [StringLength(10)]
        public string HouseWidth { get; set; }
        [Column("house_length")]
        [StringLength(10)]
        public string HouseLength { get; set; }
        [Column("land_width")]
        [StringLength(10)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        public string LandLength { get; set; }
    }
}
