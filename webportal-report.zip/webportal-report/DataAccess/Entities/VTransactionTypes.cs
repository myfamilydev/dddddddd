﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VTransactionTypes
    {
        [Column("id")]
        public byte Id { get; set; }
        [Column("transaction_name")]
        [StringLength(50)]
        public string TransactionName { get; set; }
        [Column("remark")]
        [StringLength(200)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("transaction_category_id")]
        public int? TransactionCategoryId { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("category_name")]
        [StringLength(50)]
        public string CategoryName { get; set; }
    }
}
