﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("contracts_terminations")]
    public partial class ContractsTerminations
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("termination_type")]
        public int? TerminationType { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id_transfer")]
        public int? HouseIdTransfer { get; set; }
        [Column("total_principle")]
        public double? TotalPrinciple { get; set; }
        [Column("total_paid_principle")]
        public int? TotalPaidPrinciple { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("contract_history_id")]
        public int? ContractHistoryId { get; set; }
    }
}
