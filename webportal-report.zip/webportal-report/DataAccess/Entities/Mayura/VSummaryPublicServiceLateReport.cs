﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    
    public partial class VSummaryPublicServiceLateReport
    {

        [Column("project_short")]
        public string ProjectShort { get; set; }
        [Column ("ownership")]
        public string Ownership { get; set; }

        [Column("n_house_sold")]
        public int? NHouseSold { get; set; }
        [Column("n_called_follow_up")]
        public int? NCallFollowUp { get; set; }
        [Column("n_issue_late_letter")]
        public int? NIssueLateLetter { get; set; }
        [Column("total_house_paid", TypeName = "decimal(10, 2)")]
        public decimal? TotalHousePaid { get; set; }
        [Column("count_house_paid")]
        public int? CountHousePaid { get; set; }
        [Column("count_house_paid_month_1")]
        public int? CountHousePaidMonth1 { get; set; }
        [Column("count_house_paid_month_12")]
        public int? CountHousePaidMonth12 { get; set; }
        [Column("count_house_paid_month_30")]
        public int? CountHousePaidMonth30 { get; set; }
        [Column("count_house_paid_month_gt_30")]
        public int? CountHousePaidMonthGT30 { get; set; }

        [Column("total_house_not_paid", TypeName = "decimal(10, 2)")]
        public decimal? TotalHouseNotPaid { get; set; }
        [Column("count_house_not_paid")]
        public int? CountHouseNotPaid { get; set; }
        [Column("count_house_not_paid_month_1")]
        public int? CountHouseNotPaidMonth1 { get; set; }
        [Column("count_house_not_paid_month_12")]
        public int? CountHouseNotPaidMonth12 { get; set; }
        [Column("count_house_not_paid_month_30")]
        public int? CountHouseNotPaidMonth30 { get; set; }
        [Column("count_house_not_paid_month_gt_30")]
        public int? CountHouseNotPaidMonthGT30 { get; set; }

    }
}
