﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    [Table("final_payments")]
    public partial class FinalPayments
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("customer_relationship")]
        [StringLength(100)]
        public string CustomerRelationship { get; set; }
        [Column("final_pay_amount", TypeName = "decimal(15, 8)")]
        public decimal? FinalPayAmount { get; set; }
        [Column("paid_off_percentage")]
        public double? PaidOffPercentage { get; set; }
        [Column("paid_off_discount", TypeName = "decimal(15, 8)")]
        public decimal? PaidOffDiscount { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("interest", TypeName = "decimal(15, 8)")]
        public decimal? Interest { get; set; }
        [Column("waive_interest", TypeName = "decimal(15, 8)")]
        public decimal? WaiveInterest { get; set; }
        [Column("waive_interest_ref")]
        public int? WaiveInterestRef { get; set; }
        [Column("over_final_payment", TypeName = "decimal(15, 8)")]
        public decimal? OverFinalPayment { get; set; }
        [Column("remain_amount", TypeName = "decimal(15, 8)")]
        public decimal? RemainAmount { get; set; }
        [Column("final_payment_date", TypeName = "date")]
        public DateTime? FinalPaymentDate { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("not_income")]
        public bool? NotIncome { get; set; }
    }
}
