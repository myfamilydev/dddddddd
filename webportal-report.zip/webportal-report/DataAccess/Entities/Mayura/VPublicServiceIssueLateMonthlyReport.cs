﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    public partial class VPublicServiceIssueLateLetterReport
    {
        [Column("issue_late_letter_id")]
        public int? IssueLateLetterId { get; set; }
        [Column("house_category")]
        [StringLength(250)]
        public string HouseCategory { get; set; }
        [Column("street_no")]
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Column("project_short")]
        [StringLength(50)]
        public string ProjectShort { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("n_month_late")]
        public short? NMonthLate { get; set; }
        [Column("total_payment", TypeName = "decimal(10, 2)")]
        public decimal? TotalPayment { get; set; }
        [Column("next_payment")]
        [StringLength(4000)]
        public string NextPayment { get; set; }
        [Required]
        [Column("customer_name1")]
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column("customer_name2")]
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column("phone_contract")]
        [StringLength(263)]
        public string PhoneContract { get; set; }
        [Column("remark")]
        public string Remark { get; set; }

        [Column("monthly_fee", TypeName = "decimal(8, 2)")]
        public decimal? MonthlyFee { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_part_unit")]
        [StringLength(30)]
        public string HousePartUnit { get; set; }
        [Column("house_part_number")]
        public int? HousePartNumber { get; set; }
    }
}
