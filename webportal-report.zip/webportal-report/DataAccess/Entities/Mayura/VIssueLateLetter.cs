﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    public partial class VPublicServiceIssueLateLetter
    {
        [Column("issue_late_letter_id")]
        public int? IssueLateLetterId { get; set; }
        [Column("customer_name1")]
        [StringLength(150)]
        public string CustomerName1 { get; set; }
        [Column("customer_name2")]
        [StringLength(150)]
        public string CustomerName2 { get; set; }
        [Column("house_category")]
        [StringLength(250)]
        public string HouseCategory { get; set; }
        [Column("project_short")]
        [StringLength(50)]
        public string ProjectShort { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("dead_line", TypeName = "date")]
        public DateTime? DeadLine { get; set; }
        [Column("n_month_late")]
        public short? NMonthLate { get; set; }
        [Column("total_payment", TypeName = "decimal(10, 2)")]
        public decimal? TotalPayment { get; set; }
        [Column("date_from", TypeName = "date")]
        public DateTime? DateFrom { get; set; }
        [Column("date_to", TypeName = "date")]
        public DateTime? DateTo { get; set; }
        [Column("approval_date", TypeName = "date")]
        public DateTime? ApprovalDate { get; set; }
        [Column("payproaccid")]
        [StringLength(30)]
        public string Payproaccid { get; set; }
        [Column("billercode")]
        [StringLength(30)]
        public string Billercode { get; set; }
        [Column("acleda_account_name")]
        [StringLength(150)]
        public string AcledaAccountName { get; set; }
        [Column("acleda_account_code")]
        [StringLength(150)]
        public string AcledaAccountCode { get; set; }
        [Column("aba_account_name")]
        [StringLength(150)]
        public string AbaAccountName { get; set; }
        [Column("aba_account_code")]
        [StringLength(150)]
        public string AbaAccountCode { get; set; }
        [Column("sbi_account_name")]
        [StringLength(150)]
        public string SbiAccountName { get; set; }
        [Column("sbi_account_code")]
        [StringLength(150)]
        public string SbiAccountCode { get; set; }
        [Column("fnd_no")]
        [StringLength(50)]
        public string FndNo { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("announce_no")]
        [StringLength(20)]
        public string AnnounceNo { get; set; }
        [Column("announce_date", TypeName = "date")]
        public DateTime? AnnounceDate { get; set; }

    }
}
