﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    public partial class VPresentIssueLetter
    {
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("house_category")]
        [StringLength(250)]
        public string HouseCategory { get; set; }
        [Column("street_no")]
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("booking_id")]
        public int? BookingId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("issue_no")]
        [StringLength(50)]
        public string IssueNo { get; set; }
        [Column("fnd_no")]
        [StringLength(50)]
        public string FNDNo { get; set; }
        [Column("issue_date", TypeName = "date")]
        public DateTime? IssueDate { get; set; }
        [Column("approval_date", TypeName = "date")]
        public DateTime? ApprovalDate { get; set; }
        [Column("current_customer1_id")]
        public int? CurrentCustomer1Id { get; set; }
        [Column("current_customer2_id")]
        public int? CurrentCustomer2Id { get; set; }
        [Column("customer_name")]
        [StringLength(303)]
        public string CustomerName { get; set; }
        [Column("phone_contract")]
        [StringLength(203)]
        public string PhoneContract { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
    }
}
