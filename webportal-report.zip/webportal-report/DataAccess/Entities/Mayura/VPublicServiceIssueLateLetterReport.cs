﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    public partial class VPublicServiceIssueLateMonthlyReport
    {

        [Column("project_short")]
        [StringLength(50)]
        public string ProjectShort { get; set; }


        [Column("house_category")]
        [StringLength(250)]
        public string HouseCategory { get; set; }

        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }


        [Column("street_no")]
        [StringLength(150)]
        public string StreetNo { get; set; }

        [Column("customer_name")]
        [StringLength(150)]
        public string CustomerName { get; set; }
        [Column("phone_contract")]
        [StringLength(150)]
        public string PhoneContract { get; set; }

        [Column("monthly_fee", TypeName = "decimal(10, 2)")]
        public decimal? MonthlyFee { get; set; }

        [Column("n_month_late")]
        public short? NMonthLate { get; set; }

        [Column("total_payment", TypeName = "decimal(10, 2)")]
        public decimal? TotalPayment { get; set; }

        [Column("issue_date", TypeName = "date")]
        public DateTime? IssueDate { get; set; }
        [Column("dead_line", TypeName = "date")]
        public DateTime? DeadLine { get; set; }

        [Column("fnd_no")]
        [StringLength(50)]
        public string FndNo { get; set; }

        [Column("remark")]
        public string Remark { get; set; }

    }
}
