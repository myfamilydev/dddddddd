﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    [Table("projects")]
    public partial class Projects
    {
        [Key]
        [Column("id")]
        public short Id { get; set; }
        [Column("project_code")]
        [StringLength(10)]
        public string ProjectCode { get; set; }
        [Column("project_abbr")]
        [StringLength(100)]
        public string ProjectAbbr { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("name")]
        [StringLength(255)]
        public string Name { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Column("detail")]
        public string Detail { get; set; }
        [Column("landsize")]
        [StringLength(255)]
        public string Landsize { get; set; }
        [Column("village")]
        [StringLength(255)]
        public string Village { get; set; }
        [Column("communue")]
        [StringLength(255)]
        public string Communue { get; set; }
        [Column("district")]
        [StringLength(255)]
        public string District { get; set; }
        [Column("province")]
        [StringLength(255)]
        public string Province { get; set; }
        [Column("ownership")]
        [StringLength(255)]
        public string Ownership { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("status")]
        public byte? Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
