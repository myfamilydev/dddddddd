﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entities.Mayura
{
    public partial class VCustomerWalkInProject
    {
        [Column("id")]
        public short Id { get; set; }
        [Column("project_code")]
        [StringLength(10)]
        public string ProjectCode { get; set; }
        [Column("project_abbr")]
        [StringLength(100)]
        public string ProjectAbbr { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("name")]
        [StringLength(255)]
        public string Name { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
    }
}
