﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    [Table("users")]
    public partial class Users
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("uuid")]
        public Guid? Uuid { get; set; }
        [Column("full_name")]
        [StringLength(200)]
        public string FullName { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("password")]
        [StringLength(150)]
        public string Password { get; set; }
        [Column("password_change_at", TypeName = "datetime")]
        public DateTime? PasswordChangeAt { get; set; }
        [Column("email")]
        [StringLength(100)]
        public string Email { get; set; }
        [Column("designation")]
        [StringLength(200)]
        public string Designation { get; set; }
        [Column("department")]
        public short? Department { get; set; }
        [Column("phone_number")]
        [StringLength(50)]
        public string PhoneNumber { get; set; }
        [Column("telegram_id")]
        public int? TelegramId { get; set; }
        [Column("status")]
        public byte Status { get; set; }
        [Column("direct_manager_id")]
        public int? DirectManagerId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
