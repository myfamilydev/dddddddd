﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DataAccess.Entities.Mayura
{
    public partial class VPublicServicePrepaid
    {
        [Column("regular_collection_id")]
        public int? ReceiptId { get; set; }
        [Column("project_short")]       
        public string ProjectShort { get; set; }

        [Column("contract_id")]
        public int? ContractId { get; set; }

        [Column("house_number")]        
        public string HouseNumber { get; set; }

        [Column("customer_name")]
        public string CustomerName { set; get; }

        [Column("phone_contract")]        
        public string PhoneContract { get; set; }       

        [Column("paid_date", TypeName = "date")]
        public DateTime? PaidDate { get; set; }

        [Column("monthly_fee", TypeName = "decimal(10, 2)")]
        public decimal? MonthlyFee { get; set; }
        [Column("late_n_month")]
        public int? LateNMonth { get; set; }

        [Column("total_late_amount", TypeName = "decimal(10, 2)")]
        public decimal? TotalLateAmount { get; set; }
        [Column("discount", TypeName = "decimal(10, 2)")]
        public decimal? Discount { get; set; }
        
        [Column("pre_late_n_month")]
        public int? PreLateNMonth { get; set; }

        [Column("pre_total_late_amount", TypeName = "decimal(10, 2)")]
        public decimal? PreTotalLateAmount { get; set; }



    }
}
