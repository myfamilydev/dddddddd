﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities.Mayura
{
    [Table("issue_late_letter")]
    public partial class IssueLateLetter
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("issue_no")]
        [StringLength(50)]
        public string IssueNo { get; set; }
        [Column("issue_date", TypeName = "date")]
        public DateTime? IssueDate { get; set; }
        [Column("issue_late_letter_type_id")]
        public short? IssueLateLetterTypeId { get; set; }
        [Column("penalty_letter_no")]
        public short? PenaltyLetterNo { get; set; }
        [Column("grace_period")]
        public short? GracePeriod { get; set; }
        [Column("n_late")]
        public short? NLate { get; set; }
        [Column("dead_line", TypeName = "date")]
        public DateTime? DeadLine { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("pre_project_id")]
        public short? PreProjectId { get; set; }
        [Column("pre_issue_date", TypeName = "date")]
        public DateTime? PreIssueDate { get; set; }
        [Column("pre_grace_period")]
        public short? PreGracePeriod { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("status")]
        public short? Status { get; set; }
        [Column("approval_date", TypeName = "date")]
        public DateTime? ApprovalDate { get; set; }
        [Column("fnd_start_no")]
        [StringLength(50)]
        public string FndStartNo { get; set; }
    }
}
