﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("payment_schedules_info")]
    public partial class PaymentSchedulesInfo
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("outstanding_principle")]
        public double? OutstandingPrinciple { get; set; }
        [Column("add_principle")]
        public double? AddPrinciple { get; set; }
        [Column("n_month")]
        public int? NMonth { get; set; }
        [Column("paid_off_amount")]
        public double? PaidOffAmount { get; set; }
        [Column("paid_off_type")]
        [StringLength(10)]
        public string PaidOffType { get; set; }
        [Column("interest_percent_month")]
        public double? InterestPercentMonth { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("reschedule_date", TypeName = "date")]
        public DateTime? RescheduleDate { get; set; }
        [Column("cutoff_penalty_date", TypeName = "date")]
        public DateTime? CutoffPenaltyDate { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("reschedule_no")]
        public int? RescheduleNo { get; set; }
        [Column("reschedule_id")]
        public int? RescheduleId { get; set; }
    }
}
