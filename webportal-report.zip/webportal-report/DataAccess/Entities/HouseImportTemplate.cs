﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("house_import_template")]
    public partial class HouseImportTemplate
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("house_category_name")]
        [StringLength(50)]
        public string HouseCategoryName { get; set; }
        [Column("house_type_name")]
        [StringLength(50)]
        public string HouseTypeName { get; set; }
        [Column("block")]
        [StringLength(10)]
        public string Block { get; set; }
        [Column("road_type")]
        [StringLength(30)]
        public string RoadType { get; set; }
        [Column("number")]
        [StringLength(10)]
        public string Number { get; set; }
        [Column("street_number")]
        [StringLength(200)]
        public string StreetNumber { get; set; }
        [Column("phase")]
        [StringLength(10)]
        public string Phase { get; set; }
        [Column("remarks")]
        [StringLength(500)]
        public string Remarks { get; set; }
        [Column("payproref")]
        [StringLength(30)]
        public string Payproref { get; set; }
        [Column("billercode")]
        [StringLength(30)]
        public string Billercode { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int CreatedBy { get; set; }
        [Column("batch_code")]
        [StringLength(50)]
        public string BatchCode { get; set; }
        [Column("land_width")]
        [StringLength(10)]
        public string LandWidth { get; set; }
        [Column("land_length")]
        [StringLength(10)]
        public string LandLength { get; set; }
    }
}
