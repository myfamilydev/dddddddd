﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VPaymentSchedule
    {
        [Column("id")]
        public long Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("payment_no")]
        public int? PaymentNo { get; set; }
        [Column("start_balance", TypeName = "decimal(15, 2)")]
        public decimal? StartBalance { get; set; }
        [Column("end_balance", TypeName = "decimal(15, 2)")]
        public decimal? EndBalance { get; set; }
        [Column("payment")]
        public float? Payment { get; set; }
        [Column("principle")]
        public float? Principle { get; set; }
        [Column("interest")]
        public float? Interest { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("paid_principle")]
        public float? PaidPrinciple { get; set; }
        [Column("paid_interest")]
        public float? PaidInterest { get; set; }
        [Column("accumulate_principle", TypeName = "decimal(15, 2)")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest", TypeName = "decimal(15, 2)")]
        public decimal? AccumulateInterest { get; set; }
        [Column("paymentterm_id")]
        public int? PaymenttermId { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("remark")]
        [StringLength(200)]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
    }
}
