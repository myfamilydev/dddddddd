﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("regular_collections_details_sub")]
    public partial class RegularCollectionsDetailsSub
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("regular_collection_detail_id")]
        public int? RegularCollectionDetailId { get; set; }
        [Column("subamount")]
        public float? Subamount { get; set; }
        [Column("ref_id")]
        public int? RefId { get; set; }
        [Column("current_paid_principle")]
        public float? CurrentPaidPrinciple { get; set; }
        [Column("current_paid_interest")]
        public float? CurrentPaidInterest { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
    }
}
