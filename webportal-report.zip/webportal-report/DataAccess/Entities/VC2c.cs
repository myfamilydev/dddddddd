﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VC2c
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [StringLength(100)]
        public string Project { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string OldCustomerName1 { get; set; }
        [StringLength(30)]
        public string OldPhoneCall1 { get; set; }
        [StringLength(150)]
        public string NewCustomerName1 { get; set; }
        [StringLength(30)]
        public string NewPhoneCall1 { get; set; }
        [Column("c2c_date", TypeName = "datetime")]
        public DateTime C2cDate { get; set; }
        [Column("status_name")]
        [StringLength(50)]
        public string StatusName { get; set; }
        [Column("c2c_house_price")]
        public double C2cHousePrice { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("current_customer_1")]
        public int CurrentCustomer1 { get; set; }
        [Column("current_customer_2")]
        public int? CurrentCustomer2 { get; set; }
        [Column("new_customer_1")]
        public int NewCustomer1 { get; set; }
        [Column("new_customer_2")]
        public int? NewCustomer2 { get; set; }
        [Column("customer_relationship")]
        [StringLength(50)]
        public string CustomerRelationship { get; set; }
        [Column("start_payment_date", TypeName = "datetime")]
        public DateTime StartPaymentDate { get; set; }
        [Column("charge_fee")]
        public double ChargeFee { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [StringLength(150)]
        public string OldCustomerName2 { get; set; }
        [StringLength(150)]
        public string NewCustomerName2 { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
    }
}
