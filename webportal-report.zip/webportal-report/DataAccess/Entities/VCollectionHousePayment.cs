﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VCollectionHousePayment
    {
        [Column("project_name")]
        [StringLength(100)]
        public string ProjectName { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("name_kh")]
        [StringLength(150)]
        public string NameKh { get; set; }
        [Required]
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("street_no")]
        [StringLength(150)]
        public string StreetNo { get; set; }
        [Column("house_size")]
        [StringLength(23)]
        public string HouseSize { get; set; }
        [Column("house_price", TypeName = "numeric(1, 1)")]
        public decimal HousePrice { get; set; }
        [Column("receipt_id")]
        [StringLength(30)]
        public string ReceiptId { get; set; }
        [Column("preprinted_number")]
        [StringLength(10)]
        public string PreprintedNumber { get; set; }
        [Column("payment_method")]
        [StringLength(50)]
        public string PaymentMethod { get; set; }
        [Column("insurance_fee")]
        public int? InsuranceFee { get; set; }
        [Column("principle")]
        public double Principle { get; set; }
        [Column("interest")]
        public double Interest { get; set; }
        [Column("penalty")]
        public int? Penalty { get; set; }
        [Column("booking")]
        public int? Booking { get; set; }
        [Column("utilities")]
        public int? Utilities { get; set; }
        [Column("public_service")]
        public int? PublicService { get; set; }
        [Column("paid_off_discount")]
        public int? PaidOffDiscount { get; set; }
        [Column("other")]
        public int? Other { get; set; }
        [Column("total", TypeName = "decimal(15, 2)")]
        public decimal? Total { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("in_order")]
        public int InOrder { get; set; }
        [Column("preprinted")]
        public int? Preprinted { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
