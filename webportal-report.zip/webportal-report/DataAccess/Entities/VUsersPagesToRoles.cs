﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VUsersPagesToRoles
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("page_id")]
        public int? PageId { get; set; }
        [Column("role_id")]
        public int RoleId { get; set; }
        [Column("role_name")]
        [StringLength(50)]
        public string RoleName { get; set; }
        [Column("role_status")]
        public byte? RoleStatus { get; set; }
    }
}
