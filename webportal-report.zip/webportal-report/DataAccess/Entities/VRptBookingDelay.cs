﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VRptBookingDelay
    {
        [Column("project_id")]
        public int? ProjectId { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime CreatedAt { get; set; }
        [Column("expire_date", TypeName = "datetime")]
        public DateTime ExpireDate { get; set; }
        [Column("extend_to", TypeName = "datetime")]
        public DateTime ExtendTo { get; set; }
        [Column("cus1_name_kh")]
        [StringLength(150)]
        public string Cus1NameKh { get; set; }
        [Column("house_type")]
        [StringLength(100)]
        public string HouseType { get; set; }
        [Column("house_number")]
        [StringLength(50)]
        public string HouseNumber { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [StringLength(23)]
        public string Expr1 { get; set; }
        [Column("house_price")]
        public double? HousePrice { get; set; }
        [Column("booking_amount")]
        public double? BookingAmount { get; set; }
        [Column("staff_name")]
        [StringLength(255)]
        public string StaffName { get; set; }
        [Required]
        [Column("reason")]
        public string Reason { get; set; }
    }
}
