﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("regular_collections_details_method")]
    public partial class RegularCollectionsDetailsMethod
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("regular_collection_detail_id")]
        public int? RegularCollectionDetailId { get; set; }
        [Column("amount", TypeName = "money")]
        public decimal? Amount { get; set; }
        [Column("method_id")]
        public int? MethodId { get; set; }
        [Column("transaction_type_id")]
        public int? TransactionTypeId { get; set; }
        [Column("status")]
        public int? Status { get; set; }
    }
}
