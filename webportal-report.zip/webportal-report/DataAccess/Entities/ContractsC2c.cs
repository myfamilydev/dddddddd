﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("contracts_c2c")]
    public partial class ContractsC2c
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("current_customer_1")]
        public int CurrentCustomer1 { get; set; }
        [Column("current_customer_2")]
        public int? CurrentCustomer2 { get; set; }
        [Column("new_customer_1")]
        public int NewCustomer1 { get; set; }
        [Column("new_customer_2")]
        public int? NewCustomer2 { get; set; }
        [Column("customer_relationship")]
        [StringLength(50)]
        public string CustomerRelationship { get; set; }
        [Column("c2c_house_price")]
        public double C2cHousePrice { get; set; }
        [Column("c2c_date", TypeName = "datetime")]
        public DateTime C2cDate { get; set; }
        [Column("start_payment_date", TypeName = "datetime")]
        public DateTime StartPaymentDate { get; set; }
        [Column("charge_fee")]
        public double ChargeFee { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("contract_history_id")]
        public int? ContractHistoryId { get; set; }
        [Column("c2c_no")]
        public int? C2cNo { get; set; }
        [Column("c2c_index")]
        public int? C2cIndex { get; set; }
    }
}
