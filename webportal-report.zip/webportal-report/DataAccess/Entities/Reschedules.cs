﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("reschedules")]
    public partial class Reschedules
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("outstanding_principle")]
        public float? OutstandingPrinciple { get; set; }
        [Column("reschedule_date", TypeName = "date")]
        public DateTime? RescheduleDate { get; set; }
        [Column("reschedule_month")]
        public short? RescheduleMonth { get; set; }
        [Column("interest_rule")]
        [StringLength(10)]
        public string InterestRule { get; set; }
        [Column("add_principle")]
        public float? AddPrinciple { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("interest")]
        public float? Interest { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
    }
}
