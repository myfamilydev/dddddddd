﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("contracts_ownerships")]
    public partial class ContractsOwnerships
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("contract_id")]
        public int ContractId { get; set; }
        [Column("from_customer_1")]
        public int? FromCustomer1 { get; set; }
        [Column("from_customer_2")]
        public int? FromCustomer2 { get; set; }
        [Column("to_customer_1")]
        public int? ToCustomer1 { get; set; }
        [Column("to_customer_2")]
        public int? ToCustomer2 { get; set; }
        [Column("relationship")]
        [StringLength(300)]
        public string Relationship { get; set; }
        [Column("charge_fee", TypeName = "decimal(6, 2)")]
        public decimal? ChargeFee { get; set; }
        [Column("request_type")]
        public int? RequestType { get; set; }
        [Column("request_date", TypeName = "date")]
        public DateTime? RequestDate { get; set; }
        [Column("remarks")]
        public string Remarks { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("contract_history_id")]
        public int? ContractHistoryId { get; set; }
    }
}
