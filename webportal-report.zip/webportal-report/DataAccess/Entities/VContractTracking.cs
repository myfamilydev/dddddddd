﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VContractTracking
    {
        public int ContractId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [StringLength(150)]
        public string Cus1NameKh { get; set; }
        [StringLength(30)]
        public string Cus1MobilePhone { get; set; }
        [Column("contract_amount", TypeName = "decimal(10, 2)")]
        public decimal? ContractAmount { get; set; }
        [Column("contract_date", TypeName = "date")]
        public DateTime? ContractDate { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [StringLength(50)]
        public string RecStatus { get; set; }
        [Column("initial_payment", TypeName = "decimal(10, 2)")]
        public decimal? InitialPayment { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [StringLength(200)]
        public string StaffName { get; set; }
        [StringLength(150)]
        public string Cus2NameKh { get; set; }
        [StringLength(30)]
        public string Cus2MobilePhone { get; set; }
    }
}
