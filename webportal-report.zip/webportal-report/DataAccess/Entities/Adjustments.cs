﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("adjustments")]
    public partial class Adjustments
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("regular_collection_detail_id")]
        public int? RegularCollectionDetailId { get; set; }
        [Column("dest_project_id")]
        public short? DestProjectId { get; set; }
        [Column("dest_contract_id")]
        public int? DestContractId { get; set; }
        [Column("dest_house_id")]
        public short? DestHouseId { get; set; }
        [Column("resolve_amount")]
        public double? ResolveAmount { get; set; }
        [Column("resolve_transaction")]
        public bool? ResolveTransaction { get; set; }
        [Column("method_1_id")]
        public int? Method1Id { get; set; }
        [Column("method_2_id")]
        public int? Method2Id { get; set; }
        [Column("method_3_id")]
        public int? Method3Id { get; set; }
        [Column("house_paid")]
        public double? HousePaid { get; set; }
        [Column("penalty_paid")]
        public double? PenaltyPaid { get; set; }
        [Column("public_service_paid")]
        public double? PublicServicePaid { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
