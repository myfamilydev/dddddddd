﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("direct_salers")]
    public partial class DirectSalers
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("fullname")]
        [StringLength(50)]
        public string Fullname { get; set; }
        [Column("phone")]
        [StringLength(20)]
        public string Phone { get; set; }
        [Column("staff_id")]
        [StringLength(20)]
        public string StaffId { get; set; }
        [Column("position")]
        [StringLength(50)]
        public string Position { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
