﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VOtherCollection
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int HouseId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("total_amount")]
        public float? TotalAmount { get; set; }
        [Column("method_1_id")]
        public int? Method1Id { get; set; }
        [Column("method_1_amount")]
        public float? Method1Amount { get; set; }
        [Column("ref_no1")]
        [StringLength(130)]
        public string RefNo1 { get; set; }
        [Column("ref_date1", TypeName = "date")]
        public DateTime? RefDate1 { get; set; }
        [Column("method_2_id")]
        public int? Method2Id { get; set; }
        [Column("method_2_amount")]
        public float? Method2Amount { get; set; }
        [Column("ref_no2")]
        [StringLength(130)]
        public string RefNo2 { get; set; }
        [Column("ref_date2", TypeName = "date")]
        public DateTime? RefDate2 { get; set; }
        [Column("method_3_id")]
        public int? Method3Id { get; set; }
        [Column("method_3_amount")]
        public float? Method3Amount { get; set; }
        [Column("ref_no3")]
        [StringLength(130)]
        public string RefNo3 { get; set; }
        [Column("ref_date3", TypeName = "date")]
        public DateTime? RefDate3 { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
        [Column("received_by")]
        public int? ReceivedBy { get; set; }
        [Column("preprinted_number")]
        [StringLength(10)]
        public string PreprintedNumber { get; set; }
        [Column("account_number1")]
        [StringLength(50)]
        public string AccountNumber1 { get; set; }
        [Column("account_number2")]
        [StringLength(50)]
        public string AccountNumber2 { get; set; }
        [Column("account_number3")]
        [StringLength(50)]
        public string AccountNumber3 { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("other_customer")]
        [StringLength(150)]
        public string OtherCustomer { get; set; }
        [Column("phone_contact")]
        [StringLength(20)]
        public string PhoneContact { get; set; }
        [Column("transaction_type_id")]
        public int? TransactionTypeId { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("transaction_category_id")]
        public int? TransactionCategoryId { get; set; }
        [StringLength(200)]
        public string CreatedByName { get; set; }
        [StringLength(50)]
        public string MethodName1 { get; set; }
    }
}
