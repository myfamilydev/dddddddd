﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VStreets
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short ProjectId { get; set; }
        [Column("st_no")]
        [StringLength(150)]
        public string StNo { get; set; }
        [Column("province")]
        [StringLength(250)]
        public string Province { get; set; }
        [Column("district")]
        [StringLength(250)]
        public string District { get; set; }
        [Column("commune")]
        [StringLength(250)]
        public string Commune { get; set; }
        [Column("village")]
        [StringLength(250)]
        public string Village { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
    }
}
