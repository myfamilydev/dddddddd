﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VBookingBookingHistory
    {
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("customer1_id")]
        public int? Customer1Id { get; set; }
        [Column("customer2_id")]
        public int? Customer2Id { get; set; }
        [Column("customer_relationship")]
        [StringLength(50)]
        public string CustomerRelationship { get; set; }
        [Column("direct_sale_id")]
        public int? DirectSaleId { get; set; }
        [Column("date", TypeName = "date")]
        public DateTime? Date { get; set; }
        [Column("expire_date", TypeName = "date")]
        public DateTime? ExpireDate { get; set; }
        [Column("delay_booking_day")]
        public short? DelayBookingDay { get; set; }
        [Column("booking_amount")]
        public float? BookingAmount { get; set; }
        [Column("house_price")]
        public float? HousePrice { get; set; }
        [Column("house_discount_percent")]
        public double? HouseDiscountPercent { get; set; }
        [Column("house_discount")]
        public float? HouseDiscount { get; set; }
        [Column("net_house_price")]
        public float? NetHousePrice { get; set; }
        [Column("remark_discount")]
        public string RemarkDiscount { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
        [Column("payment_term_id")]
        public int? PaymentTermId { get; set; }
        [Column("booking_history_id")]
        public int? BookingHistoryId { get; set; }
    }
}
