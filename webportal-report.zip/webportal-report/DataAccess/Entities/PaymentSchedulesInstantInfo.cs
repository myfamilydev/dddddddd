﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("payment_schedules_instant_info")]
    public partial class PaymentSchedulesInstantInfo
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("outstanding_principle", TypeName = "money")]
        public decimal? OutstandingPrinciple { get; set; }
        [Column("add_principle", TypeName = "money")]
        public decimal? AddPrinciple { get; set; }
        [Column("n_month")]
        public int? NMonth { get; set; }
        [Column("paid_off_amount", TypeName = "money")]
        public decimal? PaidOffAmount { get; set; }
        [Column("paid_off_type")]
        [StringLength(10)]
        public string PaidOffType { get; set; }
        [Column("interest_percent_month", TypeName = "decimal(8, 7)")]
        public decimal? InterestPercentMonth { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("reschedule_date", TypeName = "date")]
        public DateTime? RescheduleDate { get; set; }
        [Column("created_date", TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        [Column("created_by")]
        public int? CreatedBy { get; set; }
    }
}
