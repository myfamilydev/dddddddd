﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    public partial class VBookingsDelays
    {
        [Column("booking_delay_id")]
        public int BookingDelayId { get; set; }
        [Column("booking_id")]
        public int BookingId { get; set; }
        [Column("expire_date", TypeName = "date")]
        public DateTime ExpireDate { get; set; }
        [Column("extend_to", TypeName = "date")]
        public DateTime ExtendTo { get; set; }
        [Required]
        [Column("reason")]
        public string Reason { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("project_short")]
        [StringLength(100)]
        public string ProjectShort { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("house_number")]
        [StringLength(10)]
        public string HouseNumber { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime CreatedAt { get; set; }
        [Column("created_by")]
        [StringLength(200)]
        public string CreatedBy { get; set; }
        [Column("rec_status")]
        public byte? RecStatus { get; set; }
        [Column("status")]
        [StringLength(50)]
        public string Status { get; set; }
    }
}
