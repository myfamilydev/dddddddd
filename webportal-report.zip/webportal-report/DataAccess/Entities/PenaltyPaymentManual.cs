﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("penalty_payment_manual")]
    public partial class PenaltyPaymentManual
    {
        [Key]
        [Column("schedule_manual_id")]
        public int ScheduleManualId { get; set; }
        [Column("contract_id")]
        public int? ContractId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("penalty")]
        public double? Penalty { get; set; }
        [Column("paid")]
        public double? Paid { get; set; }
        [Column("current_paid")]
        public double? CurrentPaid { get; set; }
        [Column("late_days")]
        public int? LateDays { get; set; }
        [Column("start_date", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("end_date", TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("payment")]
        public double? Payment { get; set; }
        [Column("waive")]
        public double? Waive { get; set; }
        [Column("waive_ref")]
        public int? WaiveRef { get; set; }
    }
}
