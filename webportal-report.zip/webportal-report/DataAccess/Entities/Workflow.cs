﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("workflow")]
    public partial class Workflow
    {
        [Key]
        [Column("id")]
        public byte Id { get; set; }
        [Column("uuid")]
        public Guid? Uuid { get; set; }
        [Column("workflow_name")]
        [StringLength(50)]
        public string WorkflowName { get; set; }
        [Column("workflow_title")]
        [StringLength(100)]
        public string WorkflowTitle { get; set; }
        [Column("form_url")]
        [StringLength(200)]
        public string FormUrl { get; set; }
        [Column("indexing")]
        public short? Indexing { get; set; }
    }
}
