﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("penalties_calculation_temp")]
    public partial class PenaltiesCalculationTemp
    {
        [Column("id")]
        public long? Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Column("house_id")]
        public int? HouseId { get; set; }
        [Column("penalty_type")]
        public short? PenaltyType { get; set; }
        [Column("penalty_ref")]
        [StringLength(20)]
        public string PenaltyRef { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("calculation_date", TypeName = "date")]
        public DateTime? CalculationDate { get; set; }
        [Column("count_day")]
        public int? CountDay { get; set; }
        [Column("penalty_rule_id")]
        public int? PenaltyRuleId { get; set; }
        [Column("amount", TypeName = "decimal(10, 2)")]
        public decimal? Amount { get; set; }
        [Column("partial")]
        public short? Partial { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
        [Column("updated_by")]
        public int? UpdatedBy { get; set; }
    }
}
