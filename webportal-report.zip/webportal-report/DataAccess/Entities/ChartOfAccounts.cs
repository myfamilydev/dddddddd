﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("chart_of_accounts")]
    public partial class ChartOfAccounts
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("project_id")]
        public short? ProjectId { get; set; }
        [Required]
        [Column("number")]
        [StringLength(6)]
        public string Number { get; set; }
        [Required]
        [Column("name")]
        [StringLength(50)]
        public string Name { get; set; }
        [Column("description")]
        [StringLength(250)]
        public string Description { get; set; }
        [Column("acc_class_param_id")]
        public int AccClassParamId { get; set; }
        [Column("group_param_id")]
        public int GroupParamId { get; set; }
        [Column("mapping")]
        [StringLength(20)]
        public string Mapping { get; set; }
        [Column("remark")]
        public string Remark { get; set; }
        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; }
        [Column("created_at", TypeName = "datetime")]
        public DateTime? CreatedAt { get; set; }
        [Column("updated_at", TypeName = "datetime")]
        public DateTime? UpdatedAt { get; set; }
    }
}
