﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.Entities
{
    [Table("payment_schedules_manual")]
    public partial class PaymentSchedulesManual
    {
        [Key]
        [Column("id")]
        public long Id { get; set; }
        [Column("payment_schedule_info_id")]
        public int? PaymentScheduleInfoId { get; set; }
        [Column("payment_date", TypeName = "date")]
        public DateTime? PaymentDate { get; set; }
        [Column("promise_payment_date", TypeName = "date")]
        public DateTime? PromisePaymentDate { get; set; }
        [Column("freez_penalty")]
        public float? FreezPenalty { get; set; }
        [Column("payment")]
        public float? Payment { get; set; }
        [Column("principle")]
        public float? Principle { get; set; }
        [Column("interest")]
        public float? Interest { get; set; }
        [Column("accumulate_principle", TypeName = "decimal(15, 2)")]
        public decimal? AccumulatePrinciple { get; set; }
        [Column("accumulate_interest", TypeName = "decimal(15, 2)")]
        public decimal? AccumulateInterest { get; set; }
        [Column("end_balance", TypeName = "decimal(15, 2)")]
        public decimal? EndBalance { get; set; }
        [Column("paid_principle")]
        public float? PaidPrinciple { get; set; }
        [Column("paid_interest")]
        public float? PaidInterest { get; set; }
        [Column("paid_freez_penalty")]
        public float? PaidFreezPenalty { get; set; }
        [Column("current_paid_principle")]
        public float? CurrentPaidPrinciple { get; set; }
        [Column("current_paid_interest")]
        public float? CurrentPaidInterest { get; set; }
        [Column("current_paid_freez_penalty")]
        public float? CurrentPaidFreezPenalty { get; set; }
        [Column("receipt_no")]
        public int? ReceiptNo { get; set; }
        [Column("ref_no")]
        public int? RefNo { get; set; }
        [Column("paid_date", TypeName = "datetime")]
        public DateTime? PaidDate { get; set; }
        [Column("regular_collection_id")]
        public int? RegularCollectionId { get; set; }
        [Column("remark")]
        [StringLength(500)]
        public string Remark { get; set; }
    }
}
