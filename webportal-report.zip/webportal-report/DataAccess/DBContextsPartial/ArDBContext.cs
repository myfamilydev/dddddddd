﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.AR;
using DataAccess.Entities.Customize_AR;
using DataAccess.Entities.Ar;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.DBContexts
{
    public partial class ArDBContext : DbContext
    {
        public virtual DbSet<ClsBookingDailyReport> BookingDailyReport { get; set; }
        public virtual DbSet<ClsBookingDailyReportExcludeTransfer> BookingDailyReportExcludeTransfer { get; set; }
        public virtual DbSet<ClsContractDailyReport> ContractDailyReport { get; set; }
        public virtual DbSet<ClsProjectRevenueDailyReport> ProjectRevenueDailyReport { get; set; }
        public virtual DbSet<RevenueMonthlyCollectionReprot> RevenueMonthlyCollectionReprot { get; set; }
        public virtual DbSet<MonthlyCollectionSummuryByMethod> MonthlyCollectionSummuryByMethod { get; set; }
        public virtual DbSet<SummaySaleAndCollectionReport> SummaySaleAndCollectionReport { get; set; }
        public virtual DbSet<SummayCollectionReport> SummayCollectionReport { get; set; }
        public virtual DbSet<SummuryCollectionTerminateReport> SummuryCollectionTerminateReport { get; set; }
        
        public virtual DbSet<BookingNotContract> BookingNotContract { get; set; }

        public virtual DbSet<DailyMessageReport> DailyMessageReport { get; set; }
        public virtual DbSet<MonthlyCollectionSummuryByProject> MonthlyCollectionSummuryByProject { get; set; }
        public virtual DbSet<VprintScheduleDetail> VprintScheduleDetail { get; set; }
        public virtual DbSet<VprintScheduleDetailSale> VprintScheduleDetailSale { get; set; }
        public virtual DbSet<VprintPenaltyDetail> VprintPenaltyDetail { get; set; }
        public virtual DbSet<ClsCollectionBookingInitialPayment> CollectionBookingInitialPayment { get; set; }
        public virtual DbSet<ClsExtraPrinciplePayment> ExtraPrinciplePayment { get; set; }
        public virtual DbSet<VrepPrintContractC2c> VrepPrintContractC2c { get; set; }
    

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
        { 

            modelBuilder.Entity<ClsBookingDailyReport>().HasNoKey();
            modelBuilder.Entity<ClsBookingDailyReportExcludeTransfer>().HasNoKey();
            modelBuilder.Entity<DailyMessageReport>().HasNoKey();
            modelBuilder.Entity<ClsContractDailyReport>().HasNoKey();
            modelBuilder.Entity<ClsProjectRevenueDailyReport>().HasNoKey();
            modelBuilder.Entity<RevenueMonthlyCollectionReprot>().HasNoKey();
            modelBuilder.Entity<MonthlyCollectionSummuryByMethod>().HasNoKey();
            modelBuilder.Entity<MonthlyCollectionSummuryByProject>().HasNoKey();
            modelBuilder.Entity<VprintScheduleDetail>().HasNoKey();
            modelBuilder.Entity<VprintScheduleDetailSale>().HasNoKey();
            modelBuilder.Entity<VprintPenaltyDetail>().HasNoKey();
            modelBuilder.Entity<ClsCollectionBookingInitialPayment>().HasNoKey();
            modelBuilder.Entity<ClsExtraPrinciplePayment>().HasNoKey();
            modelBuilder.Entity<SummaySaleAndCollectionReport>().HasNoKey();
            modelBuilder.Entity<SummayCollectionReport>().HasNoKey();
            modelBuilder.Entity<BookingNotContract>().HasNoKey();
            modelBuilder.Entity<SummuryCollectionTerminateReport>().HasNoKey();
            modelBuilder.Entity<VrepPrintContractC2c>(entity =>
            {
                entity.HasNoKey();
                    
            });

        }


    }
}
