﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.Report;
using System.IO;
using Newtonsoft.Json;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.DBContexts
{
    public partial class ReportDBContext : DbContext
    {
        public ReportDBContext()
        {
        }

        public ReportDBContext(DbContextOptions<ReportDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Access> Access { get; set; }
        public virtual DbSet<AccessItem> AccessItem { get; set; }
        public virtual DbSet<Item> Item { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           /* if (!optionsBuilder.IsConfigured)
            {
                ResSetting configDB;
                using (StreamReader r = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "appsettings.json"))
                {
                    string json = r.ReadToEnd();
                    configDB = JsonConvert.DeserializeObject<ResSetting>(json);
                }
                optionsBuilder.UseSqlServer(configDB.ConnectionStrings.AppDbConnection);
            } */
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Access>(entity =>
            {
                entity.HasKey(e => e.ReportAccessId)
                    .HasName("PK_report_access");

                entity.Property(e => e.Code).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<AccessItem>(entity =>
            {
                entity.HasKey(e => new { e.ReportAccessId, e.ReportItemId })
                    .HasName("PK_report_access_item");

                entity.HasOne(d => d.ReportAccess)
                    .WithMany(p => p.AccessItem)
                    .HasForeignKey(d => d.ReportAccessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_access_item_access");

                entity.HasOne(d => d.ReportItem)
                    .WithMany(p => p.AccessItem)
                    .HasForeignKey(d => d.ReportItemId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_access_item_item");
            });

            modelBuilder.Entity<Item>(entity =>
            {
                entity.HasKey(e => e.ReportItemId)
                    .HasName("PK_report_item");

                entity.Property(e => e.ReportTitle).IsUnicode(false);

                entity.Property(e => e.ServerName).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
