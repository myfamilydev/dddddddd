﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.Mayura;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.DBContexts
{
    public partial class MayuraDBContext : DbContext
    {
        public MayuraDBContext()
        {
        }

        public MayuraDBContext(DbContextOptions<MayuraDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BankSettlement> BankSettlement { get; set; }
        public virtual DbSet<DailyMemo> DailyMemo { get; set; }
        public virtual DbSet<FinalPayments> FinalPayments { get; set; }
        public virtual DbSet<Projects> Projects { get; set; }
        public virtual DbSet<RegularCollections> RegularCollections { get; set; }
        public virtual DbSet<RegularCollectionsDetails> RegularCollectionsDetails { get; set; }
        public virtual DbSet<Reschedules> Reschedules { get; set; }
        public virtual DbSet<TblSessions> TblSessions { get; set; }
        public virtual DbSet<Users> Users { get; set; }
        public virtual DbSet<SessionsLog> SessionsLog { get; set; }
        
        public virtual DbSet<SummarySaleCollectionRemark> SummarySaleCollectionRemark { get; set; }
        public virtual DbSet<VSummarySaleCollectionRemark> VSummarySaleCollectionRemark { get; set; }
        public virtual DbSet<SummaryCollectionReportRemark> SummaryCollectionReportRemark { get; set; }
        public virtual DbSet<VSummaryCollectionReportRemark> VSummaryCollectionReportRemark { get; set; }
        public virtual DbSet<UsersToRoles> UsersToRoles { get; set; }
        public virtual DbSet<Houses> Houses { get; set; }
        public virtual DbSet<VCustomerWalkInProject> VCustomerWalkInProject { get; set; }
        public virtual DbSet<IssueLateLetter> IssueLateLetter { get; set; }

        public virtual DbSet<VPublicServiceIssueLateMonthlyReport> VPublicServiceIssueLateMonthlyReport { get; set; }
        public virtual DbSet<VPublicServiceIssueLateLetter> VPublicServiceIssueLateLetter { get; set; }
        public virtual DbSet<VPublicServiceIssueLateLetterReport> VPublicServiceIssueLateLetterReport { get; set; }
        public virtual DbSet<VPublicServicePrepaid> VPublicServicePrepaid { get; set; }
        public virtual DbSet<VSummaryPublicServiceLateReport> VSummaryPublicServiceLateReport { get; set; }
        public virtual DbSet<VPresentIssueLetter> VPresentIssueLetter { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("data source=192.168.1.88;initial catalog=db_live;user id=mayura;password=ARSystem@2021");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Projects>(entity =>
            {
                entity.HasIndex(e => e.ProjectCode)
                    .HasName("p_id");

                entity.Property(e => e.ProjectCode).IsUnicode(false);

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<RegularCollections>(entity =>
            {
                entity.Property(e => e.AccountNumber1).IsUnicode(false);

                entity.Property(e => e.AccountNumber2).IsUnicode(false);

                entity.Property(e => e.AccountNumber3).IsUnicode(false);

                entity.Property(e => e.CollectionClass).IsUnicode(false);

                entity.Property(e => e.CreatedAt).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CrossProject).IsUnicode(false);

                entity.Property(e => e.PreprintedNumber).IsUnicode(false);

                entity.Property(e => e.RefNo1).IsUnicode(false);

                entity.Property(e => e.RefNo2).IsUnicode(false);

                entity.Property(e => e.RefNo3).IsUnicode(false);
            });

            modelBuilder.Entity<RegularCollectionsDetails>(entity =>
            {
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.RecStatus).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<Reschedules>(entity =>
            {
                entity.Property(e => e.InterestRule).IsUnicode(false);
            });

            modelBuilder.Entity<TblSessions>(entity =>
            {
                entity.Property(e => e.RemoteIp).IsUnicode(false);
            });

            modelBuilder.Entity<SessionsLog>(entity =>
            {
                entity.Property(e => e.RemoteIp).IsUnicode(false);

                entity.Property(e => e.Token).IsUnicode(false);
            });

            modelBuilder.Entity<UsersToRoles>(entity =>
            {
                entity.Property(e => e.DisableNotif).HasDefaultValueSql("((0))");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.Property(e => e.Designation).IsUnicode(false);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.Password).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.Status).HasDefaultValueSql("((1))");

                entity.Property(e => e.Username).IsUnicode(false);

                entity.Property(e => e.Uuid).HasDefaultValueSql("(newid())");
            });

            modelBuilder.Entity<Houses>(entity =>
            {
                entity.Property(e => e.Billercode).IsUnicode(false);

                entity.Property(e => e.Block).IsUnicode(false);

                entity.Property(e => e.LandLength).IsUnicode(false);

                entity.Property(e => e.LandWidth).IsUnicode(false);

                entity.Property(e => e.Number).IsUnicode(false);

                entity.Property(e => e.Payproaccid).IsUnicode(false);

                entity.Property(e => e.Payproref).IsUnicode(false);

                entity.Property(e => e.Phase).IsUnicode(false);

                entity.Property(e => e.RoadType).IsUnicode(false);
            });

            modelBuilder.Entity<VSummarySaleCollectionRemark>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_summary_sale_collection_remark");
            });

            modelBuilder.Entity<VSummaryCollectionReportRemark>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_summary_collection_report_remark");
            });

            modelBuilder.Entity<VCustomerWalkInProject>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_customer_walk_in_project");

                entity.Property(e => e.ProjectCode).IsUnicode(false);
            });

            modelBuilder.Entity<IssueLateLetter>(entity =>
            {
                entity.Property(e => e.FndStartNo).IsUnicode(false);

                entity.Property(e => e.IssueNo).IsUnicode(false);
            });

            modelBuilder.Entity<VPublicServiceIssueLateMonthlyReport>(entity =>
            {
                entity.HasNoKey();
                entity.Property(e => e.HouseNumber).IsUnicode(false);
                entity.Property(e => e.PhoneContract).IsUnicode(false);
                entity.Property(e => e.ProjectShort).IsUnicode(false);
                entity.Property(e => e.HouseCategory).IsUnicode(false);
                entity.Property(e => e.StreetNo).IsUnicode(false);
                entity.Property(e => e.FndNo).IsUnicode(false);

            });

            modelBuilder.Entity<VPublicServiceIssueLateLetter>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_public_service_issue_late_letter");

                entity.Property(e => e.Billercode).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.Payproaccid).IsUnicode(false);
            });

            modelBuilder.Entity<VPublicServiceIssueLateLetterReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_public_service_issue_late_letter_report");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);
            });

            modelBuilder.Entity<VPublicServicePrepaid>(entity =>
            {
                entity.HasNoKey();                

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);
            });
            modelBuilder.Entity<VSummaryPublicServiceLateReport>(entity =>
            {
                entity.HasNoKey();             

                entity.Property(e => e.ProjectShort).IsUnicode(false);
            });

            modelBuilder.Entity<VPresentIssueLetter>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_present_issue_letter");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.IssueNo).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);

        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
