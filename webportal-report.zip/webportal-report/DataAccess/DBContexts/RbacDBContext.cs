﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.Rbac;
using System.IO;
using Newtonsoft.Json;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.DBContexts
{
    public partial class RbacDBContext : DbContext
    {
        public RbacDBContext()
        {
        }

        public RbacDBContext(DbContextOptions<RbacDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Test> Test { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           /* if (!optionsBuilder.IsConfigured)
            {
                ResSetting configDB;
                using (StreamReader r = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "appsettings.json"))
                {
                    string json = r.ReadToEnd();
                    configDB = JsonConvert.DeserializeObject<ResSetting>(json);
                }
                optionsBuilder.UseSqlServer(configDB.ConnectionStrings.AppDbConnection);
            } */
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Test>(entity =>
            {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Text).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
