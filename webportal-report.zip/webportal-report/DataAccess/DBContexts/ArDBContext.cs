﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.AR;
using DataAccess.Entities.Ar;
using System.IO;
using Newtonsoft.Json;
using DataAccess.Entities.Customize;

namespace DataAccess.DBContexts
{
    public partial class ArDBContext : DbContext
    {
        public ArDBContext()
        {
        }

        public ArDBContext(DbContextOptions<ArDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<VContractReport> VContractReport { get; set; }
        public virtual DbSet<VContractTerminationReport> VContractTerminationReport { get; set; }
        public virtual DbSet<VDailySummaryReport> VDailySummaryReport { get; set; }
        public virtual DbSet<VFinalPaymentReport> VFinalPaymentReport { get; set; }
        public virtual DbSet<VHouseSummaryReport> VHouseSummaryReport { get; set; }
        public virtual DbSet<VHouseType> VHouseType { get; set; }
        public virtual DbSet<VHousesStockReport> VHousesStockReport { get; set; }
        public virtual DbSet<VOwnershipAddReport> VOwnershipAddReport { get; set; }
        public virtual DbSet<VOwnershipRemoveReport> VOwnershipRemoveReport { get; set; }
        public virtual DbSet<VOwnershipReport> VOwnershipReport { get; set; }
        public virtual DbSet<VPaymentScheduleInstantInfo> VPaymentScheduleInstantInfo { get; set; }
        public virtual DbSet<VPaymentScheduleInstantMain> VPaymentScheduleInstantMain { get; set; }
        public virtual DbSet<VPaymentSchedulesInfo> VPaymentSchedulesInfo { get; set; }
        public virtual DbSet<VPenaltyReport> VPenaltyReport { get; set; }
        public virtual DbSet<VPhoneTracking> VPhoneTracking { get; set; }
        public virtual DbSet<VPrintContractTerminationTransfer> VPrintContractTerminationTransfer { get; set; }
        public virtual DbSet<VWaiveInterestReport> VWaiveInterestReport { get; set; }
        public virtual DbSet<VWaivePenaltyReport> VWaivePenaltyReport { get; set; }
        public virtual DbSet<VWaivePublicServiceReport> VWaivePublicServiceReport { get; set; }
        public virtual DbSet<VprintAccumulateReport> VprintAccumulateReport { get; set; }
        public virtual DbSet<VprintAdhocDiscount> VprintAdhocDiscount { get; set; }
        public virtual DbSet<VprintBookingCancel> VprintBookingCancel { get; set; }
        public virtual DbSet<VprintBookingChangeHouse> VprintBookingChangeHouse { get; set; }
        public virtual DbSet<VprintBookingChangeOwnership> VprintBookingChangeOwnership { get; set; }
        public virtual DbSet<VprintBookingCollection> VprintBookingCollection { get; set; }
        public virtual DbSet<VprintBookingCollection1> VprintBookingCollection1 { get; set; }
        public virtual DbSet<VprintOtherCollection> VprintOtherCollection { get; set; }
        public virtual DbSet<VprintBookingCollectionNewReceipt> VprintBookingCollectionNewReceipt { get; set; }
        public virtual DbSet<VprintBookingDelay> VprintBookingDelay { get; set; }
        public virtual DbSet<VprintC2cReport> VprintC2cReport { get; set; }
        public virtual DbSet<VprintContractCollection> VprintContractCollection { get; set; }
        public virtual DbSet<VprintContractCollection1> VprintContractCollection1 { get; set; }
        public virtual DbSet<VprintContractsInfo> VprintContractsInfo { get; set; }
        public virtual DbSet<VprintCustomerDailyPayment> VprintCustomerDailyPayment { get; set; }
        public virtual DbSet<VprintFinalPayment> VprintFinalPayment { get; set; }
        public virtual DbSet<VprintInterest> VprintInterest { get; set; }
        public virtual DbSet<VprintPublicServiceDetail> VprintPublicServiceDetail { get; set; }
        public virtual DbSet<VprintPublicServiceInfo> VprintPublicServiceInfo { get; set; }
        public virtual DbSet<VprintSchedule> VprintSchedule { get; set; }
        public virtual DbSet<VPrintScheduleSale> VPrintScheduleSale { get; set; }
        public virtual DbSet<VprintScheduleDetailInstant> VprintScheduleDetailInstant { get; set; }
        public virtual DbSet<VprintWaivePenalty> VprintWaivePenalty { get; set; }
        public virtual DbSet<VPrintWaivePublicService> VPrintWaivePublicService { get; set; }
        public virtual DbSet<VPrintWaiveFinalInterest> VPrintWaiveFinalInterest { get; set; }
        public virtual DbSet<VrepBooking> VrepBooking { get; set; }
        public virtual DbSet<VrepBookingCancellation> VrepBookingCancellation { get; set; }
        public virtual DbSet<VrepBookingDelay> VrepBookingDelay { get; set; }
        public virtual DbSet<VrepPrintBooking> VrepPrintBooking { get; set; }
        public virtual DbSet<VrepPrintBookingAdhocDiscount> VrepPrintBookingAdhocDiscount { get; set; }
        public virtual DbSet<VrepPrintBookingCancellation> VrepPrintBookingCancellation { get; set; }
        public virtual DbSet<VrepPrintBookingChangeHouse> VrepPrintBookingChangeHouse { get; set; }
        public virtual DbSet<VrepPrintBookingDelay> VrepPrintBookingDelay { get; set; }
        public virtual DbSet<VrepPrintContract> VrepPrintContract { get; set; }
        public virtual DbSet<VrepPrintCusInfoC2c> VrepPrintCusInfoC2c { get; set; }
        public virtual DbSet<VPrintCusInfoOwnership> VPrintCusInfoOwnership { get; set; }
        public virtual DbSet<VrepPrintOwnership> VrepPrintOwnership { get; set; }
        public virtual DbSet<VPublicServiceSchedules> VPublicServiceSchedules { get; set; }
        public virtual DbSet<LastPaymentReport> LastPaymentReport { get; set; }
        public virtual DbSet<ConfirmPublicServicePaidYearly> ConfirmPublicServicePaidYearly { get; set; }
        public virtual DbSet<VCountHouseByOwnership> VCountHouseByOwnership { get; set; }
        //public virtual DbSet<VprintHouseReachInterestReport> VprintHouseReachInterestReport { get; set; }

        public virtual DbSet<VPublicServiceLateReport> VPublicServiceLateReport { get; set; }

        public virtual DbSet<VHouseHandOverReport> VHouseHandOverReport { get; set; }

        public virtual DbSet<VPenaltyLateReport> VPenaltyLateReport { get; set; }

        public virtual DbSet<NetContractTerminate> NetContractTerminate { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           /* if (!optionsBuilder.IsConfigured)
            {
                ResSetting configDB;
                using (StreamReader r = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "appsettings.json"))
                {
                    string json = r.ReadToEnd();
                    configDB = JsonConvert.DeserializeObject<ResSetting>(json);
                }
                optionsBuilder.UseSqlServer(configDB.ConnectionStrings.AppDbConnection);
            } */
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<VHouseType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_house_types", "dbo");

            });
            modelBuilder.Entity<NetContractTerminate>(entity =>
            {
                entity.HasNoKey();

            });
            modelBuilder.Entity<VPublicServiceLateReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_public_service_late_report", "dbo");
            });

            modelBuilder.Entity<VHouseHandOverReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_house_hand_over_report", "dbo");
            });

            modelBuilder.Entity<VPenaltyLateReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_penalty_late_report", "dbo");
            });

            modelBuilder.Entity<VPrintWaivePublicService>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_print_waive_public_service", "ar");
            });

            modelBuilder.Entity<VPrintWaiveFinalInterest>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("waive_final_interest", "ar");
            });


            modelBuilder.Entity<VPrintScheduleSale>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_print_schedule_sale", "ar");
            });
            modelBuilder.Entity<VPrintCusInfoOwnership>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_print_cusInfo_ownership", "ar");
            });

            modelBuilder.Entity<LastPaymentReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("last_payment_report", "report");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.C2Phone).IsUnicode(false);

                entity.Property(e => e.C1Phone).IsUnicode(false);
            });
            modelBuilder.Entity<ConfirmPublicServicePaidYearly>(entity =>
            {
                entity.HasNoKey();                

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.C2Phone).IsUnicode(false);

                entity.Property(e => e.C1Phone).IsUnicode(false);
            });

            modelBuilder.Entity<VContractReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);

                entity.Property(e => e.PhoneContract).IsUnicode(false);
            });

            modelBuilder.Entity<VPublicServiceSchedules>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_public_service_schedules", "dbo");
            });

            modelBuilder.Entity<VContractTerminationReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_contract_termination_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VDailySummaryReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_daily_summary_report", "ar");

                entity.Property(e => e.MethodName).IsUnicode(false);
            });

            modelBuilder.Entity<VFinalPaymentReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_final_payment_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);
            });
            modelBuilder.Entity<VprintOtherCollection>(entity =>
            {
                entity.HasNoKey();

            });
            modelBuilder.Entity<VHouseSummaryReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_house_summary_report", "ar");

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);

                entity.Property(e => e.HouseList).IsUnicode(false);
            });

            modelBuilder.Entity<VHousesStockReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_houses_stock_report", "ar");

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);
            });

            modelBuilder.Entity<VOwnershipAddReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_ownership_add_report", "ar");

                entity.Property(e => e.AddedCustomer).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseType).IsUnicode(false);

                entity.Property(e => e.OldCustomer).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);

                entity.Property(e => e.RequestDate).IsUnicode(false);

                entity.Property(e => e.StreetNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VOwnershipRemoveReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_ownership_remove_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseType).IsUnicode(false);

                entity.Property(e => e.OldCustomer1).IsUnicode(false);

                entity.Property(e => e.OldCustomer2).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);

                entity.Property(e => e.RemoveCustomer).IsUnicode(false);

                entity.Property(e => e.RequestDate).IsUnicode(false);

                entity.Property(e => e.StreetNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VOwnershipReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_ownership_report", "ar");

                entity.Property(e => e.FromCus1).IsUnicode(false);

                entity.Property(e => e.FromCus2).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseType).IsUnicode(false);

                entity.Property(e => e.ProjectShort).IsUnicode(false);

                entity.Property(e => e.StreetNumber).IsUnicode(false);

                entity.Property(e => e.ToCus1).IsUnicode(false);

                entity.Property(e => e.ToCus2).IsUnicode(false);
            });

            modelBuilder.Entity<VPaymentScheduleInstantInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_payment_schedule_instant_info", "ar");

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.PaidOffType).IsUnicode(false);
            });

            modelBuilder.Entity<VPaymentScheduleInstantMain>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_payment_schedule_instant_main", "ar");
            });

            modelBuilder.Entity<VPaymentSchedulesInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_payment_schedules_info", "ar");

                entity.Property(e => e.PaidOffType).IsUnicode(false);
            });

            modelBuilder.Entity<VPenaltyReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_penalty_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VPhoneTracking>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_phone_tracking", "ar");

                entity.Property(e => e.CreatedBy).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.ModifiedBy).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);

                entity.Property(e => e.Purpose).IsUnicode(false);
            });

            modelBuilder.Entity<VPrintContractTerminationTransfer>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_print_contract_termination_transfer", "ar");

                entity.Property(e => e.Cus1id).IsUnicode(false);

                entity.Property(e => e.Cus1phone).IsUnicode(false);

                entity.Property(e => e.Cus2id).IsUnicode(false);

                entity.Property(e => e.Cus2phone).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseNoTo).IsUnicode(false);
            });

            modelBuilder.Entity<VWaiveInterestReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_waive_interest_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VWaivePenaltyReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_waive_penalty_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VWaivePublicServiceReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_waive_public_service_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VprintAccumulateReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_accumulate_report", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VprintAdhocDiscount>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_adhoc_discount", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingCancel>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_cancel", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingChangeHouse>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_change_house", "ar");

                entity.Property(e => e.HouseNumberFrom).IsUnicode(false);

                entity.Property(e => e.HouseNumberTo).IsUnicode(false);

                entity.Property(e => e.HouseSizeFrom).IsUnicode(false);

                entity.Property(e => e.HouseSizeTo).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.ProjectNameFrom).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingChangeOwnership>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_change_ownership", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.IdCard1).IsUnicode(false);

                entity.Property(e => e.IdCard2).IsUnicode(false);

                entity.Property(e => e.NewId1).IsUnicode(false);

                entity.Property(e => e.NewId2).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingCollection>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_collection", "ar");

                entity.Property(e => e.BankAccount).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneCall).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingCollection1>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_collection1", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.RpNo).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingCollectionNewReceipt>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_collection_new_receipt", "ar");

                entity.Property(e => e.BankAccount).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneCall).IsUnicode(false);

                entity.Property(e => e.PrePrinted).IsUnicode(false);

                entity.Property(e => e.Ttref).IsUnicode(false);
            });

            modelBuilder.Entity<VprintBookingDelay>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_booking_delay", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);
            });

            modelBuilder.Entity<VprintC2cReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_c2c_report", "ar");

                entity.Property(e => e.EnNewCustomerName1).IsUnicode(false);

                entity.Property(e => e.EnNewCustomerName2).IsUnicode(false);

                entity.Property(e => e.EnOldCustomerName1).IsUnicode(false);

                entity.Property(e => e.EnOldCustomerName2).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VprintContractCollection>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_contract_collection", "ar");

                entity.Property(e => e.BankAccount).IsUnicode(false);

                entity.Property(e => e.FullName).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneCall).IsUnicode(false);

                entity.Property(e => e.PrePrinted).IsUnicode(false);

                entity.Property(e => e.Ttref).IsUnicode(false);
            });

            modelBuilder.Entity<VprintContractCollection1>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_contract_collection1", "ar");

                entity.Property(e => e.BankAccount).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.PhoneCall).IsUnicode(false);
            });

            modelBuilder.Entity<VprintContractsInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_contracts_info", "ar");

                entity.Property(e => e.CustomerIdCard).IsUnicode(false);

                entity.Property(e => e.CustomerSex).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);
            });

            modelBuilder.Entity<VprintCustomerDailyPayment>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_customer_daily_payment", "ar");

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.NameEn).IsUnicode(false);

                entity.Property(e => e.NameEn2).IsUnicode(false);

                entity.Property(e => e.PhoneContact1).IsUnicode(false);

                entity.Property(e => e.PhoneContact2).IsUnicode(false);
            });

            modelBuilder.Entity<VprintFinalPayment>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_final_payment", "ar");
            });

            modelBuilder.Entity<VprintInterest>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_interest", "ar");

                entity.Property(e => e.HouseNo).IsUnicode(false);
            });

            modelBuilder.Entity<VprintPublicServiceDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_public_service_detail", "ar");

                entity.Property(e => e.UpdateBy).IsUnicode(false);

                entity.Property(e => e.Username).IsUnicode(false);
            });

            modelBuilder.Entity<VprintPublicServiceInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_public_service_info", "ar");

                entity.Property(e => e.CustomerIdCard).IsUnicode(false);

                entity.Property(e => e.CustomerSex).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);
            });

            modelBuilder.Entity<VprintSchedule>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_schedule", "ar");

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.Payproaccid).IsUnicode(false);
            });

            modelBuilder.Entity<VprintScheduleDetailInstant>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("Vprint_Schedule_Detail_Instant", "ar");
            });

            modelBuilder.Entity<VprintWaivePenalty>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vprint_waive_penalty", "ar");

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);

                entity.Property(e => e.PhoneNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VrepBooking>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_booking", "ar");

                entity.Property(e => e.ContactNumber).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);
            });

            modelBuilder.Entity<VrepBookingCancellation>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_booking_cancellation", "ar");

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);
            });

            modelBuilder.Entity<VrepBookingDelay>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_booking_delay", "ar");

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintBooking>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_booking", "ar");

                entity.Property(e => e.CustomerContact).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard1).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard2).IsUnicode(false);

                entity.Property(e => e.HouseLandLength).IsUnicode(false);

                entity.Property(e => e.HouseLandSize).IsUnicode(false);

                entity.Property(e => e.HouseLandWidth).IsUnicode(false);

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseSize).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintBookingAdhocDiscount>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_booking_adhoc_discount", "ar");

                entity.Property(e => e.CustomerIdCard1).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard2).IsUnicode(false);

                entity.Property(e => e.HouseLandLength).IsUnicode(false);

                entity.Property(e => e.HouseLandWidth).IsUnicode(false);

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintBookingCancellation>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_booking_cancellation", "ar");

                entity.Property(e => e.HouseNo).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintBookingChangeHouse>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_booking_change_house", "ar");

                entity.Property(e => e.CustomerIdCard1).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard2).IsUnicode(false);

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);

                entity.Property(e => e.LandLength).IsUnicode(false);

                entity.Property(e => e.LandWidth).IsUnicode(false);

                entity.Property(e => e.NewHouseNumber).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintBookingDelay>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_booking_delay", "ar");

                entity.Property(e => e.CustomerContact1).IsUnicode(false);

                entity.Property(e => e.CustomerContact2).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard1).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard2).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintContract>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_contract", "ar");

                entity.Property(e => e.CusEng1).IsUnicode(false);

                entity.Property(e => e.CusEng2).IsUnicode(false);

                entity.Property(e => e.CustomerGender1).IsUnicode(false);

                entity.Property(e => e.CustomerGender2).IsUnicode(false);

                entity.Property(e => e.CustomerIdno1).IsUnicode(false);

                entity.Property(e => e.CustomerIdno2).IsUnicode(false);

                entity.Property(e => e.CustomerPhoneCall1).IsUnicode(false);

                entity.Property(e => e.CustomerPhoneCall2).IsUnicode(false);

                entity.Property(e => e.HouseLandLength).IsUnicode(false);

                entity.Property(e => e.HouseLandWidth).IsUnicode(false);

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseNo).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);

                entity.Property(e => e.ProjectCode).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintCusInfoC2c>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_cusInfo_c2c", "ar");

                entity.Property(e => e.CusEng1).IsUnicode(false);

                entity.Property(e => e.CusEng2).IsUnicode(false);

                entity.Property(e => e.CustomerGender1).IsUnicode(false);

                entity.Property(e => e.CustomerGender2).IsUnicode(false);

                entity.Property(e => e.CustomerIdno1).IsUnicode(false);

                entity.Property(e => e.CustomerIdno2).IsUnicode(false);

                entity.Property(e => e.CustomerPhoneCall1).IsUnicode(false);

                entity.Property(e => e.CustomerPhoneCall2).IsUnicode(false);
            });

            modelBuilder.Entity<VrepPrintOwnership>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vrep_print_ownership", "ar");

                entity.Property(e => e.CustomerIdCard1).IsUnicode(false);

                entity.Property(e => e.CustomerIdCard2).IsUnicode(false);

                entity.Property(e => e.CustomerPhoneCall1).IsUnicode(false);

                entity.Property(e => e.CustomerPhoneCall2).IsUnicode(false);

                entity.Property(e => e.HouseLandLength).IsUnicode(false);

                entity.Property(e => e.HouseLandWidth).IsUnicode(false);

                entity.Property(e => e.HouseLength).IsUnicode(false);

                entity.Property(e => e.HouseNumber).IsUnicode(false);

                entity.Property(e => e.HouseWidth).IsUnicode(false);

                entity.Property(e => e.NewCustomerIdCard1).IsUnicode(false);

                entity.Property(e => e.NewCustomerIdCard2).IsUnicode(false);

                entity.Property(e => e.NewCustomerPhoneCall1).IsUnicode(false);

                entity.Property(e => e.NewCustomerPhoneCall2).IsUnicode(false);

                entity.Property(e => e.NewCustomerSex1).IsUnicode(false);

                entity.Property(e => e.NewCustomerSex2).IsUnicode(false);

                entity.Property(e => e.OwnershipRequestType).IsUnicode(false);
            });

            modelBuilder.Entity<VCountHouseByOwnership>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("v_count_house_by_ownership", "ar");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
