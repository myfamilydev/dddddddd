﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccess.Entities.Mayura;
using DataAccess.Entities.Customize;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccess.DBContexts
{
    public partial class MayuraDBContext : DbContext
    {

        public virtual DbSet<ClsContractReference> ContractReferences { get; set; }
        public virtual DbSet<ClsfinalPaymentInfo> FinalPaymentInfo { get; set; }
        public virtual DbSet<ClsContractAgreement> ContractAgreement { get; set; }
        public virtual DbSet<ClsRegularCollectionDetailSummary> RegularCollectionDetailSummary { get; set; }
        public virtual DbSet<ClsHousePaid> HousePaids { get; set; }
        public virtual DbSet<ClsPenaltyPaid> PenaltyPaid { get; set; }
        public virtual DbSet<ClsPublicServicePaid> PublicServicePaid { get; set; }
        public virtual DbSet<ClsFinalPaid> FinalPaid { get; set; }
       
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<ClsContractReference>().HasNoKey();
            modelBuilder.Entity<ClsfinalPaymentInfo>().HasNoKey();
            modelBuilder.Entity<ClsContractAgreement>().HasNoKey();
            modelBuilder.Entity<ClsRegularCollectionDetailSummary>().HasNoKey();
            modelBuilder.Entity<ClsHousePaid>().HasNoKey();
            modelBuilder.Entity<ClsPenaltyPaid>().HasNoKey();
            modelBuilder.Entity<ClsPublicServicePaid>().HasNoKey();
            modelBuilder.Entity<ClsFinalPaid>().HasNoKey();
           


        }
    }
}