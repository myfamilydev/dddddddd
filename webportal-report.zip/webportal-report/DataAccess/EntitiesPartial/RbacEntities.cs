﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.EntitiesPartial
{
    public class ReportPermission
    {
        public Guid Code { get; set; }
        public string AccessName { get; set; }
        public string ReportTitle { get; set; }

    }
}
