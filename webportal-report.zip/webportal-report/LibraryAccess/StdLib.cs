﻿using System;
using System.Net;

namespace LibraryAccess
{
    public static class StdLib
    {
        public static string AccountingNumberFormat(decimal value)
        {
            return  value.ToString("<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">#,##0.00</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">(#,##0.00)</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right;padding-right:20%\">-</div></div></div>");
        }

        public static string AccountingNumberFormat2(decimal value)
        {
            return value.ToString("<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">#,##0</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right\">(#,##0)</div></div></div>;" +
                                   "<div style=\"display:table;width:100%\"><div style=\"display:table-row;\"><div style=\"display:table-cell;text-align:left\">$</div><div style=\"display:table-cell;text-align:right;padding-right:20%\">-</div></div></div>");
        }
        public static string ConvertMonthToKhmer(int month)
        {
            string[] months = { "មករា", "កុម្ភះ", "មីនា", "មេសា", "ឧសភា", "មិថុនា", "កក្កដា", "សីហា", "កញ្ញា", "តុលា", "វិច្ឆិកា", "ធ្នូ" };
            return months[month-1];
        }
        public static string ConvertNumberToKhmer(int num)
        {

            string[] numbers = { "០","១", "២", "៣", "៤", "៥", "៦", "៧", "៨", "៩" };
            string str=num.ToString();
            string result = "";
            for(int i = 0; i < str.Length; i++)
            {
                string ch = str[i].ToString();
                byte index = Convert.ToByte(ch);
                result += numbers[index];
            }
            return result;  
        }

    }
}
