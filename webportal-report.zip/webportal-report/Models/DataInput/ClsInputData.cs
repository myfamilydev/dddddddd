﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebPortal.Models.InputData
{
    public class InputProjectDailyRevenue
    {
            public DateTime DateFrom { set; get; }
            public DateTime DateTo{ set; get; }
            public int ProjectId { set; get; }
           public int UserId { set; get; }
           public int Action { set; get; }
    }

    public class RevenueMonthlyInput
    {
        public DateTime DateFrom { set; get; }
        public int ProjectId { set; get; }

        public string Ownership { set; get; }
        public int Action { set; get; }
    }

    public class SummarySaleAndCollectionInput
    {
        public DateTime DateFrom { set; get; }
        public int ProjectId { set; get; }

        public string Ownership { set; get; }
        public int Action { set; get; }
        public string Remark { set; get; }
    }

    public class SummaryCollectionTerminateInput
    {
        public DateTime DateFrom { set; get; }
        public int ProjectId { set; get; }

        public string Ownership { set; get; }
        public int Action { set; get; }
    }

    public class SummaryCollectionInput
    {
        [Column(TypeName = "date")]
        public DateTime DateClose { set; get; }
        [Column(TypeName = "date")]
        public DateTime DateCurrent { set; get; }
        public int ProjectId { set; get; }

        public string Ownership { set; get; }
        public int Action { set; get; }
    }

    public class DailyMessageInput
    {
        public DateTime Date { set; get; }
     
        public int ProjectId { set; get; }
        public int Action { set; get; }
    }

    public class OwnershipList
    {
        public string Name { set; get; }
        public string Value { set; get; }
    }

    public class InputSchedule
    {
        public int ScheduleNo { set; get; }
        public int Action { set; get; }
    }
    public class InputBookingDailyRevenue
    {
            public DateTime DateFrom { set; get; }
            public DateTime DateTo { set; get; }
            public int ProjectId { set; get; }       
            public int Action { set; get; }
    }

   
    public class NetContractTerminate
    {
        public DateTime DateFrom { set; get; }
        public DateTime DateTo { set; get; }
        public int ProjectId { set; get; }
        public int Action { set; get; }
    }

    public class PhoneTracking
    {
        public DateTime DateFrom { set; get; }
        public DateTime DateTo { set; get; }
        public int ProjectId { set; get; }

        public int HouseTypeId { set; get; }

        public int HouseId { set; get; }

        public string Purpose { set; get; }
        public int Action { set; get; }
    }
    public class AccumulateReport
    {
        public DateTime DateFrom { set; get; }
        public int ProjectId { set; get; }
        public int Action { set; get; }
    }

    public class LastPaymentReportFilter
    {
        public DateTime DateFrom { set; get; }
        public int ProjectId { set; get; }
        public int Action { set; get; }
    }   

    public class LatePayment
    {
        public int ProjectId { set; get; }
        public int Action { set; get; }
    }
    public class PaymentMethod
    {
        public string name { set; get; }
        public decimal amount { set; get; }
        public PaymentMethod(string name, decimal amount)
        {
            this.name = name;
            this.amount = amount;
        }
    }
    public class HouseTypeCount
    {
        public string project { set; get; }
        public string name { set; get; }
        public decimal amount { set; get; }
        public HouseTypeCount(string project, string name, decimal amount)
        {
            this.project = project;
            this.name = name;
            this.amount = amount;
        }
    }
    public class HouseReachInterestReport
    {       
        public int @nmonth { set; get; }
        public int Action { set; get; }

    }
}
