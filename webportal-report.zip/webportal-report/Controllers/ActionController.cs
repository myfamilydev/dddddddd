﻿using DataAccess.DBContexts;
using DataAccess.Entities.Mayura;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebPortal.Models.ActionInput;

namespace WebPortal.Controllers
{
    public class ActionController : Controller
    {
        private readonly ILogger<PrintingController> _logger;
        private readonly ArDBContext _ArContext;
        private readonly MayuraDBContext _MayuraContext;

        public ActionController(ILogger<PrintingController> logger, ArDBContext ArContext, MayuraDBContext MayuraContext)
        {
            _logger = logger;
            _ArContext = ArContext;
            _MayuraContext = MayuraContext;
        }
        public async Task<IActionResult> SummarySaleAndCollectionReportRemarkAdd(SummarySaleCollectionRemark data)
        {

                try
                {

                        int user_id = 0;
                        string remote_ip = HttpContext.Connection.RemoteIpAddress?.ToString();
                        var sessionlog = await _MayuraContext.SessionsLog.Where(x => x.RemoteIp == remote_ip && x.Status == 1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                        if (sessionlog != null)
                        {
                            user_id = sessionlog.CreatedBy ?? 0;
                        }

                        var remark = new SummarySaleCollectionRemark();
                        remark.ProjectId = data.ProjectId;
                        remark.InDate = data.InDate;
                        remark.Remark = data.Remark;
                        remark.CreatedAt = DateTime.Now;
                        remark.CreatedBy = user_id;
                        remark.Status = 1;
                        _MayuraContext.SummarySaleCollectionRemark.Add(remark);
                        await _MayuraContext.SaveChangesAsync();
                        return Ok(remark);

                }catch(Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }

        public async Task<IActionResult> SummarySaleAndCollectionReportRemarkUpdate(SummarySaleCollectionRemark data)
        {

                try
                {

                        int user_id = 0;
                        string remote_ip = HttpContext.Connection.RemoteIpAddress?.ToString();
                        var sessionlog = await _MayuraContext.SessionsLog.Where(x => x.RemoteIp == remote_ip && x.Status == 1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                        if (sessionlog != null)
                        {
                            user_id = sessionlog.CreatedBy ?? 0;
                        }

                        var remark = await _MayuraContext.SummarySaleCollectionRemark.SingleOrDefaultAsync(x=>x.Id==data.Id);
                        if (remark == null)
                        {
                            return BadRequest("Update fail, please try again!");
                        }
                
                       // remark.ProjectId = data.ProjectId;
                       // remark.InDate = data.InDate;
                        remark.Remark = data.Remark;
                        remark.UpdatedAt = DateTime.Now;
                        remark.UpdatedBy = user_id;                               
                        await _MayuraContext.SaveChangesAsync();
                        return Ok();

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
        }
        public async Task<IActionResult> SummarySaleAndCollectionReportRemarkDelete(SummarySaleCollectionRemark data)
        {

            try
            {

                int user_id = 0;
                string remote_ip = HttpContext.Connection.RemoteIpAddress?.ToString();
                var sessionlog = await _MayuraContext.SessionsLog.Where(x => x.RemoteIp == remote_ip && x.Status == 1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                if (sessionlog != null)
                {
                    user_id = sessionlog.CreatedBy ?? 0;
                }

                var remark = await _MayuraContext.SummarySaleCollectionRemark.SingleOrDefaultAsync(x => x.Id == data.Id);
                if (remark == null)
                {
                    return BadRequest("Update fail, please try again!");
                }

                // remark.ProjectId = data.ProjectId;
                // remark.InDate = data.InDate;
                // remark.Remark = data.Remark;
                remark.Status = 0;
                remark.UpdatedAt = DateTime.Now;
                remark.UpdatedBy = user_id;
                await _MayuraContext.SaveChangesAsync();
                return Ok();

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        public async Task<IEnumerable<SummarySaleCollectionRemark>> GetSummarySaleAndCollectionReportRemark(SummarySaleCollectionRemark data)
        {               
                var remark =await _MayuraContext.SummarySaleCollectionRemark.Where(x =>x.ProjectId==data.ProjectId && x.InDate.Value.Month==data.InDate.Value.Month && x.InDate.Value.Year==data.InDate.Value.Year && x.Status == 1).ToListAsync();
                return remark;               
        }

    }
}
