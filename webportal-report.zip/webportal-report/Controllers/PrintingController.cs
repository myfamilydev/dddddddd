﻿using DataAccess.DBContexts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebPortal.Models.InputData;
using CsvHelper;
using CsvHelper.Configuration;
using System.IO;
using CsvHelper.TypeConversion;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using DataAccess.Entities.AR;
using System.Configuration;
using System.Globalization;
using System.Collections;
using DataAccess.Entities.Customize_AR;
using WebPortal.Helper;
using Microsoft.Extensions.Configuration;

namespace WebPortal.Controllers
{
    public class Foo
    {
        public string បុរីវិមានភ្នំពេញ{ get; set; }
        public string Report { get; set; }
        public string Date { get; set; }
    }

    public class Purpose
    {
        public Purpose(string Name, string Key)
        {
            this.Name = Name;
            this.Key = Key;
        }
        public string Name { get; set; }
        public string Key { get; set; }
    }
    public class PrintingController : Controller
    {
        private readonly ILogger<PrintingController> _logger;
        private readonly ArDBContext _ArContext;
        private readonly MayuraDBContext _MayuraContext;
        private string connectionString;
        //private string ip_remote;
        private IConfiguration Configuration { get; }
        public PrintingController(ILogger<PrintingController> logger, ArDBContext ArContext, MayuraDBContext MayuraContext, IConfiguration configuration)
        {
            
            _logger = logger;
            _ArContext = ArContext;
            _MayuraContext = MayuraContext;
            Configuration = configuration;
            connectionString = Configuration.GetConnectionString("AppDbConnection");        // ConfigurationManager.ConnectionStrings["connstr"]?.ConnectionString;
          //  ip_remote = HttpContext.Connection.RemoteIpAddress?.ToString();          
        }
        public async Task<IActionResult> Booking(int id)
        {
            //get permission
            //   string sql = "exec [dbo].[sp_sale_access_permission] @result={0} out";
            //   var result = new Microsoft.Data.SqlClient.SqlParameter("@result", SqlDbType.Int) { Direction = ParameterDirection.Output };
            //  await _ArContext.Database.ExecuteSqlRawAsync(sql, result);
            //    ViewBag.Permission = result.Value;
            _ArContext.Database.SetCommandTimeout(1200);
            var data = _ArContext.VrepPrintBooking.FromSqlRaw("exec ar.sp_print_booking {0}", id).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                if (data.ProjectId == 5)
                {
                    return View("Booking/BookingP16", data);
                }

                return View("Booking/Booking", data);
            }

            return BadRequest("Oop!, Invalid Booking Id");
        }
        public IActionResult FinalPaymentRequest(int id)
        {
            try
            {
             
                var data = _MayuraContext.FinalPaymentInfo.FromSqlRaw("exec ar.get_final_payment_info {0}", id).AsEnumerable().SingleOrDefault();
                
                if (data != null)
                {
                  
                    ViewBag.id = id;
                    ViewBag.ContractReference = _MayuraContext.ContractReferences.FromSqlRaw("exec ar.get_contract_reference {0}", id).AsEnumerable().ToList();
                    return View("Contract/fullpayment", data);
                }
                return BadRequest("Oop!, Invalid Final Payment Id");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        

        //public IActionResult FinalPaymentRequestDocx(int id)
        //{
        //    try
        //    {

        //        var code = @"<span>Hello World!!</span>";
        //        System.IO.File.WriteAllText("document.html", code);

        //        // Initialize an HTML document from the file
        //        using (var document = new HTMLDocument("document.html"))
        //        {
        //            // Initialize DocSaveOptions 
        //            var options = new Aspose.Html.Saving.DocSaveOptions();

        //            // Convert HTML webpage to DOCX
        //            Aspose.Html.Converters.Converter.ConvertHTML(document, options, "output.docx");
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        return BadRequest(e.Message);
        //    }
        //}
        public async Task<IActionResult> BookingDiscount(int id)
        {

            var data = _ArContext.VrepPrintBookingAdhocDiscount.FromSqlRaw("exec ar.sp_get_adhoc_discount {0}", id).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                if(data.projectId == 5)
                {
                    return View("Booking/BookingDiscountP16", data);
                }
                
                return View("Booking/BookingDiscount", data);

            }
            return BadRequest("Oop!, Invalid BookingDiscount Id");

        }
        public async Task<IActionResult> BookingCancel(int id)
        {

            var data = await _ArContext.VrepPrintBookingCancellation.Where(x => x.BookingCancelId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                if (data.BookingCancelDate?.Year >= 2022)
                {
                    return View("Booking/BookingCancellation2022", data);
                }
                else
                {
                    return View("Booking/BookingCancellation", data);
                }
                

            }
            return BadRequest("Oop!, Invalid BookingCancel Id");

        }
        public async Task<IActionResult> BookingDelay(int id)
        {

            var data = await _ArContext.VrepPrintBookingDelay.Where(x => x.BookingDelayId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                if(data.projectId==5)
                {
                    return View("Booking/BookingDelayP16", data);
                }

                return View("Booking/BookingDelay", data);
            }
            return BadRequest("Oop!, Invalid BookingDelay Id");

        }
        public async Task<IActionResult> BookingChangeOwner(int id)
        {

            var data = await _ArContext.VprintBookingChangeOwnership.Where(x => x.BookingChangeOwnerId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                return View("Booking/BookingChangeOwner", data);

            }
            return BadRequest("Oop!, Invalid BookingChangeOwner Id");

        }
        public async Task<IActionResult> BookingHouseChange(int id)
        {
            var data = await _ArContext.VrepPrintBookingChangeHouse.Where(x => x.BookingChangeHouseId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                if (data.BookingHouseChangeDate?.Year >= 2022)
                {
                    return View("Booking/BookingHouseChange2022", data);
                }
                else
                {
                    return View("Booking/BookingHouseChange", data);
                }
                

            }
            return BadRequest("Oop!, Invalid BookingChange Id");

        }
        public async Task<IActionResult> ContractDailyReport(InputBookingDailyRevenue data)
        {
            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
            }

            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_contract_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.ContractDailyReport = _ArContext.ContractDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/ContractDailyReport", data);
            }
            else if (data.Action == 2)
            {

                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_get_contract_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.ContractDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();
          
                sb.Clear();
                sb.AppendLine("Project,Contract ID,Booking ID,House No.,Road No.,Type,House Size,Customer Name,English Name,Contact Number,Contract Date,Contract Term,Payment Term,Booking Date,House Price,Discount,Net Amount,Booking Amount,Remark");
                foreach (var item in list)
                {
                    sb.AppendLine(item.ProjectShort + "," + item.ContractId + "," + item.BookingId + "," + item.HouseNumber + ",\"" + item.StreeNumber + "\"," + item.HouseType + "," + item.HouseSize + ",\"" +
                              item.CustomerName + "\",\"" + item.NameEn + "\"," + item.PhoneContract + "," + item.ContractDate?.ToString("dd/MM/yyyy")+","+item.ConstructionPeriod+ "," + (item.Paymenterm.Contains(",")? "\""+item.Paymenterm+"\"": item.Paymenterm) + "," + item.BookingDate?.ToString("dd/MM/yyyy") + "," + item.HousePrice + "," + item.Discount + "," + item.NetAmount + "," + item.BookingAmount + "," + item.Remark);
                }
             var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
             return File(result, "text/csv", "ContractDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                /*
                   var stream = new MemoryStream();
                   using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                   {
                       var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                       csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                   }
                   return File(stream.ToArray(), "text/csv", "ContractDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                         */
            }
            else
            {
                ViewBag.BookingDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).
                    ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/ContractDailyReport", data);
            }


        }
        public async Task<IActionResult> ContractC2C(int id)
        {

            var data = _ArContext.VrepPrintContractC2c.FromSqlRaw("exec ar.sp_print_contract_c2c {0}", id).AsEnumerable().SingleOrDefault();
            //if (data == null) return BadRequest("No house payment for this house!");

            if (data != null)
            {
                return View("Contract/C2C", data);
            }
            return BadRequest("Oop!, Invalid ContractID");


        }
        public async Task<IActionResult> ContractTerminationTransfer(int id)
        {

            var data = await _ArContext.VPrintContractTerminationTransfer.Where(x => x.id == id).FirstOrDefaultAsync();
            if (data == null) return BadRequest("No house payment for this house!");

            if (data != null)
            {
                return View("Contract/ContractTerminationTransfer", data);
            }
            return BadRequest("Oop!, Invalid ContractTerminationTransfer");


        }
        public async Task<IActionResult> Contract(int id)
        {
            /*  var userAgent = HttpContext.Request.Headers["User-Agent"];
              string token = HttpContext.Request?.Query["token"] ?? "";            

              if(String.IsNullOrEmpty(token) || Token.isValidToken(token, userAgent) == false)
              {
                 return BadRequest("Expire token!");
              }
              bool isDraff = Token.isDraffToken(token, userAgent); */

            ViewBag.isDraff = true;
            string remote_ip = HttpContext.Connection.RemoteIpAddress?.ToString();
            var sessionlog = await _MayuraContext.SessionsLog.Where(x => x.RemoteIp == remote_ip && x.Status == 1).OrderByDescending(x=>x.CreatedAt).FirstOrDefaultAsync();
            if (sessionlog != null)
            {
                int user_id = sessionlog.CreatedBy ?? 0;
                var user_role = await _MayuraContext.UsersToRoles.FirstOrDefaultAsync(x => x.UserId == user_id && !(x.RoleId ==7 || x.RoleId == 15));
                if (user_role != null) ViewBag.isDraff = false;
            }
            
            var data = await _ArContext.VrepPrintContract.Where(x => x.ContractId == id).FirstOrDefaultAsync();            

            if (data != null)
            {
                StringComparison comp = StringComparison.OrdinalIgnoreCase;
                 
                
                if (data.HouseTypeName.Contains("land", comp))
                {
                    if (data.pId > 0)
                    {
                        if(data.ProjectCode == "P14")
                        {
                            return View("Contract/LandContractP14", data);
                        }

                        return View("Contract/LandContractAll", data);
                    }
                    else
                    {
                        return View("Contract/Planing", data);
                    }
                }
                else if(data.pId<1)
                {
                    if (data.ContractDate <= new DateTime(2016, 09, 20))
                    {
                        if (data.pId == -1 ||
                            data.pId == -5 ||
                            data.pId == -6 ||
                            data.pId == -7)
                        {
                            // $this,>stencil,>title('Contract Form | V1);
                            return View("Contract/printing_contract_form", data);
                        }
                        else if (data.pId == -2)
                        {
                            // $this,>stencil,>title('Contract Form | V2);
                            return View("Contract/printing_contract_form_v2", data);
                        }
                        else if (data.pId == -3)
                        {
                            // $this,>stencil,>title('Contract Form | V3);
                            return View("Contract/printing_contract_form_v3", data);
                        }
                        else
                        {
                            // $this,>stencil,>title('Contract Form | V2);
                            return View("Contract/printing_contract_form_v2", data);
                        }
                    }
                    else
                    {
                        if (data.ContractDate >= new DateTime(2021, 01, 12))
                        {
                            if (data.pId <= -13)
                            {
                                // $this,>stencil,>title('Contract Form | V11.2);
                                return View("Contract/printing_contract_form_v11_2", data);
                            }
                            else if (data.pId == -12)
                            {
                                // $this,>stencil,>title('Contract Form | V10.3);
                                return View("Contract/printing_contract_form_v10_3", data);
                            }
                            else if (data.pId == -11)
                            {
                                // $this,>stencil,>title('Contract Form | V9.3);
                                return View("Contract/printing_contract_form_v9_3", data);
                            }
                            else if (data.pId == -10)
                            {
                                // $this,>stencil,>title('Contract Form | V8.4);
                                return View("Contract/printing_contract_form_v8_4", data);
                            }
                            else if (data.pId == -9)
                            {
                                // $this,>stencil,>title('Contract Form | V7.1);
                                return View("Contract/printing_contract_form_v7_1", data);
                            }
                            else if (data.pId == -8)
                            {
                                // $this,>stencil,>title('Contract Form | V6.1);
                                return View("Contract/printing_contract_form_v6_1", data);
                            }
                            else if (data.pId == -7)
                            {
                                // $this,>stencil,>title('Contract Form | V5.1);
                                return View("Contract/printing_contract_form_v5_1", data);
                            }
                            else if (data.pId == -6)
                            {
                                // $this,>stencil,>title('Contract Form | V4.1);
                                return View("Contract/printing_contract_form_v4_1", data);
                            }
                            else if (data.pId == -5)
                            {
                                // $this,>stencil,>title('Contract Form | V3.1);
                                return View("Contract/printing_contract_form_v3_1", data);
                            }
                            else if (data.pId == 4)
                            {
                                // $this,>stencil,>title('Contract Form | V2.1);
                                return View("Contract/printing_contract_form_v2_1", data);
                            }
                            else
                            {
                                // $this,>stencil,>title('Contract Form | V1.1);
                                return View("Contract/printing_contract_form_v1_1", data);
                            }
                        }
                        else if (data.ContractDate >= new DateTime(2019, 08, 12))
                        {
                            if (data.pId <= -13)
                            {
                                // $this,>stencil,>title('Contract Form | V11.1);
                                return View("Contract/printing_contract_form_v11_1", data);
                            }
                            else if (data.pId == -12)
                            {
                                // $this,>stencil,>title('Contract Form | V10.2);
                                return View("Contract/printing_contract_form_v10_2", data);
                            }
                            else if (data.pId == -11)
                            {
                                // $this,>stencil,>title('Contract Form | V9.2);
                                return View("Contract/printing_contract_form_v9_2", data);
                            }
                            else if (data.pId == -10)
                            {
                                // $this,>stencil,>title('Contract Form | V8.3);
                                return View("Contract/printing_contract_form_v8_3", data);
                            }
                            else if (data.pId == -9)
                            {
                                // $this,>stencil,>title('Contract Form | V7.1);
                                return View("Contract/printing_contract_form_v7_1", data);
                            }
                            else if (data.pId == -8)
                            {
                                // $this,>stencil,>title('Contract Form | V6.1);
                                return View("Contract/printing_contract_form_v6_1", data);
                            }
                            else if (data.pId == -7)
                            {
                                // $this,>stencil,>title('Contract Form | V5.1);
                                return View("Contract/printing_contract_form_v5_1", data);
                            }
                            else if (data.pId == -6)
                            {
                                // $this,>stencil,>title('Contract Form | V4.1);
                                return View("Contract/printing_contract_form_v4_1", data);
                            }
                            else if (data.pId == -5)
                            {
                                // $this,>stencil,>title('Contract Form | V3.1);
                                return View("Contract/printing_contract_form_v3_1", data);
                            }
                            else if (data.pId == -4)
                            {
                                // $this,>stencil,>title('Contract Form | V2.1);
                                return View("Contract/printing_contract_form_v2_1", data);
                            }
                            else
                            {
                                // $this,>stencil,>title('Contract Form | V1.1);
                                return View("Contract/printing_contract_form_v1_1", data);
                            }
                        }
                        else if (data.pId == -11 && data.ContractDate >= new DateTime(2019, 03, 27))
                        {
                            // $this,>stencil,>title('Contract Form | V9.1);
                            return View("Contract/printing_contract_form_v9_1", data);
                        }
                        
                        else
                        {
                            if (data.pId == -8 ||
                                data.pId == -1 ||
                                data.pId == -5)
                            {
                                // $this,>stencil,>title('Contract Form | V4);
                                return View("Contract/printing_contract_form_v4", data);
                            }
                            else if (data.pId == -3)
                            {
                                // $this,>stencil,>title('Contract Form | V3);
                                return View("Contract/printing_contract_form_v3", data);
                            }
                            else if (data.pId == -2)
                            {
                                // $this,>stencil,>title('Contract Form | V5);
                                return View("Contract/printing_contract_form_v5", data);
                            }
                            else if (data.pId == -7)
                            {
                                // $this,>stencil,>title('Contract Form | V6);
                                return View("Contract/printing_contract_form_v6", data);
                            }
                            else if (data.pId == -9)
                            {
                                // $this,>stencil,>title('Contract Form | V7);
                                return View("Contract/printing_contract_form_v7", data);
                            }
                            else if (data.pId == -10)
                            {
                                if (data.ContractDate >= new DateTime(2019, 06, 03))
                                {
                                    // $this,>stencil,>title('Contract Form | V8.2);
                                    return View("Contract/printing_contract_form_v8_2", data);
                                }
                                else if (data.ContractDate >= new DateTime(2017, 12, 07))
                                {
                                    // $this,>stencil,>title('Contract Form | V8.1);
                                    return View("Contract/printing_contract_form_v8_1", data);
                                }
                                else
                                {
                                    // $this,>stencil,>title('Contract Form | V8);
                                    return View("Contract/printing_contract_form_v8", data);
                                }
                            }
                            else if (data.pId == -11)
                            {
                                // $this,>stencil,>title('Contract Form | V9);
                                return View("Contract/printing_contract_form_v9", data);
                            }
                            else if (data.pId == -12)
                            {
                                if (data.ContractDate >= new DateTime(2019, 08, 12))
                                {
                                    // $this,>stencil,>title('Contract Form | V10.2);
                                    return View("Contract/printing_contract_form_v10_2", data);
                                }
                                else
                                {
                                    // $this,>stencil,>title('Contract Form | V10.1);
                                    return View("Contract/printing_contract_form_v10_1", data);
                                }
                            }
                            else
                            {
                                // $this,>stencil,>title('Contract Form | V6);
                                return View("Contract/printing_contract_form_v6", data);
                            }
                        }
                    }
                } else if(data.pId > 0 && data.pId == 5)
                {
                    return View("Contract/printing_contract_form_p16_v1", data);
                }
                else
                {
                    return View("Contract/Planing", data);
                }
            }
            return BadRequest("Oop!, Invalid ContractID");


        }
        public async Task<IActionResult> ContractExtra(int id)
        {
            var projects = new Dictionary<string, string>(){
                {"P09", "Contract/Extra/P09"},
                {"P10", "Contract/Extra/P10"},
                {"P11", "Contract/Extra/P11"},
                {"P12", "Contract/Extra/P12"},
                {"P14", "Contract/Extra/P14"},
                {"P15", "Contract/Extra/P15"},
                {"P16", "Contract/Extra/P16"},
                {"P07", "Contract/Extra/P07"}
            };

            var data = await _ArContext.VrepPrintContract
                        .Where(x => x.ContractId == id)
                        .FirstOrDefaultAsync();

            if (data != null)
            {
                var ProjectCode = data.ProjectCode ?? "";

                if(projects.ContainsKey(ProjectCode))
                {
                    return View(projects[ProjectCode], data);
                }

                return View("Contract/Extra/AllProject", data);
            }
            return BadRequest("Oop!, Invalid ContractID");


        }

        public async Task<IActionResult> ContractExtraTransferOwner(int id)
        {
            var projects = new Dictionary<string, string>(){
                {"P09", "Contract/Extra/P09"},
                {"P10", "Contract/Extra/P10"},
                {"P11", "Contract/Extra/P11"},
                {"P12", "Contract/Extra/P12"},
                {"P14", "Contract/Extra/P14"},
                {"P15", "Contract/Extra/P15"},
                {"P16", "Contract/Extra/P16"}
            };

            var data = await _ArContext.VrepPrintContract
                        .Where(x => x.ContractId == id)
                        .FirstOrDefaultAsync();

            if (data != null)
            {
                var ProjectCode = data.ProjectCode ?? "";

                if (projects.ContainsKey(ProjectCode))
                {
                    return View(projects[ProjectCode], data);
                }

                return View("Contract/Extra/AllProject", data);
            }
            return BadRequest("Oop!, Invalid ContractID");


        }

        public async Task<IActionResult> C2cCusInfo(int id)
        {
            var projects = new Dictionary<string, string>(){
                {"P09", "Contract/C2CExtra/P09"},
                {"P10", "Contract/C2CExtra/P10"},
                {"P11", "Contract/C2CExtra/P11"},
                {"P12", "Contract/C2CExtra/P12"},
                {"P14", "Contract/C2CExtra/P14"},
                {"P15", "Contract/C2CExtra/P15"},
                {"P16", "Contract/C2CExtra/P16"},
            };

            var data = await _ArContext.VrepPrintCusInfoC2c
                        .Where(x => x.C2cid == id)
                        .FirstOrDefaultAsync();
            if (data != null)
            {
                var ProjectCode = data.ProjectCode ?? "";

                if (projects.ContainsKey(ProjectCode))
                {
                    return View(projects[ProjectCode], data);
                }
                return View("Contract/C2CExtra/C2cAll", data);
            }
            return BadRequest("Oop!, Invalid ContractID");


        }

        public IActionResult OwnershipCusInfo(int id)
        {
            var projects = new Dictionary<string, string>(){
                {"P09", "Contract/Ownership/P09"},
                {"P10", "Contract/Ownership/P10"},
                {"P11", "Contract/Ownership/P11"},
                {"P12", "Contract/Ownership/P12"},
                {"P14", "Contract/Ownership/P14"},
                {"P15", "Contract/Ownership/P15"},
                {"P16", "Contract/Ownership/P16"},

            };

            var data = _ArContext.VPrintCusInfoOwnership
                        .FromSqlRaw("exec ar.customer_info_owership " + id)
                        .AsEnumerable()
                        .FirstOrDefault();
            if (data != null)
            {
                var ProjectCode = data.ProjectCode ?? "";

                if (projects.ContainsKey(ProjectCode))
                {
                    return View(projects[ProjectCode], data);
                }
                return View("Contract/Ownership/All", data);
            }
            return BadRequest("Oop!, Invalid ContractID");


        }

        public async Task<IActionResult> Ownership(int id, int withoutref = 0)
        {

            var data = await _ArContext.VrepPrintOwnership.Where(x => x.OwnershipId == id).FirstOrDefaultAsync();
            ViewBag.withoutref = withoutref;
            if (data != null)
            {
                string request_type = data.OwnershipRequestType.ToLower();
                if (request_type == "1") return View("Ownership/NewOwnership", data);
                if (request_type == "2") return View("Ownership/TransferOwnership", data);
                if (request_type == "3") return View("Ownership/RemoveOwnership", data);
            }
            return BadRequest("Oop!, Invalid OwnershipId");

        }
        public async Task<IActionResult> Schedule2(int id)
        {

            var data = await _ArContext.VprintSchedule.FirstOrDefaultAsync(x => x.HouseId == id);
            string scheduleNo = HttpContext.Request.Query["scheduleNo"];

            if (data != null)
            {
                //ViewBag.RescheduleCounter = await _MayuraContext.Reschedules.CountAsync(x => x.HouseId == id);
                List<VPaymentSchedulesInfo> schedule_info = new List<VPaymentSchedulesInfo>(); ;
                if (scheduleNo != "all" && scheduleNo != null)
                {
                    schedule_info = _ArContext.VPaymentSchedulesInfo.FromSqlRaw("exec dbo.sp_get_payment_schedule_info {0},{1}", id, Int32.Parse(scheduleNo)).AsEnumerable().ToList();
                        
                } else
                {
                    schedule_info = _ArContext.VPaymentSchedulesInfo.FromSqlRaw("exec dbo.sp_get_payment_schedule_info {0},0", id).AsEnumerable().ToList();
                }
                var totalFinalPaid = schedule_info.Sum(info => info.FinalPaidAmount);

                if (schedule_info.Count() == 0) return BadRequest("Oop!, There is no schedule for this house!");

                ViewBag.isFinalPaid = (totalFinalPaid > 0 && totalFinalPaid != null);
                ViewBag.printby = HttpContext.Request.Query["printby"];
                ViewBag.PaymentScheduleInfo = schedule_info;
                ViewBag.CollectionBookingInitialPayment = _ArContext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment {0}", id).AsEnumerable().ToList();
                //ViewBag.ExtraPrinciplePayment = _ArContext.ExtraPrinciplePayment.FromSqlRaw("exec dbo.sp_get_extra_principle_payment_schedule {0}", id).AsEnumerable().ToList();
                ViewBag.BankSettle = await _MayuraContext.BankSettlement.Where(x => x.ProjectId == data.ProjectId && x.Status==1).ToListAsync();
                ViewBag.ScheduleDetail = _ArContext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail {0}", id).AsNoTracking().ToList();
       
                
                //ViewBag.ScheduleDetailInterest = _ArContext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail {0},{1},{2}", id, data.ReceiptNo, 1).AsNoTracking().ToList();                
                return View("Schedule/payment1", data);
            }
            return BadRequest("Oop!, There is no schedule for this house!");

        }
        public async Task<IActionResult> Schedule(int id)
        {

            var data = await _ArContext.VPrintScheduleSale.FirstOrDefaultAsync(x => x.HouseId == id);
            if (data != null)
            {
                //ViewBag.RescheduleCounter = await _MayuraContext.Reschedules.CountAsync(x => x.HouseId == id);
                var schedule_info = await _ArContext.VPaymentSchedulesInfo.Where(x => x.HouseId == id)
                    .OrderByDescending(x => x.CreatedAt).ThenBy(x => x.InterestPercentMonth)
                    .ToListAsync();
                if (schedule_info.Count() == 0) return BadRequest("Oop!, There is no schedule for this house!");
                ViewBag.PaymentScheduleInfo = schedule_info;
                ViewBag.CollectionBookingInitialPayment = _ArContext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment {0}", id).AsEnumerable().ToList();
                //ViewBag.ExtraPrinciplePayment = _ArContext.ExtraPrinciplePayment.FromSqlRaw("exec dbo.sp_get_extra_principle_payment_schedule {0}", id).AsEnumerable().ToList();
                //int counter = bookingInitialPayments.Where(x => x.TransactionTypeId == 7).Count();                
                //ViewBag.IsInitialPayment = counter > 0;
                //ViewBag.CollectionBookingInitialPayment = bookingInitialPayments;
                ViewBag.printby = HttpContext.Request.Query["printby"];
                ViewBag.BankSettle = await _MayuraContext.BankSettlement.Where(x => x.ProjectId == data.ProjectId && x.Status == 1).ToListAsync();
                ViewBag.ScheduleDetail = _ArContext.VprintScheduleDetailSale.FromSqlRaw("exec dbo.sp_get_schedule_detail_sale {0}", id).AsNoTracking().ToList();
                //ViewBag.ScheduleDetailInterest = _ArContext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail {0},{1},{2}", id, data.ReceiptNo, 1).AsNoTracking().ToList();                
                return View("Schedule/paymentSale", data);
            }
            return BadRequest("Oop!, There is no schedule for this house!");

        }
        public async Task<IActionResult> ScheduleView(int id)
        {

            var data = await _ArContext.VprintSchedule.FirstOrDefaultAsync(x => x.HouseId == id);
            if (data != null)
            {
                //ViewBag.RescheduleCounter = await _MayuraContext.Reschedules.CountAsync(x => x.HouseId == id);
                var schedule_info = await _ArContext.VPaymentSchedulesInfo.Where(x => x.HouseId == id)
                    .OrderByDescending(x => x.RescheduleNo).ThenBy(x => x.InterestPercentMonth)
                    .ToListAsync();
                if (schedule_info.Count() == 0) return BadRequest("Oop!, There is no schedule for this house!");
                ViewBag.PaymentScheduleInfo = schedule_info;
                ViewBag.CollectionBookingInitialPayment = _ArContext.CollectionBookingInitialPayment.FromSqlRaw("exec dbo.sp_get_collection_booking_initialpayment {0}", id).AsEnumerable().ToList();
                ViewBag.ExtraPrinciplePayment = _ArContext.ExtraPrinciplePayment.FromSqlRaw("exec dbo.sp_get_extra_principle_payment_schedule {0}", id).AsEnumerable().ToList();
                //int counter = bookingInitialPayments.Where(x => x.TransactionTypeId == 7).Count();                
                //ViewBag.IsInitialPayment = counter > 0;               
                ViewBag.BankSettle = await _MayuraContext.BankSettlement.Where(x => x.ProjectId == data.ProjectId).ToListAsync();
                ViewBag.ScheduleDetail = _ArContext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail {0}", id).AsNoTracking().ToList();
                //ViewBag.ScheduleDetailInterest = _ArContext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail {0},{1},{2}", id, data.ReceiptNo, 1).AsNoTracking().ToList();                
                return View("Schedule/ScheduleView", data);
            }
            return BadRequest("Oop!, There is no schedule for this house!");

        }
        /* public async Task<IActionResult> InterestSchedule(int id)
         {

                 var data = await _ArContext.VprintSchedule.SingleOrDefaultAsync(x => x.MonthlyInterest == 0 && x.ContractId == id);

                 if (data != null)
                 {
                     ViewBag.BankSettle = await _MayuraContext.BankSettlement.Where(x => x.ProjectId == data.ProjectId).ToListAsync();
                     ViewBag.ScheduleDetail = await _ArContext.VprintScheduleDetail.Where(x => x.ContractId == id && x.Interest > 0).ToListAsync();
                     return View("Schedule/NoneInterest", data);
                 }
                 return BadRequest("Oop!, Invalid OwnershipId");

         } */
        public async Task<IActionResult> CollectionReceipt1(int id)
        {

            var data = await _ArContext.VprintContractCollection1.FirstOrDefaultAsync(x => x.Id == id);
            if (data != null)
            {
                ViewBag.HousePaid = null;
                ViewBag.PenaltyPaid = null;
                ViewBag.PublicServicePaid = null;
                ViewBag.FinalPaid = null;
                ViewBag.FirstExtraPrinciple = null;
                ViewBag.ExtraPrinciple = null;
                ViewBag.Interest = null;

                var collection_details = _MayuraContext.RegularCollectionDetailSummary.FromSqlRaw("exec dbo.get_regular_collection_detail {0}", id).AsEnumerable().ToList();
                if (collection_details != null)
                {
                    foreach (var detail in collection_details)
                    {
                        switch (detail.TransactionType)
                        {
                            case 1:
                                
                                ViewBag.HousePaid = _MayuraContext.HousePaids.FromSqlRaw("exec dbo.sp_get_house_paid {0}", id).AsEnumerable().ToList();
                                break;  //house payment
                            case 2:
                                ViewBag.PenaltyPaid = _MayuraContext.PenaltyPaid.FromSqlRaw("exec dbo.sp_get_penalty_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break; //penalty
                            case 3:
                                ViewBag.PublicServicePaid = _MayuraContext.PublicServicePaid.FromSqlRaw("exec dbo.sp_get_public_service_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break;
                            case 13:
                                ViewBag.FinalPaid = _MayuraContext.FinalPaid.FromSqlRaw("exec dbo.sp_get_final_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break; //final payment
                            case 7:
                                ViewBag.FirstExtraPrinciple = detail.Payment;
                                break;
                            case 8: //interest
                                ViewBag.Interest = detail?.Payment ?? 0;
                                break;
                            case 9: //extra principle
                                ViewBag.ExtraPrinciple = detail.Payment;
                                break;
                        }
                    }
                }

                ViewBag.CollectionDetail = await _MayuraContext.RegularCollectionsDetails.Where(x => x.RegularCollectionId == id).ToListAsync();
                return View("Payment/collectionreceipt1", data);
            }
            return BadRequest("Oop!, Invalid RegularCollectionId");
        }
        public async Task<IActionResult> PublicServiceSchedule(int id)
        {
            var data = await _ArContext.VprintSchedule.FirstOrDefaultAsync(x => x.HouseId == id);
            string dateFrom = HttpContext.Request.Query["dateFrom"] ;
            string dateTo = HttpContext.Request.Query["dateTo"];
            dateFrom = dateFrom == null ? "" : dateFrom;
            dateTo = dateTo == null ? "" : dateTo;


            if (data != null)
            {
                
                ViewBag.printby = HttpContext.Request.Query["printby"];

                if (dateFrom != "" && dateTo == "")
                {
                    DateTime _dateFrom = DateTime.ParseExact(dateFrom, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    ViewBag.PublicServiceDetail = await _ArContext.VPublicServiceSchedules
                                               .Where(x => (x.HouseId == id && (x.payment_date >= _dateFrom)))
                                               .OrderBy(x => x.payment_date)
                                               .ToListAsync();
                } else if(dateFrom == "" && dateTo != "")
                {
                    DateTime _dateTo = DateTime.ParseExact(dateTo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    ViewBag.PublicServiceDetail = await _ArContext.VPublicServiceSchedules
                                               .Where(x => (x.HouseId == id && (x.payment_date <= _dateTo)))
                                               .OrderBy(x => x.payment_date)
                                               .ToListAsync();
                }
                else if (dateFrom != "" && dateTo != "")
                {
                    DateTime _dateFrom = DateTime.ParseExact(dateFrom, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    DateTime _dateTo = DateTime.ParseExact(dateTo, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    ViewBag.PublicServiceDetail = await _ArContext.VPublicServiceSchedules
                                               .Where(x => (x.HouseId == id && (x.payment_date >= _dateFrom && x.payment_date <= _dateTo)))
                                               .OrderBy(x => x.payment_date)
                                               .ToListAsync();
                }
                else
                {
                    ViewBag.PublicServiceDetail = await _ArContext.VPublicServiceSchedules
                                               .Where(x => x.HouseId == id )
                                               .OrderBy(x => x.payment_date)
                                               .ToListAsync();
                }

                ViewBag.BankSettle = await _MayuraContext.BankSettlement.Where(x => x.ProjectId == data.ProjectId).ToListAsync();


                return View("Schedule/PublicService", data);
            }

            return BadRequest("Oop!, Invalid House Id");
        }

        public async Task<IActionResult> PenaltySchedule(int id)
        {
            var data = await _ArContext.VprintContractsInfo.FirstOrDefaultAsync(x => x.HouseId == id);
            if (data != null)
            {
                // ViewBag.printby = HttpContext.Request.Query["printby"];
                ViewBag.PenaltyDetail = _ArContext.VprintPenaltyDetail.FromSqlRaw("exec dbo.sp_get_penalty_detail {0}", id).AsEnumerable().ToList();
                return View("Schedule/Penalty", data);
            }
            return BadRequest("Oop!, Invalid HouseId");
        }
        public async Task<IActionResult> DailyPaymentTracking(LatePayment data)
        {
            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
            }

            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();               
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                if (data.ProjectId == 0)
                {
                    ViewBag.LatePayment = _ArContext.VprintCustomerDailyPayment.AsEnumerable().ToList();
                }
                else
                {
                    ViewBag.LatePayment = _ArContext.VprintCustomerDailyPayment.Where(x => x.ProjectId == data.ProjectId).AsEnumerable().ToList();
                }
                
                return View("Report/PaymentTracking", data);
            }
            else if (data.Action == 2)
            {

                StringBuilder sb = new StringBuilder();
                var list= new List<VprintCustomerDailyPayment>();
                if(data.ProjectId == 0)
                {
                    list = _ArContext.VprintCustomerDailyPayment.AsEnumerable().ToList();
                }
                else
                {
                     list = _ArContext.VprintCustomerDailyPayment.Where(x => x.ProjectId == data.ProjectId).AsEnumerable().ToList();
                }                
                sb.Clear();
                sb.AppendLine("Project,Contract Id,Project Short,Payment Date,House Type, Street,  House Number, Payment, Customer1, Customer2, Cus_en1,Cus-en2,Phone1, Phone2");

                foreach (var item in list)

                {

                    sb.AppendLine(item.ProjectId + "," + item.ContractId + "," + item.ProjectShort  + "," + item.PaymentDate?.ToString("dd/MM/yyyy") + "," + item.HouseType + "," + item.Street + "," + item.HouseNumber + ",$" + item.Payment + "," + item.CustomerName1 + "," +
                                item.CustomerName2+ "," + item.NameEn + "," + item.NameEn2 + ",#" + item.PhoneContact1 + ",#" + item.PhoneContact2);
                }
                    var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                
                    return File(result, "text/csv", "LatePaymentReport--" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.ProjectId = 0;
                return View("Report/PaymentTracking", data);
            }
            ///here
         

        }
       
        public async Task<IActionResult> InstantSchedule(int id)
        {

            ViewBag.ScheduleDetail = _ArContext.VprintScheduleDetailInstant.FromSqlRaw("exec ar.sp_get_schedule_detail_instant {0}", id).AsNoTracking().ToList();
            var schedule_info = await _ArContext.VPaymentScheduleInstantInfo.Where(x => x.CreatedBy == id).ToListAsync();
            if (schedule_info.Count() == 0) return BadRequest("Oop!, There is no schedule for this house!");
            ViewBag.PaymentScheduleInfo = schedule_info;
            ViewBag.PaymentScheduleInfoMain = await _ArContext.VPaymentScheduleInstantMain.Where(x => x.UserId == id).ToListAsync();
            //ViewBag.ScheduleDetailInterest = _ArContext.VprintScheduleDetail.FromSqlRaw("exec dbo.sp_get_schedule_detail {0},{1},{2}", id, data.ReceiptNo, 1).AsNoTracking().ToList();                
            return View("Schedule/instantSchedule");

            //return BadRequest("Oop!, There is no schedule for this house!");            

        }
        public async Task<IActionResult> ProjectCollectionDailyReport(InputProjectDailyRevenue data)
        {
          
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                        if (HttpContext.Session.GetString("test") == "") {if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}}
                   
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {

                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects
                        .OrderBy(x => x.ProjectCode)
                        .Where(x => x.Status == 1)
                        .ToListAsync();

                
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                if (data.ProjectId == 0)
                {
                    ViewBag.DailyMemo = await _MayuraContext.DailyMemo.Where(x => x.InDate >= data.DateFrom && x.InDate <= data.DateTo).OrderBy(x => x.InDate).ToListAsync();

                }
                else
                {
                    ViewBag.DailyMemo = await _MayuraContext.DailyMemo.Where(x => x.ProjectId == data.ProjectId && x.InDate >= data.DateFrom && x.InDate <= data.DateTo).OrderBy(x => x.InDate).ToListAsync();
                }
                _ArContext.Database.SetCommandTimeout(600);
                string sql = "exec dbo.sp_get_project_revenue_dailly'" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId + "," + data.UserId;
                ViewBag.ProjectRevenueDailyReport = _ArContext.ProjectRevenueDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/ProjectRevenueDailyReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Daily Collection Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                _ArContext.Database.SetCommandTimeout(600);
                string sql = "exec dbo.sp_get_project_revenue_dailly '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId + "," + data.UserId;
                var list = _ArContext.ProjectRevenueDailyReport.FromSqlRaw(sql)
                    .Select(x => new {
                        ProjectID = x.projectId, 
                        ProjectName = x.ProjectName,
                        x.ContractId,
                        CustomerName = x.NameKhmer,
                        HouseType = x.HouseType,
                        HouseNumber = x.HouseNumber,
                        StreetNumber = x.StreetNumber,
                        HouseSize = x.HouseSize,
                        PaidDate = x.PaidDate,
                        TTDate = x.tt_date,
                        ReciepNo = x.ReceiptId,
                        x.PrePrintedNumber,
                        ReferrenceNumber =x.transactionRef,
                        x.PaymentMethod,
                        x.Principle,
                        PrincipleDiscount = x.PaidOffDiscount,
                        x.Interest,
                        x.Penalty,
                        x.Booking,
                        x.PublicService,
                        x.PublicServiceDiscount,
                        x.OtherIncome,
                        OtherCollectionNotIncome=x.other_collect_not_income,
                        x.Total,
                        x.Remark
                    })
                    .AsEnumerable()
                    .ToList();
 
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Daily Collection  Report");
                    csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "CollectionDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects
                                    .Where(x => x.Status == 1)
                                    .OrderBy(x => x.ProjectCode)
                                    .ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                data.UserId = 0;
                return View("Report/ProjectRevenueDailyReport", data);
            }

        }
        public async Task<IActionResult> DailySummaryReport(InputProjectDailyRevenue data)
        {
         
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_daily_summary_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId + "," + data.UserId;
                ViewBag.DailySummaryReport = _ArContext.VDailySummaryReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/DailySummaryReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Daily Summary Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_get_daily_summary_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId + "," + data.UserId;
                var list = _ArContext.VDailySummaryReport.FromSqlRaw(sql).AsEnumerable().ToList();
            
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Daily Summary Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "DailySummaryReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.VDailySummaryReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/DailySummaryReport", data);
            }

        }
        public async Task<IActionResult> BookingDailyReport(InputBookingDailyRevenue data)
        {

          
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_booking_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.BookingDailyReport = _ArContext.BookingDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/BookingDailyReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Daily Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_get_booking_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.BookingDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                
                sb.Clear();
                sb.AppendLine("LY HOUR DEVELOPMENT VIMEANPHNOMPENH,Booking Daily Report,"+ data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));
                sb.AppendLine("Project,Booking ID,House No.,Road No.,House Type,House Size,Customer Name,English Name,Contact Number,Booking Date,Booking Expire Date,House Price,Discount,Net Amount,Booking Amount,Total Booking,Contract ID,Contract Date,Paid status,Type, Staff Name,Remark");
                string status = "";
                foreach (var item in list)
                {
                    if (item.PaidStatus == -1) { status = "Booking not yet received cash"; } else if (item.PaidStatus == 3) { status = "Booking received cash"; }
                    sb.AppendLine(item.ProjectName + "," + item.BookingId + "," + item.HouseNumber + "," + item.StreetNumber + "," + item.HouseType + "," + item.HouseSize + "," + item.NameKh + "," + item.NameEn + "," +
                              item.ContractNumber + "," + item.BookingDate?.ToString("dd/MM/yyyy") + "," + item.BookingExpiredDate?.ToString("dd/MM/yyyy") + "," + item.HousePrice + "," + item.HouseDiscount + "," + item.NetHousePrice + "," + item.BookingAmount + "," + item.TotalBooking + ","+
                              item.ContractId + "," + item.ContractDate?.ToString("dd/MM/yyyy") + "," + status + "," + item.InType + "," + item.SaleName + "," + item.Remark);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "BookingDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                /*
                  var stream = new MemoryStream();
                  using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                  {
                      var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                      csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                  }
                  return File(stream.ToArray(), "text/csv", "BookingDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                    */
            }
            else
            {
                ViewBag.BookingDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/BookingDailyReport", data);
            }

        }

        public async Task<IActionResult> BookingDailyReportExcludeTransfer(InputBookingDailyRevenue data)
        {


                if (HttpContext.Request.Query["printby"].Count != 0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
                }

                ViewBag.printby = HttpContext.Session.GetString("test");
                if (data.Action == 1)
                {
                    ViewBag.ProjectRevenueDailyReport = null;
                    ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                    ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                    string sql = "exec dbo.sp_get_booking_report_exclude_transfer '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                    ViewBag.BookingDailyReport = _ArContext.BookingDailyReportExcludeTransfer.FromSqlRaw(sql).AsEnumerable().ToList();
                    return View("Report/BookingDailyReportExcludeTransfer", data);
                }
                else if (data.Action == 2)
                {
                    var records = new List<Foo>
                    {
                        new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Daily Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                    };
                    StringBuilder sb = new StringBuilder();
                    string sql = "exec dbo.sp_get_booking_report_exclude_transfer '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                    var list = _ArContext.BookingDailyReportExcludeTransfer.FromSqlRaw(sql).AsEnumerable().ToList();

                    sb.Clear();
                    sb.AppendLine("LY HOUR DEVELOPMENT VIMEANPHNOMPENH,Booking Daily Report," + data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));
                    sb.AppendLine("Project,Booking ID,House No.,Road No.,Type,House Size,Customer Name,English Name,Contact Number,Booking Date,Booking Expire Date,House Price,Discount,Net Amount,Booking Amount,Contract ID,Contract Date,Paid status,Remark");
                    string status = "";
                    foreach (var item in list)

                    {
                        if (item.PaidStatus == -1) { status = "Booking not yet received cash"; } else if (item.PaidStatus == 3) { status = "Booking received cash"; }
                        sb.AppendLine(item.ProjectName + "," + item.BookingId + "," + item.HouseNumber + "," + item.StreetNumber + "," + item.HouseType + "," + item.HouseSize + "," + item.NameKh + "," + item.NameEn + "," +
                                  item.ContractNumber + "," + item.BookingDate?.ToString("dd/MM/yyyy") + "," + item.BookingExpiredDate?.ToString("dd/MM/yyyy") + "," + item.HousePrice + "," + item.HouseDiscount + "," + item.NetHousePrice + "," + item.BookingAmount + "," +
                                  item.ContractId + "," + item.ContractDate?.ToString("dd/MM/yyyy") + "," + status + "," + item.Remark);
                    }
                    var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                    return File(result, "text/csv", "BookingDailyReportExcludeTransfer_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                    /*
                      var stream = new MemoryStream();
                      using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                      {
                          var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                        csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                        csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                          csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                      }
                      return File(stream.ToArray(), "text/csv", "BookingDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                        */
                }
                else
                {
                    ViewBag.BookingDailyReport = null;
                    ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                    ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                    data.DateFrom = DateTime.Today;
                    data.DateTo = DateTime.Today;
                    data.ProjectId = 0;
                    return View("Report/BookingDailyReportExcludeTransfer", data);
                }

        }

        public async Task<IActionResult> SaleDailyReport(InputBookingDailyRevenue data)
        {


            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_booking_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.BookingDailyReport = _ArContext.BookingDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/SaleDailyReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Daily Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_get_booking_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.BookingDailyReport.FromSqlRaw(sql).AsEnumerable().ToList();

                sb.Clear();
                sb.AppendLine("LY HOUR DEVELOPMENT VIMEANPHNOMPENH,Booking Daily Report," + data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));
                sb.AppendLine("Project,House No,Type,Booking Date,House Price,Discount,Net Amount,Booking Amoun");
                string status = "";
                foreach (var item in list)

                {
                   
                    sb.AppendLine(item.ProjectName + "," + item.HouseNumber + "," + item.HouseType + "," +item.BookingDate?.ToString("dd/MM/yyyy") + "," +  item.HousePrice + "," + item.HouseDiscount + "," + item.NetHousePrice + "," + item.BookingAmount 
                              );
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "SaleDailyReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                /*
                  var stream = new MemoryStream();
                  using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                  {
                      var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                      csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                  }
                  return File(stream.ToArray(), "text/csv", "BookingDailyReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                    */
            }
            else
            {
                ViewBag.BookingDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/SaleDailyReport", data);
            }

        }
        public async Task<IActionResult> BookingDelayReport(InputBookingDailyRevenue data)
        {

            var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Delay Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
            if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec ar.sp_get_booking_delay_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.BookingDelayReport = _ArContext.VprintBookingDelay.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/BookingDelayReport ", data);
            }
            else if (data.Action == 2)
            {

                StringBuilder sb = new StringBuilder();
                string sql = "exec ar.sp_get_booking_delay_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VprintBookingDelay.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Project,Booking Delay ID,House No.,Road No.,Type,House Size,Customer Name,Created Date,House Price,Booking Amount,Expired Date,Delay Until,Remark");

                foreach (var item in list)

                {

                    sb.AppendLine(item.ProjectName + "," + item.FormId + "," + item.HouseNumber + "," + item.StreetNumber + "," + item.HouseTypeName + "," + item.HouseSize + "," + item.CustomerName + "," +
                               item.CreateDate.ToString("dd/MM/yyyy") + "," + item.HousePrice + "," + item.BookingAmount + "," + item.ExpiredDate.ToString("dd/MM/yyyy") + "," +
                              item.DelayUntil.ToString("dd/MM/yyyy") + "," + item.Reason);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "BookingDelayReport " + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                */
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Booking Delay Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "BookingDelayReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/BookingDelayReport ", data);
            }
        }
        public async Task<IActionResult> BookingCancelReport(InputBookingDailyRevenue data)
        {

          

                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec ar.sp_get_booking_cancel_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.BookingCancelReport = _ArContext.VprintBookingCancel.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/BookingCancelReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Cancel Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec ar.sp_get_booking_cancel_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VprintBookingCancel.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Project,Booking Cancel ID,House No.,Road No.,Type,House Size,Customer Name,House Price,Booking Amount,Cancel Date,Remark");

                foreach (var item in list)

                {

                    sb.AppendLine(item.ProjectName + "," + item.FormId + "," + item.HouseNumber + "," + item.StreetNumber + "," + item.HouseTypeName + "," + item.HouseSize + "," + item.CustomerName + "," +
                                item.HousePrice + "," + item.BookingAmount + "," + item.CancelDate?.ToString("dd/MM/yyyy") + "," +
                               item.Reason);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "BookingCancelReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                */
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Booking Cancel Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "BookingCancelReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingCancelReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/BookingCancelReport", data);
            }
        }
        public async Task<IActionResult> BookingDiscountReport(InputBookingDailyRevenue data)
        {
          
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec ar.sp_get_booking_adhoc_discount_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.AdhocDiscountReport = _ArContext.VprintAdhocDiscount.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/BookingDiscountReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Discount Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec ar.sp_get_booking_adhoc_discount_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VprintAdhocDiscount.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Project,House No.,Road No.,Type,House Size,Customer Name,House Price,Booking Amount,Discount Amount,Contract Date,Discount Date, Remark");

                foreach (var item in list)

                {

                    sb.AppendLine(item.ProjectName + "," + item.HouseNumber + "," + item.StreetNumber + "," + item.HouseTypeName + "," + item.HouseSize + "," + item.CustomerName + "," +
                                item.HousePrice + "," + item.BookingAmount + "," + item.DiscountAmount + "," +
                              item.ContractDate?.ToString("dd/MM/yyyy") + "," + item.DiscountDate.ToString("dd/MM/yyyy") + "," + item.Remark);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "BookingDiscountReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");

                */
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Booking Discount Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "BookingDiscountReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/BookingDiscountReport", data);
            }
        }
        public async Task<IActionResult> BookingChangeHouseReport(InputBookingDailyRevenue data)
        {

           
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {

                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec ar.sp_get_booking_change_house_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.BookingChangeHouseReport = _ArContext.VprintBookingChangeHouse.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/BookingChangeHouseReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Booking Change House Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec ar.sp_get_booking_change_house_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VprintBookingChangeHouse.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Id,From Project,From House No,From Street, From House Type, From House Size,From House Price ,To Project,To House No,To Street,To House Type, To House Size,To House Price,Customer Name,BookingAmount,Change Date, Reason");

                foreach (var item in list)

                {

                    sb.AppendLine(item.FormId + "," + item.ProjectNameFrom + "," + item.HouseNumberFrom + "," + item.StreetNumberFrom + "," + item.HouseTypeFrom + "," + item.HouseSizeFrom + "," + item.HousePriceFrom + "," + item.ProjectNameTo + "," + item.HouseNumberTo + "," + item.StreetNumberTo + "," + item.HouseTypeTo + "," +
                                item.HouseSizeTo + "," + item.HousePriceTo + "," + item.CustomerName + "," + item.BookingAmount + "," +
                              item.ChangeDate?.ToString("dd/MM/yyyy") + "," + item.Reason);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "BookingChangeHouseReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                */
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Booking Change House Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "BookingChangeHouseReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/BookingChangeHouseReport", data);
            }
        }
        public async Task<IActionResult> C2CReport(InputBookingDailyRevenue data)
        {
         
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_c2c_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.C2CReport = _ArContext.VprintC2cReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/ContractC2CReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="C2C Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_get_c2c_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VprintC2cReport.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Project,C2CDate,Contract Id,House No.,Type,House Price, Total Paid, Total Remain, Old Customer1, Old Customer2, New Customer1, New Customer2");

                foreach (var item in list)

                {

                    sb.AppendLine(item.Project + "," + item.C2cDate.ToString("dd/MM/yyyy") + "," + item.ContractId + "," + item.HouseNumber + "," +  item.HouseType + "," +  item.PriceContract + "," +
                                item.TotalPaid + "," + item.TotalRemain + "," + item.OldCustomerName1 + "," +
                              item.OldCustomerName2 + "," + item.NewCustomerName1+ "," + item.NewCustomerName2);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "ContractC2CReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                */
                var stream = new MemoryStream();
                
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();
                    csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "ContractC2CReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/ContractC2CReport", data);
            }
        }
        public async Task<IActionResult> AccumulateReport(AccumulateReport data)
        {
           
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_accumulate_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "'," + data.ProjectId;

                _ArContext.Database.SetCommandTimeout(1200);
                ViewBag.AccumulateReport = _ArContext.VprintAccumulateReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/AccumulateReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Accumulate Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                
            _ArContext.Database.SetCommandTimeout(1200);
                string sql = "exec dbo.sp_get_accumulate_report '" + data.DateFrom.ToString("MM/dd/yyyy")  + "'," + data.ProjectId;
                var list = _ArContext.VprintAccumulateReport.FromSqlRaw(sql).AsEnumerable().ToList();
                
                //sb.Clear();
                //sb.AppendLine("LY HOUR DEVELOPMENT VIMEANPHNOMPENH,Accumulate Report," + data.DateFrom.ToString("MM/dd/yyyy") );
                

                //foreach (var item in list)

                //{

                //    sb.AppendLine(item.Project + "," + item.HouseNumber+ "," + item.StreetNumber + "," + item.HouseSize + "," + item.HouseType + "," + item.CustomerName + "," + item.NameEn + "," +
                //                item.ContractNumber + "," + item.ContractDate?.ToString("dd/MMM/yyyy") + "," + item.NetAmount + "," +
                //              item.AccPrinciple + "," + item.AccPaidOffDiscount + "," + item.AccInterest + "," + item.AccPenalty  + "," + item.AccPublicService + "," + item.PhoneNumber + "," + item.Remark);
                //}
                //var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                //return File(result, "text/csv", "AccumulateReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                    csv.WriteField("Accumulate Report");
                    csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "AccumulateReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/AccumulateReport", data);
            }
        }
        public async Task<IActionResult> FinalRequestReport(InputBookingDailyRevenue data)
        {
         
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_final_payment_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.FinalPayment = _ArContext.VFinalPaymentReport.FromSqlRaw(sql)
                    .AsEnumerable()
                    .OrderBy(x => x.FinalPaymentDate)
                    .ToList();
                return View("Report/FinalRequestReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Final Request Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_get_final_payment_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VFinalPaymentReport.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Final Payment Id,Contract Id, Project ,House No.,Street,Type,Customer Name, Contract Date,Net Sale, Final Amount, Paid Off Discount, Total Principle Amount, Final Payment Date, Remarks");

                foreach (var item in list)

                {

                    sb.AppendLine(item.FinalpaymentId + "," + item.ContractId + "," + item.ProjectShort + "," + item.HouseNumber + "," + item.StreetNumber + "," + item.HouseType + "," +
                                item.NameKh + "," + item.ContractDate?.ToString("dd/MM/yyyy") + "," + item.NetSale + "," +
                              item.FinalAmount + "," + item.PaidOffDiscount + "," + item.TotalPrincipleAmount + "," + item.FinalPaymentDate?.ToString("dd/MM/yyyy") + "," + item.Remarks);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "FinalRequestReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                */
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Final Request Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "FinalRequestReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/FinalRequestReport", data);
            }
        }
        public async Task<IActionResult> WaivePenaltyReport (InputBookingDailyRevenue data)
        {
           
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_waive_penalty_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.WaivePenaltyReport = _ArContext.VWaivePenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/WaivePenaltyReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Waive Penalty Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_waive_penalty_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VWaivePenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();
     
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Waive Penalty Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "WaivePenaltyReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/WaivePenaltyReport", data);
            }
        }
        public async Task<IActionResult> WaivePublicServiceReport(InputBookingDailyRevenue data)
        {
         
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_waive_public_service_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.WaivePublicServiceReport = _ArContext.VWaivePublicServiceReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/WaivePublicServiceReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Waive Public Service Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_waive_public_service_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VWaivePublicServiceReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Waive Public Service Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "WaivePublicServiceReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/WaivePublicServiceReport", data);
            }
        }
        public async Task<IActionResult> WaiveInterestReport(InputBookingDailyRevenue data)
        {


                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_waive_interest_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.WaiveInterestReport = _ArContext.VWaiveInterestReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/WaiveInterestReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Waive Interest Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.sp_waive_interest_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VWaiveInterestReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Waive Interest Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "WaiveInterestReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.WaiveInterestReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/WaiveInterestReport", data);
            }
        }
        public async Task<IActionResult> PenaltyReport(AccumulateReport data)
        {
          
                if (HttpContext.Request.Query["printby"].Count!=0)
                {

                    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
                }
                else
                {
                    if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
                }
            
            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).OrderBy(x => x.ProjectCode).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.get_penalty_report'" + data.DateFrom.ToString("MM/dd/yyyy")  + "'," + data.ProjectId;
                ViewBag.Penalty = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/PenaltyReport", data);
            }
            else if (data.Action == 2)
            {

                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.get_penalty_report'" + data.DateFrom.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();
                /*
                sb.Clear();
                sb.AppendLine("Contract Id, Project ,House Type.,Street,House No, Customer Name, Phone,Total Payment, Late days, Penalty Payment, Penalty Paid");

                foreach (var item in list)

                {

                    sb.AppendLine(item.Contractid + "," + item.ProjectShort  + "," + item.HouseType + "," + item.StreetNumber + "," + item.HouseNumber  + "," + item.CustomerName + "," +
                                item.PhoneNumber + ",$" + item.TotalPayment + "," + item.LateDays + "," + item.PenaltyPayment + "," + item.PenaltyPaid );
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "PenaltyReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                */


                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Penalty Report" , Date= data.DateFrom.ToString("MM/dd/yyyy") }
                };
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                   
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Penalty Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PenaltyReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).OrderBy(x => x.ProjectCode).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today ;
                data.ProjectId = 0;
                return View("Report/PenaltyReport", data);
            }
        }
        public async Task<IActionResult> OwnerShipRemoveReport(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.get_ownership_removal_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.OwnerShipRemovalReport = _ArContext.VOwnershipRemoveReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/OwnerShipRemovalReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Ownership Remove Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.get_ownership_removal_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VOwnershipRemoveReport.FromSqlRaw(sql).AsEnumerable().ToList();
           
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Ownership Remove Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "OwnerShipRemovalReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/OwnerShipRemovalReport", data);
            }
        }
        public async Task<IActionResult> OwnerShipAddReport(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.get_ownership_add_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.OwnerShipRemovalReport = _ArContext.VOwnershipAddReport.FromSqlRaw(sql).AsNoTracking().AsEnumerable().ToList();
                return View("Report/OwnerShipAddReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Ownership add Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.get_ownership_add_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VOwnershipAddReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);

                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Ownership Add Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "OwnerShipAddReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/OwnerShipAddReport", data);
            }
        }
        public async Task<IActionResult> OwnerShipTransferReport(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.get_ownership_transfer_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.OwnerShipRemovalReport = _ArContext.VOwnershipReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/OwnerShipTransferReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Ownership Transfer Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.get_ownership_transfer_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VOwnershipReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Ownership Transfer Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "OwnerShipTransferReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/OwnerShipTransferReport", data);
            }
        }
        public async Task<IActionResult> ContractTerminationReport(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.get_contract_termination_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                ViewBag.ContractTerminationReport = _ArContext.VContractTerminationReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/ContractTerminationReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Ownership Transfer Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.get_contract_termination_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VContractTerminationReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField("Contract Termination Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "ContractTerminationReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/ContractTerminationReport", data);
            }
        }
        public async Task<IActionResult> HousesStockReport()
        {
            ViewBag.Title = "House Sammary Report";
            string printBy = HttpContext.Request?.Query["printby"] ?? "";
            if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);

            ViewBag.printby = HttpContext.Session.GetString("printby");
            var dateFrom = HttpContext.Request.Query["dateFrom"];
            var projectId = HttpContext.Request.Query["projectId"];
            var houseType = HttpContext.Request.Query["houseType"];
            var export = HttpContext.Request.Query["export"];
            ViewBag.dateFrom = dateFrom;
            ViewBag.projectId = projectId;
            ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();

            string sql = "exec dbo.get_houses_stock_report  '" + dateFrom + "'," + projectId + "," + houseType;
            
            if (export == "1")
            {
                var list = _ArContext.VHousesStockReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return writeToCsv("HousesStockReport", ViewBag.Title, list, dateFrom);
            }

            ViewBag.HousesStockReport = _ArContext.VHousesStockReport.FromSqlRaw(sql).AsEnumerable().ToList();
            return View("Report/HousesStockReport");
        }
        public async Task<IActionResult> HouseSummaryReport()
        {
            ViewBag.Title = "House Sammary Report";
            string printBy = HttpContext.Request?.Query["printby"] ?? "";
            if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);


            ViewBag.printby = HttpContext.Session.GetString("printby");
            var dateFrom = HttpContext.Request.Query["dateFrom"];
            var dateTo = HttpContext.Request.Query["dateTo"];
            var projectId = HttpContext.Request.Query["projectId"];
            var houseType = HttpContext.Request.Query["houseType"];
            var export = HttpContext.Request.Query["export"];
            ViewBag.dateFrom = dateFrom;
            ViewBag.dateTo = dateTo;
            ViewBag.projectId = projectId;

            ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
            string sql = "exec dbo.get_house_sale_summary  '" + dateFrom + "','" + dateTo + "'," + projectId + "," + houseType;

           
            if (export == "1")
            {
                var list = _ArContext.VHouseSummaryReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return writeToCsv("HouseSammaryReport", "House Sammary Report", list, dateFrom, dateTo);
            }

            ViewBag.HouseSummaryReport = _ArContext.VHouseSummaryReport.FromSqlRaw(sql).AsEnumerable().ToList();
            return View("Report/HouseSammaryReport");
        }
        public async Task<IActionResult> MonthlyCollection(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec dbo.sp_get_collection_by_house_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                //  ViewBag.MonthlyCollection = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();

               
                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_get_collection_by_house_report";
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);
                ViewBag.MonthlyCollection = dataset;
                return View("Report/MonthlyCollectionReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Monthly Collection Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                 var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_get_collection_by_house_report";
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);
              
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Monthly Collection Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();
                   // csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);*/
                    foreach (DataColumn column in dataset.Columns)
                    {
                        csv.WriteField(column.ColumnName);
                    }
                    csv.NextRecord();

                    // Write row values
                    foreach (DataRow row in dataset.Rows)
                    {
                        for (var i = 0; i < dataset.Columns.Count; i++)
                        {
                            csv.WriteField(row[i]);
                        }
                        csv.NextRecord();
                    }
                }
                return File(stream.ToArray(), "text/csv", "MonthlyCollection" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today.AddMonths(-1);

                data.DateTo = DateTime.Today;
                data.ProjectId = 1;
                return View("Report/MonthlyCollectionReport", data);
            }
        }
        public async Task<IActionResult> PeriodCollection(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                //string sql = "exec dbo.sp_get_collection_period_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + (data?.ProjectId ?? 0);
                //  ViewBag.MonthlyCollection = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();


                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_get_collection_period_report";
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);
                ViewBag.MonthlyCollection = dataset;
                return View("Report/PeriodCollection", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Period Collection Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_get_collection_period_report";
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Period Collection Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();
                    // csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);*/
                    foreach (DataColumn column in dataset.Columns)
                    {
                        csv.WriteField(column.ColumnName);
                    }
                    csv.NextRecord();

                    // Write row values
                    foreach (DataRow row in dataset.Rows)
                    {
                        for (var i = 0; i < dataset.Columns.Count; i++)
                        {
                            csv.WriteField(row[i]);
                        }
                        csv.NextRecord();
                    }
                }
                return File(stream.ToArray(), "text/csv", "PeriodCollectionReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today.AddMonths(-1);

                data.DateTo = DateTime.Today;
                data.ProjectId = 1;
                return View("Report/PeriodCollection", data);
            }
        }
        public async Task<IActionResult> SaleExecutiveReport(InputBookingDailyRevenue data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
               // string sql = "exec dbo.sale_executive_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                //  ViewBag.MonthlyCollection = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();


                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sale_executive_report";
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);
                ViewBag.MonthlyCollection = dataset;
                return View("Report/SaleExecutiveReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Period Collection Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sale_executive_report";
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField("Period Collection Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord();
                    // csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);*/
                    foreach (DataColumn column in dataset.Columns)
                    {
                        csv.WriteField(column.ColumnName);
                    }
                    csv.NextRecord();

                    // Write row values
                    foreach (DataRow row in dataset.Rows)
                    {
                        for (var i = 0; i < dataset.Columns.Count; i++)
                        {
                            csv.WriteField(row[i]);
                        }
                        csv.NextRecord();
                    }
                }
                return File(stream.ToArray(), "text/csv", "SaleExecutiveReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today.AddMonths(-1);

                data.DateTo = DateTime.Today;
                data.ProjectId = 1;
                return View("Report/SaleExecutiveReport", data);
            }
        }


        public async Task<IActionResult> SaleQuarterBookingReport(InputBookingDailyRevenue data)
        {

           
            if (data.Action == 1)
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
               // string sql = "exec dbo.sale_executive_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                //  ViewBag.MonthlyCollection = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();


                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "report.sale_quarter_booking_report";
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);

                if(dataset.Columns.Contains("project_id")) dataset.Columns.Remove("project_id");
                if (dataset.Columns.Contains("house_type_name")) dataset.Columns.Remove("house_type_name");
                ViewBag.MonthlyCollection = dataset;
                return View("Report/SaleQuarterBookingReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="By House Type Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "report.sale_quarter_booking_report";
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);
                if (dataset.Columns.Contains("project_id"))  dataset.Columns.Remove("project_id");
                if (dataset.Columns.Contains("house_type_name")) dataset.Columns.Remove("house_type_name");

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField("Period Collection Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord();
                    // csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);*/
                    foreach (DataColumn column in dataset.Columns)
                    {
                        csv.WriteField(column.ColumnName);
                    }
                    csv.NextRecord();

                    // Write row values
                    foreach (DataRow row in dataset.Rows)
                    {
                        for (var i = 0; i < dataset.Columns.Count; i++)
                        {
                            csv.WriteField(row[i]);
                        }
                        csv.NextRecord();
                    }
                }
                return File(stream.ToArray(), "text/csv", "SaleQuarterReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today.AddMonths(-1);

                data.DateTo = DateTime.Today;
                data.ProjectId = 1;
                return View("Report/SaleQuarterBookingReport", data);
            }
        }


        public async Task<IActionResult> CustomerWalkInReport(InputBookingDailyRevenue data)
        {


            if (data.Action == 1)
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.VCustomerWalkInProject.ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                // string sql = "exec dbo.sale_executive_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                //  ViewBag.MonthlyCollection = _ArContext.VPenaltyReport.FromSqlRaw(sql).AsEnumerable().ToList();


                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "report.sp_customer_walk_in_report";
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);

                if (dataset.Columns.Contains("project_id")) dataset.Columns.Remove("project_id");
                //if (dataset.Columns.Contains("house_type_name")) dataset.Columns.Remove("house_type_name");
                ViewBag.MonthlyCollection = dataset;
                return View("Report/CustomerWalkInReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Period Collection Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                var con = new SqlConnection();
                con.ConnectionString = connectionString;
                var com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "report.sp_customer_walk_in_report";
                com.Parameters.Add(new SqlParameter("@date_from", data.DateFrom.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@date_to", data.DateTo.ToString("MM/dd/yyyy")));
                com.Parameters.Add(new SqlParameter("@project_id", data.ProjectId));
                var adapt = new SqlDataAdapter();
                adapt.SelectCommand = com;
                DataTable dataset = new DataTable();
                con.Open();
                adapt.Fill(dataset);
                if (dataset.Columns.Contains("project_id")) dataset.Columns.Remove("project_id");
                //if (dataset.Columns.Contains("house_type_name")) dataset.Columns.Remove("house_type_name");

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField("Customer Walk-In Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord();
                    // csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("C2C Report");csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy"));csv.NextRecord();csv.WriteRecords(list);*/
                    foreach (DataColumn column in dataset.Columns)
                    {
                        csv.WriteField(column.ColumnName);
                    }
                    csv.NextRecord();

                    // Write row values
                    foreach (DataRow row in dataset.Rows)
                    {
                        for (var i = 0; i < dataset.Columns.Count; i++)
                        {
                            csv.WriteField(row[i]);
                        }
                        csv.NextRecord();
                    }
                }
                return File(stream.ToArray(), "text/csv", "CustomerWalkInReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.PeriodCollection = null;
                ViewBag.Projects = await _MayuraContext.VCustomerWalkInProject.ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today.AddMonths(-1);

                data.DateTo = DateTime.Today;
                data.ProjectId = 1;
                return View("Report/CustomerWalkInReport", data);
            }
        }

        public async Task<IActionResult> PhoneTracking()
        {

            if (HttpContext.Request.Query["printby"].Count!=0)
            {
                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") {HttpContext.Session.SetString("test", "Unknown(Click report from the system again)");}
            }
            
            ViewBag.printby = HttpContext.Session.GetString("test");
            var dateFrom = HttpContext.Request.Query["dateFrom"];
            var dateTo = HttpContext.Request.Query["dateTo"];
            var projectId = HttpContext.Request.Query["projectId"];
            var houseId = HttpContext.Request.Query["houseId"];
            var purpose = HttpContext.Request.Query["purpose"];
            var export = HttpContext.Request.Query["export"];
            var option = HttpContext.Request.Query["option"];
            var userId = HttpContext.Request.Query["userId"];


            var criteria = dateFrom + "','" + dateTo + "'," + projectId + "," + houseId + ",'" + purpose + "','" + option + "',"+ userId;
            ViewBag.dateFrom = Convert.ToDateTime(dateFrom).ToString("dd-MMM-yyyy");
            ViewBag.dateTo = Convert.ToDateTime(dateTo).ToString("dd-MMM-yyyy");
            ViewBag.projectId = projectId;
            ViewBag.projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();

            if (export == "1")
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="Phone Tracking Report" , Date= dateFrom +"=>"+ dateTo}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec dbo.get_phone_tracking_report '" + criteria;
                var list = await _ArContext.VPhoneTracking.FromSqlRaw(sql).ToListAsync();
                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");csv.WriteField("Phone Tracking Report");
                    csv.WriteField(dateFrom + "=>" + dateTo);
                    csv.NextRecord();csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PhoneTrackingReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                
                string sql = "exec dbo.get_phone_tracking_report '" + criteria;
                ViewBag.PhoneTracking = await _ArContext.VPhoneTracking.FromSqlRaw(sql).ToListAsync();                
                return View("Report/PhoneTrackingReport");
            }
        }

        public async Task<IActionResult> OtherCollection1(int id)
        {
            if (HttpContext.Request.Query["printby"].Count != 0)
            {
                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }
            ViewBag.printby = HttpContext.Session.GetString("test");
            var data = _ArContext.VprintOtherCollection.FromSqlRaw("exec dbo.get_other_collection_receipt {0}", id).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                //ViewBag.CollectionDetail = await _MayuraContext.RegularCollectionsDetails.Where(x => x.RegularCollectionId == id).ToListAsync();
                return View("Payment/OtherCollectionReceipt", data);
            }
            return BadRequest("Oop!, Invalid RegularCollectionId");
        }
        public async Task<IActionResult> OtherCollection(int id)
        {
            var data = _ArContext.VprintBookingCollection1.FromSqlRaw("exec dbo.get_other_collection_receipt1 {0}", id).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                //ViewBag.CollectionDetail = await _MayuraContext.RegarCollectionsDetails.Where(x => x.RegularCollectionId == id).ToListAsync();
                return View("Payment/OtherCollectionReceipt1", data);
            }
            return BadRequest("Oop!, Invalid RegularCollectionId");
        }
        public async Task<IActionResult> BookingReceipt(int id)
        {
            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");
            var data =  await _ArContext.VprintBookingCollectionNewReceipt.FirstOrDefaultAsync(x => x.Id == id);
            if (data == null)
            {

                return BadRequest("Oop!, Invalid RegularCollectionId");
            }

            return View("Payment/BookingReceipt", data);

        
        }

        public async Task<IActionResult> BookingReceipt1(int id)
        {
            var data = _ArContext.VprintBookingCollection1.FromSqlRaw("exec dbo.get_booking_receipt1 {0}", id).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                //ViewBag.CollectionDetail = await _MayuraContext.RegularCollectionsDetails.Where(x => x.RegularCollectionId == id).ToListAsync();
                return View("Payment/BookingReceipt1", data);
            }
            return BadRequest("Oop!, Invalid RegularCollectionId");
        }
        public async Task<IActionResult> CollectionReceipt(int id)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");
            
            var data = await _ArContext.VprintContractCollection.FirstOrDefaultAsync(x => x.Id == id);
            if (data != null)
            {
                ViewBag.HousePaid = null;
                ViewBag.PenaltyPaid = null;
                ViewBag.PublicServicePaid = null;
                ViewBag.FinalPaid = null;
                ViewBag.FirstExtraPrinciple = null;
                ViewBag.ExtraPrinciple = null;
                ViewBag.Interest = null;

                var collection_details = _MayuraContext.RegularCollectionDetailSummary.FromSqlRaw("exec dbo.get_regular_collection_detail {0}", id).AsEnumerable().ToList();
                if (collection_details != null)
                {
                    foreach (var detail in collection_details)
                    {
                        switch (detail.TransactionType)
                        {
                            case 1:
                                ViewBag.HousePaid = _MayuraContext.HousePaids.FromSqlRaw("exec dbo.sp_get_house_paid {0}", id).AsEnumerable().ToList();
                                break;  
                            case 2:
                                ViewBag.PenaltyPaid = _MayuraContext.PenaltyPaid.FromSqlRaw("exec dbo.sp_get_penalty_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break; 
                            case 3:
                                ViewBag.PublicServicePaid = _MayuraContext.PublicServicePaid.FromSqlRaw("exec dbo.sp_get_public_service_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break;
                            case 13:
                                ViewBag.FinalPaid = _MayuraContext.FinalPaid.FromSqlRaw("exec dbo.sp_get_final_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break; 
                            case 7:
                                ViewBag.FirstExtraPrinciple = detail.Payment;
                                break;
                            case 8: 
                                ViewBag.Interest = detail.Payment;
                                break;
                            case 9: 
                                ViewBag.ExtraPrinciple = detail.Payment;
                                break;
                        }
                    }
                }

                ViewBag.CollectionDetail = await _MayuraContext.RegularCollectionsDetails.Where(x => x.RegularCollectionId == id).ToListAsync();
                
                return View("Payment/collectionreceipt", data);
            }
            return BadRequest("Oop!, Invalid RegularCollectionId");
        }

        public async Task<IActionResult> CollectionReceiptAdjustment(int id)
        {

            var collection = await _MayuraContext.RegularCollections.FirstOrDefaultAsync(x => x.ParentId == id && x.TotalAmount > 0);
            if (collection == null) return BadRequest("Oop!, There is no adjustment for this collection!");
            id = collection.Id;

            var data = await _ArContext.VprintContractCollection.FirstOrDefaultAsync(x => x.Id == id);
            if (data != null)
            {
                ViewBag.HousePaid = null;
                ViewBag.PenaltyPaid = null;
                ViewBag.PublicServicePaid = null;
                ViewBag.FinalPaid = null;
                ViewBag.FirstExtraPrinciple = null;
                ViewBag.ExtraPrinciple = null;
                ViewBag.Interest = null;

                var collection_details = _MayuraContext.RegularCollectionDetailSummary.FromSqlRaw("exec dbo.get_regular_collection_detail {0}", id).AsEnumerable().ToList();
                if (collection_details != null)
                {
                    foreach (var detail in collection_details)
                    {
                        switch (detail.TransactionType)
                        {
                            case 1:
                                ViewBag.HousePaid = _MayuraContext.HousePaids.FromSqlRaw("exec dbo.sp_get_house_paid {0}", id).AsEnumerable().ToList();
                                break;  //house payment
                            case 2:
                                ViewBag.PenaltyPaid = _MayuraContext.PenaltyPaid.FromSqlRaw("exec dbo.sp_get_penalty_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break; //penalty
                            case 3:
                                ViewBag.PublicServicePaid = _MayuraContext.PublicServicePaid.FromSqlRaw("exec dbo.sp_get_public_service_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break;
                            case 13:
                                ViewBag.FinalPaid = _MayuraContext.FinalPaid.FromSqlRaw("exec dbo.sp_get_final_paid {0}", id).AsEnumerable().FirstOrDefault();
                                break; //final payment
                            case 7:
                                ViewBag.FirstExtraPrinciple = detail.Payment;
                                break;
                            case 8: //interest
                                ViewBag.Interest = detail.Payment;
                                break;
                            case 9: //extra principle
                                ViewBag.ExtraPrinciple = detail.Payment;
                                break;
                        }
                    }
                }

                ViewBag.CollectionDetail = await _MayuraContext.RegularCollectionsDetails.Where(x => x.RegularCollectionId == id).ToListAsync();
                return View("Payment/collectionreceiptadjustment", data);
            }
            return BadRequest("Oop!, Invalid RegularCollectionId");
        }

        public async Task<IActionResult> ContractAgreement(int id)
        {
            ViewBag.effective_dates_change_leader = new DateTime(2018, 05, 09);
            ViewBag.new_effective_dates_change_leader = new DateTime(2018,06,19);

            var data = _MayuraContext.ContractAgreement.FromSqlRaw("exec dbo.get_contract_agreement {0}", id).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                return View("Contract/Agreement", data);
            }
            return BadRequest("Oop!, Invalid ContractId");
        }
        public async Task<IActionResult> WaivePenalty(int id)
        {

            var data = await _ArContext.VprintWaivePenalty.Where(x => x.WaiveId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                return View("Payment/WaivePenalty", data);
            }
            return BadRequest("Oop!, Invalid WaiveId");
        }
        public async Task<IActionResult> WaivePenalty1(int id)
        {

            var data = await _ArContext.VprintWaivePenalty.Where(x => x.PenaltyPaymentId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                   return View("Payment/WaivePenalty", data);
            }
            return BadRequest("Oop!, Invalid WaiveId");
        }

        public async Task<IActionResult> WaivePublicService(int id)
        {

            var dataDT = await _ArContext.VPrintWaivePublicService.Where(x => x.WaiveId == id)
                                        .OrderBy(x => x.PaymentDate)
                                        .FirstOrDefaultAsync();

            var data = await _ArContext.VPrintWaivePublicService.Where(x => x.WaiveId == id)
                                        .OrderByDescending(x => x.PaymentDate)
                                        .FirstOrDefaultAsync();

            if (data != null)
            {
                ViewBag.dataDT = dataDT;
                return View("Payment/WaivePublicService", data);
            }

            return BadRequest("Oop!, Invalid WaiveId");
        }

        public IActionResult WaiveFinalInterest(int id)
        {
            string sql = "exec ar.waive_final_interest " + id;
            var data = _ArContext.VPrintWaiveFinalInterest.FromSqlRaw(sql).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                return View("Payment/WaiveFinalInterest", data);
            }

            return BadRequest("Oop!, Invalid WaiveId");
        }

        public IActionResult WaiveRescheduleInterest(int id)
        {
            string sql = "exec ar.waive_reschedule_interest " + id;
            var data = _ArContext.VPrintWaiveFinalInterest.FromSqlRaw(sql).AsEnumerable().FirstOrDefault();
            if (data != null)
            {
                return View("Payment/WaiveRescheduleInterest", data);
            }

            return BadRequest("Oop!, Invalid WaiveId");
        }

        public async Task<IActionResult> LastPaymentReport(LastPaymentReportFilter data)
        {
            ViewBag.Projects = await _MayuraContext.Projects
                .Where(x => x.Status == 1)
                .OrderBy(x => x.ProjectCode)
                .ToListAsync();
           
            List<LastPaymentReport> dataLastPayments = new List<LastPaymentReport>();

            string sql = "exec report.last_payment_report "+ data.ProjectId +",'"+ data.DateFrom.ToString("yyyy-MM-dd") + "'" ;

            if (data.Action == 2) { 
                dataLastPayments = _ArContext.LastPaymentReport.FromSqlRaw(sql).AsEnumerable().ToList();
                //ViewBag.DataLastPayments = dataLastPayments;

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                    csv.WriteField("Last Payment Report");
                    csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(dataLastPayments);
                }
                return File(stream.ToArray(), "text/csv", "LastPayment" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            } else if(data.Action == 1) {

                dataLastPayments = _ArContext.LastPaymentReport.FromSqlRaw(sql).AsEnumerable().ToList();
                ViewBag.DataLastPayments = dataLastPayments;
                return View("Report/LastPaymentReport", data);
            }


            data.DateFrom = DateTime.Today;
            data.ProjectId = 0;
            ViewBag.DataLastPayments = dataLastPayments;
            return View("Report/LastPaymentReport", data);
        }

        public async Task<IActionResult> ConfirmPublicServicePaidYearly(LastPaymentReportFilter data)
        {

            ViewBag.Projects = await _MayuraContext.Projects
                .Where(x => x.Status == 1)
                .OrderBy(x => x.ProjectCode)
                .ToListAsync();

            List<ConfirmPublicServicePaidYearly> publicServicePaidYearly = new List<ConfirmPublicServicePaidYearly>();

            string sql = "exec report.get_confirm_public_service_paid_yearly " + data.ProjectId + ",'" + data.DateFrom.ToString("yyyy-MM-dd") + "'";

            if (data.Action == 2)
            {
                publicServicePaidYearly = _ArContext.ConfirmPublicServicePaidYearly.FromSqlRaw(sql).AsEnumerable().ToList();
                //ViewBag.publicServicePaidYearly = publicServicePaidYearly;

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                    csv.WriteField("Confirm Public Service Paid Yearly");
                    csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(publicServicePaidYearly);
                }
                return File(stream.ToArray(), "text/csv", "confirm_public_service_paid_yearly" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else if (data.Action == 1)
            {
                publicServicePaidYearly = _ArContext.ConfirmPublicServicePaidYearly.FromSqlRaw(sql).AsEnumerable().ToList();
                ViewBag.publicServicePaidYearly = publicServicePaidYearly;
                return View("Report/ConfirmPublicServicePaidYearly", data);
            }


            data.DateFrom = DateTime.Today;
            data.ProjectId = 0;
            ViewBag.publicServicePaidYearly = publicServicePaidYearly;
            return View("Report/ConfirmPublicServicePaidYearly", data);
        }

        DateTime LastDayOfMonth(DateTime dt)
        {
            DateTime ss = new DateTime(dt.Year, dt.Month, 1);
            return ss.AddMonths(1).AddDays(-1);
        }

        DateTime FirstDayOfMonth(DateTime dt)
        {
            DateTime ss = new DateTime(dt.Year, dt.Month, 1);
            return ss;
        }

        public async Task<IActionResult> RevenueMonthlyCollectionReport(RevenueMonthlyInput data)
        {
            ViewBag.Title = "Monthly Collection Report";
            string printBy = HttpContext.Request?.Query["printby"] ?? "";
            if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);

            ViewBag.printby = HttpContext.Session.GetString("printby");
            ViewBag.RevenueMonthlyReport = new List<RevenueMonthlyCollectionReprot>();
            ViewBag.MonthlyCollectionSummuryByMethod = new List<MonthlyCollectionSummuryByMethod>();
            ViewBag.MonthlyCollectionSummuryByProject = new List<MonthlyCollectionSummuryByProject>();           

            if (data.Action == 1)
            {

                ViewBag.Projects = await _MayuraContext.Projects
                        .OrderBy(x => x.ProjectCode)
                        .Where(x => x.Status == 1)
                        .ToListAsync();                                
                    
                _ArContext.Database.SetCommandTimeout(600);

                DateTime dt_from = DateTime.Parse(data.DateFrom.ToString("MM/01/yyyy"));
                DateTime dt_to = DateTime.Parse(data.DateFrom.AddMonths(1).ToString("MM/01/yyyy"));

                string sql = "exec report.revenue_monthly_collection " + data.ProjectId + ",'" + data.DateFrom.ToString("MM/dd/yyyy") + "','"+ data.Ownership  + "'";
                ViewBag.RevenueMonthlyReport = _ArContext.RevenueMonthlyCollectionReprot.FromSqlRaw(sql).AsEnumerable().ToList();
               

                if (data.ProjectId == 0) ViewBag.SummayCollectionReportRemark = _MayuraContext.VSummaryCollectionReportRemark.AsNoTracking().Where(x => x.InDate >= dt_from && x.InDate < dt_to).ToList();
                else ViewBag.SummayCollectionReportRemark = _MayuraContext.VSummaryCollectionReportRemark.AsNoTracking().Where(x => x.ProjectId == data.ProjectId && x.InDate >= dt_from && x.InDate < dt_to).ToList();
                //sql = "exec report.monthly_collection_summury_by_method " + data.ProjectId + ",'" + data.DateFrom.ToString("MM/dd/yyyy") + "','"+ data.Ownership + "'";
                //ViewBag.MonthlyCollectionSummuryByMethod = _ArContext.MonthlyCollectionSummuryByMethod.FromSqlRaw(sql).AsEnumerable().ToList();
                //if(data.ProjectId == 0 && (data.Ownership=="" || data.Ownership == null)) { 
                //    sql = "exec report.monthly_collection_summury_by_project '" + data.DateFrom.ToString("MM/dd/yyyy") + "'";
                //    ViewBag.MonthlyCollectionSummuryByProject = _ArContext.MonthlyCollectionSummuryByProject.FromSqlRaw(sql).AsEnumerable().ToList();
                //}

                return View("Report/RevenueMonthlyCollectionReport", data);
            } else if(data.Action == 2)
            {
                //StringBuilder sb = new StringBuilder();
                _ArContext.Database.SetCommandTimeout(600);
                string sql = "exec report.revenue_monthly_collection " + data.ProjectId + ",'" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.Ownership + "'";
                var list = _ArContext.RevenueMonthlyCollectionReprot.FromSqlRaw(sql)
                    .AsEnumerable()
                    .ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); 
                    csv.WriteField("Monthly Collection Report");
                    csv.WriteField("01 " + "=>" + LastDayOfMonth(data.DateFrom).ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "RevenueMonthlyCollectionReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                
                ViewBag.Projects = await _MayuraContext.Projects
                                    .Where(x => x.Status == 1)
                                    .OrderBy(x => x.ProjectCode)
                                    .ToListAsync();
                data.DateFrom = DateTime.Today;
                data.ProjectId = 0;
                data.Ownership = "";
                
                return View("Report/RevenueMonthlyCollectionReport", data);
            }

        }

        //Summary sale and collection report
        public async Task<IActionResult> SummarySaleAndCollectionReport(SummarySaleAndCollectionInput data)
        {

                int user_id = 0;
                string remote_ip = HttpContext.Connection.RemoteIpAddress?.ToString();
                var sessionlog = await _MayuraContext.SessionsLog.Where(x => x.RemoteIp == remote_ip && x.Status == 1).OrderByDescending(x => x.CreatedAt).FirstOrDefaultAsync();
                if (sessionlog != null)
                {
                    user_id = sessionlog.CreatedBy ?? 0;
                }

                ViewBag.Title = "Summary Sale and Collection";
                string printBy = HttpContext.Request?.Query["printby"] ?? "";
                if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);

          
                ViewBag.printby = HttpContext.Session.GetString("printby");
                var summaySaleAndCollectionReport = new List<SummaySaleAndCollectionReport>();
                ViewBag.Projects = _MayuraContext.Projects
                                       .Where(x => x.Status == 1)
                                       .OrderBy(x => x.ProjectCode)
                                       .ToList();

               // var permission = _MayuraContext.Users.SingleOrDefaultAsync(x=>x.Id in); 

                string sql = "exec report.summary_sale_and_collection_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "',"+ data.ProjectId+",'" + data.Ownership + "'";

                if (data.Action == 1)
                {
                    summaySaleAndCollectionReport = _ArContext.SummaySaleAndCollectionReport
                                                            .FromSqlRaw(sql).AsEnumerable().ToList();

                    ViewBag.SummaySaleAndCollectionReport = summaySaleAndCollectionReport;
                    if (data.ProjectId == 0) ViewBag.SummaySaleCollectionRemark = _MayuraContext.VSummarySaleCollectionRemark.AsNoTracking().Where(x=>(x.InDate.Value.Month==data.DateFrom.Month && x.InDate.Value.Year== data.DateFrom.Year) || (x.Id == 1)).ToList();
                    else ViewBag.SummaySaleCollectionRemark = _MayuraContext.VSummarySaleCollectionRemark.AsNoTracking().Where(x => x.ProjectId == data.ProjectId && ((x.InDate.Value.Month == data.DateFrom.Month && x.InDate.Value.Year == data.DateFrom.Year) || x.Id == 1)).ToList();

                    return View("Report/SummarySaleAndCollectionReport", data);

                } else if (data.Action == 2) {
                    StringBuilder sb = new StringBuilder();
                    _ArContext.Database.SetCommandTimeout(600);
                    var list = _ArContext.SummaySaleAndCollectionReport.FromSqlRaw(sql)
                        .AsEnumerable()
                        .ToList();
                    return writeToCsv("SummarySaleAndCollectionReport", ViewBag.Title, list, data.DateFrom.ToString("MM/dd/yyyy"));
                } else
                {
                    ViewBag.SummaySaleAndCollectionReport = summaySaleAndCollectionReport;
                    data.DateFrom = DateTime.Today;
                    data.ProjectId = 0;
                    data.Ownership = "";
                }

                return View("Report/SummarySaleAndCollectionReport", data);
        }

        //Summary collection report
        public IActionResult SummaryCollectionReport(SummaryCollectionInput data)
        {
            
            ViewBag.Title = "SUMMARY COLLECTION REPORT";
            string printBy = HttpContext.Request?.Query["printby"] ?? "";
            if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);


            ViewBag.printby = HttpContext.Session.GetString("printby");
                        
            var summayCollectionReport = new List<SummayCollectionReport>();
            var bookingNotContract = new List<BookingNotContract>();
            ViewBag.Projects = _MayuraContext.Projects
                                   .Where(x => x.Status == 1)
                                   .OrderBy(x => x.ProjectCode)
                                   .ToList();
            string sql = "exec report.master_collection_report '" + data.DateClose.ToString("MM/dd/yyyy") + "','" + data.DateCurrent.ToString("MM/dd/yyyy") + "'," + data.ProjectId + ",'" + data.Ownership + "'";

            ViewBag.AdjPrincipal = 0;
            ViewBag.AdjInterest = 0;
            ViewBag.AdjPenalty = 0;
            ViewBag.AdjPS = 0;
                       

            if (data.Action == 1)
            {           

                bookingNotContract = _ArContext.BookingNotContract.FromSqlRaw("exec report.summary_booking_report '" + data.DateCurrent.ToString("MM/dd/yyyy") + "'," + data.ProjectId + ",'" + data.Ownership + "'")
                                                        .AsEnumerable()
                                                        .ToList();
                summayCollectionReport = _ArContext.SummayCollectionReport
                                                        .FromSqlRaw(sql)
                                                        .AsEnumerable()
                                                        .ToList();
                ViewBag.AdjPrincipal = Math.Abs(summayCollectionReport.Sum(x => x.AccAdjPrinciple) ?? 0);
                ViewBag.AdjInterest = summayCollectionReport.Sum(x => x.AccAdjInterest);
                ViewBag.AdjPenalty = summayCollectionReport.Sum(x => x.AccAdjPenalty);
                ViewBag.AdjPS = summayCollectionReport.Sum(x => x.AccAdjPublicService);
                ViewBag.SummaryCollectionReport = summayCollectionReport;
                ViewBag.BookingNotContract = bookingNotContract;
                
                if (data.ProjectId == 0) ViewBag.SummayCollectionReportRemark = _MayuraContext.VSummaryCollectionReportRemark.AsNoTracking().Where(x=>x.InDate >= data.DateClose && x.InDate <= data.DateCurrent).ToList();
                else ViewBag.SummayCollectionReportRemark = _MayuraContext.VSummaryCollectionReportRemark.AsNoTracking().Where(x => x.ProjectId == data.ProjectId && x.InDate>=data.DateClose && x.InDate <= data.DateCurrent).ToList();

                return View("Report/SummaryCollectionReport", data);
            }
            else if (data.Action == 2)
            {
                StringBuilder sb = new StringBuilder();
                _ArContext.Database.SetCommandTimeout(600);
                var list = _ArContext.SummayCollectionReport.FromSqlRaw(sql)
                    .AsEnumerable()
                    .ToList();

                sb.Clear();
                sb.AppendLine("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD. " + ViewBag.Title + " " + data.DateClose.ToString("dd/MM/yyyy") + " => " + data.DateCurrent.ToString("dd/MM/yyyy"));
                sb.AppendLine("Ownership,Project,HouseNumber,StreetNumber,CustomerName,HouseType,HouseSize,ContractDate,NetAmount,AccPrinciple,AccAdjPrinciple,AccPrincipleCurrent,TotalPrincipal,AccPaidOffDiscount,OutstandingPrincipal,%OfCollection,AccInterest,AccAdjInterest,AccInterestCurrent,TotalInterest,AccPenalty,AccAdjPenalty,AccPenaltyCurrent,TotalPenalty,AccPublicService,AccAdjPublicService,AccPublicServiceCurrent,AccPSDiscount,TotalPublicService");
                foreach (var item in list)
                {
                    sb.AppendLine(item.Ownership + "," + item.Project + "," + item.HouseNumber + "," + item.StreetNumber + ",\"" + item.CustomerName + "\",\"" + item.HouseType + "\"," + item.HouseSize + "," +
                              item.ContractDate?.ToString("dd/MM/yyyy") + "," + item.NetAmount + "," + item.AccPrinciple + "," + item.AccAdjPrinciple + "," + item.AccPrincipleCurrent + "," + item.TotalPrincipal + "," + item.AccPaidOffDiscount + "," + item.OutstandingPrincipal + "," + item.OutstandingPrincipalPercent + "," + item.AccInterest + "," + item.AccAdjInterest + "," + item.AccInterestCurrent + "," + item.TotalInterest + "," + item.AccPenalty + "," + item.AccAdjPenalty + "," + item.AccPenaltyCurrent + "," + item.TotalPenalty + "," + item.AccPublicService + "," + item.AccAdjPublicService + "," + item.AccPublicServiceCurrent + "," + item.AccPSDiscount + ","  + item.TotalPublicService);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "SummaryCollectionReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
                //var _bookingNotContract = _ArContext.BookingNotContract.FromSqlRaw("exec report.summary_booking_report '" + data.DateCurrent.ToString("MM/dd/yyyy") + "'," + data.ProjectId + ",'" + data.Ownership + "'")
                //    .AsEnumerable()
                //   .ToList();

               // return writeToCsv("SummaryCollectionReport", ViewBag.Title, list, data.DateClose.ToString("MM/dd/yyyy"), data.DateCurrent.ToString("MM/dd/yyyy"));
            }
            else
            {
                ViewBag.SummaryCollectionReport = summayCollectionReport;
                ViewBag.BookingNotContract = bookingNotContract;
                data.DateClose = FirstDayOfMonth(DateTime.Today);
                data.DateCurrent = DateTime.Today;
                data.ProjectId = 0;
                data.Ownership = "";
            }


            return View("Report/SummaryCollectionReport", data);
        }


        //Daily Message Report
        public IActionResult DailyMessageReport(DailyMessageInput data)
        {
            ViewBag.Title = "DAILY MESSAGE REPORT";
            string printBy = HttpContext.Request?.Query["printby"] ?? "";
            if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);


            ViewBag.printby = HttpContext.Session.GetString("printby");
            var dailyMessageReport = new List<DailyMessageReport>();

            ViewBag.Projects = _MayuraContext.Projects
                                  .Where(x => x.Status == 1)
                                  .OrderBy(x => x.ProjectCode)
                                  .ToList();

            if (data.Action == 1)
            {

                string sql = "exec report.daily_message_report '" + data.Date.ToString("MM/dd/yyyy") + "'," + data.ProjectId ;
                dailyMessageReport = _ArContext.DailyMessageReport

                                                        .FromSqlRaw(sql)
                                                        .AsEnumerable()
                                                        .ToList();

                ViewBag.DailyMessageReport = dailyMessageReport;
                return View("Report/DailyMessageReport", data);
            }
            else if (data.Action == 2)
            {
                string sql = "exec report.daily_message_report '" + data.Date.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                dailyMessageReport = _ArContext.DailyMessageReport
                                                        .FromSqlRaw(sql)
                                                        .AsEnumerable()
                                                        .ToList();
                return writeToCsv("DailyMessageReport", ViewBag.Title, dailyMessageReport, data.Date.ToString("MM/dd/yyyy"));
            }
            else
            {

                ViewBag.DailyMessageReport = dailyMessageReport;
                data.Date = DateTime.Today;
                data.ProjectId = 0;
                
            }


            return View("Report/DailyMessageReport", data);
        }


        //Summary collection Terminate report
        public IActionResult SummaryCollectionTerminateReport(SummaryCollectionTerminateInput data)
        {
            ViewBag.Title = "Termination,​ Repurchase&Transfer Contract Report";
            string printBy = HttpContext.Request?.Query["printby"] ?? "";
            if (!String.IsNullOrEmpty(printBy)) HttpContext.Session.SetString("printby", printBy);


            ViewBag.printby = HttpContext.Session.GetString("printby");
            var summuryCollectionTerminateReport = new List<SummuryCollectionTerminateReport>();
            ViewBag.Projects = _MayuraContext.Projects
                                   .Where(x => x.Status == 1)
                                   .OrderBy(x => x.ProjectCode)
                                   .ToList();
            string sql = "exec report.termination_repurchase_transfer_contract_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "'," + data.ProjectId + ",'" + data.Ownership + "'";

            if (data.Action == 1)
            {
                summuryCollectionTerminateReport = _ArContext.SummuryCollectionTerminateReport
                                                        .FromSqlRaw(sql)
                                                        .AsEnumerable()
                                                        .ToList();
                ViewBag.SummuryCollectionTerminateReport = summuryCollectionTerminateReport;

                return View("Report/SummaryCollectionTerminateReport", data);
            }
            else if (data.Action == 2)
            {
                StringBuilder sb = new StringBuilder();
                sb.Clear();
                sb.AppendLine("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                sb.AppendLine(ViewBag.Title);
                sb.AppendLine(data.DateFrom.ToString("dd-MM-yyyy"));
                sb.AppendLine("Ownership,Project,TerminateDate,HouseNo,StreetNo,Customer,HouseType,ContractDate,NetAmount,AccPrinciple,AccPaidOffDiscount,OutstandingPincipal,% of collection,AccInterest,AccPenalty,AccPublicService,TerminationType,Remark,Description,TerminationTypeOrder");
                _ArContext.Database.SetCommandTimeout(600);
                var list = _ArContext.SummuryCollectionTerminateReport.FromSqlRaw(sql)
                    .AsEnumerable()
                    .ToList();

                foreach (var item in list)
                {                    
                    sb.AppendLine(item.Ownership + "," + item.Project + "," + item.TerminateDate?.ToString("dd-MM-yyyy") + "," + item.HouseNo + "," + item.StreetNo + "," + item.Customer + "," + item.HouseType + "," + item.ContractDate?.ToString("dd-MM-yyyy") + "," +
                              item.NetAmount + "," + item.AccPrinciple + "," + item.AccPaidOffDiscount + "," + item.OutstandingPincipal + "," + item.OutstandingPincipalPercent + "," + item.AccInterest + "," + item.AccPenalty + "," +
                              item.AccPublicService + "," + item.TerminationType + "," + item.Remark + "," + item.Description + "," + item.TerminationTypeOrder);
                }
                var result = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
                return File(result, "text/csv", "SummuryCollectionTerminateReport_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");

                //return writeToCsv("SummuryCollectionTerminateReport", ViewBag.Title, list, data.DateFrom.ToString("MM/dd/yyyy"));
            }
            else
            {
                ViewBag.SummuryCollectionTerminateReport = summuryCollectionTerminateReport;
                data.DateFrom = DateTime.Today;
                data.ProjectId = 0;
                data.Ownership = "";
            }


            return View("Report/SummaryCollectionTerminateReport", data);
        }

        FileContentResult writeToCsv<T>(string filename, string title, List<T> list, string dateFrom, string dateTo="")
        {
            var stream = new MemoryStream();
            using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
            {
                var csv = new CsvWriter(writeFile, new CsvConfiguration(new CultureInfo("en-US")));
                var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                csv.WriteField(title);
                if (String.IsNullOrEmpty(dateFrom))
                {
                    csv.WriteField(dateFrom);
                } else
                {
                    csv.WriteField(dateFrom+"=>" + dateTo);
                }

                csv.NextRecord();
                csv.WriteRecords(list);
            }
            return File(stream.ToArray(), "text/csv", filename+ "_" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
        }

        public async Task<IActionResult> HouseReachInterestReport(HouseReachInterestReport data)
        {

            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec sp_get_house_reach_interest_in_next_nmonth " + data.nmonth;

                _ArContext.Database.SetCommandTimeout(1200);
                ViewBag.HouseReachInterestReport = _ArContext.VprintAccumulateReport.FromSqlRaw(sql).AsEnumerable().ToList();
                return View("Report/HouseReachInterestReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="House Reach Interest Report" , Date= data.nmonth.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();

                _ArContext.Database.SetCommandTimeout(1200);
                string sql = "exec sp_get_house_reach_interest_in_next_nmonth " + data.nmonth;
                var list = _ArContext.VprintAccumulateReport.FromSqlRaw(sql).AsEnumerable().ToList();
               

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                    csv.WriteField("House Reach non-Interest Report");
                    //csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "HouseReachInterestReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");

            }

            else if (data.Action == 3)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report ="House Reach Interest Report" , Date= data.nmonth.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();

                _ArContext.Database.SetCommandTimeout(1200);
                string sql = "exec sp_get_house_interest_paid_in_next_nmonth " ;
                var list = _ArContext.VprintAccumulateReport.FromSqlRaw(sql).AsEnumerable().ToList();


                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.");
                    csv.WriteField("House Interest Report");
                    //csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy"));
                    csv.NextRecord();
                    csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "HouseReachInterestReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");

            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                //data.DateFrom = DateTime.Today;
                //data.ProjectId = 0;
                return View("Report/HouseReachInterestReport", data);
            }
        }
        public async Task<IActionResult> PublicServiceLateReport(InputBookingDailyRevenue data)
        {


            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.get_public_service_late {0},{1}";
                ViewBag.PublicServiceLateReport = _ArContext.VPublicServiceLateReport.FromSqlRaw(sql, data.DateFrom.ToString("yyyy-MM-dd"), data.ProjectId).AsEnumerable().ToList();
                return View("Report/PublicServiceLateReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" Public Service late Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.get_public_service_late '" + data.DateFrom.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VPublicServiceLateReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Public Service Late Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PublicServiceLateReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/PublicServiceLateReport", data);
            }
        }

        public async Task<IActionResult> HouseHandOverReport(InputBookingDailyRevenue data)
        {


            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.get_house_handover_report {0},{1},{2}";
                ViewBag.HouseHandOverReport = _ArContext.VHouseHandOverReport.FromSqlRaw(sql, data.DateFrom.ToString("yyyy-MM-dd"), data.DateTo.ToString("yyyy-MM-dd"), data.ProjectId).AsEnumerable().ToList();
                return View("Report/HouseHandOverReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" House Hand Over Report" , Date= data.DateFrom.ToString("yyyy-MM-dd")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.get_house_handover_report '" + data.DateFrom.ToString("MM/dd/yyyy") + "','" + data.DateTo.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VHouseHandOverReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Public Service Late Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "HouseHandOverReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/HouseHandOverReport", data);
            }
        }

        public async Task<IActionResult> PenaltyLateReport(InputBookingDailyRevenue data)
        {


            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.get_penalty_late {0},{1}";
                ViewBag.PenaltyLateReport = _ArContext.VPenaltyLateReport.FromSqlRaw(sql, data.DateFrom.ToString("yyyy-MM-dd"), data.ProjectId).AsEnumerable().ToList();
                return View("Report/PenaltyLateReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" Penalty late Report" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.get_penalty_late '" + data.DateFrom.ToString("MM/dd/yyyy") + "'," + data.ProjectId;
                var list = _ArContext.VPenaltyLateReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Penalty Late Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PenaltyLateReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/PenaltyLateReport", data);
            }
        }

        public async Task<IActionResult> NetContractTerminate(NetContractTerminate data)
        {


            if (HttpContext.Request.Query["printby"].Count != 0)
            {

                HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            }
            else
            {
                if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            }

            ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.contracts_terminations {0},{1},{2}";
                ViewBag.NetContractTerminate = _ArContext.NetContractTerminate.FromSqlRaw(sql, data.DateFrom.ToString("MM/dd/yyyy"), data.DateTo.ToString("MM/dd/yyyy"), data.ProjectId).AsEnumerable().ToList();
                return View("Report/NetContractTerminate", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
{
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" Net Contract Terminate" , Date= data.DateFrom.ToString("MM/dd/yyyy")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.contracts_terminations {0},{1},{2}";
                var list = _ArContext.NetContractTerminate.FromSqlRaw(sql, data.DateFrom.ToString("MM/dd/yyyy"), data.DateTo.ToString("MM/dd/yyyy"), data.ProjectId).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Net Contract Terminate"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "NetContractTerminate" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                //ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                data.ProjectId = 0;
                return View("Report/NetContractTerminate", data);
            }
        }


        public async Task<IActionResult> PubliceServiceIssueLateLetter(int id)
        {

            var data = await _MayuraContext.VPublicServiceIssueLateLetter
                     .FromSqlRaw("exec dbo.get_public_service_print_issue_late_letter {0}",id).AsNoTracking()
                     .ToListAsync();
            if (data != null)
            {
                ViewBag.data = data;
                return View("Contract/PublicServiceIssueLateLatter");

            }
            return BadRequest("Oop!, Invalid IssueLateLetter Id");

        }


        public async Task<IActionResult> PubliceServiceIssueLateLetterReport(int id)
        {

            var list = await _MayuraContext.VPublicServiceIssueLateLetterReport
                    .Where(x => x.IssueLateLetterId == id)
                    .OrderBy(x=>x.HouseCategory)
                    .ThenBy(x=>x.HousePartUnit)
                    .ThenBy(x=>x.HousePartNumber)
                    .ToListAsync();
            if (list != null)
            {

               ViewBag.data = list;
               ViewBag.projectShort = "";

                var data = await _MayuraContext.IssueLateLetter.SingleOrDefaultAsync(x => x.Id == id);
                if (data != null)
                {
                    short project_id = data.ProjectId??0;
                    if (project_id != 0)
                    {
                        var project = await _MayuraContext.Projects.SingleOrDefaultAsync(x => x.Id == project_id && x.Status == 1);
                        if (project != null) ViewBag.projectShort = project.ProjectShort;
                    }

                } 
                return View("Report/PubliceServiceIssueLateLetterReport",data);

            }
            return BadRequest("Oop!, Invalid IssueLateLetter Id");

        }

        public async Task<IActionResult> PublicServiceDailyReport(InputBookingDailyRevenue data)
        {


            //if (HttpContext.Request.Query["printby"].Count != 0)
            //{

            //    HttpContext.Session.SetString("test", HttpContext.Request.Query["printby"]);
            //}
            //else
            //{
            //    if (HttpContext.Session.GetString("test") == "") { HttpContext.Session.SetString("test", "Unknown(Click report from the system again)"); }
            //}

            //ViewBag.printby = HttpContext.Session.GetString("test");

            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.get_public_service_daily_report {0},{1},{2}";
                ViewBag.PublicServicePrePaidReport = _MayuraContext.VPublicServicePrepaid.FromSqlRaw(sql, data.DateFrom.ToString("yyyy-MM-dd"), data.DateTo.ToString("yyyy-MM-dd"),data.ProjectId).AsEnumerable().ToList();
                return View("Report/PublicServiceDailyReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" Public Service Late Report" , Date= data.DateFrom.ToString("yyyy-MM-dd")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.get_public_service_daily_report '" + data.DateFrom.ToString("yyyy-MM-dd") + "','" + data.DateTo.ToString("yyyy-MM-dd") + "'," + data.ProjectId;
                var list = _MayuraContext.VPublicServicePrepaid.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Public Service Late Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PublicServiceDailyReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;               
                return View("Report/PublicServiceDailyReport", data);
            }
        }


        public async Task<IActionResult> PubliceServiceIssueLateMonthlyReport(InputBookingDailyRevenue data)
        {
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.get_public_service_issue_late_monthly_report {0},{1},{2}";
                ViewBag.PublicServiceLateMonthlyReport = _MayuraContext.VPublicServiceIssueLateMonthlyReport.FromSqlRaw(sql, data.DateFrom.ToString("yyyy-MM-dd"), data.DateTo.ToString("yyyy-MM-dd"), data.ProjectId).AsEnumerable().ToList();
                return View("Report/PubliceServiceIssueLateMonthlyReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" Public Service Late Monthly Report" , Date= data.DateFrom.ToString("yyyy-MM-dd")+"=>"+  data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.get_public_service_issue_late_monthly_report '" + data.DateFrom.ToString("yyyy-MM-dd") + "','" + data.DateTo.ToString("yyyy-MM-dd") + "'," + data.ProjectId;
                var list = _MayuraContext.VPublicServiceIssueLateMonthlyReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Public Service Late Monthly Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PubliceServiceIssueLateMonthlyReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                return View("Report/PubliceServiceIssueLateMonthlyReport", data);
            }
        }

        public async Task<IActionResult> PublicServiceLateSummaryReport(InputBookingDailyRevenue data)
        {
            if (data.Action == 1)
            {
                ViewBag.ProjectRevenueDailyReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();
                string sql = "exec report.get_public_service_late_summary_report {0},{1}";
                ViewBag.PublicServiceLateSummaryReport = _MayuraContext.VSummaryPublicServiceLateReport.FromSqlRaw(sql, data.DateTo.ToString("yyyy-MM-dd"), data.ProjectId).AsEnumerable().ToList();
                return View("Report/PubliceServiceLateSummaryReport", data);
            }
            else if (data.Action == 2)
            {
                var records = new List<Foo>
                {
                    new Foo { បុរីវិមានភ្នំពេញ="LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD.", Report =" Summary Public Service Late Report" , Date= data.DateTo.ToString("MM/dd/yyyy")}
                };
                StringBuilder sb = new StringBuilder();
                string sql = "exec report.get_public_service_late_summary_report '" + data.DateTo.ToString("yyyy-MM-dd")  + "'," + data.ProjectId;
                var list = _MayuraContext.VSummaryPublicServiceLateReport.FromSqlRaw(sql).AsEnumerable().ToList();

                var stream = new MemoryStream();
                using (var writeFile = new StreamWriter(stream, encoding: new UTF8Encoding(true)))
                {
                    var csv = new CsvWriter(writeFile, new CsvConfiguration(new System.Globalization.CultureInfo("en-US")));
                    var options = new TypeConverterOptions { Formats = new[] { " dd-MM-yyyy" } };
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime>(options);
                    csv.Context.TypeConverterOptionsCache.AddOptions<DateTime?>(options);
                    csv.WriteField("LY HOUR DEVELOPMENT VIMEANPHNOMPENH CO., LTD."); csv.WriteField(" Public Service Late Monthly Report"); csv.WriteField(data.DateFrom.ToString("MM/dd/yyyy") + "=>" + data.DateTo.ToString("MM/dd/yyyy")); csv.NextRecord(); csv.WriteRecords(list);
                }
                return File(stream.ToArray(), "text/csv", "PubliceServiceLateSummaryReport" + DateTime.Now.ToString("ddMMyyyy_HH:mm") + ".csv");
            }
            else
            {
                ViewBag.BookingDelayReport = null;
                ViewBag.Projects = await _MayuraContext.Projects.Where(x => x.Status == 1).ToListAsync();
                ViewBag.Users = await _MayuraContext.Users.Where(x => x.Department == 3 && x.Status == 1).OrderBy(x => x.FullName).ToListAsync();

                data.DateFrom = DateTime.Today;
                data.DateTo = DateTime.Today;
                return View("Report/PubliceServiceLateSummaryReport", data);
            }
        }

        public async Task<IActionResult> PresentIssueLetter(int id)
        {

            var data = await _MayuraContext.VPresentIssueLetter
                    .Where(x => x.Id == id)
                    .ToListAsync();
            if (data != null)
            {
                ViewBag.data = data;
                return View("Contract/PresentIssueLetter");

            }
            return BadRequest("Oop!, Invalid IssueLateLetter Id");

        }



    }
}
