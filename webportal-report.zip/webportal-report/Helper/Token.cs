﻿using System;
using System.Text;

namespace WebPortal.Helper
{
    public static class Token
    {
        public static bool isValidToken(string token, string userAgent)
        {
            try
            {
                byte[] data = Convert.FromBase64String(token);
                string decodedString = Encoding.UTF8.GetString(data);
                string[] strArr = decodedString.Split("|");


                return strArr[1] == userAgent;
            } catch
            {
                return false;
            }
        }

        public static bool isDraffToken(string token, string userAgent)
        {
            byte[] data = Convert.FromBase64String(token);
            string decodedString = Encoding.UTF8.GetString(data);
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("draff|" + userAgent);
            var bs = System.Convert.ToBase64String(plainTextBytes);
            return bs == token;
        }
    }
}
