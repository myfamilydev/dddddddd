﻿namespace WebPortal.Helper
{
    public static class URL
    {
        public static string GetBaseURL()
        {
            var url = "http://192.168.1.88:8001/";
            return url;
        }
    }
}
