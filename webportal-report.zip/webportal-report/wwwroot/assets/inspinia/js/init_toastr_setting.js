//toastr notification setting
toastr.options = {
    "closeButton": true,
    "debug": false,
    "progressBar": true,
    "preventDuplicates": true,
    "positionClass": "toast-bottom-left",
    "onclick": null,
    "showDuration": "500",
    "hideDuration": "1000",
    "timeOut": "15000",
    "extendedTimeOut": "15000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "slideDown",
    "hideMethod": "slideUp"
};